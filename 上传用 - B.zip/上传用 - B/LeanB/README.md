# LeanB

Lean formalization of Paper B (v3.2.1 and the F2 capacity results). The main import is PaperB. The 17 PaperA modules it uses are supplied as sources in this package.

## Rebuild and audit

From the extracted project directory, use Lean via Elan. The toolchain and all 14 external dependency revisions are pinned by the included files. On the first build, Lake needs access to the pinned Git repositories.

```text
lake build
lake env lean Audit.lean
```

For a faster first build, you can run `lake exe cache get` before `lake build` to fetch available compiled dependencies.

A clean build and audit of these proof sources and lockfile passed with Lean 4.36.0. The audit checked 327 declarations and found only Lean's standard foundational axioms.
