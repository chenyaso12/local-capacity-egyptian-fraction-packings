import PaperB
import Lean

open Lean Elab Command

/-- Print the public type and reject any transitive axiom outside Lean's standard foundation. -/
elab "#audit " decl:ident : command => do
  elabCommand (← `(command| #check $decl))
  elabCommand (← `(command| #print axioms $decl))
  let name ← liftCoreM <| realizeGlobalConstNoOverloadWithInfo decl
  let allowed := #[``propext, ``Classical.choice, ``Quot.sound]
  let unexpected := (← collectAxioms name).filter (fun dependency => !allowed.contains dependency)
  unless unexpected.isEmpty do
    throwErrorAt decl "Unapproved axioms in {name}: {unexpected.toList}"

#audit LeanAB.configurationEquivPacking
#audit LeanAB.fiber_card_eq_ordered_packings
#audit LeanAB.interval_fiber_card_eq_ordered_packings
#audit LeanAB.card_configuration_empty
#audit LeanAB.support_empty
#audit LeanAB.interval_six_two_unit_fiber

#audit LeanAB.PaperB.deletionCost_spec
#audit LeanAB.PaperB.local_block_optimum
#audit LeanAB.PaperB.capacity_isGreatest
#audit LeanAB.PaperB.integral_localFeasible
#audit LeanAB.PaperB.h_isGreatest
#audit LeanAB.PaperB.k_isGreatest
#audit LeanAB.PaperB.local_capacity_upper
#audit LeanAB.PaperB.capacity_mono
#audit LeanAB.PaperB.capacity_succ_ge
#audit LeanAB.PaperB.primePart_eq_empty_of_lcm_mul_mass_lt
#audit LeanAB.PaperB.capacity_four
#audit LeanAB.PaperB.capacity_six

#audit LeanAB.strongPsiError_pntPlus
#audit LeanAB.thetaLogSquaredError_pntPlus

#audit LeanAB.PaperB.Allocation.exists_stopping_prefix
#audit LeanAB.PaperB.Allocation.group_tail_le
#audit LeanAB.PaperB.Allocation.weighted_tail_le
#audit LeanAB.PaperB.Allocation.greedy_reciprocal_allocation
#audit LeanAB.PaperB.Allocation.length_bound_with_total_targets

#audit LeanAB.PaperB.eventually_obstructionBlockBounds
#audit LeanAB.PaperB.eventually_primePart_empty_above_obstructionCutoff
#audit LeanAB.PaperB.excludedDenominators_mass
#audit LeanAB.PaperB.eventually_packing_necessary
#audit LeanAB.PaperB.eventually_windowPrimeMass_error_loglog

#audit LeanAB.PaperB.Closure.shared_smooth_pool
#audit LeanAB.PaperB.Closure.exists_prime_cancellation
#audit LeanAB.PaperB.Closure.exists_medium_repairs
#audit LeanAB.PaperB.Closure.finite_three_stage_repair
#audit LeanAB.PaperB.Closure.eventually_powersmooth_dilation
#audit LeanAB.PaperB.Closure.exists_scaled_block_cancellation
#audit LeanAB.PaperB.Closure.coversResidues_union_of_large_images
#audit LeanAB.PaperB.Closure.coversResidues_of_fourier_bound
#audit LeanAB.PaperB.Closure.norm_one_add_stdAddChar_le
#audit LeanAB.PaperB.Closure.small_phase_card_le
#audit LeanAB.PaperB.Closure.eventually_pointwise_reciprocal_cover

#audit LeanAB.PaperB.Closure.residueFourier_parseval
#audit LeanAB.PaperB.Closure.integerSet_nonzero_energy_ge
#audit LeanAB.PaperB.Closure.card_exceptions_le_of_energy
#audit LeanAB.PaperB.Closure.exists_crt_residue_representatives

#audit LeanAB.PaperB.FixedTargets.matchingNumber_spec
#audit LeanAB.PaperB.FixedTargets.matchingNumber_boundary
#audit LeanAB.PaperB.FixedTargets.k_eq_one_add_fixedPackingNumber_one
#audit LeanAB.PaperB.FixedTargets.represented_initial_segment_if_close
#audit LeanAB.PaperB.FixedTargets.eventually_fixedPacking_upper
#audit LeanAB.PaperB.FixedTargets.eventually_unit_and_integer_upper
#audit LeanAB.PaperB.FixedTargets.eventually_fixed_matching_floor_of_sufficiency
#audit LeanAB.PaperB.FixedTargets.eventually_boundedPacking_lower_with_length_of_sufficiency
#audit LeanAB.PaperB.FixedTargets.eventually_unit_and_integer_initial_segment_of_sufficiency
#audit LeanAB.PaperB.FixedTargets.fixedHeight_spec
#audit LeanAB.PaperB.FixedTargets.integerHeight_spec
#audit LeanAB.PaperB.FixedTargets.eventually_fixedHeight_adjacent_of_sufficiency
#audit LeanAB.PaperB.FixedTargets.targetStock_log_error
#audit LeanAB.PaperB.FixedTargets.eventually_fixedHeight_log_of_sufficiency

#audit LeanAB.PaperB.eventually_card_smoothHeights_ge
#audit LeanAB.PaperB.eventually_capacity_window_growth
#audit LeanAB.PaperB.deletionCost_div_le_of_scaled_cover
#audit LeanAB.PaperB.eventually_capacity_harmonic_error
#audit LeanAB.PaperB.capacityNearHarmonic
#audit LeanAB.PaperB.capacity_integer_values_except_band_of_attainment

#audit LeanAB.PaperB.eventually_prime_power_window_mass
#audit LeanAB.PaperB.eventually_short_prime_window_count
#audit LeanAB.PaperB.powersmoothInterval_card_ge_of_prime_pools
#audit LeanAB.PaperB.eventually_powersmoothInterval_card_ge
#audit LeanAB.PaperB.eventually_powersmooth_half_card_ge
#audit LeanAB.PaperB.eventually_powersmooth_carriers

#audit LeanAB.PaperB.SmoothSeparation.multiple_outside_interval
#audit LeanAB.PaperB.SmoothSeparation.exists_witness_of_lcm
#audit LeanAB.PaperB.SmoothSeparation.normalized_separation
#audit LeanAB.PaperB.SmoothSeparation.exists_separated_denominators
#audit LeanAB.PaperB.SmoothSeparation.card_divisors_at_most_three
#audit LeanAB.PaperB.SmoothSeparation.carrier_multiplicity
#audit LeanAB.PaperB.SmoothSeparation.exists_carrier_multiple
#audit LeanAB.PaperB.SmoothSeparation.lcm_carrier_denominators
#audit LeanAB.PaperB.SmoothSeparation.short_interval_separation
#audit LeanAB.PaperB.SmoothSeparation.eventually_carrier_prime_pairs
#audit LeanAB.PaperB.SmoothSeparation.eventually_smooth_separation_of_density
#audit LeanAB.PaperB.SmoothSeparation.eventually_smooth_separation

#audit LeanAB.PaperB.Closure.exists_smooth_closure_of_separation
#audit LeanAB.PaperB.Closure.mass_le_one_of_short_interval
#audit LeanAB.PaperB.Closure.exists_intermediate_smooth_mass
#audit LeanAB.PaperB.Closure.eventually_power_separation_controls_fourier
#audit LeanAB.PaperB.Closure.uniformSmoothClosure_of_pools_and_separation
#audit LeanAB.PaperB.Closure.exists_wide_smooth_closure_pool
#audit LeanAB.PaperB.Closure.exists_uniformSmoothClosure_of_density_and_separation
#audit LeanAB.PaperB.Closure.exists_uniformSmoothClosure
#audit LeanAB.PaperB.Closure.finite_three_stage_repair_of_distinct_markers
#audit LeanAB.PaperB.Closure.exists_equal_disjoint_pools
#audit LeanAB.PaperB.Closure.exists_smooth_reserve
#audit LeanAB.PaperB.Closure.coversResidues_of_halfPrimes_subset
#audit LeanAB.PaperB.Closure.exists_medium_repair_pools
#audit LeanAB.PaperB.Closure.eventually_medium_cofactor_covers
#audit LeanAB.PaperB.Closure.eventually_medium_repair_pools
#audit LeanAB.PaperB.Closure.eventually_marker_primes
#audit LeanAB.PaperB.Closure.mass_biUnion_le
#audit LeanAB.PaperB.Closure.mass_excluded_multiples_le
#audit LeanAB.PaperB.Closure.eventually_sum_inv_prime_sq_le
#audit LeanAB.PaperB.Closure.eventually_mass_highPrimePowers_le
#audit LeanAB.PaperB.Closure.mem_highPrimePowers_of_dvd
#audit LeanAB.PaperB.Closure.highPrimePowers_pos
#audit LeanAB.PaperB.Closure.eventually_mass_high_power_multiples
#audit LeanAB.PaperB.Closure.mass_excluded_multiples_le_of_lower
#audit LeanAB.PaperB.Closure.eventually_mass_marker_multiples
#audit LeanAB.PaperB.Closure.eventually_smoothReserveAt_of_sublinear
#audit LeanAB.PaperB.Closure.eventually_baselineSmoothReserve
#audit LeanAB.PaperB.Closure.eventually_nearCapacitySmoothReserve
#audit LeanAB.PaperB.Closure.mass_repair_exclusions_le
#audit LeanAB.PaperB.Closure.eventually_baseline_reserve_cost
#audit LeanAB.PaperB.Closure.eventually_nearCapacity_reserve_cost
#audit LeanAB.PaperB.Closure.eventually_baseline_repair_budget
#audit LeanAB.PaperB.Closure.eventually_nearCapacity_repair_budget
#audit LeanAB.PaperB.Closure.eventually_nearCapacity_repair_reserves

#audit LeanAB.PaperB.NearCapacity.mem_mediumPrimes
#audit LeanAB.PaperB.NearCapacity.mul_mem_unreserved_of_smooth
#audit LeanAB.PaperB.NearCapacity.scaled_grid_mem_unreserved_cutoff
#audit LeanAB.PaperB.NearCapacity.mul_mem_available_of_smooth
#audit LeanAB.PaperB.NearCapacity.available_dvd_common
#audit LeanAB.PaperB.NearCapacity.exists_undamaged_optimum
#audit LeanAB.PaperB.NearCapacity.exists_damaged_correction
#audit LeanAB.PaperB.NearCapacity.card_proxyPrimes_le
#audit LeanAB.PaperB.NearCapacity.exists_retainedBlocks_of_corrections
#audit LeanAB.PaperB.NearCapacity.eventually_proxyCharge_le
#audit LeanAB.PaperB.NearCapacity.eventually_proxyWidth_le
#audit LeanAB.PaperB.NearCapacity.eventually_retainedBlocks
#audit LeanAB.PaperB.NearCapacity.eventually_ordered_unit_groups
#audit LeanAB.PaperB.NearCapacity.attains_local_capacity
#audit LeanAB.PaperB.NearCapacity.capacity_integer_values_except
#audit LeanAB.PaperB.NearCapacity.capacity_inverse_heights

#audit LeanAB.PaperB.Closure.nthRoot_eq_floor_rpow
#audit LeanAB.PaperB.Closure.eventually_log_pow_le_rpow
#audit LeanAB.PaperB.Closure.nearCapacityCutoffFactor_pos
#audit LeanAB.PaperB.Closure.eventually_nearCapacity_marker_geometry
#audit LeanAB.PaperB.Closure.eventually_floor_twentieth_le_nearCapacityCutoff
#audit LeanAB.PaperB.Closure.eventually_nearCapacity_residual_parameters
#audit LeanAB.PaperB.Closure.eventually_nearCapacity_repair_costs
#audit LeanAB.PaperB.Closure.eventually_nearCapacity_close_bases

#audit LeanAB.PaperB.Allocation.exists_sorted_blockList
#audit LeanAB.PaperB.Allocation.nearCapacity_unit_allocation
#audit LeanAB.PaperB.Allocation.nearCapacity_prefix_estimates
#audit LeanAB.PaperB.Allocation.eventually_nearCapacity_unit_allocation

#audit LeanAB.PaperB.eventually_nearCapacityGroupCount
#audit LeanAB.PaperB.unitPacking_insert_one_of_ordered
#audit LeanAB.PaperB.unitPacking_insert_one_length_le
#audit LeanAB.PaperB.capacityAttainment_of_nearCapacity_ordered
#audit LeanAB.PaperB.eventually_nearCapacity_unitPacking_of_ordered
#audit LeanAB.PaperB.exists_height_of_capacity
#audit LeanAB.PaperB.localCapacityHeight_spec
#audit LeanAB.PaperB.tendsto_localCapacityHeight
#audit LeanAB.PaperB.exists_unit_height_of_attainment
#audit LeanAB.PaperB.exists_integer_height_of_attainment
#audit LeanAB.PaperB.localCapacityHeight_le_integerHeight
#audit LeanAB.PaperB.eventually_nearCapacity_height_window
#audit LeanAB.PaperB.eventually_nearCapacity_inverse_heights
#audit LeanAB.PaperB.eventually_nearCapacity_inverse_log_gap

#audit LeanAB.PaperB.FixedTargets.exists_padding_count
#audit LeanAB.PaperB.FixedTargets.padTargets_total
#audit LeanAB.PaperB.FixedTargets.padTargets_admissible
#audit LeanAB.PaperB.FixedTargets.eventually_padding_room
#audit LeanAB.PaperB.FixedTargets.packingLength_antitone_total
#audit LeanAB.PaperB.FixedTargets.packingSufficiency_of_highTotal
#audit LeanAB.PaperB.FixedTargets.packingSufficiency_iff_highTotal
#audit LeanAB.PaperB.FixedTargets.eventually_target_total_and_count_bound

#audit LeanAB.PaperB.ShortPointwise.covers_of_prime_heights
#audit LeanAB.PaperB.ShortPointwise.eventually_logloglog_pow_le_loglog
#audit LeanAB.PaperB.ShortPointwise.eventually_coverWidth_lt
#audit LeanAB.PaperB.ShortPointwise.eventually_shortPointwiseCover_of_LiuSawhney
#audit LeanAB.PaperB.ShortPointwise.coverWidth_mono
#audit LeanAB.PaperB.ShortPointwise.eventually_log_coverWidth_bounds

#audit LeanAB.PaperB.mem_baselineCutoffPart
#audit LeanAB.PaperB.eventually_baselineCoverBound_logs
#audit LeanAB.PaperB.tendsto_baselineCoverBound_div_sqrt
#audit LeanAB.PaperB.eventually_baselineCutoff_gt_sqrt
#audit LeanAB.PaperB.eventually_baselineCutoffPart_mass
#audit LeanAB.PaperB.ShortPointwise.eventually_baseline_common_cover_of_LiuSawhney

#audit LeanAB.PaperB.Baseline.mem_correctionPrimes
#audit LeanAB.PaperB.Baseline.mem_stock
#audit LeanAB.PaperB.Baseline.stock_eq_sdiff
#audit LeanAB.PaperB.Baseline.avoids_reservations_of_subset_stock
#audit LeanAB.PaperB.Baseline.mass_stock_ge
#audit LeanAB.PaperB.Baseline.mediumDenominator_eq_permitted
#audit LeanAB.PaperB.Baseline.exists_corrected_stock_block
#audit LeanAB.PaperB.Baseline.exists_retainedBlocks_of_corrections
#audit LeanAB.PaperB.Baseline.eventually_retainedBlocks
#audit LeanAB.PaperB.Baseline.eventually_correctionCharge_le
#audit LeanAB.PaperB.Baseline.prefix_sdiff_stock_subset_exclusions
#audit LeanAB.PaperB.Baseline.eventually_retainedBlocks_with_mass
#audit LeanAB.PaperB.Baseline.natSqrt_lt_of_sqrt_lt
#audit LeanAB.PaperB.Baseline.eventually_repair_reserves
#audit LeanAB.PaperB.Baseline.allocate_of_prefix_bounds
#audit LeanAB.PaperB.Baseline.eventually_residual_parameters
#audit LeanAB.PaperB.Baseline.eventually_residual_le
#audit LeanAB.PaperB.Baseline.eventually_allocate
#audit LeanAB.PaperB.Baseline.eventually_marker_geometry
#audit LeanAB.PaperB.Baseline.eventually_repair_costs
#audit LeanAB.PaperB.Baseline.eventually_close_bases
#audit LeanAB.PaperB.Baseline.highTotalPackingSufficiency_of_LiuSawhney
#audit LeanAB.PaperB.Baseline.packingSufficiency_of_LiuSawhney
#audit LeanAB.PaperB.Baseline.simultaneous_rational_packing_of_LiuSawhney

#audit LeanAB.PaperB.eventually_scaled_cover_charge
#audit LeanAB.PaperB.eventually_capacity_deficit_upper_of_LiuSawhney
#audit LeanAB.PaperB.eventually_unit_and_integer_coarse_bounds
#audit LeanAB.PaperB.eventually_unit_and_integer_bounds_of_LiuSawhney
#audit LeanAB.PaperB.eventually_harmonic_floor_and_initial_segment
#audit LeanAB.PaperB.exists_unit_inverse_height
#audit LeanAB.PaperB.exists_integer_inverse_height
#audit LeanAB.PaperB.integerInverseHeight_le_unitInverseHeight
#audit LeanAB.PaperB.tendsto_integerInverseHeight
#audit LeanAB.PaperB.tendsto_unitInverseHeight
#audit LeanAB.PaperB.eventually_inverse_heights_coarse
#audit LeanAB.PaperB.eventually_inverse_heights_sharp_lower
#audit LeanAB.PaperB.eventually_inverse_heights_of_LiuSawhney
#audit LeanAB.PaperB.tendsto_normalized_inverse_heights_of_LiuSawhney

#audit LeanAB.PaperB.FixedTargets.mass_le_harmonic_card
#audit LeanAB.PaperB.FixedTargets.boundedPackingNumber_mass_bounds
#audit LeanAB.PaperB.FixedTargets.eventually_boundedPacking_uniform_upper
#audit LeanAB.PaperB.FixedTargets.boundedPackingNumber_height_mono
#audit LeanAB.PaperB.FixedTargets.eventually_boundedPacking_uniform_of_sufficiency
#audit LeanAB.PaperB.FixedTargets.boundedPackingNumber_length_mono
#audit LeanAB.PaperB.FixedTargets.boundedPackingNumber_le_lengthPackingNumber
#audit LeanAB.PaperB.FixedTargets.lengthPackingNumber_attains
#audit LeanAB.PaperB.FixedTargets.eventually_lengthPackingNumber_of_sufficiency
#audit LeanAB.PaperB.FixedTargets.eventually_boundedPacking_floors_of_sufficiency
#audit LeanAB.PaperB.FixedTargets.eventually_boundedPacking_floors_of_LiuSawhney
#audit LeanAB.PaperB.cofactorResidue_ne_zero_of_injective
#audit LeanAB.PaperB.primePart_eq_empty_of_projection_injective
#audit LeanAB.PaperB.packing_mass_le_sub_window_with_exceptions
#audit LeanAB.PaperB.eventually_nextCapacity_necessary
#audit LeanAB.PaperB.eventually_nextCapacity_deficit_lower
#audit LeanAB.PaperB.Closure.prime_frequency_separated
#audit LeanAB.PaperB.Closure.primeFrequencyValue_mem_Ioo
#audit LeanAB.PaperB.Closure.primeFrequencyPairs_separated
#audit LeanAB.PaperB.Closure.sum_primeFrequencyPairEnergy_eq
#audit LeanAB.PaperB.Closure.card_smallPrimeImageExceptions_le_of_pairEnergy
#audit LeanAB.PaperB.LargeSieve.value_le_interval_average_add_variation
#audit LeanAB.PaperB.LargeSieve.sum_values_le_interval_average_add_variation
#audit LeanAB.PaperB.LargeSieve.sum_values_le_period_integrals_of_separated

#audit LeanAB.PaperB.Closure.primeCofactorPools_disjoint
#audit LeanAB.PaperB.Closure.primeCofactorPool_exists_representatives
#audit LeanAB.PaperB.Closure.primeCofactorPool_dvd
#audit LeanAB.PaperB.Closure.card_integer_image_le_residueSupport
#audit LeanAB.PaperB.Closure.coversResidues_of_large_primeCofactor_images
#audit LeanAB.PaperB.Closure.card_primeCofactorCoverExceptions_le_of_energy

#audit LeanAB.PaperB.eventually_prime_window_log_mass
#audit LeanAB.PaperB.eventually_retained_prime_window_log_product
#audit LeanAB.PaperB.eventually_crt_retained_window_log_products
#audit LeanAB.PaperB.eventually_crt_support_le
#audit LeanAB.PaperB.eventually_dyadic_bad_count_on_subwindow
#audit LeanAB.PaperB.eventually_dyadic_bad_count
#audit LeanAB.PaperB.Closure.pointwiseCoverHeight_monotoneOn
#audit LeanAB.PaperB.Closure.liftedCoverHeight_monotoneOn
#audit LeanAB.PaperB.Closure.eventually_pointwiseCoverHeight_four_mul_le
#audit LeanAB.PaperB.Closure.eventually_liftedPointwiseCoverHeight_four_mul_le
#audit LeanAB.PaperB.Closure.eventually_twiceLiftedPointwiseCoverHeight_le

#audit LeanAB.PaperB.Closure.sum_primeFrequencyPairEnergy_le
#audit LeanAB.PaperB.LargeSieve.trigSum_integral_sq
#audit LeanAB.PaperB.LargeSieve.sum_trigSum_sq_le_of_separated

#audit LeanAB.PaperB.Closure.eventually_reciprocalCoverExceptions_le_of_window_covers
#audit LeanAB.PaperB.Closure.hasAverageReciprocalCover_pointwise
#audit LeanAB.PaperB.Closure.HasAverageReciprocalCover.lift
#audit LeanAB.PaperB.Closure.hasAverageReciprocalCover_twice
#audit LeanAB.PaperB.Closure.eventually_average_reciprocal_cover

#audit LeanAB.PaperB.mem_cutoffPart
#audit LeanAB.PaperB.FixedTargets.eventually_padding_room_of_lt_one
#audit LeanAB.PaperB.FixedTargets.packingAtLoss_of_highTotal
#audit LeanAB.PaperB.FixedTargets.eventually_target_total_and_count_bound_of_mass_le
#audit LeanAB.PaperB.Baseline.stock_eq_sdiff_of_nonneg
#audit LeanAB.PaperB.Baseline.mass_stock_ge_of_nonneg
#audit LeanAB.PaperB.Baseline.eventually_retainedBlocks_at_width
#audit LeanAB.PaperB.Baseline.eventually_correctionCharge_le_at_width
#audit LeanAB.PaperB.Baseline.hasRetainedBlockMass_of_LiuSawhney
#audit LeanAB.PaperB.Baseline.highTotalPackingAtLoss_of_retainedBlockMass
#audit LeanAB.PaperB.Baseline.simultaneous_rational_packing_of_sufficiency
#audit LeanAB.PaperB.Closure.mem_badCoverPrimes
#audit LeanAB.PaperB.Closure.eventually_badCoverPart_mass_le_rpow
#audit LeanAB.PaperB.Closure.eventually_badCoverPart_mass_le
#audit LeanAB.PaperB.Closure.eventually_nextCoverBound_logs
#audit LeanAB.PaperB.Closure.eventually_nextCutoff_geometry
#audit LeanAB.PaperB.Closure.eventually_nextCutoffPart_mass
#audit LeanAB.PaperB.eventually_nextSufficientLoss_le_sufficientLoss
#audit LeanAB.PaperB.eventually_nextSufficientLoss_monotone
#audit LeanAB.PaperB.eventually_nextSufficientLoss_nonneg_lt_one
#audit LeanAB.PaperB.Baseline.hasRetainedBlockMass_of_averageCover
#audit LeanAB.PaperB.eventually_nextCapacity_deficit_upper
#audit LeanAB.PaperB.index_le_h_at_integer
#audit LeanAB.PaperB.index_le_h_at_unit
#audit LeanAB.PaperB.log_predecessor_gap_le_one
#audit LeanAB.PaperB.harmonic_log_center
#audit LeanAB.PaperB.tendsto_unitInversePredecessor
#audit LeanAB.PaperB.unitInverse_adjacent_upper
#audit LeanAB.PaperB.log_inverse_within_three
#audit LeanAB.PaperB.reciprocal_height_le_inverse_index
#audit LeanAB.PaperB.eventually_next_inverse_heights_lower
#audit LeanAB.PaperB.eventually_next_inverse_heights_of_count
#audit LeanAB.PaperB.eventually_unit_lower_of_nextPacking
#audit LeanAB.PaperB.eventually_next_inverse_heights_of_nextPacking
#audit LeanAB.PaperB.nextPackingSufficiency
#audit LeanAB.PaperB.packingSufficiency
#audit LeanAB.PaperB.simultaneous_rational_packing
#audit LeanAB.PaperB.eventually_nextCapacity_packing
#audit LeanAB.PaperB.eventually_nextCapacity_deficit
#audit LeanAB.PaperB.eventually_unit_lower_at_nextCapacity
#audit LeanAB.PaperB.eventually_next_inverse_heights
#audit LeanAB.PaperB.FixedTargets.eventually_fixed_matching_floor
#audit LeanAB.PaperB.FixedTargets.eventually_fixedHeight_log
#audit LeanAB.PaperB.FixedTargets.eventually_boundedPacking_floors
#audit LeanAB.PaperB.FixedTargets.eventually_boundedPacking_uniform
#audit LeanAB.PaperB.FixedTargets.eventually_lengthPackingNumber

#audit LeanAB.PaperB.normalized_inverse_correction
#audit LeanAB.PaperB.eventually_inverse_heights
#audit LeanAB.PaperB.tendsto_normalized_inverse_heights
#audit LeanAB.PaperB.eventually_unit_and_integer_initial_segment
#audit LeanAB.PaperB.FixedTargets.eventually_fixedPacking_floors
#audit LeanAB.PaperB.FixedTargets.eventually_boundedPacking_at_fixed_length_height
#audit LeanAB.PaperB.Closure.exists_crt_subset_for_residues
#audit LeanAB.PaperB.Closure.primeCofactorPool_exists_subset_for_residues
#audit LeanAB.PaperB.ShortPointwise.mass_cast_of_cofactors
#audit LeanAB.PaperB.ShortPointwise.eventually_baseline_common_cover_of_shortPointwise
#audit LeanAB.PaperB.ShortPointwise.eventually_shortPointwiseResources
#audit LeanAB.PaperB.ShortPointwise.coversResidues_of_short_cover_pool
#audit LeanAB.PaperB.ShortPointwise.eventually_shortPointwiseCover
#audit LeanAB.PaperB.ShortPointwise.eventually_baseline_common_cover
#audit LeanAB.PaperB.ShortPointwise.eventually_shortPointwiseCover_fifth_power

#print LeanAB.PaperB.nextSufficientLoss
#print LeanAB.PaperB.FixedTargets.PackingAtLoss
#print LeanAB.PaperB.Baseline.HasRetainedBlockMass

#print LeanAB.PaperB.Closure.CoversResidues
#print LeanAB.PaperB.Closure.UniformSmoothClosure
#print LeanAB.PaperB.FixedTargets.PackingSufficiency
#print LeanAB.PaperB.CapacityAttainment
#print LeanAB.PaperB.FixedTargets.HighTotalPackingSufficiency
#print LeanAB.PaperB.ShortPointwise.LiuSawhneyPrimeHeight
