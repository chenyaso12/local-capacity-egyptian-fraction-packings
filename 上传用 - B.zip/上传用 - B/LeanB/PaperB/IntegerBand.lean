module

public import PaperB.Obstruction.Published
public import Mathlib.NumberTheory.LSeries.WeakPNT
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.Algebra.Order.Floor.Semifield
meta import Mathlib.Tactic

/-! Growth of local reciprocal capacity in a dyadic height interval. -/

@[expose] public section

open Finset Filter
open scoped BigOperators Topology Interval

namespace LeanAB.PaperB

/-- Heights for which every prime divisor is at most the square root. -/
def SqrtSmooth (n : ℕ) : Prop :=
  ∀ p : ℕ, p.Prime → p ∣ n → p ≤ Nat.sqrt n

/-- Heights in a window that can be added to a previous locally feasible set. -/
noncomputable def smoothHeights (u v : ℕ) : Finset ℕ := by
  classical
  exact (Ioc u v).filter SqrtSmooth

/-- The primes used to create smooth heights in [X,2X]. -/
noncomputable def growthPrimes (X : ℕ) : Finset ℕ :=
  primesBetween ((X : ℝ) ^ (3 / 10 : ℝ)) ((X : ℝ) ^ (1 / 3 : ℝ))

private theorem eventually_theta_relative_small :
    ∀ᶠ t : ℝ in atTop, |Chebyshev.theta t - t| ≤ (1 / 100 : ℝ) * t := by
  have h := Metric.tendsto_nhds.mp Chebyshev.tendsto_theta_div_atTop
    (1 / 100 : ℝ) (by norm_num)
  filter_upwards [h, eventually_gt_atTop (1 : ℝ)] with t ht hOne
  have ht₀ : 0 < t := zero_lt_one.trans hOne
  rw [Real.dist_eq] at ht
  have hr : Chebyshev.theta t / t - 1 = (Chebyshev.theta t - t) / t := by
    field_simp [ht₀.ne']
  rw [hr, abs_div, abs_of_pos ht₀] at ht
  exact (div_le_iff₀ ht₀).mp ht.le

theorem eventually_growthPrimes_reciprocal_sum_ge :
    ∀ᶠ X : ℕ in atTop,
      (1 / 20 : ℝ) ≤ ∑ p ∈ growthPrimes X, (p : ℝ)⁻¹ := by
  obtain ⟨T, hT⟩ := eventually_atTop.mp eventually_theta_relative_small
  have hCast : Tendsto (fun X : ℕ => (X : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hPow : Tendsto (fun X : ℕ => (X : ℝ) ^ (3 / 10 : ℝ)) atTop atTop :=
    (tendsto_rpow_atTop (by norm_num)).comp hCast
  have hLog : Tendsto (fun X : ℕ => Real.log (X : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp hCast
  filter_upwards [hPow.eventually_ge_atTop T, hLog.eventually_ge_atTop 2,
    eventually_ge_atTop (2 : ℕ)] with X hAT hLog₂ hX
  let x : ℝ := X
  let a := x ^ (3 / 10 : ℝ)
  let b := x ^ (1 / 3 : ℝ)
  let L := Real.log x
  have hx : 1 < x := by change (1 : ℝ) < X; exact_mod_cast (by omega : 1 < X)
  have hx₀ : 0 < x := zero_lt_one.trans hx
  have ha : 0 < a := Real.rpow_pos_of_pos hx₀ _
  have hab : a ≤ b := Real.rpow_le_rpow_of_exponent_le hx.le (by norm_num)
  have ha₀ : 0 ≤ a := ha.le
  have hs (t : ℝ) (ht : t ∈ Set.Icc a b) : t ≠ 0 := (ha.trans_le ht.1).ne'
  have hAbel := abs_weighted_prime_sum_sub_integral_le
    (f := fun t : ℝ => t⁻¹) (f' := fun t : ℝ => -(t^2)⁻¹)
    ha₀ hab (fun t ht => hasDerivAt_inv (hs t ht))
    (((continuous_id.continuousOn.pow 2).inv₀ fun t ht => pow_ne_zero _ (hs t ht)).neg)
    (fun t ht => inv_nonneg.mpr (ha₀.trans ht.1))
    (fun _ _ => neg_nonpos.mpr (inv_nonneg.mpr (sq_nonneg _)))
    (fun t ht => hT t (hAT.trans ht.1))
  have hInt : (∫ t in a..b, t⁻¹) = L / 30 := by
    rw [integral_inv (by
      rw [Set.uIcc_of_le hab]
      exact fun ht => hs 0 ht rfl), Real.log_div (ha.trans_le hab).ne' ha.ne']
    dsimp [a,b,L]
    rw [Real.log_rpow hx₀, Real.log_rpow hx₀]
    ring
  have hLeft : 2 * a * a⁻¹ = 2 := by field_simp [ha.ne']
  rw [hInt,hLeft] at hAbel
  have hLo : L / 60 ≤ ∑ p ∈ growthPrimes X, (p : ℝ)⁻¹ * Real.log p := by
    exact (show L / 60 ≤ L / 30 - (1 / 100 : ℝ) * (L / 30 + 2) by linarith only [hLog₂]).trans
      (by
        change _ ≤ ∑ p ∈ primesBetween a b, (p : ℝ)⁻¹ * Real.log p
        have := (abs_le.mp hAbel).1
        linarith only [this])
  have hHi : (∑ p ∈ growthPrimes X, (p : ℝ)⁻¹ * Real.log p) ≤
      (∑ p ∈ growthPrimes X, (p : ℝ)⁻¹) * (L / 3) := by
    rw [Finset.sum_mul]
    apply Finset.sum_le_sum
    intro p hp
    have hw := (mem_primesBetween ha.le (ha.le.trans hab)).mp hp
    have hLp : Real.log (p : ℝ) ≤ Real.log b :=
      Real.log_le_log (ha.trans hw.1) hw.2.1
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    exact hLp.trans_eq (by dsimp [b,L]; rw [Real.log_rpow hx₀]; ring)
  apply (mul_le_mul_iff_right₀ (show 0 < L / 3 by linarith only [hLog₂])).mp
  calc
    _ = L / 60 := by ring
    _ ≤ _ := by simpa only [mul_comm] using hLo.trans hHi

/-- Number of multiples in a left-open, right-closed integer window. -/
theorem card_multiples_Ioc {u v d : ℕ} (huv : u ≤ v) :
    ((Ioc u v).filter (d ∣ ·)).card = v / d - u / d := by
  let A := (Finset.range (v + 1)).filter (fun n => n ≠ 0 ∧ d ∣ n)
  let B := (Finset.range (u + 1)).filter (fun n => n ≠ 0 ∧ d ∣ n)
  have hBA : B ⊆ A := by
    intro n hn
    have h := mem_filter.mp hn
    exact mem_filter.mpr ⟨Finset.mem_range.mpr ((Finset.mem_range.mp h.1).trans_le
      (Nat.succ_le_succ huv)), h.2⟩
  have hDiff : A \ B = (Ioc u v).filter (d ∣ ·) := by
    ext n
    simp only [A, B, Finset.mem_sdiff, mem_filter, Finset.mem_range, mem_Ioc]
    omega
  rw [← hDiff, Finset.card_sdiff_of_subset hBA]
  dsimp [A,B]
  rw [Nat.card_multiples', Nat.card_multiples']

/-- A window of length at least twice the modulus contains the required fraction of multiples. -/
theorem card_multiples_Ioc_ge {u v d : ℕ} (hd : 0 < d)
    (hwindow : 2 * (d : ℝ) ≤ (v : ℝ) - u) :
    ((v : ℝ) - u) / (2 * d) ≤ (((Ioc u v).filter (d ∣ ·)).card : ℝ) := by
  have hdR : (0 : ℝ) < d := by exact_mod_cast hd
  have huv : u ≤ v := by exact_mod_cast (by linarith only [hwindow,hdR] : (u : ℝ) ≤ v)
  rw [card_multiples_Ioc huv, Nat.cast_sub (Nat.div_le_div_right huv)]
  have hv : (v : ℝ) / d - 1 ≤ ((v / d : ℕ) : ℝ) := by
    rw [← Nat.floor_div_eq_div (K := ℝ)]
    linarith only [Nat.lt_floor_add_one ((v : ℝ) / d)]
  have hu : ((u / d : ℕ) : ℝ) ≤ (u : ℝ) / d := Nat.cast_div_le
  have hw₂ : 2 ≤ ((v : ℝ) - u) / d := (le_div_iff₀ hdR).mpr hwindow
  have hsplit : ((v : ℝ) - u) / (2 * d) = (((v : ℝ) - u) / d) / 2 := by ring
  rw [hsplit, sub_div] at *
  linarith only [hv, hu, hw₂]

/-- Capacity increases by at least the mass of the smooth heights in the window. -/
theorem capacity_sub_ge_smoothHeights_mass {u v : ℕ} (huv : u ≤ v) :
    mass (smoothHeights u v) ≤ capacity v - capacity u := by
  induction v, huv using Nat.le_induction with
  | base => simp [smoothHeights,mass]
  | succ v huv ih =>
    have hInsert : Ioc u (v + 1) = insert (v + 1) (Ioc u v) := by
      ext n
      simp only [mem_Ioc, mem_insert]
      omega
    by_cases hs : SqrtSmooth (v + 1)
    · have hSmooth : smoothHeights u (v + 1) = insert (v + 1) (smoothHeights u v) := by
        simp [smoothHeights, hInsert, Finset.filter_insert, hs]
      have hnot : v + 1 ∉ smoothHeights u v := by simp [smoothHeights]
      rw [hSmooth, mass, Finset.sum_insert hnot, ← mass]
      linarith only [ih, capacity_succ_ge hs]
    · have hSmooth : smoothHeights u (v + 1) = smoothHeights u v := by
        simp [smoothHeights, hInsert, Finset.filter_insert, hs]
      rw [hSmooth]
      linarith only [ih, capacity_mono (Nat.le_succ v)]


private def distinctPairs (P : Finset ℕ) : Finset (ℕ × ℕ) :=
  (P ×ˢ P).filter (fun a => a.1 ≠ a.2)

private theorem mem_distinctPairs {P : Finset ℕ} {a : ℕ × ℕ} :
    a ∈ distinctPairs P ↔ a.1 ∈ P ∧ a.2 ∈ P ∧ a.1 ≠ a.2 := by
  simp only [distinctPairs, mem_filter, mem_product, and_assoc]

private theorem sum_reciprocal_distinctPairs_ge {P : Finset ℕ}
    (hSum : (1 / 20 : ℝ) ≤ ∑ p ∈ P, (p : ℝ)⁻¹)
    (hSingle : ∀ p ∈ P, (p : ℝ)⁻¹ ≤ 1 / 40) :
    (1 / 800 : ℝ) ≤ ∑ a ∈ distinctPairs P, ((a.1 * a.2 : ℕ) : ℝ)⁻¹ := by
  have hErase (p : ℕ) (hp : p ∈ P) :
      (1 / 40 : ℝ) ≤ ∑ q ∈ P.erase p, (q : ℝ)⁻¹ := by
    have h := Finset.sum_erase_add P (fun q : ℕ => (q : ℝ)⁻¹) hp
    linarith only [h, hSum, hSingle p hp]
  have hPair : (∑ a ∈ distinctPairs P, ((a.1 * a.2 : ℕ) : ℝ)⁻¹) =
      ∑ p ∈ P, (p : ℝ)⁻¹ * (∑ q ∈ P.erase p, (q : ℝ)⁻¹) := by
    rw [distinctPairs, sum_filter, sum_product]
    apply sum_congr rfl
    intro p hp
    rw [mul_sum, ← Finset.filter_ne P p, sum_filter]
    apply sum_congr rfl
    intro q hq
    by_cases h : p = q
    · simp [h]
    · simp [h, Nat.cast_mul, mul_comm]
  calc
    _ = (∑ p ∈ P, (p : ℝ)⁻¹) * (1 / 40) -
        ((∑ p ∈ P, (p : ℝ)⁻¹) - 1 / 20) * (1 / 40) := by ring
    _ ≤ (∑ p ∈ P, (p : ℝ)⁻¹) * (1 / 40) := by
      exact sub_le_self _ (mul_nonneg (sub_nonneg.mpr hSum) (by norm_num))
    _ = ∑ p ∈ P, (p : ℝ)⁻¹ * (1 / 40) := by rw [Finset.sum_mul]
    _ ≤ _ := hPair ▸ Finset.sum_le_sum (fun p hp =>
      mul_le_mul_of_nonneg_left (hErase p hp) (by positivity))

private theorem card_matching_pairs_le {P : Finset ℕ} (n : ℕ)
    (hFew : ((P.filter (· ∣ n)).card : ℕ) ≤ 3) :
    ((distinctPairs P).filter (fun a => a.1 * a.2 ∣ n)).card ≤ 9 := by
  let D := P.filter (· ∣ n)
  have hsub : (distinctPairs P).filter (fun a => a.1 * a.2 ∣ n) ⊆ D ×ˢ D := by
    intro a ha
    obtain ⟨hpair, hd⟩ := mem_filter.mp ha
    obtain ⟨hp,hq,_⟩ := mem_distinctPairs.mp hpair
    exact mem_product.mpr ⟨mem_filter.mpr ⟨hp, (dvd_mul_right _ _).trans hd⟩,
      mem_filter.mpr ⟨hq, (dvd_mul_left _ _).trans hd⟩⟩
  have hD : D.card ≤ 3 := hFew
  exact (card_le_card hsub).trans (by rw [card_product]; nlinarith only [hD])

/-- Double counting from a finite family of large coprime prime factors. The
multiplicity bound is stated explicitly so this lemma is independent of the PNT. -/
theorem card_smoothHeights_ge_of_pairs {P : Finset ℕ} {u v : ℕ}
    (huv : u ≤ v)
    (hPos : ∀ p ∈ P, 0 < p)
    (hSum : (1 / 20 : ℝ) ≤ ∑ p ∈ P, (p : ℝ)⁻¹)
    (hSingle : ∀ p ∈ P, (p : ℝ)⁻¹ ≤ 1 / 40)
    (hFew : ∀ n ∈ Ioc u v, (P.filter (· ∣ n)).card ≤ 3)
    (hWindow : ∀ a b : ℕ, a ∈ P → b ∈ P → 2 * ((a * b : ℕ) : ℝ) ≤ (v : ℝ) - u)
    (hSmooth : ∀ n ∈ Ioc u v, ∀ a b : ℕ, a ∈ P → b ∈ P → a ≠ b →
      a * b ∣ n → SqrtSmooth n) :
    ((v : ℝ) - u) / 14400 ≤ ((smoothHeights u v).card : ℝ) := by
  classical
  let W := Ioc u v
  let K := distinctPairs P
  let count (a : ℕ × ℕ) := (W.filter (a.1 * a.2 ∣ ·)).card
  let mult (n : ℕ) := (K.filter (fun a => a.1 * a.2 ∣ n)).card
  let Y := (v : ℝ) - u
  have hY : 0 ≤ Y := sub_nonneg.mpr (by exact_mod_cast huv)
  have hDouble : (∑ a ∈ K, count a) = ∑ n ∈ W, mult n := by
    simp only [count, mult, Finset.card_filter]
    rw [Finset.sum_comm]
  have hUpper : (∑ a ∈ K, count a) ≤ 9 * (smoothHeights u v).card := by
    rw [hDouble]
    calc
      _ ≤ ∑ n ∈ W, if SqrtSmooth n then 9 else 0 := by
        apply sum_le_sum
        intro n hn
        by_cases h : SqrtSmooth n
        · simpa [h] using card_matching_pairs_le n (hFew n hn)
        · have hZero : K.filter (fun a => a.1 * a.2 ∣ n) = ∅ := by
            refine eq_empty_iff_forall_notMem.mpr fun a ha => ?_
            obtain ⟨ha,hd⟩ := mem_filter.mp ha
            obtain ⟨hp,hq,hne⟩ := mem_distinctPairs.mp ha
            exact h (hSmooth n hn a.1 a.2 hp hq hne hd)
          simp [mult, hZero, h]
      _ = _ := by
        rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul, mul_comm]
        rfl
  have hLower : Y / 1600 ≤ ∑ a ∈ K, (count a : ℝ) := calc
    _ = (Y / 2) * (1 / 800) := by ring
    _ ≤ (Y / 2) * (∑ a ∈ K, ((a.1 * a.2 : ℕ) : ℝ)⁻¹) :=
      mul_le_mul_of_nonneg_left (sum_reciprocal_distinctPairs_ge hSum hSingle) (by positivity)
    _ = ∑ a ∈ K, Y / (2 * ((a.1 * a.2 : ℕ) : ℝ)) := by
      rw [Finset.mul_sum]
      apply sum_congr rfl
      intro a ha
      rw [← div_div, div_eq_mul_inv (Y / 2)]
    _ ≤ _ := by
      apply sum_le_sum
      intro a ha
      obtain ⟨hp,hq,_⟩ := mem_distinctPairs.mp ha
      exact card_multiples_Ioc_ge (Nat.mul_pos (hPos _ hp) (hPos _ hq)) (hWindow _ _ hp hq)
  have hUpperR : (∑ a ∈ K, (count a : ℝ)) ≤ 9 * ((smoothHeights u v).card : ℝ) := by
    exact_mod_cast hUpper
  linarith only [hLower,hUpperR]

private theorem le_natSqrt_of_cast_le_sqrt {k X : ℕ} (hk : (k : ℝ) ≤ Real.sqrt (X : ℝ)) :
    k ≤ Nat.sqrt X := by
  apply Nat.le_sqrt.mpr
  have hs := pow_le_pow_left₀ (Nat.cast_nonneg k) hk 2
  rw [Real.sq_sqrt (by positivity), pow_two] at hs
  exact_mod_cast hs

private theorem sqrtSmooth_of_pair {X n p q : ℕ} (hn₀ : 0 < n) (hXn : X ≤ n)
    (hn : n ≤ 2 * X) (hp : 0 < p) (hq : 0 < q) (hps : p ≤ Nat.sqrt X)
    (hqs : q ≤ Nat.sqrt X) (hLarge : (2 : ℝ) * X ≤ (p : ℝ) * q * Real.sqrt (X : ℝ))
    (hd : p * q ∣ n) : SqrtSmooth n := by
  obtain ⟨k, hk⟩ := hd
  have hpq : (0 : ℝ) < (p : ℝ) * q := by positivity
  have hkr : (k : ℝ) ≤ Real.sqrt (X : ℝ) := by
    apply (mul_le_mul_iff_right₀ hpq).mp
    calc
      _ = (n : ℝ) := by rw [hk]; push_cast; ring
      _ ≤ (2 : ℝ) * X := by exact_mod_cast hn
      _ ≤ _ := by simpa only [mul_comm, mul_assoc, mul_left_comm] using hLarge
  have hks := le_natSqrt_of_cast_le_sqrt hkr
  have hk₀ : 0 < k := by rw [hk] at hn₀; exact Nat.pos_of_mul_pos_left hn₀
  intro r hr hrd
  rw [hk, hr.dvd_mul, hr.dvd_mul] at hrd
  apply le_trans _ (Nat.sqrt_le_sqrt hXn)
  rcases hrd with (hrp | hrq) | hrk
  · exact (Nat.le_of_dvd hp hrp).trans hps
  · exact (Nat.le_of_dvd hq hrq).trans hqs
  · exact (Nat.le_of_dvd hk₀ hrk).trans hks



private theorem card_large_prime_divisors_le_three {P : Finset ℕ} {a : ℝ} {n : ℕ}
    (ha : 1 ≤ a) (hn : 0 < n) (hBound : (n : ℝ) ≤ a^4)
    (hP : ∀ p ∈ P, p.Prime ∧ a < (p : ℝ)) :
    (P.filter (· ∣ n)).card ≤ 3 := by
  let D := P.filter (· ∣ n)
  by_contra! hnD
  have hFour : 4 ≤ D.card := by change 3 < D.card at hnD; omega
  have hnEmpty : D.Nonempty := card_pos.mp (by omega)
  have hD (p : ℕ) (hp : p ∈ D) : a < (p : ℝ) := (hP p (mem_filter.mp hp).1).2
  have hdiv : (∏ p ∈ D, p) ∣ n := by
    have hSub : D ⊆ n.primeFactors := by
      intro p hp
      obtain ⟨hpP,hpn⟩ := mem_filter.mp hp
      exact (hP p hpP).1.mem_primeFactors hpn hn.ne'
    exact (Finset.prod_dvd_prod_of_subset D n.primeFactors id hSub).trans
      (Nat.prod_primeFactors_dvd n)
  have hCast : (∏ p ∈ D, (p : ℝ)) ≤ n := by
    rw [← Nat.cast_prod]
    exact_mod_cast Nat.le_of_dvd hn hdiv
  have hProd : a ^ D.card < ∏ p ∈ D, (p : ℝ) := by
    rw [← Finset.prod_const]
    exact Finset.prod_lt_prod_of_nonempty₀ (fun _ _ => zero_lt_one.trans_le ha) hD hnEmpty
  exact not_lt_of_ge (hCast.trans hBound) ((pow_le_pow_right₀ ha hFour).trans_lt hProd)

/-- There are linearly many square-root-smooth heights in every sufficiently
long integer window inside [X,2X]. -/
theorem eventually_card_smoothHeights_ge :
    ∀ᶠ X : ℕ in atTop, ∀ u v : ℕ, X ≤ u → u ≤ v → v ≤ 2 * X →
      2 * ((X : ℝ) ^ (2 / 3 : ℝ)) ≤ (v : ℝ) - u →
      ((v : ℝ) - u) / 14400 ≤ ((smoothHeights u v).card : ℝ) := by
  have hcast : Tendsto (fun X : ℕ => (X : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hcut : Tendsto (fun X : ℕ => (X : ℝ) ^ (3 / 10 : ℝ)) atTop atTop :=
    (tendsto_rpow_atTop (by norm_num)).comp hcast
  have hscale : Tendsto (fun X : ℕ => (X : ℝ) ^ (1 / 10 : ℝ)) atTop atTop :=
    (tendsto_rpow_atTop (by norm_num)).comp hcast
  filter_upwards [eventually_growthPrimes_reciprocal_sum_ge, eventually_ge_atTop (2 : ℕ),
    hcut.eventually_ge_atTop 40, hscale.eventually_ge_atTop 2] with
    X hSum hX hcut hscale u v hXu huv hv hlength
  let x : ℝ := X
  let a := x ^ (3 / 10 : ℝ)
  let b := x ^ (1 / 3 : ℝ)
  let P := growthPrimes X
  change (40 : ℝ) ≤ a at hcut
  change (2 : ℝ) ≤ x ^ (1 / 10 : ℝ) at hscale
  have hx : 1 ≤ x := by change (1 : ℝ) ≤ X; exact_mod_cast (by omega : 1 ≤ X)
  have hx₀ : 0 < x := zero_lt_one.trans_le hx
  have ha : 0 < a := Real.rpow_pos_of_pos hx₀ _
  have hb : 0 < b := Real.rpow_pos_of_pos hx₀ _
  have hp (p : ℕ) (h : p ∈ P) : a < (p : ℝ) ∧ (p : ℝ) ≤ b ∧ p.Prime :=
    (mem_primesBetween ha.le hb.le).mp h
  have hs (p : ℕ) (h : p ∈ P) : p ≤ Nat.sqrt X := by
    apply le_natSqrt_of_cast_le_sqrt
    rw [Real.sqrt_eq_rpow]
    exact (hp p h).2.1.trans (Real.rpow_le_rpow_of_exponent_le hx (by norm_num))
  have hSingle (p : ℕ) (h : p ∈ P) : (p : ℝ)⁻¹ ≤ 1 / 40 := by
    rw [one_div]
    exact inv_anti₀ (by norm_num) (hcut.trans (hp p h).1.le)
  have ha4 : (2 : ℝ) * x ≤ a^4 := calc
    _ ≤ x * (x ^ (1 / 5 : ℝ)) := by
      have he := hscale.trans (Real.rpow_le_rpow_of_exponent_le hx
        (show (1 / 10 : ℝ) ≤ 1 / 5 by norm_num))
      simpa only [mul_comm] using mul_le_mul_of_nonneg_left he hx₀.le
    _ = x ^ (1 + 1 / 5 : ℝ) := by rw [Real.rpow_add hx₀, Real.rpow_one]
    _ = x ^ ((3 / 10 : ℝ) * (4 : ℕ)) := by norm_num
    _ = a ^ 4 := by rw [Real.rpow_mul hx₀.le, Real.rpow_natCast]
  have hFew (n : ℕ) (hn : n ∈ Ioc u v) : (P.filter (· ∣ n)).card ≤ 3 := by
    apply card_large_prime_divisors_le_three (a := a) (by linarith only [hcut]) (by
      have := (mem_Ioc.mp hn).1
      omega)
    · exact (show (n : ℝ) ≤ 2 * x by
        change (n : ℝ) ≤ 2 * (X : ℝ)
        exact_mod_cast (mem_Ioc.mp hn).2.trans hv).trans ha4
    · exact fun p h => ⟨(hp p h).2.2, (hp p h).1⟩
  have hMod (p q : ℕ) (hpP : p ∈ P) (hqP : q ∈ P) :
      ((p*q : ℕ) : ℝ) ≤ (X : ℝ) ^ (2 / 3 : ℝ) := by
    rw [Nat.cast_mul, show (2 / 3 : ℝ) = 1 / 3 + 1 / 3 by norm_num, Real.rpow_add hx₀]
    exact mul_le_mul (hp p hpP).2.1 (hp q hqP).2.1 (Nat.cast_nonneg _) hb.le
  have hSmooth (n : ℕ) (hn : n ∈ Ioc u v) (p q : ℕ) (hpP : p ∈ P) (hqP : q ∈ P)
      (_ : p ≠ q) (hd : p * q ∣ n) : SqrtSmooth n := by
    obtain ⟨hnu, hnv⟩ := mem_Ioc.mp hn
    have hLarge : (2 : ℝ) * x ≤ (p : ℝ) * q * Real.sqrt x := calc
      _ ≤ x * (x ^ (1 / 10 : ℝ)) := by
        simpa only [mul_comm] using mul_le_mul_of_nonneg_left hscale hx₀.le
      _ = (x ^ (3 / 10 : ℝ)) * (x ^ (3 / 10 : ℝ)) * Real.sqrt x := by
        calc
          _ = x ^ (1 + 1 / 10 : ℝ) := by rw [Real.rpow_add hx₀, Real.rpow_one]
          _ = _ := by
            rw [Real.sqrt_eq_rpow, ← Real.rpow_add hx₀, ← Real.rpow_add hx₀]
            norm_num
      _ ≤ _ := mul_le_mul_of_nonneg_right
        (mul_le_mul (hp p hpP).1.le (hp q hqP).1.le ha.le (Nat.cast_nonneg _))
        (Real.sqrt_nonneg _)
    exact sqrtSmooth_of_pair (by omega) (hXu.trans hnu.le) (hnv.trans hv)
      (hp p hpP).2.2.pos (hp q hqP).2.2.pos (hs p hpP) (hs q hqP) hLarge hd
  exact card_smoothHeights_ge_of_pairs huv
    (fun p h => (hp p h).2.2.pos) hSum hSingle hFew
    (fun p q hp hq => (mul_le_mul_of_nonneg_left (hMod p q hp hq) (by norm_num)).trans hlength) hSmooth

/-- Unconditional capacity growth across every sufficiently long real window
inside [X,2X], with the integer floors at the endpoints retained. -/
theorem eventually_capacity_window_growth :
    ∀ᶠ X : ℕ in atTop, ∀ u v : ℝ, (X : ℝ) ≤ u → v ≤ 2 * (X : ℝ) →
      4 * ((X : ℝ) ^ (2 / 3 : ℝ)) ≤ v - u →
      (v - u) / (57600 * (X : ℝ)) ≤ (capacity ⌊v⌋₊ : ℝ) - (capacity ⌊u⌋₊ : ℝ) := by
  classical
  filter_upwards [eventually_card_smoothHeights_ge, eventually_ge_atTop (2 : ℕ)] with
    X hX hTwo u v hXu hv hlen
  let x : ℝ := X
  let a := ⌊u⌋₊
  let b := ⌊v⌋₊
  let Y := v - u
  have hx : 1 ≤ x := by
    change (1 : ℝ) ≤ X
    exact_mod_cast (by omega : 1 ≤ X)
  have hx₀ : 0 < x := zero_lt_one.trans_le hx
  have hPow : 1 ≤ x ^ (2 / 3 : ℝ) := Real.one_le_rpow hx (by norm_num)
  have hY : 2 ≤ Y := by linarith only [hlen,hPow]
  have huv : u ≤ v := by dsimp [Y] at hY; linarith only [hY]
  have hu₀ : 0 ≤ u := hx₀.le.trans hXu
  have hv₀ : 0 ≤ v := hu₀.trans huv
  have hXa : X ≤ a := Nat.le_floor hXu
  have hab : a ≤ b := Nat.floor_mono huv
  have hbX : b ≤ 2 * X := by
    have h := (Nat.floor_le hv₀).trans hv
    exact_mod_cast h
  have hFloorLen : Y / 2 ≤ (b : ℝ) - a := by
    have hU : (a : ℝ) ≤ u := Nat.floor_le hu₀
    have hV : v < (b : ℝ) + 1 := Nat.lt_floor_add_one v
    dsimp [Y] at *
    linarith only [hU,hV,hY]
  have hlen' : 2 * (x ^ (2 / 3 : ℝ)) ≤ (b : ℝ) - a := by
    linarith only [hlen,hFloorLen]
  have hcount := hX a b hXa hab hbX hlen'
  let F := smoothHeights a b
  have hMass : (mass F : ℝ) ≤ (capacity b : ℝ) - (capacity a : ℝ) := by
    exact_mod_cast capacity_sub_ge_smoothHeights_mass hab
  have hLower : (F.card : ℝ) / (2 * x) ≤ (mass F : ℝ) := by
    rw [mass, Rat.cast_sum]
    calc
      _ = ∑ n ∈ F, (2 * x)⁻¹ := by simp [Finset.sum_const, nsmul_eq_mul, div_eq_mul_inv]
      _ ≤ _ := by
        apply Finset.sum_le_sum
        intro n hn
        obtain ⟨hans, hnb⟩ := mem_Ioc.mp (mem_filter.mp hn).1
        rw [Rat.cast_inv, Rat.cast_natCast]
        exact inv_anti₀ (by exact_mod_cast (by omega : 0 < n))
          (by change (n : ℝ) ≤ 2 * (X : ℝ); exact_mod_cast hnb.trans hbX)
  calc
    _ = (Y / 2 / 14400) / (2 * x) := by ring
    _ ≤ (F.card : ℝ) / (2 * x) := by
      apply div_le_div_of_nonneg_right _ (by positivity)
      exact (div_le_div_of_nonneg_right hFloorLen (by norm_num)).trans hcount
    _ ≤ _ := hLower.trans hMass



/-- Heights in one integer capacity band inside [X,2X]. -/
noncomputable def capacityBand (X : ℕ) (j : ℤ) (ε : ℝ) : Finset ℕ := by
  classical
  exact (Icc X (2 * X)).filter (fun n =>
    (j : ℝ) ≤ (capacity n : ℝ) ∧ (capacity n : ℝ) ≤ (j : ℝ) + ε)

/-- The set where the local capacity upper bound does not identify k. -/
noncomputable def capacityExceptions (heights : Finset ℕ) : Finset ℕ := by
  classical
  exact heights.filter (fun n => (k n : ℤ) < ⌊(capacity n : ℝ)⌋)

theorem equals_floor_capacity_of_not_exception {n : ℕ} (h : n ∉ capacityExceptions {n}) :
    (k n : ℤ) = ⌊capacity n⌋ ∧ (PaperB.h n : ℤ) = ⌊capacity n⌋ := by
  have hfloor : ⌊capacity n⌋ ≤ (k n : ℤ) := by
    simpa only [capacityExceptions, mem_filter, mem_singleton, true_and, Rat.floor_cast,
      not_lt] using h
  have hkh : (k n : ℤ) ≤ (PaperB.h n : ℤ) := by exact_mod_cast k_le_h n
  have hhc : (PaperB.h n : ℤ) ≤ ⌊capacity n⌋ := h_le_floor_capacity n
  exact ⟨le_antisymm (hkh.trans hhc) hfloor, le_antisymm hhc (hfloor.trans hkh)⟩

/-- A finite capacity band can span at most the greater of the cutoff window
length and the width times the reciprocal growth rate. -/
theorem card_capacityBand_le_of_window_growth {X : ℕ} (hX : 0 < X) (j : ℤ) (ε : ℝ)
    (hGrow : ∀ u v : ℝ, (X : ℝ) ≤ u → v ≤ 2 * (X : ℝ) →
      4 * ((X : ℝ) ^ (2 / 3 : ℝ)) ≤ v - u →
      (v - u) / (57600 * (X : ℝ)) ≤ (capacity ⌊v⌋₊ : ℝ) - (capacity ⌊u⌋₊ : ℝ)) :
    ((capacityBand X j ε).card : ℝ) ≤
      1 + max (4 * ((X : ℝ) ^ (2 / 3 : ℝ))) (ε * (57600 * (X : ℝ))) := by
  classical
  let E := capacityBand X j ε
  rcases E.eq_empty_or_nonempty with hEmpty | hE
  · change (E.card : ℝ) ≤ _
    rw [hEmpty, Finset.card_empty, Nat.cast_zero]
    have hPos : (0 : ℝ) ≤ 4 * ((X : ℝ) ^ (2 / 3 : ℝ)) := by positivity
    linarith only [hPos, le_max_left (4 * ((X : ℝ) ^ (2 / 3 : ℝ))) (ε * (57600 * (X : ℝ)))]
  · let u := E.min' hE
    let v := E.max' hE
    have hu : u ∈ E := Finset.min'_mem E _
    have hv : v ∈ E := Finset.max'_mem E _
    have huv : u ≤ v := Finset.min'_le E v hv
    have hsub : E ⊆ Icc u v := fun n hn =>
      mem_Icc.mpr ⟨Finset.min'_le E n hn, Finset.le_max' E n hn⟩
    have hCard : (E.card : ℝ) ≤ (v : ℝ) - u + 1 := calc
      _ ≤ ((Icc u v).card : ℝ) := by exact_mod_cast Finset.card_le_card hsub
      _ = _ := by
        rw [Nat.card_Icc, Nat.cast_sub (by omega : u ≤ v + 1)]
        push_cast
        ring
    have ha : (X : ℝ) ≤ u := Nat.cast_le.mpr (mem_Icc.mp (mem_filter.mp hu).1).1
    have hb := (show (v : ℝ) ≤ 2 * (X : ℝ) by
      exact_mod_cast (mem_Icc.mp (mem_filter.mp hv).1).2)
    have hSpan : (v : ℝ) - u ≤ max (4 * ((X : ℝ) ^ (2 / 3 : ℝ)))
        (ε * (57600 * (X : ℝ))) := by
      by_cases hlong : 4 * ((X : ℝ) ^ (2 / 3 : ℝ)) ≤ (v : ℝ) - u
      · have hg := hGrow (u : ℝ) (v : ℝ) ha hb hlong
        rw [Nat.floor_natCast, Nat.floor_natCast] at hg
        have hDifference : (capacity v : ℝ) - (capacity u : ℝ) ≤ ε := by
          linarith only [(mem_filter.mp hv).2.2, (mem_filter.mp hu).2.1]
        exact ((div_le_iff₀ (by positivity)).mp (hg.trans hDifference)).trans (le_max_right _ _)
      · exact (lt_of_not_ge hlong).le.trans (le_max_left _ _)
    linarith only [hCard,hSpan]

/-- For a dyadic height interval, the exceptional-set count is bounded by
the number of integer bands times their maximum cardinality. -/
theorem card_capacityExceptions_dyadic_le {X : ℕ} (hX : 0 < X) {ε low high : ℝ}
    {loss : ℕ → ℝ}
    (hRange : ∀ n ∈ Icc X (2 * X), low ≤ (capacity n : ℝ) ∧ (capacity n : ℝ) ≤ high)
    (hLoss : ∀ n ∈ Icc X (2 * X), loss n ≤ ε)
    (hAttain : ∀ n ∈ Icc X (2 * X), ⌊(capacity n : ℝ) - loss n⌋ ≤ (k n : ℤ))
    (hGrow : ∀ u v : ℝ, (X : ℝ) ≤ u → v ≤ 2 * (X : ℝ) →
      4 * ((X : ℝ) ^ (2 / 3 : ℝ)) ≤ v - u →
      (v - u) / (57600 * (X : ℝ)) ≤ (capacity ⌊v⌋₊ : ℝ) - (capacity ⌊u⌋₊ : ℝ)) :
    ((capacityExceptions (Icc X (2 * X))).card : ℝ) ≤
      ((Icc (⌊low⌋ : ℤ) ⌊high⌋).card : ℝ) *
        (1 + max (4 * ((X : ℝ) ^ (2 / 3 : ℝ))) (ε * (57600 * (X : ℝ)))) := by
  classical
  let J : Finset ℤ := Icc ⌊low⌋ ⌊high⌋
  let E := capacityExceptions (Icc X (2 * X))
  have hsub : E ⊆ J.biUnion (fun j => capacityBand X j ε) := by
    intro n hn
    obtain ⟨hn,hBad⟩ := mem_filter.mp hn
    let j := ⌊(capacity n : ℝ)⌋
    obtain ⟨hl,hr⟩ := hRange n hn
    have hj : j ∈ J := mem_Icc.mpr ⟨Int.floor_mono hl, Int.floor_mono hr⟩
    have hLower : (j : ℝ) ≤ (capacity n : ℝ) := Int.floor_le _
    have hloss : (capacity n : ℝ) - loss n < j :=
      Int.floor_lt.mp ((hAttain n hn).trans_lt hBad)
    have hUpper : (capacity n : ℝ) ≤ (j : ℝ) + ε := by linarith only [hloss, hLoss n hn]
    exact mem_biUnion.mpr ⟨j,hj,mem_filter.mpr ⟨hn,hLower,hUpper⟩⟩
  calc
    _ ≤ ∑ j ∈ J, ((capacityBand X j ε).card : ℝ) := by
      exact_mod_cast (card_le_card hsub).trans Finset.card_biUnion_le
    _ ≤ ∑ j ∈ J, (1 + max (4 * ((X : ℝ) ^ (2 / 3 : ℝ))) (ε * (57600 * (X : ℝ)))) :=
      Finset.sum_le_sum fun j _ => card_capacityBand_le_of_window_growth hX j ε hGrow
    _ = _ := by rw [Finset.sum_const, nsmul_eq_mul]



/-- Capacity attainment after a loss of A N^(-1/12), the unresolved lower
side of the F2 capacity theorem. -/
def CapacityAttainment (A : ℝ) : Prop :=
  ∀ᶠ N : ℕ in atTop,
    ⌊(capacity N : ℝ) - A / ((N : ℝ) ^ (1 / 12 : ℝ))⌋ ≤ (k N : ℤ)

/-- The strength of the capacity approximation needed for the number of
integer bands. The manuscript's O(U²/L) estimate implies this input. -/
def CapacityNearHarmonic : Prop :=
  ∀ᶠ N : ℕ in atTop, |(capacity N : ℝ) - (_root_.harmonic N : ℝ)| ≤ 1

/-- Conditional dyadic form of the F2 exception estimate. Its two inputs
are stated separately from the unconditional capacity growth. -/
theorem eventually_card_capacityExceptions_dyadic_le (A : ℝ) (hA : 0 ≤ A)
    (hAttain : CapacityAttainment A) (hApprox : CapacityNearHarmonic) :
    ∀ᶠ X : ℕ in atTop, ((capacityExceptions (Icc X (2 * X))).card : ℝ) ≤
      (25 + 288000 * A) * ((X : ℝ) ^ (11 / 12 : ℝ)) := by
  obtain ⟨T₁,hT₁⟩ := eventually_atTop.mp hAttain
  obtain ⟨T₂,hT₂⟩ := eventually_atTop.mp hApprox
  filter_upwards [eventually_capacity_window_growth, eventually_ge_atTop T₁,
    eventually_ge_atTop T₂, eventually_ge_atTop (1 : ℕ)] with X hGrowth hT₁X hT₂X hX
  let x : ℝ := X
  let L := Real.log x
  let ε := A / (x ^ (1 / 12 : ℝ))
  have hx : 1 ≤ x := by change (1 : ℝ) ≤ (X : ℝ); exact_mod_cast hX
  have hx₀ : 0 < x := zero_lt_one.trans_le hx
  have hlog₂ : Real.log 2 ≤ 1 := by linarith [Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 2)]
  have hRange (n : ℕ) (hn : n ∈ Icc X (2 * X)) :
      L - 1 ≤ (capacity n : ℝ) ∧ (capacity n : ℝ) ≤ L + 3 := by
    obtain ⟨hnl,hnh⟩ := mem_Icc.mp hn
    have hn₀ : 0 < (n : ℝ) := hx₀.trans_le (by change (X : ℝ) ≤ n; exact_mod_cast hnl)
    have hl : L ≤ Real.log (n : ℝ) := Real.log_le_log hx₀
      (by change (X : ℝ) ≤ n; exact_mod_cast hnl)
    have hu : Real.log (n : ℝ) ≤ L + Real.log 2 := by
      calc
        _ ≤ Real.log (2 * x) := Real.log_le_log hn₀ (by
          change (n : ℝ) ≤ 2 * (X : ℝ); exact_mod_cast hnh)
        _ = _ := by rw [Real.log_mul (by norm_num) hx₀.ne']; ring
    have hHLo : Real.log (n : ℝ) ≤ (_root_.harmonic n : ℝ) :=
      (Real.log_le_log hn₀ (by exact_mod_cast Nat.le_succ n)).trans (log_add_one_le_harmonic n)
    have hHHi := harmonic_le_one_add_log n
    obtain ⟨hloss,hgain⟩ := abs_le.mp (hT₂ n (hT₂X.trans hnl))
    constructor <;> linarith only [hl,hu,hHLo,hHHi,hloss,hgain,hlog₂]
  have hLoss (n : ℕ) (hn : n ∈ Icc X (2 * X)) :
      A / ((n : ℝ) ^ (1 / 12 : ℝ)) ≤ ε := by
    have hle : x ≤ (n : ℝ) := by
      change (X : ℝ) ≤ n
      exact_mod_cast (mem_Icc.mp hn).1
    exact div_le_div_of_nonneg_left hA (Real.rpow_pos_of_pos hx₀ _)
      (Real.rpow_le_rpow hx₀.le hle (by norm_num))
  have hc := card_capacityExceptions_dyadic_le
    (show 0 < X by omega) hRange hLoss
    (fun n hn => hT₁ n (hT₁X.trans (mem_Icc.mp hn).1)) hGrowth
  have hBands : (Icc (⌊L - 1⌋ : ℤ) ⌊L + 3⌋).card = 5 := by
    have hF1 : ⌊L - 1⌋ = ⌊L⌋ - 1 := by exact_mod_cast Int.floor_sub_intCast L (1 : ℤ)
    have hF3 : ⌊L + 3⌋ = ⌊L⌋ + 3 := by exact_mod_cast Int.floor_add_intCast L (3 : ℤ)
    rw [hF1,hF3,Int.card_Icc]
    omega
  rw [hBands, Nat.cast_ofNat] at hc
  let W := x ^ (11 / 12 : ℝ)
  have hW₁ : 1 ≤ W := Real.one_le_rpow hx (by norm_num)
  have hSmaller : x ^ (2 / 3 : ℝ) ≤ W :=
    Real.rpow_le_rpow_of_exponent_le hx (by norm_num)
  have hEq : ε * (57600 * x) = 57600 * A * W := by
    have hp : x / x ^ (1 / 12 : ℝ) = W := by
      dsimp [W]
      rw [show (11 / 12 : ℝ) = 1 - 1 / 12 by norm_num, Real.rpow_sub hx₀, Real.rpow_one]
    calc
      _ = (57600 * A) * (x / x ^ (1 / 12 : ℝ)) := by dsimp [ε]; ring
      _ = _ := by rw [hp]
  change _ ≤ 5 * (1 + max (4 * x ^ (2 / 3 : ℝ)) (ε * (57600 * x))) at hc
  have hMax : max (4 * x ^ (2 / 3 : ℝ)) (ε * (57600 * x)) ≤
      4 * W + 57600 * A * W := by
    rw [hEq]
    apply max_le
    · exact (mul_le_mul_of_nonneg_left hSmaller (by norm_num)).trans
        (le_add_of_nonneg_right (by positivity))
    · exact le_add_of_nonneg_left (by positivity)
  change _ ≤ (25 + 288000 * A) * W
  nlinarith only [hc,hMax,hW₁]



/-- Sum the dyadic exception estimate by splitting at the integer half-height. -/
theorem card_capacityExceptions_le {A : ℝ} (hA : 0 ≤ A) (hAttain : CapacityAttainment A)
    (hApprox : CapacityNearHarmonic) :
    ∃ C : ℝ, 0 < C ∧ ∀ X : ℕ, ((capacityExceptions (Icc 1 X)).card : ℝ) ≤
      C * ((X : ℝ) ^ (11 / 12 : ℝ)) := by
  obtain ⟨T,hT⟩ := eventually_atTop.mp
    (eventually_card_capacityExceptions_dyadic_le A hA hAttain hApprox)
  let α : ℝ := 11 / 12
  let D : ℝ := 25 + 288000 * A
  let r : ℝ := (1 / 2 : ℝ) ^ α
  let C : ℝ := max (2 * (T : ℝ) + 2) (D / (1 - r))
  have hD : 0 ≤ D := by dsimp [D]; positivity
  have hα : 0 < α := by dsimp [α]; norm_num
  have hr : r < 1 := Real.rpow_lt_one (by norm_num) (by norm_num) hα
  have hC : 0 < C := (by positivity : 0 < 2 * (T : ℝ) + 2).trans_le (le_max_left _ _)
  have hDC : D ≤ C * (1 - r) := (div_le_iff₀ (sub_pos.mpr hr)).mp (le_max_right _ _)
  refine ⟨C,hC,?_⟩
  intro X
  induction X using Nat.strong_induction_on with
  | ind N ih =>
    by_cases hN : N = 0
    · subst N
      have hE : capacityExceptions (Icc 1 0) = ∅ := by simp [capacityExceptions]
      rw [hE, card_empty, Nat.cast_zero]
      exact mul_nonneg hC.le (by positivity)
    have hN₀ : 0 < N := Nat.pos_of_ne_zero hN
    have hNcast : (1 : ℝ) ≤ N := by exact_mod_cast hN₀
    by_cases hsmall : N < 2 * T + 2
    · have hc : (N : ℝ) ≤ C := (show (N : ℝ) ≤ 2 * (T : ℝ) + 2 by
        exact_mod_cast hsmall.le).trans (le_max_left _ _)
      have hNpow : 1 ≤ (N : ℝ) ^ α := Real.one_le_rpow hNcast hα.le
      calc
        _ ≤ ((Icc 1 N).card : ℝ) := by
          have hSub : capacityExceptions (Icc 1 N) ⊆ Icc 1 N := Finset.filter_subset _ _
          exact_mod_cast Finset.card_le_card hSub
        _ = (N : ℝ) := by simp [Nat.card_Icc]
        _ ≤ C := hc
        _ ≤ _ := le_mul_of_one_le_right hC.le hNpow
    let a := N / 2
    let b := (N + 1) / 2
    have hTa : T ≤ b := by dsimp [b]; omega
    have hNa : a < N := Nat.div_lt_self hN₀ (by decide)
    have hNb : b ≤ N := by dsimp [b]; omega
    have hN₂ : N ≤ 2 * b := by dsimp [b]; omega
    let F := capacityExceptions (Icc 1 a)
    let G := capacityExceptions (Icc b (2 * b))
    have hSub : capacityExceptions (Icc 1 N) ⊆ F ∪ G := by
      intro n hn
      obtain ⟨hnIcc,hBad⟩ := Finset.mem_filter.mp hn
      obtain ⟨hOne,hnN⟩ := Finset.mem_Icc.mp hnIcc
      apply Finset.mem_union.mpr
      by_cases hna : n ≤ a
      · exact Or.inl (Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨hOne,hna⟩,hBad⟩)
      · have hbn : b ≤ n := by dsimp [a,b] at *; omega
        exact Or.inr (Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨hbn,hnN.trans hN₂⟩,hBad⟩)
    have hCard : ((capacityExceptions (Icc 1 N)).card : ℝ) ≤ (F.card : ℝ) + (G.card : ℝ) := by
      exact_mod_cast (Finset.card_le_card hSub).trans (Finset.card_union_le F G)
    have hA : (a : ℝ) ^ α ≤ r * (N : ℝ) ^ α := calc
      _ ≤ ((N : ℝ) / 2) ^ α := Real.rpow_le_rpow (by positivity) Nat.cast_div_le hα.le
      _ = _ := by
        rw [show (N : ℝ) / 2 = (1 / 2 : ℝ) * (N : ℝ) by ring,
          Real.mul_rpow (by norm_num) (by positivity)]
    have hB : (b : ℝ) ^ α ≤ (N : ℝ) ^ α :=
      Real.rpow_le_rpow (by positivity) (by exact_mod_cast hNb) hα.le
    have hComp : C * r + D ≤ C := by linarith only [hDC]
    calc
      _ ≤ (F.card : ℝ) + (G.card : ℝ) := hCard
      _ ≤ C * (a : ℝ) ^ α + D * (b : ℝ) ^ α := add_le_add (ih a hNa) (hT b hTa)
      _ ≤ C * (r * (N : ℝ) ^ α) + D * (N : ℝ) ^ α :=
        add_le_add (mul_le_mul_of_nonneg_left hA hC.le) (mul_le_mul_of_nonneg_left hB hD)
      _ = (C * r + D) * (N : ℝ) ^ α := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_right hComp (by positivity)

/-- The F2 exception bound, conditional on local-capacity attainment and
approximation by harmonic mass. -/
theorem capacity_integer_values_except_band {A : ℝ} (hA : 0 ≤ A)
    (hAttain : CapacityAttainment A) (hApprox : CapacityNearHarmonic) :
    ∃ C : ℝ, 0 < C ∧ ∀ X : ℕ, ∃ E ⊆ Icc 1 X,
      (E.card : ℝ) ≤ C * ((X : ℝ) ^ (11 / 12 : ℝ)) ∧
      ∀ n ∈ Icc 1 X, n ∉ E → (k n : ℤ) = ⌊capacity n⌋ ∧ (h n : ℤ) = ⌊capacity n⌋ := by
  obtain ⟨C,hC,hCard⟩ := card_capacityExceptions_le hA hAttain hApprox
  refine ⟨C,hC,fun X => ⟨capacityExceptions (Icc 1 X), Finset.filter_subset _ _, hCard X, ?_⟩⟩
  intro n hn hnE
  apply equals_floor_capacity_of_not_exception
  intro hBad
  exact hnE (Finset.mem_filter.mpr ⟨hn,(Finset.mem_filter.mp hBad).2⟩)


end LeanAB.PaperB
