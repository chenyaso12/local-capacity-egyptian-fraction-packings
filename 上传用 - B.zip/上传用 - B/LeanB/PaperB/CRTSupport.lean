module

public import Mathlib.NumberTheory.Harmonic.Defs
public import Mathlib.NumberTheory.Chebyshev
meta import Mathlib.Tactic

/-! Uniform bounds for the integer representatives obtained by clearing CRT denominators. -/

@[expose] public section

open Filter
open scoped BigOperators Topology

namespace LeanAB.PaperB

private theorem log_lcmUpto_le_six (q : ℕ) : Real.log (Nat.lcmUpto q : ℝ) ≤ 6 * q := by
  rw [← Chebyshev.psi_eq_log_lcmUpto]
  have hlog : Real.log 4 ≤ 2 := by
    rw [show (4 : ℝ) = 2 * 2 by norm_num, Real.log_mul (by norm_num) (by norm_num)]
    linarith [Real.log_lt_sub_one_of_pos (show (0 : ℝ) < 2 by norm_num) (by norm_num)]
  exact (Chebyshev.psi_le_const_mul_self (show (0 : ℝ) ≤ q by positivity)).trans
    (by gcongr; linarith)

private theorem harmonic_nonneg_and_le (n : ℕ) :
    0 ≤ harmonic n ∧ harmonic n ≤ (n : ℚ) := by
  unfold harmonic
  constructor
  · positivity
  · calc
      _ ≤ ∑ i ∈ Finset.range n, (1 : ℚ) := by
        apply Finset.sum_le_sum
        intro i _
        apply inv_le_one_of_one_le₀
        exact_mod_cast Nat.succ_le_succ (Nat.zero_le i)
      _ = _ := by simp

/-- A denominator with the stipulated product and cofactor scales gives CRT
representatives in an interval of length at most \(\exp(2x)\). -/
theorem eventually_crt_support_le :
    ∀ᶠ x : ℝ in atTop, ∀ T W M : ℕ,
      (T : ℝ) ≤ x / 100 → (W : ℝ) ≤ 6 * x → 0 < M →
      Real.log (M : ℝ) ≤ (7 / 4) * x →
      ((M * Nat.lcmUpto T : ℕ) : ℝ) * (harmonic (W * T) : ℝ) ≤ Real.exp (2 * x) := by
  filter_upwards [eventually_ge_atTop (400 : ℝ)] with x hx T W M hT hW hM hlogM
  have hx0 : 0 ≤ x := by linarith
  have hMR : (0 : ℝ) < M := by exact_mod_cast hM
  have hLR : (0 : ℝ) < Nat.lcmUpto T := by exact_mod_cast Nat.lcmUpto_pos T
  have hlog : Real.log ((M : ℝ) * Nat.lcmUpto T) ≤ (19 / 10) * x := by
    rw [Real.log_mul hMR.ne' hLR.ne']
    linarith [log_lcmUpto_le_six T]
  have hC : ((M * Nat.lcmUpto T : ℕ) : ℝ) ≤ Real.exp ((19 / 10) * x) := by
    rw [Nat.cast_mul, ← Real.exp_log (mul_pos hMR hLR)]
    exact Real.exp_le_exp.mpr hlog
  have hmass : (harmonic (W * T) : ℝ) ≤ (x * 6) * (x / 100) := calc
    _ ≤ ((W * T : ℕ) : ℝ) := by exact_mod_cast (harmonic_nonneg_and_le (W * T)).2
    _ ≤ _ := by
      rw [Nat.cast_mul, mul_comm x 6]
      exact mul_le_mul hW hT (Nat.cast_nonneg _) (by positivity)
  have hcubic : (x * 6) * (x / 100) ≤ Real.exp (x / 10) := by
    have hexp := Real.pow_div_factorial_le_exp (x / 10) (show 0 ≤ x / 10 by positivity) 3
    norm_num [Nat.factorial] at hexp
    refine le_trans ?_ hexp
    nlinarith [mul_nonneg (sq_nonneg x) (sub_nonneg.mpr hx), sq_nonneg x]
  calc
    _ ≤ Real.exp ((19 / 10) * x) * Real.exp (x / 10) := by
      apply mul_le_mul hC (hmass.trans hcubic)
      · exact_mod_cast (harmonic_nonneg_and_le (W * T)).1
      · positivity
    _ = _ := by rw [← Real.exp_add]; congr 1; ring

end LeanAB.PaperB
