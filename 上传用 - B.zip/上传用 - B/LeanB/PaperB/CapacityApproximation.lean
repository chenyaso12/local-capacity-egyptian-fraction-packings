module

public import PaperB.IntegerBand
public import PaperB.PointwiseCover
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.Algebra.Order.Floor.Semifield
meta import Mathlib.Tactic

/-! Compare local capacity with harmonic mass by scaling modular covers into their original blocks. -/

@[expose] public section

open Filter Finset Asymptotics
open scoped BigOperators Topology

namespace LeanAB.PaperB

theorem deletionCost_nonneg (N p : ℕ) : 0 ≤ deletionCost N p := by
  obtain ⟨D, _, hD⟩ := (deletionCost_spec N p).1
  rw [← hD]
  exact mass_nonneg D

theorem deletionCost_le_cofactorMass (N p : ℕ) :
    deletionCost N p ≤ mass (cofactorBlock N p) := by
  apply (deletionCost_spec N p).2
  exact ⟨_, mem_filter.mpr ⟨mem_powerset.mpr (Subset.refl _), by simp [cofactorResidue]⟩, rfl⟩

/-- A cover of every residue in [1,Q] lets the deletion from a full cofactor
block be dilated by floor(q/Q), substantially reducing its reciprocal mass. -/
theorem deletionCost_div_le_of_scaled_cover {N p Q : ℕ} (hp : p ∈ largePrimes N)
    (hQ : 0 < Q) (hQq : Q ≤ N / p)
    (hCover : ∀ z : ZMod p, ∃ J ⊆ denominators Q, cofactorResidue p J = z) :
    deletionCost N p / p ≤ 4 * (Q : ℚ) * mass (denominators Q) / N := by
  classical
  obtain ⟨hPrime,hpN,_⟩ := mem_largePrimes.mp hp
  let _ : Fact p.Prime := ⟨hPrime⟩
  let q := N / p
  let t := q / Q
  have ht : 0 < t := Nat.div_pos hQq hQ
  have htq : t ≤ q := Nat.div_le_self _ _
  have htp : t < p := htq.trans_lt (cofactor_lt_prime hp)
  have htMod : (t : ZMod p) ≠ 0 := fun h =>
    (not_le_of_gt htp) (Nat.le_of_dvd ht ((ZMod.natCast_eq_zero_iff _ _).mp h))
  let block := cofactorBlock N p
  obtain ⟨J,hJ,hJMod⟩ := hCover ((t : ZMod p) * cofactorResidue p block)
  let D := J.image (t * ·)
  have hD : D ⊆ block := by
    intro b hb
    obtain ⟨a,ha,rfl⟩ := mem_image.mp hb
    obtain ⟨hal,hah⟩ := mem_Icc.mp (hJ ha)
    exact mem_Icc.mpr ⟨Nat.mul_pos ht hal,
      (Nat.mul_le_mul_left t hah).trans (Nat.div_mul_le_self q Q)⟩
  have hResidue : cofactorResidue p D = cofactorResidue p block := by
    have hMul : cofactorResidue p D = (t : ZMod p)⁻¹ * cofactorResidue p J := by
      dsimp [D]
      rw [cofactorResidue, Finset.sum_image (fun a _ b _ hab => Nat.eq_of_mul_eq_mul_left ht hab),
        cofactorResidue, Finset.mul_sum]
      exact Finset.sum_congr rfl (fun a _ => by simp only [Nat.cast_mul, mul_inv])
    rw [hMul, hJMod, ← mul_assoc, inv_mul_cancel₀ htMod, one_mul]
  have hRemain : cofactorResidue p (block \ D) = 0 := by
    have hs : cofactorResidue p (block \ D) + cofactorResidue p D = cofactorResidue p block :=
      Finset.sum_sdiff hD
    rw [hResidue] at hs
    exact add_right_cancel (hs.trans (zero_add _).symm)
  have hDel : D ∈ deletions N p := mem_filter.mpr ⟨mem_powerset.mpr hD, hRemain⟩
  have hCost : deletionCost N p ≤ mass D :=
    (deletionCost_spec N p).2 ⟨D,hDel,rfl⟩
  have hMass : mass D ≤ mass (denominators Q) / t := calc
    _ = mass J / t := mass_image_mul t ht J
    _ ≤ _ := div_le_div_of_nonneg_right (mass_mono hJ) (by positivity)
  have qpos : 0 < q := hQ.trans_le hQq
  have hqUb : q ≤ (2 : ℕ) * t * Q := by
    have hh := (Nat.div_lt_iff_lt_mul hQ).mp (show q / Q < t + 1 from Nat.lt_succ_self t)
    exact hh.le.trans (Nat.mul_le_mul_right _ (by omega))
  have hNub : N ≤ 4 * Q * (t * p) := calc
    _ ≤ (q + 1) * p := ((Nat.div_lt_iff_lt_mul hPrime.pos).mp
      (show N / p < q + 1 from Nat.lt_succ_self q)).le
    _ ≤ 2 * q * p := Nat.mul_le_mul_right p (by omega)
    _ ≤ 2 * (2 * t * Q) * p := Nat.mul_le_mul_right p (Nat.mul_le_mul_left 2 hqUb)
    _ = _ := by ring
  have hH : 0 ≤ mass (denominators Q) := mass_nonneg _
  have hNpos : (0 : ℚ) < N := by exact_mod_cast hPrime.pos.trans_le hpN
  have htpos : (0 : ℚ) < (t : ℚ) * p :=
    mul_pos (by exact_mod_cast ht) (by exact_mod_cast hPrime.pos)
  calc
    _ ≤ (mass (denominators Q) / t) / p :=
      div_le_div_of_nonneg_right (hCost.trans hMass) (by positivity)
    _ = _ / ((t : ℚ) * p) := div_div ..
    _ ≤ _ := (div_le_div_iff₀ htpos hNpos).mpr (by
      have h := mul_le_mul_of_nonneg_left
        (show (N : ℚ) ≤ 4 * Q * ((t : ℚ) * p) by exact_mod_cast hNub) hH
      nlinarith only [h])


/-- The total deficit of local capacity relative to harmonic mass. -/
theorem capacity_deficit_eq_sum (N : ℕ) :
    (_root_.harmonic N : ℝ) - (capacity N : ℝ) =
      ∑ p ∈ largePrimes N, (deletionCost N p : ℝ) / p := by
  rw [← mass_denominators_eq_harmonic, capacity, Rat.cast_sub, sub_sub_cancel, Rat.cast_sum]
  exact Finset.sum_congr rfl (fun _ _ => by rw [Rat.cast_div, Rat.cast_natCast])

theorem capacity_le_harmonic (N : ℕ) : (capacity N : ℝ) ≤ (_root_.harmonic N : ℝ) := by
  apply sub_nonneg.mp
  rw [capacity_deficit_eq_sum]
  exact sum_nonneg fun p _ => div_nonneg (by exact_mod_cast deletionCost_nonneg N p) (Nat.cast_nonneg p)

/-- Split the deficit at q=Q. For long blocks one charges a scaled cover, and
for short blocks one charges only the exact mass of their high-prime window. -/
theorem capacity_deficit_le_window_of_cover {N Q : ℕ} (hQ : 0 < Q)
    (hCover : ∀ p ∈ largePrimes N, Q ≤ N / p →
      ∀ z : ZMod p, ∃ J ⊆ denominators Q, cofactorResidue p J = z) :
    (_root_.harmonic N : ℝ) - (capacity N : ℝ) ≤
      (4 * (Q : ℝ) * (_root_.harmonic Q : ℝ) / N) * (Nat.primeCounting (N / Q) : ℝ) +
        windowPrimeMass N (Real.log (Q : ℝ)) := by
  classical
  let small := (largePrimes N).filter (Q ≤ N / ·)
  let large := (largePrimes N).filter (fun p => ¬ Q ≤ N / p)
  let A := 4 * (Q : ℝ) * (_root_.harmonic Q : ℝ) / N
  have hQ₀ : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hA : 0 ≤ A := by
    have h : (0 : ℝ) ≤ (_root_.harmonic Q : ℝ) := by
      rw [← mass_denominators_eq_harmonic]
      exact_mod_cast mass_nonneg (denominators Q)
    dsimp [A]
    positivity
  have hs : small ⊆ Nat.primesLE (N / Q) := by
    intro p hp
    obtain ⟨hp,hq⟩ := mem_filter.mp hp
    obtain ⟨hPrime,_,_⟩ := mem_largePrimes.mp hp
    have hmul := (Nat.le_div_iff_mul_le hPrime.pos).mp hq
    exact Nat.mem_primesLE.mpr ⟨(Nat.le_div_iff_mul_le hQ).mpr (by simpa [mul_comm] using hmul),hPrime⟩
  have hSmall : (∑ p ∈ small, (deletionCost N p : ℝ) / p) ≤ A * (Nat.primeCounting (N / Q) : ℝ) :=
    calc
      _ ≤ ∑ _p ∈ small, A := by
        apply Finset.sum_le_sum
        intro p hp
        obtain ⟨hp,hq⟩ := mem_filter.mp hp
        have hCost := deletionCost_div_le_of_scaled_cover hp hQ hq (hCover p hp hq)
        rw [mass_denominators_eq_harmonic] at hCost
        dsimp [A]
        exact_mod_cast hCost
      _ = (small.card : ℝ) * A := by rw [Finset.sum_const, nsmul_eq_mul]
      _ ≤ _ := by
        rw [mul_comm A]
        apply mul_le_mul_of_nonneg_right _ hA
        exact_mod_cast (card_le_card hs).trans_eq (Nat.primesLE_card_eq_primeCounting (N / Q))
  have hLog : (N : ℝ) * Real.exp (-Real.log (Q : ℝ)) = (N : ℝ) / Q := by
    rw [Real.exp_neg, Real.exp_log hQ₀, div_eq_mul_inv]
  have hl : large ⊆ primesBetween ((N : ℝ) / Q) N := by
    intro p hp
    obtain ⟨hp,hq⟩ := mem_filter.mp hp
    obtain ⟨hPrime,hpN,_⟩ := mem_largePrimes.mp hp
    have hmul := (Nat.div_lt_iff_lt_mul hPrime.pos).mp (lt_of_not_ge hq)
    exact (mem_primesBetween (by positivity) (by positivity)).mpr
      ⟨(div_lt_iff₀ hQ₀).mpr (by exact_mod_cast (by simpa [mul_comm] using hmul : N < p * Q)),
        by exact_mod_cast hpN, hPrime⟩
  have hLarge : (∑ p ∈ large, (deletionCost N p : ℝ) / p) ≤ windowPrimeMass N (Real.log Q) := by
    rw [windowPrimeMass, hLog]
    calc
      _ ≤ ∑ p ∈ large, (mass (cofactorBlock N p) : ℝ) / p := by
        apply Finset.sum_le_sum
        intro p hp
        exact div_le_div_of_nonneg_right (by exact_mod_cast deletionCost_le_cofactorMass N p)
          (Nat.cast_nonneg _)
      _ ≤ _ := Finset.sum_le_sum_of_subset_of_nonneg hl fun p _ _ =>
        div_nonneg (by exact_mod_cast mass_nonneg (cofactorBlock N p)) (Nat.cast_nonneg p)
  have hSplit : (∑ p ∈ largePrimes N, (deletionCost N p : ℝ) / p) =
      (∑ p ∈ small, (deletionCost N p : ℝ) / p) + ∑ p ∈ large, (deletionCost N p : ℝ) / p := by
    exact (Finset.sum_filter_add_sum_filter_not (largePrimes N)
      (fun p => Q ≤ N / p) (fun p => (deletionCost N p : ℝ) / p)).symm
  rw [capacity_deficit_eq_sum,hSplit]
  exact add_le_add hSmall hLarge



private theorem eventually_primeCounting_le_twice :
    ∀ᶠ n : ℕ in atTop, (Nat.primeCounting n : ℝ) ≤ 2 * ((n : ℝ) / Real.log n) := by
  have h := (isEquivalent_iff_tendsto_one (by
    filter_upwards [eventually_gt_atTop (1 : ℝ)] with x hx
    exact div_ne_zero (zero_lt_one.trans hx).ne' (Real.log_pos hx).ne')).mp
      Nat.isEquivalent_primeCounting
  have hc : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  filter_upwards [(h.comp hc).eventually_lt_const (show (1 : ℝ) < 2 by norm_num),
    eventually_ge_atTop (2 : ℕ)] with n hn hn₂
  have hn₁ : (1 : ℝ) < n := by exact_mod_cast (by omega : 1 < n)
  have hpos : 0 < (n : ℝ) / Real.log n := div_pos (zero_lt_one.trans hn₁) (Real.log_pos hn₁)
  have hratio : (Nat.primeCounting n : ℝ) / ((n : ℝ) / Real.log n) < 2 := by
    simpa only [Function.comp_apply, Pi.div_apply, Nat.floor_natCast] using hn
  exact ((div_lt_iff₀ hpos).mp hratio).le

private theorem eventually_capacity_cover_cutoff_bounds :
    ∀ᶠ N : ℕ in atTop, let x := (N : ℝ); let L := Real.log x; let U := Real.log L
      let Q := ⌈L ^ 4⌉₊; let w := Real.log (Q : ℝ)
      1 < x ∧ 0 < Q ∧ (Q : ℝ) ≤ x ^ (1 / 4 : ℝ) ∧ 2 ≤ x ^ (1 / 4 : ℝ) ∧
      1 ≤ U ∧ 1 ≤ w ∧ w ≤ 5 * U ∧ 2 * w ≤ L ∧ w^2 ≤ L := by
  have hc : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hL := Real.tendsto_log_atTop.comp hc
  have hU := Real.tendsto_log_atTop.comp hL
  have hP := (tendsto_rpow_atTop (y := (1 / 4 : ℝ)) (by norm_num)).comp hc
  have hSmall := (isLittleO_log_rpow_rpow_atTop (s := (1 / 4 : ℝ)) 4 (by norm_num)).bound
    (show (0 : ℝ) < 1 / 2 by norm_num)
  have hTiny := (isLittleO_log_rpow_atTop (r := (1 / 2 : ℝ)) (by norm_num)).bound
    (show (0 : ℝ) < 1 / 5 by norm_num)
  filter_upwards [eventually_ge_atTop (2 : ℕ), hL.eventually_ge_atTop (max 4 (Real.exp 1)),
    hU.eventually_ge_atTop 1, hP.eventually_ge_atTop 2, hc.eventually hSmall,
    hL.eventually hTiny] with N hN hL hU hP hSmall hTiny
  let x : ℝ := N
  let L := Real.log x
  let U := Real.log L
  let Q := ⌈L ^ 4⌉₊
  let w := Real.log (Q : ℝ)
  change max 4 (Real.exp 1) ≤ L at hL
  change 1 ≤ U at hU
  change (2 : ℝ) ≤ x ^ (1 / 4 : ℝ) at hP
  change ‖L ^ (4 : ℝ)‖ ≤ (1 / 2 : ℝ) * ‖x ^ (1 / 4 : ℝ)‖ at hSmall
  change ‖U‖ ≤ (1 / 5 : ℝ) * ‖L ^ (1 / 2 : ℝ)‖ at hTiny
  have hx : 1 < x := by change (1 : ℝ) < (N : ℝ); exact_mod_cast (by omega : 1 < N)
  have hL₄ : 4 ≤ L := (le_max_left _ _).trans hL
  have hL₁ : 1 ≤ L := by linarith
  have hL₀ : 0 < L := zero_lt_one.trans_le hL₁
  have hPow : L ^ (4 : ℕ) ≤ (1 / 2 : ℝ) * x ^ (1 / 4 : ℝ) := by
    have hcast : (4 : ℝ) = ((4 : ℕ) : ℝ) := by norm_num
    simpa only [hcast, Real.rpow_natCast, Real.norm_eq_abs, abs_of_nonneg (pow_nonneg hL₀.le _),
      abs_of_nonneg (Real.rpow_nonneg (zero_le_one.trans hx.le) _)] using hSmall
  have hQL : L ^ (4 : ℕ) ≤ (Q : ℝ) := Nat.le_ceil _
  have hQpos : 0 < (Q : ℝ) := (pow_pos hL₀ _).trans_le hQL
  have hQUpper : (Q : ℝ) ≤ L ^ (4 : ℕ) + 1 := by
    have h : (Q : ℝ) ≤ ((⌊L ^ (4 : ℕ)⌋₊ + 1 : ℕ) : ℝ) := by
      exact_mod_cast Nat.ceil_le_floor_add_one (L ^ (4 : ℕ))
    rw [Nat.cast_succ] at h
    exact h.trans (add_le_add_left (Nat.floor_le (pow_nonneg hL₀.le _)) _)
  have hQx : (Q : ℝ) ≤ x ^ (1 / 4 : ℝ) := by linarith only [hQUpper,hPow,hP]
  have hLQ : L ≤ (Q : ℝ) := (le_self_pow₀ hL₁ (by decide : 4 ≠ 0)).trans hQL
  have hw₁ : 1 ≤ w := (Real.le_log_iff_exp_le hQpos).mpr ((le_max_right _ _).trans (hL.trans hLQ))
  have hwU : w ≤ 5 * U := calc
    _ ≤ Real.log (2 * L ^ (4 : ℕ)) := Real.log_le_log hQpos (by
      linarith only [hQUpper, one_le_pow₀ hL₁ (n := 4)])
    _ = Real.log 2 + 4 * U := by
      rw [Real.log_mul (by norm_num) (pow_pos hL₀ _).ne', Real.log_pow]
      rfl
    _ ≤ _ := by linarith only [hU, Real.log_le_sub_one_of_pos (show (0 : ℝ) < 2 by norm_num)]
  have hUR : U ≤ (1 / 5 : ℝ) * Real.sqrt L := by
    simpa only [Real.norm_eq_abs, abs_of_nonneg (zero_le_one.trans hU), ← Real.sqrt_eq_rpow,
      abs_of_nonneg (Real.sqrt_nonneg L)] using hTiny
  have hwR : w ≤ Real.sqrt L := by linarith only [hwU,hUR]
  have hs₂ : 2 ≤ Real.sqrt L := by
    have h := Real.sqrt_le_sqrt hL₄
    rwa [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (show (0 : ℝ) ≤ 2 by norm_num)] at h
  have hHalf : 2 * w ≤ L := by
    have h := mul_le_mul_of_nonneg_right hs₂ (Real.sqrt_nonneg L)
    rw [Real.mul_self_sqrt hL₀.le] at h
    linarith only [hwR,h]
  have hWsq : w ^ 2 ≤ L :=
    (pow_le_pow_left₀ (zero_le_one.trans hw₁) hwR _).trans_eq (Real.sq_sqrt hL₀.le)
  exact ⟨hx, by exact_mod_cast hQpos, hQx, hP, hU, hw₁, hwU, hHalf, hWsq⟩



/-- The capacity deficit is O((log log N)^2/log N). This uses the proven
pointwise modular covers, with no cover or counting hypothesis in its type. -/
theorem eventually_capacity_harmonic_error :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      |(capacity N : ℝ) - (_root_.harmonic N : ℝ)| ≤
        C * (Real.log (Real.log (N : ℝ)))^2 / Real.log (N : ℝ) := by
  obtain ⟨T₁,hT₁⟩ := eventually_atTop.mp Closure.eventually_pointwise_reciprocal_cover
  obtain ⟨T₂,hT₂⟩ := eventually_atTop.mp eventually_primeCounting_le_twice
  obtain ⟨C,hC,hWindow⟩ := eventually_windowPrimeMass_error
  refine ⟨109 + 5 * C, by positivity, ?_⟩
  filter_upwards [eventually_capacity_cover_cutoff_bounds, eventually_ge_atTop (T₁ * T₁),
    eventually_ge_atTop (T₂ ^ 2), hWindow] with N hN hT₁N hT₂N hWindow
  let x : ℝ := N
  let L := Real.log x
  let U := Real.log L
  let Q := ⌈L ^ 4⌉₊
  let w := Real.log (Q : ℝ)
  let z := N / Q
  obtain ⟨hx,hQ,hQx,hQmin,hU,hw,hwU,hHalf,hSq⟩ := hN
  have hx₀ : 0 < x := zero_lt_one.trans hx
  have hL₀ : 0 < L := Real.log_pos hx
  have hU₀ : 0 ≤ U := zero_le_one.trans hU
  have hQ₀ : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hCovers (p : ℕ) (hp : p ∈ largePrimes N) (_ : Q ≤ N / p) :
      ∀ r : ZMod p, ∃ J ⊆ denominators Q, cofactorResidue p J = r := by
    obtain ⟨hPrime,hpN,hLarge⟩ := mem_largePrimes.mp hp
    have hTp := (Nat.le_sqrt.mpr hT₁N).trans hLarge.le
    intro r
    obtain ⟨J,hJ,hMod⟩ := hT₁ p hTp hPrime r
    have hlog : Real.log (p : ℝ) ≤ L := Real.log_le_log (by exact_mod_cast hPrime.pos)
      (by change (p : ℝ) ≤ (N : ℝ); exact_mod_cast hpN)
    have hpos : 0 ≤ Real.log (p : ℝ) :=
      Real.log_nonneg (by exact_mod_cast hPrime.one_le)
    have hCut : ⌈Real.log (p : ℝ) ^ 4⌉₊ ≤ Q :=
      Nat.ceil_mono (pow_le_pow_left₀ hpos hlog _)
    refine ⟨J, ?_, hMod⟩
    intro a ha
    obtain ⟨ha₀,haQ⟩ := Finset.mem_Icc.mp (hJ ha)
    exact Finset.mem_Icc.mpr ⟨ha₀,haQ.trans hCut⟩
  have hEstimate := capacity_deficit_le_window_of_cover (N := N) hQ hCovers
  have hYge : 2 * Real.sqrt x ≤ x / (Q : ℝ) := calc
    _ ≤ Real.sqrt x * x ^ (1 / 4 : ℝ) := by
      simpa only [mul_comm] using mul_le_mul_of_nonneg_left hQmin (Real.sqrt_nonneg x)
    _ = x ^ (3 / 4 : ℝ) := by rw [Real.sqrt_eq_rpow, ← Real.rpow_add hx₀]; norm_num
    _ = x / x ^ (1 / 4 : ℝ) := by
      rw [show (3 / 4 : ℝ) = 1 - 1 / 4 by norm_num, Real.rpow_sub hx₀, Real.rpow_one]
    _ ≤ _ := div_le_div_of_nonneg_left hx₀.le hQ₀ hQx
  have hZFloor : x / (Q : ℝ) - 1 ≤ (z : ℝ) := by
    have hf := (Nat.lt_floor_add_one (x / (Q : ℝ))).le
    rw [show ⌊x / (Q : ℝ)⌋₊ = z from Nat.floor_div_eq_div ..] at hf
    linarith only [hf]
  have hSQ₁ : 1 ≤ Real.sqrt x := calc
    _ = Real.sqrt 1 := by norm_num
    _ ≤ _ := Real.sqrt_le_sqrt hx.le
  have hzSQ : Real.sqrt x ≤ (z : ℝ) := by linarith only [hYge,hZFloor,hSQ₁]
  have hzUpper : (z : ℝ) ≤ x / (Q : ℝ) := Nat.cast_div_le
  have hTS : (T₂ : ℝ) ≤ Real.sqrt x := by
    apply (Real.le_sqrt (by positivity) hx₀.le).mpr
    change (T₂ : ℝ)^2 ≤ (N : ℝ)
    exact_mod_cast hT₂N
  have hzT : T₂ ≤ z := by exact_mod_cast hTS.trans hzSQ
  have hZlog : L / 2 ≤ Real.log (z : ℝ) := by
    have h := Real.log_le_log (zero_lt_one.trans_le hSQ₁) hzSQ
    rw [Real.sqrt_eq_rpow, Real.log_rpow hx₀] at h
    linarith only [h]
  have hPrimeCount : (Nat.primeCounting z : ℝ) ≤ 4 * (x / (Q : ℝ)) / L := calc
    _ ≤ 2 * ((z : ℝ) / Real.log (z : ℝ)) := hT₂ _ hzT
    _ ≤ 2 * ((x / (Q : ℝ)) / (L / 2)) := by
      apply mul_le_mul_of_nonneg_left _ (by norm_num)
      exact div_le_div₀ (by positivity) hzUpper (by positivity) hZlog
    _ = _ := by ring
  let H : ℝ := (_root_.harmonic Q : ℝ)
  have hH : 0 ≤ H := by
    change 0 ≤ (_root_.harmonic Q : ℝ)
    rw [← mass_denominators_eq_harmonic]
    exact_mod_cast mass_nonneg (denominators Q)
  have hHU : H ≤ 6 * U := by
    have hH := harmonic_le_one_add_log Q
    change H ≤ 1 + w at hH
    linarith only [hH,hwU,hU]
  have hUU : U ≤ U^2 := by nlinarith only [mul_le_mul_of_nonneg_right hU hU₀]
  have hSmall : (4 * (Q : ℝ) * H / x) * (Nat.primeCounting z : ℝ) ≤ 96 * U ^ 2 / L := calc
    _ ≤ (4 * (Q : ℝ) * H / x) * (4 * (x / (Q : ℝ)) / L) :=
      mul_le_mul_of_nonneg_left hPrimeCount (by positivity)
    _ = 16 * H / L := by
      field_simp [hx₀.ne',hQ₀.ne',hL₀.ne']
      ring
    _ ≤ _ := div_le_div_of_nonneg_right (by linarith only [hHU,hUU]) hL₀.le
  have hW := (abs_le.mp (hWindow w hw hHalf hSq)).2
  have hLarge : windowPrimeMass N w ≤ (13 + 5 * C) * U ^ 2 / L := by
    have hpw : w ^ 2 ≤ (5 * U)^2 := pow_le_pow_left₀ (zero_le_one.trans hw) hwU _
    have hlin : C * w ≤ 5 * C * U^2 := by
      have h := mul_le_mul_of_nonneg_left (hwU.trans (mul_le_mul_of_nonneg_left hUU (by norm_num))) hC.le
      nlinarith only [h]
    calc
      _ ≤ w ^ 2 / (2 * L) + C * w / L := by linarith only [hW]
      _ = (w ^ 2 / 2 + C * w) / L := by ring
      _ ≤ _ := div_le_div_of_nonneg_right (by nlinarith only [hpw,hlin,sq_nonneg U]) hL₀.le
  rw [abs_of_nonpos (sub_nonpos.mpr (capacity_le_harmonic N)), neg_sub]
  calc
    _ ≤ (4 * (Q : ℝ) * H / x) * (Nat.primeCounting z : ℝ) + windowPrimeMass N w := hEstimate
    _ ≤ (96 * U^2 / L) + (13 + 5 * C) * U^2 / L := add_le_add hSmall hLarge
    _ = _ := by ring



/-- Eventually the capacity is within one of harmonic mass, as needed in B7. -/
theorem capacityNearHarmonic : CapacityNearHarmonic := by
  obtain ⟨C,hC,hError⟩ := eventually_capacity_harmonic_error
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hSmall := (isLittleO_log_rpow_rpow_atTop (s := (1 : ℝ)) 2 one_pos).bound
    (show (0 : ℝ) < 1 / C by positivity)
  filter_upwards [hError, hLog.eventually hSmall, hLog.eventually_ge_atTop 2] with N hE hs hL
  let L := Real.log (N : ℝ)
  let U := Real.log L
  change (2 : ℝ) ≤ L at hL
  change ‖U ^ (2 : ℝ)‖ ≤ (1 / C) * ‖L ^ (1 : ℝ)‖ at hs
  have hL₀ : 0 < L := by linarith only [hL]
  have hU : U^2 ≤ (1 / C) * L := by
    have hc : (2 : ℝ) = ((2 : ℕ) : ℝ) := by norm_num
    simpa only [Real.norm_eq_abs, hc, Real.rpow_natCast, Real.rpow_one, abs_of_nonneg (sq_nonneg U),
      abs_of_nonneg hL₀.le] using hs
  calc
    _ ≤ C * U^2 / L := hE
    _ ≤ C * ((1 / C) * L) / L :=
      div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hU hC.le) hL₀.le
    _ = 1 := by field_simp [hC.ne',hL₀.ne']

/-- The 11/12 exception bound with only the near-capacity packing lower
bound exposed as an input. -/
theorem capacity_integer_values_except_band_of_attainment {A : ℝ} (hA : 0 ≤ A)
    (hAttain : CapacityAttainment A) :
    ∃ C : ℝ, 0 < C ∧ ∀ X : ℕ, ∃ E ⊆ Icc 1 X,
      (E.card : ℝ) ≤ C * ((X : ℝ) ^ (11 / 12 : ℝ)) ∧
      ∀ n ∈ Icc 1 X, n ∉ E → (k n : ℤ) = ⌊capacity n⌋ ∧ (h n : ℤ) = ⌊capacity n⌋ :=
  capacity_integer_values_except_band hA hAttain capacityNearHarmonic


end LeanAB.PaperB
