module

public import PaperB.RepairBudget
public import PaperB.SmoothClosure
public import PaperB.CapacityApproximation
meta import Mathlib.Tactic

/-! Parameters and exact repair at the marker scale of the local-capacity construction. -/

@[expose] public section

open Filter Finset Asymptotics
open scoped Topology

namespace LeanAB.PaperB.Closure

/-- The constant whose square gives the coefficient of N^(1/6) in the cutoff. -/
noncomputable def nearCapacityCutoffFactor (C : ℕ) : ℝ :=
  (4 * (C : ℝ)) ^ (-1 / 10 : ℝ)

/-- Integer cutoff for divisibility by lcm(1,...,z). -/
noncomputable def nearCapacityCutoff (N C : ℕ) : ℕ :=
  ⌊(nearCapacityCutoffFactor C * (N : ℝ) ^ (1 / 12 : ℝ)) ^ (2 : ℕ)⌋₊

/-- Rational residual parameters, with integer roots used before taking inverses. -/
def nearCapacityDelta (N : ℕ) : ℚ := (Nat.nthRoot 8 N : ℚ)⁻¹

def nearCapacityEta (N : ℕ) : ℚ := (Nat.nthRoot 4 N : ℚ)⁻¹

theorem nearCapacityCutoffFactor_pos {C : ℕ} (hC : 0 < C) :
    0 < nearCapacityCutoffFactor C := by
  unfold nearCapacityCutoffFactor
  exact Real.rpow_pos_of_pos (by positivity) _

private theorem rpow_nat_mul {x a : ℝ} (hx : 0 ≤ x) (k : ℕ) :
    (x ^ a) ^ k = x ^ (a * (k : ℝ)) := by
  rw [← Real.rpow_natCast, ← Real.rpow_mul hx]

/-- The marker interval in F2 is compatible with the cutoff, the exact
closure threshold, and the term budget, uniformly in the chosen marker. -/
theorem eventually_nearCapacity_marker_geometry (C X₀ : ℕ) (hC : 1 < C) :
    ∀ᶠ N : ℕ in atTop, ∀ P : ℕ, (N : ℝ) ^ (1 / 6 : ℝ) < (P : ℝ) →
      (P : ℝ) ≤ 2 * (N : ℝ) ^ (1 / 6 : ℝ) →
      let X := markerScale N C P
      X₀ ≤ X ∧ 0 < X ∧ 2 ≤ P * X ∧
      nearCapacityCutoff N C ≤ Nat.nthRoot 5 X ∧
      ((Nat.nthRoot 5 X : ℕ) : ℝ) < (N : ℝ) ^ (1 / 6 : ℝ) ∧
      P ≤ Nat.sqrt N ∧ 8 * P ≤ N ∧
      (C : ℝ) * (X : ℝ) ≤ (N : ℝ) ^ (5 / 6 : ℝ) := by
  let K : ℝ := 4 * (C : ℝ)
  have hCr : (1 : ℝ) < C := by exact_mod_cast hC
  have hC₀ : 0 < (C : ℝ) := zero_lt_one.trans hCr
  have hK : 0 < K := by dsimp [K]; positivity
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hSix := (tendsto_rpow_atTop (show 0 < (1 / 6 : ℝ) by norm_num)).comp hcast
  have hFive := (tendsto_rpow_atTop (show 0 < (5 / 6 : ℝ) by norm_num)).comp hcast
  filter_upwards [hSix.eventually_ge_atTop 2,
    hFive.eventually_ge_atTop (max 16 (K * ((X₀ : ℝ) + 1))),
    eventually_ge_atTop (1 : ℕ)] with N ht' hT' hN P hPL hPU
  let x : ℝ := N
  let t : ℝ := x ^ (1 / 6 : ℝ)
  let T : ℝ := x ^ (5 / 6 : ℝ)
  let X := markerScale N C P
  let q : ℝ := (C : ℝ) * (P : ℝ)
  let d := nearCapacityCutoffFactor C
  let Z := (d * x ^ (1 / 12 : ℝ)) ^ (2 : ℕ)
  have hx : 0 < x := by change (0 : ℝ) < (N : ℝ); exact_mod_cast (Nat.succ_le_iff.mp hN)
  have ht : 2 ≤ t := ht'
  have ht₀ : 0 < t := by linarith
  have hT : 16 ≤ T := (le_max_left _ _).trans hT'
  have hTX₀ : K * ((X₀ : ℝ) + 1) ≤ T := (le_max_right _ _).trans hT'
  have hT₀ : 0 < T := by linarith
  have hPL' : t < (P : ℝ) := hPL
  have hPU' : (P : ℝ) ≤ 2 * t := hPU
  have hP₀ : 0 < (P : ℝ) := ht₀.trans hPL'
  have hq : 0 < q := mul_pos hC₀ hP₀
  have htT : t * T = x := by
    dsimp only [t, T]
    rw [← Real.rpow_add hx, show (1 / 6 : ℝ) + 5 / 6 = 1 by norm_num, Real.rpow_one]
  have ht5 : t ^ (5 : ℕ) = T := by
    dsimp only [t, T]
    rw [rpow_nat_mul hx.le]
    norm_num
  have ht6 : t ^ (6 : ℕ) = x := by
    dsimp only [t]
    rw [rpow_nat_mul hx.le]
    norm_num
  have hFloor : X = ⌊x / q⌋₊ := by
    dsimp only [X, x, q, markerScale]
    rw [← Nat.cast_mul, Nat.floor_div_natCast, Nat.floor_natCast]
  have hXU : (X : ℝ) ≤ x / q :=
    hFloor ▸ Nat.floor_le (div_nonneg hx.le hq.le)
  have hXL : x / q < (X : ℝ) + 1 := hFloor ▸ Nat.lt_floor_add_one _
  have hQBound : T / (2 * (C : ℝ)) ≤ x / q := by
    apply (div_le_div_iff₀ (by positivity : 0 < 2 * (C : ℝ)) hq).mpr
    dsimp only [q]
    have h := mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left hPU' hC₀.le) hT₀.le
    rw [← htT]
    nlinarith only [h]
  have hCutLow : T / K ≤ (X : ℝ) := by
    have hB : (X₀ : ℝ) + 1 ≤ T / K := (le_div_iff₀ hK).mpr (by simpa only [mul_comm] using hTX₀)
    have hQeq : T / (2 * (C : ℝ)) = 2 * (T / K) := by dsimp [K]; ring
    rw [hQeq] at hQBound
    linarith only [hQBound, hB, hXL, Nat.cast_nonneg (α := ℝ) X₀]
  have hX1 : 1 ≤ X := by
    have hB : (X₀ : ℝ) + 1 ≤ T / K := (le_div_iff₀ hK).mpr (by simpa only [mul_comm] using hTX₀)
    have h : (1 : ℝ) ≤ (X : ℝ) := by linarith only [hB.trans hCutLow, Nat.cast_nonneg (α := ℝ) X₀]
    exact_mod_cast h
  have hX0 : X₀ ≤ X := by
    have hB : (X₀ : ℝ) + 1 ≤ T / K := (le_div_iff₀ hK).mpr (by simpa only [mul_comm] using hTX₀)
    have h : (X₀ : ℝ) ≤ (X : ℝ) := by linarith only [hB.trans hCutLow]
    exact_mod_cast h
  have hXlt : (X : ℝ) < T := hXU.trans_lt (by
    apply (div_lt_iff₀ hq).mpr
    have hq' : t < q := hPL'.trans_le (le_mul_of_one_le_left hP₀.le hCr.le)
    rw [← htT, mul_comm t T]
    exact mul_lt_mul_of_pos_left hq' hT₀)
  have hZ5 : Z ^ (5 : ℕ) = T / K := by
    have hd : d ^ (10 : ℕ) = K⁻¹ := by
      change (K ^ (-1 / 10 : ℝ)) ^ (10 : ℕ) = _
      rw [rpow_nat_mul hK.le, show (-1 / 10 : ℝ) * ((10 : ℕ) : ℝ) = -1 by norm_num,
        Real.rpow_neg hK.le, Real.rpow_one]
    have hx' : (x ^ (1 / 12 : ℝ)) ^ (10 : ℕ) = T := by
      dsimp only [T]
      rw [rpow_nat_mul hx.le]
      norm_num
    dsimp only [Z]
    rw [← pow_mul, show (2 : ℕ) * 5 = 10 by decide, mul_pow, hd, hx']
    ring
  have hz : nearCapacityCutoff N C ≤ Nat.nthRoot 5 X := by
    apply (Nat.le_nthRoot_iff (by decide : (5 : ℕ) ≠ 0)).mpr
    have hF : ((nearCapacityCutoff N C : ℕ) : ℝ) ≤ Z := Nat.floor_le (sq_nonneg _)
    have hh := (pow_le_pow_left₀ (Nat.cast_nonneg _) hF 5).trans
      (hZ5 ▸ hCutLow)
    exact_mod_cast hh
  have hBelow : ((Nat.nthRoot 5 X : ℕ) : ℝ) < t := by
    by_contra! hh
    have hU0 : ((Nat.nthRoot 5 X : ℕ) : ℝ) ^ (5 : ℕ) ≤ (X : ℝ) := by
      exact_mod_cast (Nat.pow_nthRoot_le (n := 5) (a := X) (.inl (by decide)))
    exact (not_le_of_gt hXlt) (ht5 ▸ (pow_le_pow_left₀ ht₀.le hh 5).trans hU0)
  have hP2 : 2 ≤ P := by
    exact_mod_cast (ht.trans hPL'.le)
  have hP8 : 8 * P ≤ N := by
    have h : 8 * (P : ℝ) ≤ x := calc
      _ ≤ 16 * t := by linarith only [hPU']
      _ ≤ T * t := mul_le_mul_of_nonneg_right hT ht₀.le
      _ = _ := by rw [mul_comm, htT]
    exact_mod_cast (show 8 * (P : ℝ) ≤ (N : ℝ) from h)
  have hPS : P ≤ Nat.sqrt N := by
    apply Nat.le_sqrt'.mpr
    have h : (P : ℝ) ^ (2 : ℕ) ≤ x := calc
      _ ≤ (2 * t) ^ (2 : ℕ) := pow_le_pow_left₀ hP₀.le hPU' _
      _ = 4 * t ^ (2 : ℕ) := by ring
      _ ≤ t ^ (4 : ℕ) * t ^ (2 : ℕ) := by
        have hs : 4 ≤ t ^ (4 : ℕ) := by
          have hh := pow_le_pow_left₀ (show 0 ≤ (2 : ℝ) by norm_num) ht 4
          norm_num at hh
          linarith
        exact mul_le_mul_of_nonneg_right hs (by positivity)
      _ = x := by rw [← pow_add, show (4 : ℕ) + 2 = 6 by decide, ht6]
    exact_mod_cast (show (P : ℝ) ^ (2 : ℕ) ≤ (N : ℝ) from h)
  have hLength : (C : ℝ) * (X : ℝ) ≤ T := calc
    _ ≤ (C : ℝ) * (x / q) := mul_le_mul_of_nonneg_left hXU hC₀.le
    _ = x / (P : ℝ) := by dsimp only [q]; field_simp
    _ ≤ T := (div_le_iff₀ hP₀).mpr (by
          rw [← htT, mul_comm t T]
          exact mul_le_mul_of_nonneg_left hPL'.le hT₀.le)
  exact ⟨hX0, by omega, by simpa using Nat.mul_le_mul hP2 hX1,
    hz, hBelow, hPS, hP8, hLength⟩

/-- The smooth reserve and the medium cofactors use a cutoff below z. -/
theorem eventually_floor_twentieth_le_nearCapacityCutoff (C : ℕ) (hC : 0 < C) :
    ∀ᶠ N : ℕ in atTop, ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ ≤ nearCapacityCutoff N C := by
  let D := nearCapacityCutoffFactor C
  have hD : 0 < D := nearCapacityCutoffFactor_pos hC
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hGrow := (tendsto_rpow_atTop (show (0 : ℝ) < 1 / 6 - 1 / 20 by norm_num)).comp hcast
  filter_upwards [hGrow.eventually_ge_atTop (1 / D ^ 2), eventually_ge_atTop (1 : ℕ)]
    with N hG hN
  have hx : 0 < (N : ℝ) := by exact_mod_cast (Nat.succ_le_iff.mp hN)
  have hscale : 1 ≤ D ^ 2 * (N : ℝ) ^ (1 / 6 - 1 / 20 : ℝ) := by
    rw [mul_comm]
    exact (div_le_iff₀ (sq_pos_of_pos hD)).mp hG
  apply Nat.floor_mono
  calc
    (N : ℝ) ^ (1 / 20 : ℝ) ≤
        (D ^ 2 * (N : ℝ) ^ (1 / 6 - 1 / 20 : ℝ)) * (N : ℝ) ^ (1 / 20 : ℝ) := by
      exact le_mul_of_one_le_left (Real.rpow_nonneg hx.le _) hscale
    _ = (D * (N : ℝ) ^ (1 / 12 : ℝ)) ^ (2 : ℕ) := by
      rw [mul_assoc, ← Real.rpow_add hx, sub_add_cancel, mul_pow, rpow_nat_mul hx.le]
      congr 2
      norm_num

private theorem eventually_root_inverse_bounds (u : ℕ) (hu : 0 < u) :
    ∀ᶠ N : ℕ in atTop, let R := (Nat.nthRoot u N : ℚ)⁻¹
      0 < R ∧ (N : ℝ) ^ (-(1 / (u : ℝ))) ≤ (R : ℝ) ∧
        (R : ℝ) ≤ 2 * (N : ℝ) ^ (-(1 / (u : ℝ))) := by
  have hu' : (0 : ℝ) < u := by exact_mod_cast hu
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hGrow := (tendsto_rpow_atTop (one_div_pos.mpr hu')).comp hcast
  filter_upwards [hGrow.eventually_ge_atTop 2] with N hN
  let x : ℝ := (N : ℝ) ^ (1 / (u : ℝ))
  let b : ℝ := Nat.nthRoot u N
  have hx : 2 ≤ x := hN
  have hEq : b = (⌊x⌋₊ : ℝ) := by dsimp only [b, x]; rw [nthRoot_eq_floor_rpow u N hu]
  have hb₁ : b ≤ x := hEq ▸ Nat.floor_le (by linarith)
  have hb₂ : x / 2 ≤ b := by
    have h := Nat.lt_floor_add_one x
    rw [← hEq] at h
    linarith only [h, hx]
  have hb : 0 < b := by linarith
  have hx' : 0 < x := by linarith
  have hnat : 0 < Nat.nthRoot u N := by exact_mod_cast (show 0 < (Nat.nthRoot u N : ℝ) from hb)
  have hcastR : (((Nat.nthRoot u N : ℚ)⁻¹ : ℚ) : ℝ) = b⁻¹ := by simp [b]
  refine ⟨inv_pos.mpr (by exact_mod_cast hnat), ?_, ?_⟩
  · rw [Real.rpow_neg (Nat.cast_nonneg N), hcastR]
    exact inv_anti₀ hb hb₁
  · rw [Real.rpow_neg (Nat.cast_nonneg N), hcastR]
    calc
      _ ≤ (x / 2)⁻¹ := inv_anti₀ (by positivity) hb₂
      _ = _ := by rw [inv_div, div_eq_mul_inv]

/-- Integer roots give rational residual parameters at the exact exponents
used for the repair. They preserve both sides of the necessary size bounds. -/
theorem eventually_nearCapacity_residual_parameters :
    ∀ᶠ N : ℕ in atTop, 0 < nearCapacityDelta N ∧ 0 < nearCapacityEta N ∧
      nearCapacityEta N ≤ nearCapacityDelta N ∧
      (N : ℝ) ^ (-1 / 8 : ℝ) ≤ (nearCapacityDelta N : ℝ) ∧
      (nearCapacityDelta N : ℝ) ≤ 2 * (N : ℝ) ^ (-1 / 8 : ℝ) ∧
      (N : ℝ) ^ (-1 / 4 : ℝ) ≤ (nearCapacityEta N : ℝ) ∧
      (nearCapacityEta N : ℝ) ≤ 2 * (N : ℝ) ^ (-1 / 4 : ℝ) := by
  filter_upwards [eventually_root_inverse_bounds 8 (by decide), eventually_root_inverse_bounds 4 (by decide),
    eventually_ge_atTop (1 : ℕ)] with N hδ hη hN
  have hD : 0 < nearCapacityDelta N ∧ (N : ℝ) ^ (-1 / 8 : ℝ) ≤ (nearCapacityDelta N : ℝ) ∧
      (nearCapacityDelta N : ℝ) ≤ 2 * (N : ℝ) ^ (-1 / 8 : ℝ) := by
    simpa only [nearCapacityDelta, Nat.cast_ofNat, neg_div] using hδ
  have hE : 0 < nearCapacityEta N ∧ (N : ℝ) ^ (-1 / 4 : ℝ) ≤ (nearCapacityEta N : ℝ) ∧
      (nearCapacityEta N : ℝ) ≤ 2 * (N : ℝ) ^ (-1 / 4 : ℝ) := by
    simpa only [nearCapacityEta, Nat.cast_ofNat, neg_div] using hη
  have hRoot : Nat.nthRoot 8 N ≤ Nat.nthRoot 4 N := by
    rw [nthRoot_eq_floor_rpow 8 N (by decide), nthRoot_eq_floor_rpow 4 N (by decide)]
    exact Nat.floor_mono (Real.rpow_le_rpow_of_exponent_le (by exact_mod_cast hN) (by norm_num))
  have hRoot₀ : 0 < ((Nat.nthRoot 8 N : ℕ) : ℚ) := inv_pos.mp hD.1
  refine ⟨hD.1, hE.1, ?_, hD.2.1, hD.2.2, hE.2.1, hE.2.2⟩
  exact inv_anti₀ hRoot₀ (by exact_mod_cast hRoot)

/-- Quantitative estimates for the residual, the shared reserve and the number
of extra denominators used by the three near-capacity repairs. -/
theorem eventually_nearCapacity_repair_costs :
    ∀ᶠ N : ℕ in atTop,
      let x : ℝ := N
      let L := Real.log x
      let δ : ℝ := nearCapacityDelta N
      692 * ((⌈L ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) / Real.sqrt x ≤ δ / 2 ∧
      (∀ m : ℕ, (m : ℝ) ≤ 2 * L → 2 * (m : ℝ) * δ ≤
        ((⌈8 * L * x ^ (7 / 8 : ℝ)⌉₊ : ℕ) : ℝ) / x) ∧
      Real.sqrt x * L ^ (10 : ℕ) + x * (2 * δ) + x ^ (5 / 6 : ℝ) ≤ 6 * (x / L ^ 2) := by
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hcast
  have hPow := (tendsto_rpow_atTop (show 0 < (1 / 8 : ℝ) by norm_num)).comp hcast
  filter_upwards [eventually_ge_atTop (1 : ℕ), hLog.eventually_ge_atTop 1,
    hPow.eventually_ge_atTop 2768, eventually_nearCapacity_residual_parameters,
    eventually_log_pow_le_rpow 12 (show 0 < (1 / 4 : ℝ) by norm_num),
    eventually_log_pow_le_rpow 2 (show 0 < (1 / 8 : ℝ) by norm_num)]
    with N hN hLog hGrow hParameters hTwelve hTwo
  let x : ℝ := N
  let L := Real.log x
  let δ : ℝ := nearCapacityDelta N
  let Q := ⌈L ^ (12 : ℕ)⌉₊
  let W := ⌈8 * L * x ^ (7 / 8 : ℝ)⌉₊
  have hL : 1 ≤ L := hLog
  have hL₀ : 0 < L := zero_lt_one.trans_le hL
  have hx₁ : 1 ≤ x := by change (1 : ℝ) ≤ (N : ℝ); exact_mod_cast hN
  have hx : 0 < x := zero_lt_one.trans_le hx₁
  have hδ₀ : 0 ≤ δ := by change 0 ≤ (nearCapacityDelta N : ℝ); exact_mod_cast hParameters.1.le
  have hδL : x ^ (-1 / 8 : ℝ) ≤ δ := hParameters.2.2.2.1
  have hδU : δ ≤ 2 * x ^ (-1 / 8 : ℝ) := hParameters.2.2.2.2.1
  have hshift : x ^ (-1 / 8 : ℝ) * x = x ^ (7 / 8 : ℝ) := calc
    _ = x ^ (-1 / 8 : ℝ) * x ^ (1 : ℝ) := by rw [Real.rpow_one]
    _ = _ := by rw [← Real.rpow_add hx]; norm_num
  change 692 * (Q : ℝ) / Real.sqrt x ≤ δ / 2 ∧
    (∀ m : ℕ, (m : ℝ) ≤ 2 * L → 2 * (m : ℝ) * δ ≤ (W : ℝ) / x) ∧
    Real.sqrt x * L ^ (10 : ℕ) + x * (2 * δ) + x ^ (5 / 6 : ℝ) ≤ 6 * (x / L ^ 2)
  refine ⟨?_, ?_, ?_⟩
  · have hCeil : (Q : ℝ) ≤ 2 * x ^ (1 / 4 : ℝ) := by
      have h := (Nat.ceil_lt_add_one (pow_nonneg hL₀.le 12)).le
      have hOne : 1 ≤ L ^ (12 : ℕ) := one_le_pow₀ hL
      change L ^ (12 : ℕ) ≤ x ^ (1 / 4 : ℝ) at hTwelve
      dsimp only [Q]
      linarith only [h, hOne, hTwelve]
    have hSmall : x ^ (-1 / 8 : ℝ) ≤ (2768 : ℝ)⁻¹ := by
      rw [neg_div, Real.rpow_neg hx.le]
      exact inv_anti₀ (by norm_num) hGrow
    calc
      _ ≤ 1384 * x ^ (1 / 4 : ℝ) / Real.sqrt x :=
        div_le_div_of_nonneg_right (by linarith only [hCeil]) (Real.sqrt_nonneg _)
      _ = 1384 * x ^ (-1 / 4 : ℝ) := by
        rw [Real.sqrt_eq_rpow, mul_div_assoc, ← Real.rpow_sub hx]
        norm_num
      _ = (1384 * x ^ (-1 / 8 : ℝ)) * x ^ (-1 / 8 : ℝ) := by
        rw [mul_assoc, ← Real.rpow_add hx]
        norm_num
      _ ≤ (1 / 2) * x ^ (-1 / 8 : ℝ) :=
        mul_le_mul_of_nonneg_right (by linarith only [hSmall]) (Real.rpow_nonneg hx.le _)
      _ ≤ _ := by linarith only [hδL]
  · intro m hm
    calc
      _ ≤ (2 * (2 * L)) * (2 * x ^ (-1 / 8 : ℝ)) :=
        mul_le_mul (by linarith only [hm]) hδU hδ₀ (by positivity)
      _ = 8 * L * x ^ (-1 / 8 : ℝ) := by ring
      _ ≤ _ := by
        apply (le_div_iff₀ hx).mpr
        rw [mul_assoc, hshift]
        exact Nat.le_ceil _
  · have hMove {a b : ℝ} (hab : a + b = 1) (hlog : L ^ (2 : ℕ) ≤ x ^ b) :
        x ^ a ≤ x / L ^ 2 := by
      apply (le_div_iff₀ (sq_pos_of_pos hL₀)).mpr
      calc
        _ ≤ x ^ a * x ^ b := mul_le_mul_of_nonneg_left hlog (Real.rpow_nonneg hx.le _)
        _ = _ := by rw [← Real.rpow_add hx, hab, Real.rpow_one]
    have hMain : Real.sqrt x * L ^ (10 : ℕ) ≤ x / L ^ 2 := by
      apply (le_div_iff₀ (sq_pos_of_pos hL₀)).mpr
      rw [mul_assoc, ← pow_add, show (10 : ℕ) + 2 = 12 by decide, Real.sqrt_eq_rpow]
      calc
        _ ≤ x ^ (1 / 2 : ℝ) * x ^ (1 / 2 : ℝ) :=
          mul_le_mul_of_nonneg_left (hTwelve.trans
            (Real.rpow_le_rpow_of_exponent_le hx₁ (by norm_num))) (Real.rpow_nonneg hx.le _)
        _ = _ := by rw [← Real.rpow_add hx]; norm_num
    have hSmooth : x * (2 * δ) ≤ 4 * (x / L ^ 2) := calc
      _ ≤ x * (2 * (2 * x ^ (-1 / 8 : ℝ))) :=
        mul_le_mul_of_nonneg_left (by linarith only [hδU]) hx.le
      _ = 4 * x ^ (7 / 8 : ℝ) := by rw [← hshift]; ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (hMove (by norm_num) hTwo) (by norm_num)
    have hMarked : x ^ (5 / 6 : ℝ) ≤ x / L ^ 2 := hMove (b := 1 / 6) (by norm_num)
      (hTwo.trans (Real.rpow_le_rpow_of_exponent_le hx₁ (by norm_num)))
    linarith only [hMain, hSmooth, hMarked]

/-- Close all near-capacity base groups using the actual medium and smooth
reserves, adding at most 6N/(log N)^2 denominators to each group. -/
theorem eventually_nearCapacity_close_bases (C X₀ : ℕ) (hClosure : UniformSmoothClosure C X₀) :
    ∀ᶠ N : ℕ in atTop,
      ∀ (m : ℕ), (m : ℝ) ≤ 2 * Real.log N →
      ∀ (P : Fin m → ℕ), Function.Injective P →
      (∀ i, (P i).Prime ∧ (N : ℝ) ^ (1 / 6 : ℝ) < (P i : ℝ) ∧
        (P i : ℝ) ≤ 2 * (N : ℝ) ^ (1 / 6 : ℝ)) →
      ∀ (Q : Finset ℕ) (Cof : Fin m → ℕ → Finset ℕ) (S R : Finset ℕ),
      (∀ p ∈ Q, p.Prime ∧ nearCapacityCutoff N C < p ∧ p ≤ Nat.sqrt N) →
      (∀ p ∈ Q, ∀ i, p ≠ P i) →
      (∀ i p, p ∈ Q → (Cof i p).card = ⌊Real.log (N : ℝ) ^ (10 : ℕ)⌋₊ ∧
        (∀ b ∈ Cof i p, b ∣ Nat.lcmUpto ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊) ∧
        CoversResidues p (Cof i p)) →
      (∀ p ∈ Q, Pairwise (fun i j => Disjoint (Cof i p) (Cof j p))) →
      (∀ i, mediumPool Q (Cof i) ⊆ S) → S ⊆ interval 2 N →
      (mass S : ℝ) ≤ 692 * ((⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) / Real.sqrt N →
      R ⊆ interval 2 N → R.card = ⌈8 * Real.log N * (N : ℝ) ^ (7 / 8 : ℝ)⌉₊ →
      (∀ b ∈ R, N ≤ 2 * b ∧ b ∣ Nat.lcmUpto ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊) →
      (R.card : ℚ) / N ≤ mass R →
      ∀ (Base : Fin m → Finset ℕ), Pairwise (fun i j => Disjoint (Base i) (Base j)) →
      (∀ i, Base i ⊆ interval 2 N ∧ Disjoint (Base i) S ∧ Disjoint (Base i) R ∧
        (∀ b ∈ Base i, ∀ j, ¬ P j ∣ b) ∧
        (1 - mass (Base i)).den ∣ mediumDenominator (nearCapacityCutoff N C) Q ∧
        nearCapacityDelta N ≤ 1 - mass (Base i) ∧
        1 - mass (Base i) ≤ nearCapacityDelta N + nearCapacityEta N) →
      ∃ Out : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (Out i) (Out j)) ∧
        ∀ i, Base i ⊆ Out i ∧ Out i ⊆ interval 2 N ∧ mass (Out i) = 1 ∧
          ((Out i).card : ℝ) ≤ (Base i).card + 6 * ((N : ℝ) / (Real.log N) ^ 2) := by
  filter_upwards [eventually_nearCapacity_marker_geometry C X₀ hClosure.1,
    eventually_floor_twentieth_le_nearCapacityCutoff C (zero_lt_one.trans hClosure.1),
    eventually_nearCapacity_residual_parameters, eventually_nearCapacity_repair_costs,
    eventually_ge_atTop (1 : ℕ)] with N hGeom hY hD hBudget hN
  intro m hm P hInj hP Q Cof S R hQ hNot hCof hCPair hSContains hS hSMass hR hRSize
    hRProps hRMass Base hBasePairwise hBase
  let z := nearCapacityCutoff N C
  let δ := nearCapacityDelta N
  let η := nearCapacityEta N
  let X (i : Fin m) := markerScale N C (P i)
  let L := Real.log (N : ℝ)
  have hG (i : Fin m) := hGeom (P i) (hP i).2.1 (hP i).2.2
  have hMarkerScale (i : Fin m) : X₀ ≤ X i ∧ 0 < X i ∧ 2 ≤ P i * X i := by
    obtain ⟨h₁, h₂, h₃, _⟩ := hG i
    exact ⟨h₁, h₂, h₃⟩
  have hCut (i : Fin m) : z ≤ Nat.nthRoot 5 (X i) := by
    obtain ⟨_, _, _, h, _⟩ := hG i
    exact h
  have hCutDistinct (i j : Fin m) : Nat.nthRoot 5 (X i) < P j := by
    obtain ⟨_, _, _, _, hh, _⟩ := hG i
    exact_mod_cast hh.trans (hP j).2.1
  have hEight (i : Fin m) : 8 * P i ≤ N := by
    obtain ⟨_, _, _, _, _, _, hh, _⟩ := hG i
    exact hh
  have hLower (i : Fin m) : markerLower (P i) ≤ (1 : ℚ) * δ / 2 := by
    have hRoot : 0 < (Nat.nthRoot 8 N : ℚ) := inv_pos.mp hD.1
    have hRootP : Nat.nthRoot 8 N ≤ P i := by
      have hx : 1 ≤ (N : ℝ) := by exact_mod_cast hN
      rw [nthRoot_eq_floor_rpow 8 N (by decide)]
      exact (Nat.floor_lt (by positivity)).mpr ((Real.rpow_le_rpow_of_exponent_le hx (by norm_num)).trans_lt
        (hP i).2.1) |>.le
    dsimp only [markerLower, δ, nearCapacityDelta]
    calc
      _ ≤ 1 / (2 * (Nat.nthRoot 8 N : ℚ)) :=
        div_le_div_of_nonneg_left zero_le_one (mul_pos (by norm_num) hRoot)
          (mul_le_mul_of_nonneg_left (by exact_mod_cast hRootP) (by norm_num))
      _ = _ := by rw [one_div, mul_inv_rev, div_eq_mul_inv]; ring
  have hVolume : (∑ _i : Fin m, (2 : ℚ) * 1 * δ) ≤ mass R := by
    have hBound := hBudget.2.1 m hm
    have hRM : ((R.card : ℝ) / N) ≤ (mass R : ℝ) := by
      have h' : (((R.card : ℚ) / N : ℚ) : ℝ) ≤ (mass R : ℝ) := Rat.cast_le.mpr hRMass
      simpa only [Rat.cast_div, Rat.cast_natCast] using h'
    have hh : 2 * (m : ℝ) * (δ : ℝ) ≤ (mass R : ℝ) :=
      hBound.trans (hRSize ▸ hRM)
    have hq : (2 : ℚ) * (m : ℚ) * δ ≤ mass R := by exact_mod_cast hh
    simpa only [sum_const, card_univ, Fintype.card_fin, nsmul_eq_mul, mul_one] using
      (show (m : ℚ) * (2 * δ) ≤ mass R by linarith only [hq])
  have hCosts (i : Fin m) : mass (mediumPool Q (Cof i)) ≤ (1 : ℚ) * δ / 2 := by
    have ht : (mass (mediumPool Q (Cof i)) : ℝ) ≤ (mass S : ℝ) :=
      Rat.cast_le.mpr (mass_mono (hSContains i))
    have hq : (mass (mediumPool Q (Cof i)) : ℝ) ≤ (δ : ℝ) / 2 :=
      ht.trans (hSMass.trans hBudget.1)
    simpa only [one_mul] using (show mass (mediumPool Q (Cof i)) ≤ δ / 2 by exact_mod_cast hq)
  obtain ⟨F,E,G,hPair,hOut⟩ := finite_three_stage_repair_of_distinct_markers
    (Nat.succ_le_iff.mp hN) hClosure P (fun i => (hP i).1) hInj hEight hMarkerScale hCut hCutDistinct
    Q Cof (fun p hp => ⟨(hQ p hp).1,(hQ p hp).2.1⟩) hNot
    (fun i p hp b hb => ((hCof i p hp).2.1 b hb).trans (Nat.lcmUpto_dvd_lcmUpto hY))
    (fun i p hp => (hCof i p hp).2.2) hCPair (fun i => (hSContains i).trans hS)
    Base (fun i => (hBase i).1) hBasePairwise
    (fun i j => (hBase i).2.1.mono_right (hSContains j)) (fun i => (hBase i).2.2.2.1)
    R hR (fun b hb => (hRProps b hb).1)
    (fun b hb => (hRProps b hb).2.trans (Nat.lcmUpto_dvd_lcmUpto hY))
    (fun i => (hBase i).2.2.1) (fun _ => 1) zero_lt_one hD.1 hD.2.2.1 (fun _ => le_rfl)
    (fun i => (hBase i).2.2.2.2.1) (fun i => by simpa only [one_mul] using (hBase i).2.2.2.2.2)
    hCosts hLower hVolume
  let Out (i : Fin m) := Base i ∪ F i ∪ E i ∪ G i
  refine ⟨Out, hPair, fun i => ⟨?_, (hOut i).2.2.1, (hOut i).2.2.2.1, ?_⟩⟩
  · exact (subset_union_left.trans subset_union_left).trans subset_union_left
  · have hQSize : Q.card ≤ Nat.sqrt N := by
      have hSub : Q ⊆ Icc 1 (Nat.sqrt N) := fun p hp =>
        mem_Icc.mpr ⟨(hQ p hp).1.one_le,(hQ p hp).2.2⟩
      simpa using card_le_card hSub
    have hQSizeR : (Q.card : ℝ) ≤ Real.sqrt N :=
      (Real.le_sqrt (by positivity) (by positivity)).mpr (by exact_mod_cast Nat.le_sqrt'.mp hQSize)
    have hLog : 0 ≤ L := Real.log_nonneg (by exact_mod_cast hN)
    have hTerms : (∑ p ∈ Q, ((Cof i p).card : ℝ)) ≤ Real.sqrt N * L ^ (10 : ℕ) := calc
      _ = (Q.card : ℝ) * (⌊L ^ (10 : ℕ)⌋₊ : ℝ) := by
        calc
          _ = ∑ _p ∈ Q, (⌊L ^ (10 : ℕ)⌋₊ : ℝ) := sum_congr rfl fun p hp => by rw [(hCof i p hp).1]
          _ = _ := by rw [sum_const, nsmul_eq_mul]
      _ ≤ _ := mul_le_mul hQSizeR (Nat.floor_le (pow_nonneg hLog _)) (by positivity) (by positivity)
    have hMarked : (C : ℝ) * (X i : ℝ) ≤ (N : ℝ) ^ (5 / 6 : ℝ) := by
      obtain ⟨_, _, _, _, _, _, _, h⟩ := hG i
      exact h
    have hCardQ := (hOut i).2.2.2.2
    have hCardR : ((Out i).card : ℝ) ≤ (Base i).card + (∑ p ∈ Q, ((Cof i p).card : ℝ)) +
        (N : ℝ) * (2 * (δ : ℝ)) + (C : ℝ) * (X i : ℝ) := by
      exact_mod_cast (by simpa only [mul_one] using hCardQ : ((Out i).card : ℚ) ≤
        (Base i).card + (∑ p ∈ Q, ((Cof i p).card : ℚ)) + (N : ℚ) * (2 * δ) +
          ((C * X i : ℕ) : ℚ))
    calc
      _ ≤ _ := hCardR
      _ ≤ (Base i).card + (Real.sqrt N * L ^ (10 : ℕ) +
          (N : ℝ) * (2 * (δ : ℝ)) + (N : ℝ) ^ (5 / 6 : ℝ)) := by linarith only [hTerms, hMarked]
      _ ≤ _ := add_le_add_right hBudget.2.2 _

end LeanAB.PaperB.Closure
