module

public import PaperB.NearCapacity
public import PaperB.ShortPointwiseCover
import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.NumberTheory.LSeries.WeakPNT
meta import Mathlib.Tactic

/-! Inverse heights for the unit and integer problems. -/

@[expose] public section

open Filter Finset Asymptotics
open scoped BigOperators Topology

namespace LeanAB.PaperB

open Closure FixedTargets

private theorem eventually_prime_counting_upper :
    ∀ᶠ n : ℕ in atTop, (Nat.primeCounting n : ℝ) ≤ 2 * ((n : ℝ) / Real.log n) := by
  have h := (isEquivalent_iff_tendsto_one (by
    filter_upwards [eventually_gt_atTop (1 : ℝ)] with x hx
    exact div_ne_zero (zero_lt_one.trans hx).ne' (Real.log_pos hx).ne')).mp
      Nat.isEquivalent_primeCounting
  have hc : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  filter_upwards [(h.comp hc).eventually_lt_const (show (1 : ℝ) < 2 by norm_num),
    eventually_ge_atTop (2 : ℕ)] with n hn hn₂
  have hn₁ : (1 : ℝ) < n := by exact_mod_cast (by omega : 1 < n)
  have hpos : 0 < (n : ℝ) / Real.log n := div_pos (zero_lt_one.trans hn₁) (Real.log_pos hn₁)
  have hratio : (Nat.primeCounting n : ℝ) / ((n : ℝ) / Real.log n) < 2 := by
    simpa only [Function.comp_apply, Pi.div_apply, Nat.floor_natCast] using hn
  exact ((div_lt_iff₀ hpos).mp hratio).le

/-- Summing the per-block saving for a scaled reciprocal cover loses only
a factor of the harmonic sum of the cofactor width, divided by log N. -/
theorem eventually_scaled_cover_charge :
    ∀ᶠ N : ℕ in atTop, ∀ Q : ℕ, 0 < Q →
      2 * (Q : ℝ) ≤ Real.sqrt (N : ℝ) →
      (4 * (Q : ℝ) * (harmonic Q : ℝ) / N) * (Nat.primeCounting (N / Q) : ℝ) ≤
        16 * (harmonic Q : ℝ) / Real.log (N : ℝ) := by
  obtain ⟨T, hT⟩ := eventually_atTop.mp eventually_prime_counting_upper
  filter_upwards [eventually_ge_atTop (T ^ 2), eventually_ge_atTop (2 : ℕ)] with N hTN hN Q hQ hSmall
  let x : ℝ := N
  let L := Real.log x
  let z := N / Q
  let H : ℝ := harmonic Q
  have hx : (1 : ℝ) < x := by
    dsimp [x]
    exact_mod_cast (show 1 < N by omega)
  have hx₀ := zero_lt_one.trans hx
  have hL₀ : 0 < L := Real.log_pos hx
  have hQ₀ : (0 : ℝ) < Q := by exact_mod_cast hQ
  have hYge : 2 * Real.sqrt x ≤ x / (Q : ℝ) := by
    apply (le_div_iff₀ hQ₀).mpr
    calc
      _ = (2 * (Q : ℝ)) * Real.sqrt x := by ring
      _ ≤ Real.sqrt x * Real.sqrt x :=
        mul_le_mul_of_nonneg_right hSmall (Real.sqrt_nonneg x)
      _ = _ := Real.mul_self_sqrt hx₀.le
  have hZFloor : x / (Q : ℝ) - 1 ≤ (z : ℝ) := by
    have hf := (Nat.lt_floor_add_one (x / (Q : ℝ))).le
    rw [show ⌊x / (Q : ℝ)⌋₊ = z from Nat.floor_div_eq_div ..] at hf
    linarith only [hf]
  have hs₁ : 1 ≤ Real.sqrt x := by
    simpa only [Real.sqrt_one] using Real.sqrt_le_sqrt hx.le
  have hz₁ : Real.sqrt x ≤ (z : ℝ) := by linarith only [hYge, hZFloor, hs₁]
  have hz₂ : (z : ℝ) ≤ x / (Q : ℝ) := Nat.cast_div_le
  have hTs : (T : ℝ) ≤ Real.sqrt x := by
    apply (Real.le_sqrt (by positivity) hx₀.le).mpr
    dsimp [x]
    exact_mod_cast hTN
  have hzT : T ≤ z := by exact_mod_cast hTs.trans hz₁
  have hZlog : L / 2 ≤ Real.log (z : ℝ) := by
    have h := Real.log_le_log (zero_lt_one.trans_le hs₁) hz₁
    rw [Real.sqrt_eq_rpow, Real.log_rpow hx₀] at h
    linarith only [h]
  have hCount : (Nat.primeCounting z : ℝ) ≤ 4 * (x / (Q : ℝ)) / L := calc
    _ ≤ 2 * ((z : ℝ) / Real.log (z : ℝ)) := hT z hzT
    _ ≤ 2 * ((x / (Q : ℝ)) / (L / 2)) := by
      apply mul_le_mul_of_nonneg_left _ (by norm_num)
      exact div_le_div₀ (by positivity) hz₂ (by positivity) hZlog
    _ = _ := by ring
  have hH : 0 ≤ H := by
    change 0 ≤ (harmonic Q : ℝ)
    rw [← mass_denominators_eq_harmonic]
    exact_mod_cast mass_nonneg (denominators Q)
  change (4 * (Q : ℝ) * H / x) * (Nat.primeCounting z : ℝ) ≤ 16 * H / L
  calc
    _ ≤ (4 * (Q : ℝ) * H / x) * (4 * (x / (Q : ℝ)) / L) :=
      mul_le_mul_of_nonneg_left hCount (by positivity)
    _ = _ := by
      field_simp [hx₀.ne', hQ₀.ne', hL₀.ne']
      ring

/-- The sharp baseline upper bound for the local capacity deficit requires
only short modular covers, independently of the general packing construction. -/
theorem eventually_capacity_deficit_upper_of_LiuSawhney
    (h : ShortPointwise.LiuSawhneyPrimeHeight) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      (harmonic N : ℝ) - (capacity N : ℝ) ≤ sufficientLoss N C := by
  obtain ⟨C, hC, hW⟩ := eventually_windowPrimeMass_error_loglog 5 (by norm_num)
  let D := C + 60
  refine ⟨D, by dsimp [D]; positivity, ?_⟩
  have hNat : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  have hLog₂ := Real.tendsto_log_atTop.comp hLog
  have hLog₃ := Real.tendsto_log_atTop.comp hLog₂
  filter_upwards [hW, hLog.eventually_ge_atTop 1, hLog₂.eventually_ge_atTop 1,
    hLog₃.eventually_ge_atTop 1, eventually_ge_atTop (1 : ℕ),
    eventually_baselineCoverBound_logs 4, eventually_scaled_cover_charge,
    ShortPointwise.eventually_baseline_common_cover_of_LiuSawhney h,
    (tendsto_baselineCoverBound_div_sqrt 4).eventually_lt_const
      (show (0 : ℝ) < 1 / 2 by norm_num)] with
      N hW hL hU hLogU hN hWidth hCharge hCover hSmall
  let Q := baselineCoverBound 4 N
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let w := Real.log (Q : ℝ)
  have hL₁ : 1 ≤ L := hL
  have hL₀ : 0 < L := zero_lt_one.trans_le hL₁
  have hU₁ : 1 ≤ U := hU
  have hU₀ : 0 ≤ U := zero_le_one.trans hU₁
  have hLogU₁ : 1 ≤ Real.log U := hLogU
  have hWclose : |w - U| ≤ 5 * Real.log U := by
    have hh := hWidth.2.2.2.1
    norm_num at hh
    exact hh
  have hUle : U ≤ w := hWidth.2.2.1
  have hwle : w ≤ 2 * U := hWidth.2.2.2.2.1
  have hSqrt : 0 < Real.sqrt (N : ℝ) := Real.sqrt_pos.mpr (by exact_mod_cast (show 0 < N by omega))
  have hQsmall : 2 * (Q : ℝ) ≤ Real.sqrt (N : ℝ) := by
    have hp := ((div_lt_iff₀ hSqrt).mp hSmall).le
    change (Q : ℝ) ≤ _ at hp
    linarith only [hp]
  have hSum : (harmonic N : ℝ) - (capacity N : ℝ) ≤
      16 * (harmonic Q : ℝ) / L + windowPrimeMass N w :=
    (capacity_deficit_le_window_of_cover hWidth.1
      (fun p hp _ => (hCover p hp).1)).trans
        (add_le_add (hCharge Q hWidth.1 hQsmall) le_rfl)
  have hH : (harmonic Q : ℝ) ≤ 3 * U := by
    have hn := harmonic_le_one_add_log Q
    change (harmonic Q : ℝ) ≤ 1 + w at hn
    linarith only [hn, hwle, hU₁]
  have hSquare : w ^ 2 / (2 * L) ≤ U ^ 2 / (2 * L) + 8 * (U * Real.log U / L) := by
    have hDelta : w - U ≤ 5 * Real.log U := (le_abs_self _).trans hWclose
    have hDiff : w ^ 2 - U ^ 2 ≤ 15 * (U * Real.log U) := by
      have hProd := mul_le_mul hDelta (show w + U ≤ 3 * U by linarith only [hwle])
        (add_nonneg (hU₀.trans hUle) hU₀) (by positivity)
      nlinarith only [hProd]
    have hTerm := div_le_div_of_nonneg_right hDiff (show (0 : ℝ) ≤ 2 * L by positivity)
    have hE : 0 ≤ U * Real.log U / L := by positivity
    calc
      _ ≤ U ^ 2 / (2 * L) + 15 / 2 * (U * Real.log U / L) := by
        convert add_le_add_right hTerm (U ^ 2 / (2 * L)) using 1 <;> ring
      _ ≤ _ := add_le_add le_rfl (by linarith only [hE])
  have hRatio : U / L ≤ U * Real.log U / L :=
    div_le_div_of_nonneg_right (le_mul_of_one_le_right hU₀ hLogU₁) hL₀.le
  have hWindow : windowPrimeMass N w ≤ w ^ 2 / (2 * L) + C * (U / L) := by
    have hw := (abs_le.mp (hW w hWclose)).2
    convert sub_le_iff_le_add.mp hw using 1; ring
  have hUpper : 16 * (harmonic Q : ℝ) / L + windowPrimeMass N w ≤
      U ^ 2 / (2 * L) + (C + 56) * (U * Real.log U / L) := by
    have hCH : 16 * (harmonic Q : ℝ) / L ≤ 48 * (U / L) := by
      apply (div_le_iff₀ hL₀).mpr
      simpa only [mul_assoc, div_mul_cancel₀ _ hL₀.ne'] using
        (show 16 * (harmonic Q : ℝ) ≤ 48 * U by linarith only [hH])
    nlinarith only [hCH, hWindow, hSquare, hRatio,
      mul_le_mul_of_nonneg_left hRatio hC.le]
  calc
    _ ≤ U ^ 2 / (2 * L) + (C + 56) * (U * Real.log U / L) := hSum.trans hUpper
    _ ≤ U ^ 2 / (2 * L) + D * (U * Real.log U / L) := add_le_add le_rfl
      (mul_le_mul_of_nonneg_right (by dsimp [D]; linarith) (by positivity))
    _ = sufficientLoss N D := by unfold sufficientLoss; dsimp only [U, L]; ring

private theorem eventually_rpow_loss_le_inv_log (A : ℝ) :
    ∀ᶠ N : ℕ in atTop, A / (N : ℝ) ^ (1 / 12 : ℝ) ≤ 1 / Real.log (N : ℝ) := by
  have hNat : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  have hr := (tendsto_rpow_atTop (show (0 : ℝ) < 1 / 24 by norm_num)).comp hNat
  filter_upwards [hLog.eventually_ge_atTop 1, eventually_ge_atTop (1 : ℕ),
    eventually_log_pow_le_rpow 1 (show (0 : ℝ) < 1 / 24 by norm_num),
    hr.eventually_ge_atTop A] with N hLog hN₁ hSlow hA
  let x : ℝ := N
  have hx : 0 < x := Nat.cast_pos.mpr (by omega)
  have hL : 0 < Real.log x := zero_lt_one.trans_le hLog
  have hAx : A ≤ x ^ (1 / 24 : ℝ) := hA
  have hLx : Real.log x ≤ x ^ (1 / 24 : ℝ) := by simpa only [pow_one] using hSlow
  apply (div_le_div_iff₀ (Real.rpow_pos_of_pos hx _) hL).mpr
  rw [one_mul]
  calc
    _ ≤ x ^ (1 / 24 : ℝ) * x ^ (1 / 24 : ℝ) :=
      mul_le_mul hAx hLx hL.le (Real.rpow_nonneg hx.le _)
    _ = _ := by rw [← Real.rpow_add hx, show (1 / 24 : ℝ) + 1 / 24 = 1 / 12 by norm_num]

/-- Lower and upper floor estimates with the unconditional near-capacity lower estimate. -/
theorem eventually_unit_and_integer_coarse_bounds :
    ∃ C D : ℝ, 0 < C ∧ 0 < D ∧ ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      let U := Real.log L
      ⌊(harmonic N : ℝ) - D * U ^ 2 / L⌋ ≤ (k N : ℤ) ∧
      (h N : ℤ) ≤ ⌊(harmonic N : ℝ) - necessaryLoss N C⌋ := by
  obtain ⟨A, _, hA, _, hAttain⟩ := NearCapacity.attains_local_capacity
  obtain ⟨C, hC, hUp⟩ := eventually_unit_and_integer_upper
  obtain ⟨D, hD, hCap⟩ := eventually_capacity_harmonic_error
  refine ⟨C, D + 1, hC, by positivity, ?_⟩
  have hNat : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  have hLog₂ := Real.tendsto_log_atTop.comp hLog
  filter_upwards [hCap, hUp, hAttain, eventually_rpow_loss_le_inv_log A,
    hLog.eventually_ge_atTop 1, hLog₂.eventually_ge_atTop 1] with N hCap hUp hAttain hPow hL hU
  let L := Real.log (N : ℝ)
  let U := Real.log L
  have hL₀ : 0 < L := zero_lt_one.trans_le hL
  have hU₁ : 1 ≤ U := hU
  have hU₂ : 1 ≤ U ^ 2 := one_le_pow₀ hU₁
  have hUdiv : 1 / L ≤ U ^ 2 / L := div_le_div_of_nonneg_right hU₂ hL₀.le
  have hC := (abs_le.mp hCap).1
  refine ⟨(Int.floor_mono ?_).trans hAttain.1, ?_⟩
  · change (harmonic N : ℝ) - (D + 1) * U ^ 2 / L ≤ (capacity N : ℝ) -
      A / (N : ℝ) ^ (1 / 12 : ℝ)
    rw [add_mul, add_div, one_mul]
    linarith only [hC, hPow, hUdiv]
  · simpa only [mass_interval_one_eq_harmonic] using hUp.2

/-- The exact baseline lower floor for unit groups follows from capacity
attainment and short prime height alone. -/
theorem eventually_unit_and_integer_bounds_of_LiuSawhney
    (hHeight : ShortPointwise.LiuSawhneyPrimeHeight) :
    ∃ C D : ℝ, 0 < C ∧ 0 < D ∧ ∀ᶠ N : ℕ in atTop,
      ⌊(harmonic N : ℝ) - sufficientLoss N D⌋ ≤ (k N : ℤ) ∧
      (h N : ℤ) ≤ ⌊(harmonic N : ℝ) - necessaryLoss N C⌋ := by
  obtain ⟨A, _, hA, _, hAttain⟩ := NearCapacity.attains_local_capacity
  obtain ⟨C, hC, hUp⟩ := eventually_unit_and_integer_upper
  obtain ⟨D, hD, hCap⟩ := eventually_capacity_deficit_upper_of_LiuSawhney hHeight
  refine ⟨C, D + 1, hC, by positivity, ?_⟩
  have hNat : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  have hLog₂ := Real.tendsto_log_atTop.comp hLog
  have hLog₃ := Real.tendsto_log_atTop.comp hLog₂
  filter_upwards [hCap, hUp, hAttain, eventually_rpow_loss_le_inv_log A,
    hLog.eventually_ge_atTop 1, hLog₂.eventually_ge_atTop 1,
    hLog₃.eventually_ge_atTop 1] with N hCap hUp hAttain hPow hL hU hLogU
  let L := Real.log (N : ℝ)
  let U := Real.log L
  have hL₀ : 0 < L := zero_lt_one.trans_le hL
  have hU₁ : 1 ≤ U := hU
  have hLogU₁ : 1 ≤ Real.log U := hLogU
  have hE : 1 / L ≤ U * Real.log U / L := by
    apply div_le_div_of_nonneg_right _ hL₀.le
    simpa only [one_mul] using mul_le_mul hU₁ hLogU₁ zero_le_one
      (zero_le_one.trans hU₁)
  refine ⟨(Int.floor_mono ?_).trans hAttain.1, ?_⟩
  · change (harmonic N : ℝ) - (U ^ 2 / (2 * L) + (D + 1) * U * Real.log U / L) ≤
      (capacity N : ℝ) - A / (N : ℝ) ^ (1 / 12 : ℝ)
    change (harmonic N : ℝ) - (capacity N : ℝ) ≤ U ^ 2 / (2 * L) + D * U * Real.log U / L at hCap
    rw [show (D + 1) * U * Real.log U / L = D * U * Real.log U / L + U * Real.log U / L by ring]
    linarith only [hCap, hPow, hE]
  · simpa only [mass_interval_one_eq_harmonic] using hUp.2


private theorem eventually_coarse_loss_le_one {D : ℝ} (hD : 0 < D) :
    ∀ᶠ N : ℕ in atTop, let L := Real.log (N : ℝ); let U := Real.log L
      D * U ^ 2 / L ≤ 1 := by
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hSmall := (isLittleO_log_rpow_rpow_atTop (s := (1 : ℝ)) 2 one_pos).bound
    (show (0 : ℝ) < 1 / D by positivity)
  filter_upwards [hLog.eventually hSmall, hLog.eventually_ge_atTop 1] with N hs hL
  let L := Real.log (N : ℝ)
  let U := Real.log L
  have hL₀ : 0 < L := zero_lt_one.trans_le hL
  change ‖U ^ (2 : ℝ)‖ ≤ (1 / D) * ‖L ^ (1 : ℝ)‖ at hs
  have hU : U ^ 2 ≤ (1 / D) * L := by
    have hc : (2 : ℝ) = ((2 : ℕ) : ℝ) := by norm_num
    simpa only [Real.norm_eq_abs, hc, Real.rpow_natCast, Real.rpow_one, abs_of_nonneg (sq_nonneg U),
      abs_of_pos hL₀] using hs
  change D * U ^ 2 / L ≤ 1
  apply (div_le_iff₀ hL₀).mpr
  calc
    _ ≤ D * ((1 / D) * L) := mul_le_mul_of_nonneg_left hU hD.le
    _ = 1 * L := by field_simp [hD.ne']

/-- The eventual initial segment and the two possible values relative to
the harmonic floor follow already from near-capacity attainment. -/
theorem eventually_harmonic_floor_and_initial_segment :
    ∀ᶠ N : ℕ in atTop,
      ((k N : ℤ) = ⌊(harmonic N : ℝ)⌋ - 1 ∨ (k N : ℤ) = ⌊(harmonic N : ℝ)⌋) ∧
      representedIntegers N = range (h N + 1) := by
  obtain ⟨C, D, hC, hD, hBounds⟩ := eventually_unit_and_integer_coarse_bounds
  filter_upwards [hBounds, eventually_coarse_loss_le_one hD] with N hB hLoss
  let H : ℝ := harmonic N
  have hk : ⌊H⌋ - 1 ≤ (k N : ℤ) := by
    rw [show ⌊H⌋ - 1 = ⌊H - 1⌋ by simp]
    exact (Int.floor_mono (sub_le_sub_left hLoss H)).trans hB.1
  have hFloor : (h N : ℤ) ≤ ⌊(capacity N : ℝ)⌋ := by exact_mod_cast h_le_floor_capacity N
  have hh : (h N : ℤ) ≤ ⌊H⌋ := hFloor.trans (Int.floor_mono (capacity_le_harmonic N))
  have hkh := k_le_h N
  have hInt : (h N : ℤ) ≤ (k N : ℤ) + 1 := by omega
  refine ⟨?_, represented_initial_segment_if_close (by exact_mod_cast hInt)⟩
  have hkh' : (k N : ℤ) ≤ h N := by exact_mod_cast hkh
  change (k N : ℤ) = ⌊H⌋ - 1 ∨ (k N : ℤ) = ⌊H⌋
  omega

theorem exists_unit_inverse_height (j : ℕ) : ∃ N, j ≤ k N := by
  obtain ⟨A, _, hA, _, h⟩ := NearCapacity.attains_local_capacity
  exact exists_unit_height_of_attainment hA.le (h.mono fun _ hN => hN.1) j

theorem exists_integer_inverse_height (j : ℕ) : ∃ N, j ∈ representedIntegers N := by
  obtain ⟨N, hN⟩ := exists_unit_inverse_height j
  exact ⟨N, integer_represented_of_le_k hN⟩

/-- Least denominator height supporting j disjoint unit-sum groups. -/
noncomputable def unitInverseHeight (j : ℕ) : ℕ :=
  unitHeight j (exists_unit_inverse_height j)

/-- Least denominator height representing the integer j. -/
noncomputable def integerInverseHeight (j : ℕ) : ℕ :=
  integerHeight j (exists_integer_inverse_height j)

theorem integerInverseHeight_le_unitInverseHeight (j : ℕ) :
    integerInverseHeight j ≤ unitInverseHeight j :=
  integerHeight_le_unitHeight j (exists_integer_inverse_height j) (exists_unit_inverse_height j)

theorem tendsto_integerInverseHeight : Tendsto integerInverseHeight atTop atTop :=
  tendsto_atTop_mono (fun j => localCapacityHeight_le_integerHeight j (exists_integer_inverse_height j))
    tendsto_localCapacityHeight

theorem tendsto_unitInverseHeight : Tendsto unitInverseHeight atTop atTop :=
  tendsto_atTop_mono integerInverseHeight_le_unitInverseHeight tendsto_integerInverseHeight

theorem index_le_h_at_integer (j : ℕ) : j ≤ h (integerInverseHeight j) :=
  (h_isGreatest _).2 (mem_representedIntegers.mp (integerHeight_spec j (exists_integer_inverse_height j)).1)

theorem index_le_h_at_unit (j : ℕ) : j ≤ h (unitInverseHeight j) :=
  (unitHeight_spec j (exists_unit_inverse_height j)).1.trans (k_le_h _)

theorem log_predecessor_gap_le_one {N : ℕ} (hN : 2 ≤ N) :
    Real.log (N : ℝ) - Real.log ((N - 1 : ℕ) : ℝ) ≤ 1 := by
  have hNp : (0 : ℝ) < N := by exact_mod_cast (show 0 < N by omega)
  have hPrev : (0 : ℝ) < ((N - 1 : ℕ) : ℝ) := by exact_mod_cast (show 0 < N - 1 by omega)
  rw [← Real.log_div hNp.ne' hPrev.ne']
  refine (Real.log_le_sub_one_of_pos (div_pos hNp hPrev)).trans ?_
  have hh : (N : ℝ) / ((N - 1 : ℕ) : ℝ) ≤ 2 :=
    (div_le_iff₀ hPrev).2 (by exact_mod_cast (show N ≤ 2 * (N - 1) by omega))
  linarith

theorem harmonic_log_center {N : ℕ} (hN : 0 < N) :
    0 ≤ (harmonic N : ℝ) - Real.log (N : ℝ) - Real.eulerMascheroniConstant ∧
      (harmonic N : ℝ) - Real.log (N : ℝ) - Real.eulerMascheroniConstant ≤ 1 / (N : ℝ) := by
  have hn' : (0 : ℝ) < N := Nat.cast_pos.mpr hN
  have hp : (0 : ℝ) < (N : ℝ) + 1 := by positivity
  have hLower : Real.eulerMascheroniConstant < (harmonic N : ℝ) - Real.log (N : ℝ) := by
    simpa only [Real.eulerMascheroniSeq', ite_eq_right hN.ne'] using
      Real.eulerMascheroniConstant_lt_eulerMascheroniSeq' N
  have hUpper : (harmonic N : ℝ) - Real.log ((N : ℝ) + 1) < Real.eulerMascheroniConstant := by
    simpa only [Real.eulerMascheroniSeq, Nat.cast_add, Nat.cast_one] using
      Real.eulerMascheroniSeq_lt_eulerMascheroniConstant N
  have hDiff : Real.log ((N : ℝ) + 1) - Real.log (N : ℝ) ≤ 1 / (N : ℝ) := calc
    _ = Real.log (((N : ℝ) + 1) / (N : ℝ)) := (Real.log_div hp.ne' hn'.ne').symm
    _ ≤ ((N : ℝ) + 1) / (N : ℝ) - 1 := Real.log_le_sub_one_of_pos (div_pos hp hn')
    _ = _ := by field_simp; ring
  exact ⟨by linarith only [hLower], by linarith only [hUpper, hDiff]⟩

theorem tendsto_unitInversePredecessor :
    Tendsto (fun j => unitInverseHeight j - 1) atTop atTop := by
  refine tendsto_atTop.2 fun M => ?_
  filter_upwards [tendsto_unitInverseHeight.eventually_ge_atTop (M + 1)] with j hj
  omega

theorem unitInverse_adjacent_upper {B : ℕ → ℝ}
    (hLower : ∀ᶠ N : ℕ in atTop, ⌊(harmonic N : ℝ) - B N⌋ ≤ (k N : ℤ)) :
    ∀ᶠ j : ℕ in atTop, let N := unitInverseHeight j
      (harmonic N : ℝ) - (j : ℝ) < B (N - 1) + 1 / (N : ℝ) := by
  filter_upwards [tendsto_unitInversePredecessor.eventually hLower,
    tendsto_unitInverseHeight.eventually_ge_atTop (2 : ℕ)] with j hL hN
  let N := unitInverseHeight j
  have hN' : 2 ≤ N := hN
  have hPrev : N - 1 < N := by omega
  have hUnit : k (N - 1) < j :=
    (unitHeight_spec j (exists_unit_inverse_height j)).2 _ hPrev
  have hF : ⌊(harmonic (N - 1 : ℕ) : ℝ) - B (N - 1)⌋ < (j : ℤ) :=
    hL.trans_lt (by exact_mod_cast hUnit)
  have hReal := (Int.floor_lt.mp hF)
  rw [Int.cast_natCast] at hReal
  have hH : (harmonic N : ℝ) = (harmonic (N - 1 : ℕ) : ℝ) + 1 / (N : ℝ) := by
    have hEq : N - 1 + 1 = N := by omega
    have hr := harmonic_succ (N - 1)
    rw [hEq] at hr
    rw [one_div]
    simpa only [Rat.cast_add, Rat.cast_inv, Rat.cast_natCast] using (congrArg (fun q : ℚ => (q : ℝ)) hr)
  change _ < B (N - 1) + 1 / (N : ℝ)
  linarith only [hReal, hH]

theorem log_inverse_within_three :
    ∀ᶠ j : ℕ in atTop,
      |Real.log (unitInverseHeight j : ℝ) - j| ≤ 3 ∧
      |Real.log (integerInverseHeight j : ℝ) - j| ≤ 3 := by
  obtain ⟨C,D,hC,hD,hB⟩ := eventually_unit_and_integer_coarse_bounds
  let B (N : ℕ) := D * Real.log (Real.log (N : ℝ)) ^ 2 / Real.log (N : ℝ)
  have hL (M : ℕ) (j : ℕ) (hj : j ≤ h M) : (j : ℝ) - 1 ≤ Real.log (M : ℝ) := by
    have hF : (h M : ℤ) ≤ ⌊(capacity M : ℝ)⌋ := by exact_mod_cast h_le_floor_capacity M
    have hCap : (h M : ℝ) ≤ (capacity M : ℝ) := by
      simpa only [Int.cast_natCast] using (Int.le_floor.mp hF)
    have hJ : (j : ℝ) ≤ (capacity M : ℝ) :=
      (by exact_mod_cast hj : (j : ℝ) ≤ (h M : ℝ)).trans hCap
    linarith only [hJ,capacity_le_harmonic M,harmonic_le_one_add_log M]
  have hLower : ∀ᶠ N : ℕ in atTop, ⌊(harmonic N : ℝ) - B N⌋ ≤ (k N : ℤ) := hB.mono (fun _ hN => hN.1)
  filter_upwards [unitInverse_adjacent_upper hLower,
    tendsto_unitInversePredecessor.eventually (eventually_coarse_loss_le_one hD),
    tendsto_unitInverseHeight.eventually_ge_atTop (2 : ℕ),
    tendsto_integerInverseHeight.eventually_ge_atTop (1 : ℕ)] with j hAdj hLoss hU hI
  let N := unitInverseHeight j
  let T := integerInverseHeight j
  have hN : 2 ≤ N := hU
  have hT : 1 ≤ T := hI
  have hH : Real.log (N : ℝ) ≤ (harmonic N : ℝ) := by
    simpa only [Nat.floor_natCast] using log_le_harmonic_floor (N : ℝ) (by positivity)
  have hRecip : 1 / (N : ℝ) ≤ 1 := by
    apply (div_le_iff₀ (Nat.cast_pos.mpr (by omega : 0 < N))).mpr
    have hOne : (1 : ℝ) ≤ (N : ℝ) := by exact_mod_cast (show 1 ≤ N by omega)
    simpa only [one_mul] using hOne
  have hUpper : Real.log (N : ℝ) ≤ (j : ℝ) + 3 := by
    change (harmonic N : ℝ) - (j : ℝ) < B (N - 1) + 1 / (N : ℝ) at hAdj
    change B (N - 1) ≤ 1 at hLoss
    linarith only [hH,hAdj,hLoss,hRecip]
  have hTN : Real.log (T : ℝ) ≤ Real.log (N : ℝ) :=
    Real.log_le_log (Nat.cast_pos.mpr (by omega : 0 < T))
      (Nat.cast_le.mpr (integerInverseHeight_le_unitInverseHeight j))
  exact ⟨abs_le.mpr ⟨by linarith only [hL N j (index_le_h_at_unit j)],
      by linarith only [hUpper]⟩,
    abs_le.mpr ⟨by linarith only [hL T j (index_le_h_at_integer j)],
      by linarith only [hTN,hUpper]⟩⟩

private theorem inverse_scale_comparison {x L : ℝ}
    (hx : 8 ≤ x) (hClose : |L - x| ≤ 4)
    (hV : 1 ≤ Real.log x) (hLogV : 1 ≤ Real.log (Real.log x))
    (hU : 1 ≤ Real.log L) :
    let U := Real.log L
    let V := Real.log x
    let J := V * Real.log V / x
    |U ^ 2 / (2 * L) - V ^ 2 / (2 * x)| ≤ 7 * J ∧
    U * Real.log U / L ≤ 8 * J ∧ U ^ 2 / L ≤ 8 * (V ^ 2 / x) := by
  let U := Real.log L
  let V := Real.log x
  let J := V * Real.log V / x
  change 1 ≤ U at hU
  change 1 ≤ V at hV
  change 1 ≤ Real.log V at hLogV
  change |U ^ 2 / (2 * L) - V ^ 2 / (2 * x)| ≤ 7 * J ∧
    U * Real.log U / L ≤ 8 * J ∧ U ^ 2 / L ≤ 8 * (V ^ 2 / x)
  have hx₀ : 0 < x := by linarith
  have hL₁ : x / 2 ≤ L := by linarith only [(abs_le.mp hClose).1, hx]
  have hL₂ : L ≤ 2 * x := by linarith only [(abs_le.mp hClose).2, hx]
  have hL₀ : 0 < L := (by positivity : 0 < x / 2).trans_le hL₁
  have hU₀ : 0 ≤ U := zero_le_one.trans hU
  have hV₀ : 0 ≤ V := zero_le_one.trans hV
  have hLogU₀ : 0 ≤ Real.log U := Real.log_nonneg hU
  have hLogV₀ : 0 ≤ Real.log V := zero_le_one.trans hLogV
  have hlog2 : Real.log 2 ≤ 1 := by
    linarith only [Real.log_le_sub_one_of_pos (show 0 < (2 : ℝ) by norm_num)]
  have hUV : |U - V| ≤ 1 := by
    change |Real.log L - Real.log x| ≤ 1
    rw [← Real.log_div hL₀.ne' hx₀.ne']
    have hmin : 1 / 2 ≤ L / x := (le_div_iff₀ hx₀).mpr (by
      convert hL₁ using 1; ring)
    have hmax : L / x ≤ 2 := (div_le_iff₀ hx₀).mpr hL₂
    have hlo := Real.log_le_log (show 0 < (1 / 2 : ℝ) by norm_num) hmin
    have hhi := Real.log_le_log (div_pos hL₀ hx₀) hmax
    rw [one_div, Real.log_inv] at hlo
    exact abs_le.mpr ⟨by linarith only [hlo, hlog2], hhi.trans hlog2⟩
  have hUle : U ≤ 2 * V := by linarith only [(abs_le.mp hUV).2,hV]
  have hLogUle : Real.log U ≤ 2 * Real.log V := calc
    _ ≤ Real.log (2 * V) := Real.log_le_log (zero_lt_one.trans_le hU) hUle
    _ = Real.log 2 + Real.log V := Real.log_mul (by norm_num) (by positivity)
    _ ≤ _ := by linarith only [hlog2, hLogV]
  have hVJ : V / x ≤ J := by
    apply div_le_div_of_nonneg_right _ hx₀.le
    exact le_mul_of_one_le_right hV₀ hLogV
  have hU₂ : |U ^ 2 - V ^ 2| ≤ 3 * V := by
    rw [show U ^ 2 - V ^ 2 = (U - V) * (U + V) by ring,
      abs_mul, abs_of_nonneg (add_nonneg hU₀ hV₀)]
    have hSum : U + V ≤ 3 * V := by linarith only [hUle]
    simpa only [one_mul] using mul_le_mul hUV hSum (add_nonneg hU₀ hV₀) zero_le_one
  have hVx : V / x ≤ 1 :=
    (div_le_one₀ hx₀).mpr ((Real.log_le_sub_one_of_pos hx₀).trans (by linarith))
  have hA₁ : |(U ^ 2 - V ^ 2) / (2 * L)| ≤ 3 * J := calc
    _ = |U ^ 2 - V ^ 2| / (2 * L) := by rw [abs_div, abs_of_pos (by positivity : 0 < 2 * L)]
    _ ≤ 3 * V / (2 * L) := div_le_div_of_nonneg_right hU₂ (by positivity)
    _ ≤ 3 * V / x := div_le_div_of_nonneg_left (by positivity) hx₀
      (by linarith only [hL₁])
    _ = 3 * (V / x) := by ring
    _ ≤ 3 * J := mul_le_mul_of_nonneg_left hVJ (by norm_num)
  have hA₂ : |V ^ 2 * (x - L) / (2 * L * x)| ≤ 4 * J := calc
    _ = V ^ 2 * |L - x| / (2 * L * x) := by
      rw [abs_div, abs_mul, abs_sub_comm x, abs_of_nonneg (sq_nonneg V),
        abs_of_pos (by positivity : 0 < 2 * L * x)]
    _ ≤ V ^ 2 * 4 / (2 * L * x) := div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_left hClose (sq_nonneg V)) (by positivity)
    _ ≤ V ^ 2 * 4 / x ^ 2 := by
      apply div_le_div_of_nonneg_left (by positivity) (by positivity)
      have h := mul_le_mul_of_nonneg_right (show x ≤ 2 * L by linarith only [hL₁]) hx₀.le
      nlinarith only [h]
    _ = 4 * ((V / x) * (V / x)) := by ring
    _ ≤ 4 * (V / x) := by
      apply mul_le_mul_of_nonneg_left _ (by norm_num)
      simpa only [mul_one] using mul_le_mul_of_nonneg_left hVx (div_nonneg hV₀ hx₀.le)
    _ ≤ 4 * J := mul_le_mul_of_nonneg_left hVJ (by norm_num)
  refine ⟨?_, ?_, ?_⟩
  · rw [show U ^ 2 / (2 * L) - V ^ 2 / (2 * x) =
      (U ^ 2 - V ^ 2) / (2 * L) + V ^ 2 * (x - L) / (2 * L * x) by
        field_simp [hx₀.ne', hL₀.ne']; ring]
    exact (abs_add_le _ _).trans ((add_le_add hA₁ hA₂).trans_eq (by ring))
  · calc
      _ ≤ (2 * V) * (2 * Real.log V) / L :=
        div_le_div_of_nonneg_right
          (mul_le_mul hUle hLogUle hLogU₀ (by positivity)) hL₀.le
      _ ≤ (2 * V) * (2 * Real.log V) / (x / 2) :=
        div_le_div_of_nonneg_left (by positivity) (by positivity) hL₁
      _ = 8 * J := by dsimp [J]; ring
  · calc
      _ ≤ (2 * V) ^ 2 / L :=
        div_le_div_of_nonneg_right (pow_le_pow_left₀ hU₀ hUle _) hL₀.le
      _ ≤ (2 * V) ^ 2 / (x / 2) :=
        div_le_div_of_nonneg_left (by positivity) (by positivity) hL₁
      _ = _ := by ring

private theorem eventually_inverse_scale {f : ℕ → ℕ} (hf : Tendsto f atTop atTop)
    (hClose : ∀ᶠ j : ℕ in atTop, |Real.log (f j : ℝ) - (j : ℝ)| ≤ 4) :
    ∀ᶠ j : ℕ in atTop,
      let N := f j
      let V := Real.log (j : ℝ)
      let J := V * Real.log V / (j : ℝ)
      |heightMainCorrection N - V ^ 2 / (2 * (j : ℝ))| ≤ 7 * J ∧
      heightErrorScale N ≤ 8 * J ∧
      Real.log (Real.log (N : ℝ)) ^ 2 / Real.log (N : ℝ) ≤ 8 * (V ^ 2 / (j : ℝ)) := by
  have hNat : Tendsto (fun j : ℕ => (j : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  have hLog₂ := Real.tendsto_log_atTop.comp hLog
  filter_upwards [hClose, eventually_ge_atTop (8 : ℕ), hLog.eventually_ge_atTop 1,
    hLog₂.eventually_ge_atTop 1, (hLog₂.comp hf).eventually_ge_atTop 1] with j hClose hj hV hLogV hU
  exact inverse_scale_comparison (by exact_mod_cast hj) hClose hV hLogV hU

private theorem eventually_unit_predecessor_scale :
    ∀ᶠ j : ℕ in atTop,
      let N := unitInverseHeight j - 1
      let V := Real.log (j : ℝ)
      let J := V * Real.log V / (j : ℝ)
      |heightMainCorrection N - V ^ 2 / (2 * (j : ℝ))| ≤ 7 * J ∧
      heightErrorScale N ≤ 8 * J ∧
      Real.log (Real.log (N : ℝ)) ^ 2 / Real.log (N : ℝ) ≤ 8 * (V ^ 2 / (j : ℝ)) := by
  apply eventually_inverse_scale tendsto_unitInversePredecessor
  filter_upwards [log_inverse_within_three,tendsto_unitInverseHeight.eventually_ge_atTop (2 : ℕ)] with j hC hN
  let N := unitInverseHeight j
  have hNp : (0 : ℝ) < ((N - 1 : ℕ) : ℝ) := by
    have hN' : 2 ≤ N := hN
    exact_mod_cast (show 0 < N - 1 by omega)
  have hGap := log_predecessor_gap_le_one hN
  have hMon := Real.log_le_log hNp (show ((N - 1 : ℕ) : ℝ) ≤ N by exact_mod_cast Nat.sub_le N 1)
  have hAbs := abs_le.mp hC.1
  exact abs_le.mpr ⟨by linarith only [hGap,hAbs.1], by linarith only [hMon,hAbs.2]⟩


private theorem index_le_harmonic {j N : ℕ} (hj : j ≤ h N) :
    (j : ℝ) ≤ (harmonic N : ℝ) := by
  obtain ⟨S,hS,hSum⟩ := (h_isGreatest N).1
  have hMass := mass_mono hS
  rw [hSum,mass_denominators_eq_harmonic] at hMass
  exact (by exact_mod_cast hj : (j : ℝ) ≤ (h N : ℝ)).trans (by exact_mod_cast hMass)

theorem reciprocal_height_le_inverse_index {j N : ℕ} (hj : 0 < j) (hJ : j ≤ h N) :
    1 / (N : ℝ) ≤ 1 / (j : ℝ) := by
  have hJr := index_le_harmonic hJ
  have hz : N ≠ 0 := by
    intro hN
    subst N
    norm_num [harmonic] at hJr
    omega
  have hR : (0 : ℝ) < N := Nat.cast_pos.mpr (Nat.pos_of_ne_zero hz)
  have hH := harmonic_le_one_add_log N
  have hL := Real.log_le_sub_one_of_pos hR
  exact one_div_le_one_div_of_le (Nat.cast_pos.mpr hj) (by linarith only [hJr,hH,hL])

private theorem harmonic_inverse_lower {j N : ℕ} (hN : 0 < N) (hj : j ≤ h N) :
    (j : ℝ) - Real.eulerMascheroniConstant - 1 / (N : ℝ) ≤ Real.log (N : ℝ) := by
  have hJ := index_le_harmonic hj
  have hc := (harmonic_log_center hN).2
  linarith only [hJ,hc]

/-- The unconditional logarithmic asymptotic with the full constant term. -/
theorem eventually_inverse_heights_coarse :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ j : ℕ in atTop,
      |Real.log (unitInverseHeight j : ℝ) - ((j : ℝ) - Real.eulerMascheroniConstant)| ≤
        C * (Real.log (j : ℝ) ^ 2 / (j : ℝ)) ∧
      |Real.log (integerInverseHeight j : ℝ) - ((j : ℝ) - Real.eulerMascheroniConstant)| ≤
        C * (Real.log (j : ℝ) ^ 2 / (j : ℝ)) := by
  obtain ⟨_, D, _, hD, hBounds⟩ := eventually_unit_and_integer_coarse_bounds
  let B (N : ℕ) := D * Real.log (Real.log (N : ℝ)) ^ 2 / Real.log (N : ℝ)
  have hFloor : ∀ᶠ N : ℕ in atTop, ⌊(harmonic N : ℝ) - B N⌋ ≤ (k N : ℤ) :=
    hBounds.mono fun _ hN => hN.1
  refine ⟨8 * D + 1, by positivity, ?_⟩
  have hLog : Tendsto (fun j : ℕ => Real.log (j : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [unitInverse_adjacent_upper hFloor, eventually_unit_predecessor_scale,
    hLog.eventually_ge_atTop 1, eventually_ge_atTop (1 : ℕ),
    tendsto_integerInverseHeight.eventually_ge_atTop (1 : ℕ)] with j hAdj hP hLog hj hT
  let N := unitInverseHeight j
  let T := integerInverseHeight j
  let U := Real.log (j : ℝ)
  let E := U ^ 2 / (j : ℝ)
  have hj₀ : 0 < j := Nat.succ_le_iff.mp hj
  have hU : 1 ≤ U := hLog
  have hT₀ : 0 < T := Nat.succ_le_iff.mp hT
  have hN₀ : 0 < N := hT₀.trans_le (integerInverseHeight_le_unitInverseHeight j)
  have hE₀ : 0 ≤ E := by dsimp [E]; positivity
  have hE : 1 / (j : ℝ) ≤ E :=
    div_le_div_of_nonneg_right (one_le_pow₀ hU) (Nat.cast_nonneg _)
  have hNT : Real.log (T : ℝ) ≤ Real.log (N : ℝ) :=
    Real.log_le_log (Nat.cast_pos.mpr hT₀) (by exact_mod_cast integerInverseHeight_le_unitInverseHeight j)
  have hPrev : B (N - 1) ≤ 8 * D * E := by
    have hh := mul_le_mul_of_nonneg_left hP.2.2 hD.le
    dsimp only [B]
    convert hh using 1 <;> dsimp only [N,E,U] <;> ring
  have hSup : Real.log (N : ℝ) - ((j : ℝ) - Real.eulerMascheroniConstant) ≤ (8 * D + 1) * E := by
    have hErr := reciprocal_height_le_inverse_index hj₀ (index_le_h_at_unit j)
    have hCenter := (harmonic_log_center hN₀).1
    change (harmonic N : ℝ) - j < B (N - 1) + 1 / (N : ℝ) at hAdj
    nlinarith only [hCenter,hAdj,hPrev,hErr.trans hE]
  have hNlower := harmonic_inverse_lower hN₀ (index_le_h_at_unit j)
  have hTlower := harmonic_inverse_lower hT₀ (index_le_h_at_integer j)
  have hNerr := (reciprocal_height_le_inverse_index hj₀ (index_le_h_at_unit j)).trans hE
  have hTerr := (reciprocal_height_le_inverse_index hj₀ (index_le_h_at_integer j)).trans hE
  have hDE := mul_nonneg hD.le hE₀
  exact ⟨abs_le.mpr ⟨by nlinarith only [hNlower,hNerr,hDE],hSup⟩,
    abs_le.mpr ⟨by nlinarith only [hTlower,hTerr,hDE],by linarith only [hNT,hSup]⟩⟩

private theorem sharp_inverse_lower {f : ℕ → ℕ} (hf : Tendsto f atTop atTop)
    (hIdx : ∀ j, j ≤ h (f j))
    (hClose : ∀ᶠ j : ℕ in atTop, |Real.log (f j : ℝ) - (j : ℝ)| ≤ 4)
    {C : ℝ} (hC : 0 ≤ C)
    (hNecessary : ∀ᶠ N : ℕ in atTop,
      (h N : ℤ) ≤ ⌊(harmonic N : ℝ) - necessaryLoss N C⌋) :
    ∀ᶠ j : ℕ in atTop,
      let V := Real.log (j : ℝ)
      let J := V * Real.log V / (j : ℝ)
      (j : ℝ) - Real.eulerMascheroniConstant + V ^ 2 / (2 * (j : ℝ)) -
        (8 * C + 8) * J ≤ Real.log (f j : ℝ) := by
  have hNat : Tendsto (fun j : ℕ => (j : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  have hLog₂ := Real.tendsto_log_atTop.comp hLog
  have hLog₃ := Real.tendsto_log_atTop.comp hLog₂
  filter_upwards [hf.eventually hNecessary, eventually_inverse_scale hf hClose,
    hf.eventually_ge_atTop (1 : ℕ), eventually_ge_atTop (1 : ℕ),
    hLog.eventually_ge_atTop 1, hLog₂.eventually_ge_atTop 1,
    (hLog.comp hf).eventually_ge_atTop 1,
    (hLog₂.comp hf).eventually_ge_atTop 1,
    (hLog₃.comp hf).eventually_ge_atTop 1] with
      j hNec hScale hN hj hV hLogV hM hU hLogU
  let N := f j
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let V := Real.log (j : ℝ)
  let J := V * Real.log V / (j : ℝ)
  have hL₁ : 1 ≤ L := hM
  have hL₀ : 0 < L := zero_lt_one.trans_le hL₁
  have hU₁ : 1 ≤ U := hU
  have hLogU₁ : 1 ≤ Real.log U := hLogU
  have hj₀ : 0 < j := Nat.succ_le_iff.mp hj
  have hN₀ : 0 < N := Nat.succ_le_iff.mp hN
  have hIdxz : (j : ℤ) ≤ (h N : ℤ) := by exact_mod_cast (hIdx j)
  have hLow := (Int.le_floor.mp (hIdxz.trans hNec))
  rw [Int.cast_natCast] at hLow
  change (j : ℝ) ≤ (harmonic N : ℝ) - (U ^ 2 / (2 * L) - C * U / L) at hLow
  have hScaleM : V ^ 2 / (2 * (j : ℝ)) - 7 * J ≤ U ^ 2 / (2 * L) := by
    have h := (abs_le.mp hScale.1).1
    change -(7 * J) ≤ U ^ 2 / (2 * L) - V ^ 2 / (2 * (j : ℝ)) at h
    linarith only [h]
  have hExtra : C * U / L ≤ 8 * C * J := calc
    _ = C * (U / L) := by ring
    _ ≤ C * (U * Real.log U / L) := mul_le_mul_of_nonneg_left
      (div_le_div_of_nonneg_right (le_mul_of_one_le_right (zero_le_one.trans hU₁) hLogU₁) hL₀.le) hC
    _ ≤ C * (8 * J) := mul_le_mul_of_nonneg_left hScale.2.1 hC
    _ = _ := by ring
  change 1 ≤ V at hV
  change 1 ≤ Real.log V at hLogV
  have hOne : 1 / (j : ℝ) ≤ J := by
    apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg _)
    simpa only [one_mul] using mul_le_mul hV hLogV zero_le_one (zero_le_one.trans hV)
  have hRec := (reciprocal_height_le_inverse_index hj₀ (hIdx j)).trans hOne
  have hCenter := (harmonic_log_center hN₀).2
  change (j : ℝ) - Real.eulerMascheroniConstant + V ^ 2 / (2 * (j : ℝ)) -
    (8 * C + 8) * J ≤ L
  nlinarith only [hLow,hScaleM,hExtra,hRec,hCenter]

/-- The sharp lower coefficient in both inverse heights already follows
from the obstruction without requiring the short cover. -/
theorem eventually_inverse_heights_sharp_lower :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ j : ℕ in atTop,
      let V := Real.log (j : ℝ)
      let J := V * Real.log V / (j : ℝ)
      let A := (j : ℝ) - Real.eulerMascheroniConstant + V ^ 2 / (2 * (j : ℝ))
      A - C * J ≤ Real.log (unitInverseHeight j : ℝ) ∧
      A - C * J ≤ Real.log (integerInverseHeight j : ℝ) := by
  obtain ⟨C, hC, hNecessary⟩ := eventually_unit_and_integer_upper
  have hNec : ∀ᶠ N : ℕ in atTop, (h N : ℤ) ≤ ⌊(harmonic N : ℝ) - necessaryLoss N C⌋ := by
    filter_upwards [hNecessary] with N hN
    simpa only [mass_interval_one_eq_harmonic] using hN.2
  have hUnit : ∀ᶠ j : ℕ in atTop, |Real.log (unitInverseHeight j : ℝ) - (j : ℝ)| ≤ 4 :=
    log_inverse_within_three.mono (fun _ h => h.1.trans (by norm_num))
  have hInteger : ∀ᶠ j : ℕ in atTop, |Real.log (integerInverseHeight j : ℝ) - (j : ℝ)| ≤ 4 :=
    log_inverse_within_three.mono (fun _ h => h.2.trans (by norm_num))
  refine ⟨8 * C + 8, by positivity, ?_⟩
  filter_upwards [sharp_inverse_lower tendsto_unitInverseHeight index_le_h_at_unit hUnit hC.le hNec,
    sharp_inverse_lower tendsto_integerInverseHeight index_le_h_at_integer hInteger hC.le hNec]
    with j hN hT
  exact ⟨hN,hT⟩

/-- The full baseline inverse-height coefficient for both problems follows
from the short height theorem without any packing-sufficiency premise. -/
theorem eventually_inverse_heights_of_LiuSawhney
    (hHeight : ShortPointwise.LiuSawhneyPrimeHeight) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ j : ℕ in atTop,
      let V := Real.log (j : ℝ)
      let J := V * Real.log V / (j : ℝ)
      let A := (j : ℝ) - Real.eulerMascheroniConstant + V ^ 2 / (2 * (j : ℝ))
      |Real.log (unitInverseHeight j : ℝ) - A| ≤ C * J ∧
      |Real.log (integerInverseHeight j : ℝ) - A| ≤ C * J := by
  obtain ⟨_, D, _, hD, hBounds⟩ := eventually_unit_and_integer_bounds_of_LiuSawhney hHeight
  obtain ⟨C, hC, hLower⟩ := eventually_inverse_heights_sharp_lower
  have hFloor : ∀ᶠ N : ℕ in atTop, ⌊(harmonic N : ℝ) - sufficientLoss N D⌋ ≤ (k N : ℤ) :=
    hBounds.mono fun _ hN => hN.1
  let F := C + 8 * D + 8
  refine ⟨F, by dsimp [F]; positivity, ?_⟩
  have hNat : Tendsto (fun j : ℕ => (j : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  have hLog₂ := Real.tendsto_log_atTop.comp hLog
  filter_upwards [unitInverse_adjacent_upper hFloor, eventually_unit_predecessor_scale,
    hLower, hLog.eventually_ge_atTop 1, hLog₂.eventually_ge_atTop 1,
    eventually_ge_atTop (1 : ℕ), tendsto_integerInverseHeight.eventually_ge_atTop (1 : ℕ)]
    with j hAdj hScale hLow hV hLogV hj hT
  let N := unitInverseHeight j
  let T := integerInverseHeight j
  let V := Real.log (j : ℝ)
  let J := V * Real.log V / (j : ℝ)
  let A := (j : ℝ) - Real.eulerMascheroniConstant + V ^ 2 / (2 * (j : ℝ))
  have hj₀ : 0 < j := Nat.succ_le_iff.mp hj
  have hT₀ : 0 < T := Nat.succ_le_iff.mp hT
  have hN₀ : 0 < N := hT₀.trans_le (integerInverseHeight_le_unitInverseHeight j)
  have hJ₀ : 0 ≤ J := by
    exact div_nonneg (mul_nonneg (zero_le_one.trans hV) (zero_le_one.trans hLogV)) (Nat.cast_nonneg _)
  change 1 ≤ V at hV
  change 1 ≤ Real.log V at hLogV
  have hOne : 1 / (j : ℝ) ≤ J := by
    apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg _)
    simpa only [one_mul] using mul_le_mul hV hLogV zero_le_one (zero_le_one.trans hV)
  have hRec := (reciprocal_height_le_inverse_index hj₀ (index_le_h_at_unit j)).trans hOne
  have hSuff : sufficientLoss (N - 1) D ≤ V ^ 2 / (2 * (j : ℝ)) + (8 * D + 7) * J := by
    have hM := (abs_le.mp hScale.1).2
    have hE := mul_le_mul_of_nonneg_left hScale.2.1 hD.le
    change heightMainCorrection (N - 1) - V ^ 2 / (2 * (j : ℝ)) ≤ 7 * J at hM
    change D * heightErrorScale (N - 1) ≤ D * (8 * J) at hE
    have hEq : sufficientLoss (N - 1) D = heightMainCorrection (N - 1) +
        D * heightErrorScale (N - 1) := by unfold sufficientLoss heightMainCorrection heightErrorScale; ring
    rw [hEq]
    nlinarith only [hM,hE]
  have hCenter := (harmonic_log_center hN₀).1
  have hUpper : Real.log (N : ℝ) - A ≤ (8 * D + 8) * J := by
    change (harmonic N : ℝ) - (j : ℝ) < sufficientLoss (N - 1) D + 1 / (N : ℝ) at hAdj
    dsimp only [A]
    nlinarith only [hAdj,hCenter,hRec,hSuff]
  have hTN : Real.log (T : ℝ) ≤ Real.log (N : ℝ) :=
    Real.log_le_log (Nat.cast_pos.mpr hT₀) (by exact_mod_cast integerInverseHeight_le_unitInverseHeight j)
  have hLowF : C * J ≤ F * J :=
    mul_le_mul_of_nonneg_right (by dsimp [F]; linarith only [hD]) hJ₀
  have hUpF : (8 * D + 8) * J ≤ F * J :=
    mul_le_mul_of_nonneg_right (by dsimp [F]; linarith only [hC]) hJ₀
  change A - C * J ≤ Real.log (N : ℝ) ∧ A - C * J ≤ Real.log (T : ℝ) at hLow
  change |Real.log (N : ℝ) - A| ≤ F * J ∧ |Real.log (T : ℝ) - A| ≤ F * J
  exact ⟨abs_le.mpr ⟨by linarith only [hLow.1,hLowF],hUpper.trans hUpF⟩,
    abs_le.mpr ⟨by linarith only [hLow.2,hLowF],by linarith only [hTN,hUpper.trans hUpF]⟩⟩



theorem normalized_inverse_correction {f : ℕ → ℕ} {C : ℝ}
    (h : ∀ᶠ j : ℕ in atTop,
      let V := Real.log (j : ℝ)
      let J := V * Real.log V / (j : ℝ)
      |Real.log (f j : ℝ) - ((j : ℝ) - Real.eulerMascheroniConstant + V ^ 2 / (2 * (j : ℝ)))| ≤
        C * J) :
    Tendsto (fun j : ℕ => (j : ℝ) *
      (Real.log (f j : ℝ) - (j : ℝ) + Real.eulerMascheroniConstant) / Real.log (j : ℝ) ^ 2)
      atTop (𝓝 (1 / 2 : ℝ)) := by
  have hNat : Tendsto (fun j : ℕ => (j : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  have hSmall := (Real.isLittleO_log_id_atTop.tendsto_div_nhds_zero.comp hLog).const_mul C
  have hSmall' : Tendsto (fun j : ℕ => C * (Real.log (Real.log (j : ℝ)) / Real.log (j : ℝ)))
      atTop (𝓝 (0 : ℝ)) := by simpa only [mul_zero, Function.comp_apply, id_eq] using hSmall
  refine Metric.tendsto_nhds.2 fun ε hε => ?_
  filter_upwards [h, hSmall'.eventually_lt_const hε, hLog.eventually_ge_atTop 1,
    eventually_ge_atTop (1 : ℕ)] with j hApprox hεj hV hj
  let x : ℝ := j
  let V := Real.log x
  let L := Real.log (f j : ℝ)
  have hx : 0 < x := Nat.cast_pos.mpr (Nat.succ_le_iff.mp hj)
  have hV₀ : 0 < V := zero_lt_one.trans_le hV
  change C * (Real.log V / V) < ε at hεj
  rw [Real.dist_eq]
  change |x * (L - x + Real.eulerMascheroniConstant) / V ^ 2 - 1 / 2| < ε
  rw [show x * (L - x + Real.eulerMascheroniConstant) / V ^ 2 - 1 / 2 =
      (x / V ^ 2) * (L - (x - Real.eulerMascheroniConstant + V ^ 2 / (2 * x))) by
        field_simp [hx.ne',hV₀.ne']; ring,
    abs_mul, abs_of_nonneg (div_nonneg hx.le (sq_nonneg V))]
  refine lt_of_le_of_lt ?_ hεj
  calc
    _ ≤ (x / V ^ 2) * (C * (V * Real.log V / x)) :=
      mul_le_mul_of_nonneg_left hApprox (div_nonneg hx.le (sq_nonneg V))
    _ = _ := by field_simp [hx.ne',hV₀.ne']

/-- The normalized corrections for the unit and integer inverse heights
converge to one half under the short prime height bound. -/
theorem tendsto_normalized_inverse_heights_of_LiuSawhney
    (hHeight : ShortPointwise.LiuSawhneyPrimeHeight) :
    Tendsto (fun j : ℕ => (j : ℝ) *
      (Real.log (unitInverseHeight j : ℝ) - (j : ℝ) + Real.eulerMascheroniConstant) /
        Real.log (j : ℝ) ^ 2) atTop (𝓝 (1 / 2 : ℝ)) ∧
    Tendsto (fun j : ℕ => (j : ℝ) *
      (Real.log (integerInverseHeight j : ℝ) - (j : ℝ) + Real.eulerMascheroniConstant) /
        Real.log (j : ℝ) ^ 2) atTop (𝓝 (1 / 2 : ℝ)) := by
  obtain ⟨_, _, h⟩ := eventually_inverse_heights_of_LiuSawhney hHeight
  exact ⟨normalized_inverse_correction (h.mono fun _ hj => hj.1),
    normalized_inverse_correction (h.mono fun _ hj => hj.2)⟩

end LeanAB.PaperB
