module

public import PaperB.ShortPointwiseResources
public import PaperB.CRTCoverPools
public import PaperB.SmoothClosure
meta import Mathlib.Tactic

/-! Construct the short pointwise cover using auxiliary CRT primes and smooth closure. -/

public section

open Finset Filter
open scoped Topology

namespace LeanAB.PaperB.ShortPointwise

open Closure

private theorem exists_middle_numerator {p M : ℕ} [Fact p.Prime]
    (hM : 20 * p < M) (a : ZMod p) :
    ∃ r : ℕ, (2 / 3 : ℚ) ≤ (r : ℚ) / M ∧ (r : ℚ) / M ≤ 3 / 4 ∧
      (r : ZMod p) = a * (M : ZMod p) := by
  let j := (2 * M + 2) / 3
  let d := a * (M : ZMod p) - (j : ZMod p)
  let r := j + d.val
  have hv := ZMod.val_lt d
  have hLo : 2 * M ≤ 3 * r := by dsimp only [r, j]; omega
  have hHi : 4 * r ≤ 3 * M := by dsimp only [r, j]; omega
  have hM₀ : (0 : ℚ) < M := Nat.cast_pos.mpr (Nat.zero_le _ |>.trans_lt hM)
  refine ⟨r, (le_div_iff₀ hM₀).mpr ?_, (div_le_iff₀ hM₀).mpr ?_, ?_⟩
  · have h : (2 : ℚ) * M ≤ 3 * r := by exact_mod_cast hLo
    linarith only [h]
  · have h : (4 : ℚ) * r ≤ 3 * M := by exact_mod_cast hHi
    linarith only [h]
  · dsimp only [r]
    rw [Nat.cast_add, ZMod.natCast_zmod_val]
    dsimp only [d]
    abel

/-- Rectify a cleared CRT subset to an exact rational with denominator dividing
the auxiliary prime product. A disjoint smooth block cancels its small factors. -/
theorem coversResidues_of_short_cover_pool {C₀ X₀ Q p T X : ℕ}
    (hclose : UniformSmoothClosure C₀ X₀) (hp : p.Prime) (hQ : Q < p)
    (hX₀ : X₀ ≤ X) (hX : 0 < X) (hTX : T ^ 5 ≤ X) (hXQ : C₀ * X ≤ Q)
    (P : Finset ℕ) (hM : 20 * p < ∏ q ∈ P, q)
    (hP : ∀ q ∈ P, q.Prime ∧ T < q ∧ q < p ∧ q * T ≤ Q ∧ C₀ * X < q)
    (hSmall : mass (primeCofactorPool P T) ≤ 1 / 6)
    (hCover : ∀ q ∈ P, CoversResidues q (interval 1 T)) :
    CoversResidues p (interval 1 Q) := by
  classical
  let _ : Fact p.Prime := ⟨hp⟩
  intro a
  let M := ∏ q ∈ P, q
  let L := Nat.lcmUpto T
  let D := M * L
  have hM₀ : 0 < M := (Nat.zero_le _).trans_lt hM
  have hL₀ : 0 < L := Nat.lcmUpto_pos T
  have hD₀ : 0 < D := Nat.mul_pos hM₀ hL₀
  have hMR : (0 : ℚ) < M := Nat.cast_pos.mpr hM₀
  have hLR : (0 : ℚ) < L := Nat.cast_pos.mpr hL₀
  have hDR : (0 : ℚ) < D := Nat.cast_pos.mpr hD₀
  have hMd : ¬ p ∣ M := by
    have hc : p.Coprime M := Nat.coprime_prod_right_iff.mpr fun q hq =>
      (Nat.coprime_primes hp (hP q hq).1).mpr ((hP q hq).2.2.1.ne.symm)
    exact hp.coprime_iff_not_dvd.mp hc
  have hMZ : (M : ZMod p) ≠ 0 :=
    fun h => hMd ((ZMod.natCast_eq_zero_iff _ _).mp h)
  obtain ⟨r, hrLo, hrHi, hrZ⟩ := exists_middle_numerator hM a
  obtain ⟨S, hS, hCodes⟩ := primeCofactorPool_exists_subset_for_residues
    (fun q hq => ⟨(hP q hq).1, (hP q hq).2.1⟩) hCover (fun q => ((r * L : ℕ) : ZMod q.val))
  have hSmallS := (mass_mono hS).trans hSmall
  let c : ℕ := ∑ b ∈ S, D / b
  have hcR : (c : ℚ) = (D : ℚ) * mass S := by
    dsimp only [c]
    rw [Nat.cast_sum]
    calc
      _ = ∑ b ∈ S, (D : ℚ) / (b : ℚ) := sum_congr rfl fun _ hb =>
        Nat.cast_div_charZero (primeCofactorPool_dvd (hS hb))
      _ = _ := by simp only [mass, div_eq_mul_inv, mul_sum]
  let s : ℚ := (r : ℚ) / M - mass S
  have hsLo : (1 / 2 : ℚ) ≤ s := by dsimp only [s]; linarith only [hrLo, hSmallS]
  have hsHi : s ≤ 3 / 4 := by dsimp only [s]; linarith only [hrHi, mass_nonneg S]
  have hdiff : (r : ℚ) * (L : ℚ) - (c : ℚ) = (D : ℚ) * s := by
    rw [hcR]
    dsimp only [D, s]
    push_cast
    field_simp [hMR.ne']
  have hcLe : c ≤ r * L := by
    have h : (c : ℚ) ≤ (r : ℚ) * (L : ℚ) :=
      sub_nonneg.mp (hdiff.symm ▸ mul_nonneg hDR.le (by linarith only [hsLo]))
    exact_mod_cast h
  have hProd : M ∣ r * L - c := by
    apply Finset.prod_dvd_of_isRelPrime
    · intro q hq l hl hne
      exact Nat.coprime_iff_isRelPrime.mp ((Nat.coprime_primes (hP q hq).1 (hP l hl).1).mpr hne)
    · intro q hq
      apply (ZMod.natCast_eq_zero_iff _ _).mp
      rw [Nat.cast_sub hcLe, sub_eq_zero]
      simpa only [c, D, M, L, Nat.cast_sum] using (hCodes ⟨q, hq⟩).symm
  let k := (r * L - c) / M
  have hk : k * M = r * L - c := Nat.div_mul_cancel hProd
  have hkR : (k : ℚ) * M = (D : ℚ) * s := by
    have h := congrArg (fun n : ℕ => (n : ℚ)) hk
    rw [Nat.cast_mul, Nat.cast_sub hcLe, Nat.cast_mul, hdiff] at h
    exact h
  have hs : s = (k : ℚ) / L := by
    apply (eq_div_iff hLR.ne').mpr
    apply mul_right_cancel₀ hMR.ne'
    calc
      s * (L : ℚ) * (M : ℚ) = (D : ℚ) * s := by dsimp only [D]; push_cast; ring
      _ = (k : ℚ) * (M : ℚ) := hkR.symm
  have hDen : s.den ∣ L := by
    rw [hs, Rat.natCast_div_eq_divInt]
    exact_mod_cast Rat.den_dvd (k : ℤ) (L : ℤ)
  have hRoot : T ≤ Nat.nthRoot 5 X := (Nat.le_nthRoot_iff (by decide)).mpr hTX
  obtain ⟨R, hR, _, hMassR⟩ :=
    hclose.2 X hX₀ hX s hsLo hsHi (hDen.trans (Nat.lcmUpto_dvd_lcmUpto hRoot))
  have hPool (n : ℕ) (hn : n ∈ primeCofactorPool P T) :
      n ∈ interval 1 Q ∧ C₀ * X < n := by
    obtain ⟨q,hq,hn⟩ := mem_biUnion.mp hn
    obtain ⟨b,hb,rfl⟩ := mem_image.mp hn
    obtain ⟨hb₀,hbT⟩ := mem_Icc.mp hb
    have hq₀ := (hP q hq).1.pos
    have hqle : q ≤ q * b := by
      simpa only [max_self, mul_one] using Nat.mul_le_mul_left q hb₀
    exact ⟨mem_Icc.mpr ⟨Nat.mul_pos hq₀ hb₀,
      (Nat.mul_le_mul_left q hbT).trans (hP q hq).2.2.2.1⟩, (hP q hq).2.2.2.2.trans_le hqle⟩
  have hDisc : Disjoint S R := disjoint_left.mpr fun n hn hm =>
    (hPool n (hS hn)).2.not_ge (mem_Icc.mp (hR hm)).2
  have hAll : S ∪ R ⊆ interval 1 Q := union_subset
    (fun n hn => (hPool n (hS hn)).1)
    (fun _ hn => Icc_subset_Icc (le_max_left _ _) hXQ (hR hn))
  have hMass : mass (S ∪ R) = (r : ℚ) / M := by
    rw [show mass (S ∪ R) = mass S + mass R from sum_union hDisc, hMassR]
    dsimp only [s]
    ring
  refine ⟨S ∪ R, hAll, ?_⟩
  obtain ⟨_, hCast⟩ := mass_cast_of_cofactors (p := p) (S ∪ R) (fun b hb => by
    obtain ⟨hb₀,hbQ⟩ := mem_Icc.mp (hAll hb)
    exact ⟨hb₀, fun h => (hbQ.trans_lt hQ).not_ge (Nat.le_of_dvd hb₀ h)⟩)
  change (∑ b ∈ S ∪ R, (b : ZMod p)⁻¹) = a
  rw [← hCast, hMass, Rat.cast_div_of_ne_zero]
  · rw [Rat.cast_natCast, Rat.cast_natCast, hrZ, mul_div_cancel_right₀ _ hMZ]
  · simp
  · simpa only [Rat.num_natCast, Int.cast_natCast] using hMZ

/-- F2's short cover for every sufficiently large prime, at the original width. -/
theorem eventually_shortPointwiseCover :
    ∀ᶠ p : ℕ in atTop, p.Prime → CoversResidues p (interval 1 (coverWidth p)) := by
  obtain ⟨C₀, X₀, hClose⟩ := exists_uniformSmoothClosure
  have hC₀ : (0 : ℝ) < C₀ := Nat.cast_pos.mpr (zero_lt_one.trans hClose.1)
  filter_upwards [eventually_coverWidth_lt,
    eventually_shortPointwiseResources hC₀ (max 1 X₀)] with p hpQ hRes hp
  obtain ⟨P, T, X, hM, hTX, hX₀, hWidth, hSmall, hP, hCover⟩ := hRes
  have hParams (q : ℕ) (hq : q ∈ P) :
      q.Prime ∧ T < q ∧ q < p ∧ q * T ≤ coverWidth p ∧ C₀ * X < q := by
    obtain ⟨hqP, hqT, hqp, hqQ, hqX⟩ := hP q hq
    exact ⟨hqP, hqT, hqp, hqQ, by exact_mod_cast hqX⟩
  exact coversResidues_of_short_cover_pool hClose hp hpQ
    ((le_max_right _ _).trans hX₀) (zero_lt_one.trans_le ((le_max_left _ _).trans hX₀))
    hTX (by exact_mod_cast hWidth) P hM hParams hSmall hCover

/-- The common fourth-power width for the full baseline prime window. -/
theorem eventually_baseline_common_cover :
    ∀ᶠ N : ℕ in atTop, ∀ p ∈ largePrimes N,
      CoversResidues p (interval 1 (baselineCoverBound 4 N)) ∧
      baselineCoverBound 4 N < p ∧
      ((p : ℝ) ≤ baselineCutoff 4 N → p * baselineCoverBound 4 N ≤ N) :=
  eventually_baseline_common_cover_of_shortPointwise eventually_shortPointwiseCover

/-- The fifth-power width given as an alternative in the manuscript. -/
theorem eventually_shortPointwiseCover_fifth_power :
    ∀ᶠ p : ℕ in atTop, p.Prime →
      CoversResidues p (interval 1 (baselineCoverBound 5 p)) := by
  have hL : Tendsto (fun p : ℕ => Real.log (p : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [eventually_shortPointwiseCover, hL.eventually_ge_atTop 0,
    (Real.tendsto_log_atTop.comp hL).eventually_ge_atTop 1] with p hC hL hU hprime
  have hW : coverWidth p ≤ baselineCoverBound 5 p := Nat.ceil_mono
    (mul_le_mul_of_nonneg_left
      (pow_le_pow_right₀ (show 1 ≤ Real.log (Real.log (p : ℝ)) from hU) (by decide)) hL)
  intro a
  obtain ⟨S, hS, hz⟩ := hC hprime a
  exact ⟨S, hS.trans (Icc_subset_Icc_right hW), hz⟩

end LeanAB.PaperB.ShortPointwise
