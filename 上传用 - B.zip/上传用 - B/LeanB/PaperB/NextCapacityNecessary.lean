module

public import PaperA.ModularProjection
public import PaperA.BGMS
public import PaperA.IntegralRecurrence
public import PaperB.Obstruction.Published
public import PaperB.RepairBudget
import Mathlib.Tactic

public section

/-! The next-order capacity obstruction, using one-color modular injectivity
to exclude almost all blocks above the sharper cutoff. -/

namespace LeanAB.PaperB

open Filter Finset Asymptotics
open scoped Topology BigOperators

private theorem cast_reciprocal_mass {p q : ℕ} [Fact p.Prime] (hqp : q < p)
    {J : Finset ℕ} (hJ : J ⊆ interval 1 q) :
    (((mass J).den : ZMod p) ≠ 0) ∧ ((mass J : ℚ) : ZMod p) = cofactorResidue p J := by
  classical
  induction J using Finset.induction_on with
  | empty => simp [mass, cofactorResidue]
  | insert a J ha ih =>
    have hJa : J ⊆ interval 1 q := fun b hb => hJ (mem_insert_of_mem hb)
    have ha' := mem_Icc.mp (hJ (mem_insert_self a J))
    have ha0 : 0 < a := ha'.1
    have hpa : ¬ p ∣ a := fun h => (hqp.not_ge ((Nat.le_of_dvd ha0 h).trans ha'.2))
    have hd : (((a : ℚ)⁻¹).den : ZMod p) ≠ 0 := by
      rw [Rat.inv_natCast_den_of_pos ha0]
      exact fun h => hpa ((ZMod.natCast_eq_zero_iff _ _).mp h)
    have hc : (((a : ℚ)⁻¹ : ℚ) : ZMod p) = (a : ZMod p)⁻¹ := by
      rw [Rat.cast_inv_of_ne_zero, Rat.cast_natCast]
      simpa only [Rat.num_natCast, Int.cast_natCast] using fun h =>
        hpa ((ZMod.natCast_eq_zero_iff a p).mp h)
    obtain ⟨hden, hcast⟩ := ih hJa
    have hm : mass (insert a J) = (a : ℚ)⁻¹ + mass J := by simp [mass, sum_insert ha]
    rw [hm]
    refine ⟨?_, ?_⟩
    · intro h
      have hDiv := ((ZMod.natCast_eq_zero_iff _ p).mp h).trans
        (Rat.add_den_dvd ((a : ℚ)⁻¹) (mass J))
      have hProd := (ZMod.natCast_eq_zero_iff _ p).mpr hDiv
      rw [Nat.cast_mul] at hProd
      exact mul_ne_zero hd hden hProd
    · rw [Rat.cast_add_of_ne_zero hd hden, hc, hcast, cofactorResidue, cofactorResidue, sum_insert ha]

/-- Injectivity of the one-color projection excludes every nonempty zero-residue subset. -/
theorem cofactorResidue_ne_zero_of_injective {p q : ℕ} [Fact p.Prime] (hqp : q < p)
    (hinj : Function.Injective (PaperA.reduceOutput (q := q) (m := 1) (p := p)))
    {J : Finset ℕ} (hJ : J ⊆ interval 1 q) (hJ₀ : J.Nonempty) :
    cofactorResidue p J ≠ 0 := by
  intro hzero
  have hJsum : mass J ∈ PaperA.BGMS.subsetSums (interval 1 q) :=
    PaperA.BGMS.mem_subsetSums.mpr ⟨J,hJ,rfl⟩
  have h0sum : 0 ∈ PaperA.BGMS.subsetSums (interval 1 q) :=
    PaperA.BGMS.mem_subsetSums.mpr ⟨∅, empty_subset _, by simp [mass]⟩
  obtain ⟨c,hc⟩ := (PaperA.BGMS.mem_subsetSums_iff_exists_value _ _).mp hJsum
  obtain ⟨d,hd⟩ := (PaperA.BGMS.mem_subsetSums_iff_exists_value _ _).mp h0sum
  let x := PaperA.sampleOutput (interval 1 q) 1 c
  let y := PaperA.sampleOutput (interval 1 q) 1 d
  have hX : x.val 0 = mass J := hc
  have hY : y.val 0 = 0 := hd
  have hProj : PaperA.reduceOutput (p := p) x = PaperA.reduceOutput (p := p) y := by
    funext i
    have hi : i = 0 := Subsingleton.elim _ _
    subst i
    change (x.val 0 : ZMod p) = (y.val 0 : ZMod p)
    rw [hX,hY,(cast_reciprocal_mass (p := p) hqp hJ).2,hzero,Rat.cast_zero]
  have hxy := congrArg (fun t : PaperA.Output (interval 1 q) 1 => t.val 0) (hinj hProj)
  change x.val 0 = y.val 0 at hxy
  rw [hX,hY] at hxy
  have hPos : 0 < mass J := by
    apply sum_pos'
    · intro b _
      exact inv_nonneg.mpr (Nat.cast_nonneg _)
    · obtain ⟨b,hb⟩ := hJ₀
      exact ⟨b,hb,inv_pos.mpr (by exact_mod_cast (mem_Icc.mp (hJ hb)).1)⟩
  exact hPos.ne' hxy

private theorem primePart_eq_empty_of_projection_injective_of_localResidue {N p : ℕ} (hp : p ∈ largePrimes N)
    (hinj : let : Fact p.Prime := ⟨(mem_largePrimes.mp hp).1⟩
      Function.Injective (PaperA.reduceOutput (q := N / p) (m := 1) (p := p)))
    {S : Finset ℕ} (hS : S ⊆ denominators N) (hz : localResidue p S = 0) :
    primePart p S = ∅ := by
  classical
  obtain ⟨hpP, _, hpL⟩ := mem_largePrimes.mp hp
  let : Fact p.Prime := ⟨hpP⟩
  have hq : N / p < p := (Nat.div_lt_iff_lt_mul hpP.pos).mpr (Nat.sqrt_lt.mp hpL)
  let F := primePart p S
  let J := F.image (· / p)
  have hJ : J ⊆ interval 1 (N / p) := by
    intro b hb
    obtain ⟨a,ha,rfl⟩ := mem_image.mp hb
    obtain ⟨ha,hd⟩ := mem_filter.mp ha
    obtain ⟨ha₀,haN⟩ := mem_Icc.mp (hS ha)
    exact mem_Icc.mpr ⟨Nat.div_pos (Nat.le_of_dvd ha₀ hd) hpP.pos, Nat.div_le_div_right haN⟩
  have hInj : Set.InjOn (· / p) (↑F : Set ℕ) := by
    intro a ha b hb hv
    have ha' := (mem_filter.mp ha).2
    have hb' := (mem_filter.mp hb).2
    have hh := congrArg (· * p) hv
    simpa only [Nat.div_mul_cancel ha',Nat.div_mul_cancel hb'] using hh
  change (∑ n ∈ F, ((n / p : ℕ) : ZMod p)⁻¹) = 0 at hz
  have hJz : cofactorResidue p J = 0 := by
    rw [cofactorResidue, sum_image (fun _ ha _ hb => hInj ha hb)]
    exact hz
  by_contra! h
  exact cofactorResidue_ne_zero_of_injective hq hinj hJ (h.image _) hJz

/-- Given local injectivity, a representation with denominator coprime to the
large prime p uses no multiples of p. -/
theorem primePart_eq_empty_of_projection_injective {N p : ℕ} (hp : p ∈ largePrimes N)
    (hinj : let : Fact p.Prime := ⟨(mem_largePrimes.mp hp).1⟩
      Function.Injective (PaperA.reduceOutput (q := N / p) (m := 1) (p := p)))
    {S : Finset ℕ} (hS : S ⊆ denominators N) (hden : ¬ p ∣ (mass S).den) :
    primePart p S = ∅ :=
  primePart_eq_empty_of_projection_injective_of_localResidue hp hinj hS
    (localResidue_zero_of_den_ndvd hp hS hden)

private theorem subset_denominators_of_subset_interval {N d : ℕ} {S : Finset ℕ}
    (hS : S ⊆ interval d N) : S ⊆ denominators N := fun b hb => by
  obtain ⟨hLo,hHi⟩ := mem_Icc.mp (hS hb)
  exact mem_Icc.mpr ⟨(le_max_left _ _).trans hLo,hHi⟩

private theorem packing_mass_le_sub_window_with_exceptions_of_localResidue {N d Q m : ℕ} (hN : 0 < N)
    (hQ : 0 < Q) (hd : d ≤ Nat.sqrt N) (hHalf : 2 * Real.log (Q : ℝ) ≤ Real.log N)
    (E : Finset ℕ)
    (hInject : ∀ (p : ℕ) [Fact p.Prime], p ≤ N → (N : ℝ) / (Q : ℝ) < (p : ℝ) →
      p ∉ E → Function.Injective (PaperA.reduceOutput (q := N / p) (m := 1) (p := p)))
    (r : Fin m → ℚ) (S : Fin m → Finset ℕ)
    (hdis : Pairwise (fun i j => Disjoint (S i) (S j)))
    (hall : ∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧
      ∀ p ∈ largePrimes N, localResidue p (S i) = 0) :
    ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) -
      windowPrimeMass N (Real.log (Q : ℝ)) + (E.card : ℝ) * (Q : ℝ) ^ 2 / N := by
  classical
  have hN₀ : (0 : ℝ) < N := by exact_mod_cast hN
  have hQ₀ : (0 : ℝ) < Q := by exact_mod_cast hQ
  let Z := (N : ℝ) / Q
  let P := primesBetween Z N
  let W (p : ℕ) : ℝ := (mass (cofactorBlock N p) : ℝ) / p
  let good := P \ E
  let bad := P \ good
  have hZ : (N : ℝ) * Real.exp (-Real.log (Q : ℝ)) = Z := by
    rw [Real.exp_neg, Real.exp_log hQ₀]
    exact (div_eq_mul_inv _ _).symm
  have hRoot : √(N : ℝ) ≤ Z := (sqrt_le_windowLeft hN₀ hHalf).trans_eq hZ
  have hP (p : ℕ) (hp : p ∈ P) : (p ∈ largePrimes N) ∧ Z < (p : ℝ) := by
    obtain ⟨hpZ,hpN,hPrime⟩ := (mem_primesBetween (div_nonneg hN₀.le hQ₀.le) hN₀.le).mp hp
    have hS := hRoot.trans_lt hpZ
    have hLarge := (Real.sqrt_lt hN₀.le (Nat.cast_nonneg p)).mp hS
    rw [pow_two] at hLarge
    exact ⟨mem_largePrimes.mpr ⟨hPrime,by exact_mod_cast hpN,Nat.sqrt_lt.mpr (by exact_mod_cast hLarge)⟩,hpZ⟩
  have hCost (p : ℕ) (hp : p ∈ P) : W p ≤ (Q : ℝ) ^ 2 / N := by
    obtain ⟨hpL,hpZ⟩ := hP p hp
    have hp₀ : (0 : ℝ) < p := by exact_mod_cast (mem_largePrimes.mp hpL).1.pos
    have hQN : (N : ℝ) < (p : ℝ) * Q := (div_lt_iff₀ hQ₀).mp hpZ
    have hcof : ((N / p : ℕ) : ℝ) ≤ Q := Nat.cast_div_le.trans
      ((div_lt_iff₀ hp₀).mpr (by rwa [mul_comm])).le
    have hMass : (mass (cofactorBlock N p) : ℝ) ≤ (Q : ℝ) :=
      (show (mass (cofactorBlock N p) : ℝ) ≤ ((N / p : ℕ) : ℝ) by
        exact_mod_cast (PaperA.harmonic_le (N / p))).trans hcof
    calc
      _ ≤ (Q : ℝ) / p := div_le_div_of_nonneg_right hMass hp₀.le
      _ ≤ (Q : ℝ) / Z := div_le_div_of_nonneg_left hQ₀.le (div_pos hN₀ hQ₀) hpZ.le
      _ = _ := by dsimp only [Z]; field_simp
  have hPsum : windowPrimeMass N (Real.log (Q : ℝ)) = ∑ p ∈ P, W p := by
    rw [windowPrimeMass_eq_union_mass hN hHalf, hZ]
    have hh : ((P : Finset ℕ) : Set ℕ).PairwiseDisjoint
        (fun p => primePart p (denominators N)) := by
      intro p hp q hq hpq
      exact primePart_disjoint (hP p hp).1 (hP q hq).1 hpq
    change (mass (P.biUnion (fun p => primePart p (denominators N))) : ℝ) = _
    rw [show mass (P.biUnion (fun p => primePart p (denominators N))) =
      ∑ p ∈ P, mass (primePart p (denominators N)) from sum_biUnion hh, Rat.cast_sum]
    exact sum_congr rfl fun p hp => by rw [mass_primePart (mem_largePrimes.mp (hP p hp).1).1.pos,
      Rat.cast_div,Rat.cast_natCast]
  have hBadE : bad ⊆ E := by
    intro p hp
    obtain ⟨hpP,hpG⟩ := mem_sdiff.mp hp
    by_contra he
    exact hpG (mem_sdiff.mpr ⟨hpP, he⟩)
  have hBad : ∑ p ∈ bad, W p ≤ (E.card : ℝ) * (Q : ℝ) ^ 2 / N := calc
    _ ≤ ∑ _p ∈ bad, (Q : ℝ) ^ 2 / N := sum_le_sum fun p hp => hCost p (mem_sdiff.mp hp).1
    _ ≤ _ := by
      rw [sum_const, nsmul_eq_mul, ← mul_div_assoc]
      exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right
        (by exact_mod_cast card_le_card hBadE) (sq_nonneg _)) hN₀.le
  let X := good.biUnion (fun p => primePart p (denominators N))
  have hXsub : X ⊆ interval d N := by
    intro n hn
    obtain ⟨p,hpg,hpn⟩ := mem_biUnion.mp hn
    obtain ⟨hnN,hdiv⟩ := mem_filter.mp hpn
    have hI := mem_Icc.mp hnN
    have hLarge := (mem_largePrimes.mp (hP p (mem_sdiff.mp hpg).1).1).2.2
    exact mem_Icc.mpr ⟨max_le hI.1 ((hd.trans hLarge.le).trans
      (Nat.le_of_dvd hI.1 hdiv)),hI.2⟩
  have hXsum : (mass X : ℝ) = ∑ p ∈ good, W p := by
    have hD : ((good : Finset ℕ) : Set ℕ).PairwiseDisjoint
        (fun p => primePart p (denominators N)) := by
      intro p hp q hq hpq
      exact primePart_disjoint (hP p (mem_sdiff.mp hp).1).1 (hP q (mem_sdiff.mp hq).1).1 hpq
    rw [show mass X = ∑ p ∈ good, mass (primePart p (denominators N)) from sum_biUnion hD,
      Rat.cast_sum]
    exact sum_congr rfl fun p hp => by rw [mass_primePart
      (mem_largePrimes.mp (hP p (mem_sdiff.mp hp).1).1).1.pos,Rat.cast_div,Rat.cast_natCast]
  have hSX (i : Fin m) : S i ⊆ interval d N \ X := by
    intro n hn
    refine mem_sdiff.mpr ⟨(hall i).1 hn, ?_⟩
    intro hX
    obtain ⟨p,hpG,hpn⟩ := mem_biUnion.mp hX
    obtain ⟨hpP,hpE⟩ := mem_sdiff.mp hpG
    obtain ⟨hpL,hpZ⟩ := hP p hpP
    obtain ⟨hpPrime,hpN,_⟩ := mem_largePrimes.mp hpL
    let : Fact p.Prime := ⟨hpPrime⟩
    have hm := primePart_eq_empty_of_projection_injective_of_localResidue hpL
      (hInject p hpN hpZ hpE) (subset_denominators_of_subset_interval (hall i).1)
      ((hall i).2.2 p hpL)
    have hmemb : n ∈ primePart p (S i) := mem_filter.mpr ⟨hn,(mem_filter.mp hpn).2⟩
    rw [hm] at hmemb
    exact notMem_empty _ hmemb
  have hPack : (∑ i, r i) ≤ mass (interval d N) - mass X := by
    have hSub : univ.biUnion S ⊆ interval d N \ X :=
      Finset.biUnion_subset.mpr (fun i _ => hSX i)
    rw [← show mass (interval d N \ X) + mass X = mass (interval d N) from sum_sdiff hXsub,
      add_sub_cancel_right]
    calc
      _ = ∑ i, mass (S i) := sum_congr rfl fun i _ => (hall i).2.1.symm
      _ = mass (univ.biUnion S) := (sum_biUnion (fun i _ j _ hij => hdis hij)).symm
      _ ≤ _ := mass_mono hSub
  have hPackR : ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) - (mass X : ℝ) := by
    exact_mod_cast hPack
  have hSplit : (∑ p ∈ bad, W p) + (∑ p ∈ good, W p) = ∑ p ∈ P, W p :=
    sum_sdiff (show good ⊆ P from sdiff_subset)
  linarith only [hPackR,hXsum,hSplit,hBad,hPsum]


private theorem localResidue_eq_zero_of_interval_mass_den_ndvd {N d : ℕ} {S : Finset ℕ} {r : ℚ}
    (hS : S ⊆ interval d N) (hMass : mass S = r)
    (hDen : ∀ p : ℕ, p.Prime → Nat.sqrt N < p → ¬p ∣ r.den)
    (p : ℕ) (hp : p ∈ largePrimes N) : localResidue p S = 0 := by
  obtain ⟨hPrime,_,hLarge⟩ := mem_largePrimes.mp hp
  exact localResidue_zero_of_den_ndvd hp (subset_denominators_of_subset_interval hS)
    (hMass ▸ hDen p hPrime hLarge)

/-- The packing loss from a prime window with exceptional primes. The
exceptions are charged by their number times the uniform block mass bound. -/
theorem packing_mass_le_sub_window_with_exceptions {N d Q m : ℕ} (hN : 0 < N)
    (hQ : 0 < Q) (hd : d ≤ Nat.sqrt N) (hHalf : 2 * Real.log (Q : ℝ) ≤ Real.log N)
    (E : Finset ℕ)
    (hInject : ∀ (p : ℕ) [Fact p.Prime], p ≤ N → (N : ℝ) / (Q : ℝ) < (p : ℝ) →
      p ∉ E → Function.Injective (PaperA.reduceOutput (q := N / p) (m := 1) (p := p)))
    (r : Fin m → ℚ) (S : Fin m → Finset ℕ)
    (hdis : Pairwise (fun i j => Disjoint (S i) (S j)))
    (hall : ∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧
      ∀ p : ℕ, p.Prime → Nat.sqrt N < p → ¬p ∣ (r i).den) :
    ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) -
      windowPrimeMass N (Real.log (Q : ℝ)) + (E.card : ℝ) * (Q : ℝ) ^ 2 / N :=
  packing_mass_le_sub_window_with_exceptions_of_localResidue hN hQ hd hHalf E hInject r S hdis
    (fun i => ⟨(hall i).1, (hall i).2.1, localResidue_eq_zero_of_interval_mass_den_ndvd
      (hall i).1 (hall i).2.1 (hall i).2.2⟩)

private theorem eventually_shortAliasLength_window (a : ℝ) (ha : 0 < a) :
    ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      let U := Real.log L
      let V := Real.log U
      let Z := Real.log (Real.log V)
      let Q := PaperA.shortAliasLength a N
      let w := Real.log (Q : ℝ)
      0 < Q ∧ (Q : ℝ) ≤ L ^ 2 ∧ 2 * w ≤ L ∧
        |w - U| ≤ 2 * V ∧ U + V - 2 * Z - max 0 (Real.log 2 - Real.log a) ≤ w := by
  let K := max 0 (Real.log 2 - Real.log a)
  have hN : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hL := Real.tendsto_log_atTop.comp hN
  have hU := Real.tendsto_log_atTop.comp hL
  have hV := Real.tendsto_log_atTop.comp hU
  have hW := Real.tendsto_log_atTop.comp hV
  have hQuarter := Real.isLittleO_log_id_atTop.bound (show (0 : ℝ) < 1 / 4 by norm_num)
  filter_upwards [hN.eventually (PaperA.eventually_scaled_aliasScale_bounds a ha),
    hL.eventually PaperA.eventually_iteratedLogA_bounds, hL.eventually_ge_atTop 2,
    hU.eventually_ge_atTop 1, hV.eventually_ge_atTop K,
    hV.eventually_ge_atTop (Real.log a), hW.eventually_ge_atTop 1,
    hL.eventually hQuarter] with N hScale hA hL2 hU1 hVK hVa hW1 hFour
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let V := Real.log U
  let W := Real.log V
  let Z := Real.log W
  let Q := PaperA.shortAliasLength a N
  let w := Real.log (Q : ℝ)
  let x := a * PaperA.aliasScale (N : ℝ)
  change 0 < Q ∧ (Q : ℝ) ≤ L ^ 2 ∧ 2 * w ≤ L ∧
    |w - U| ≤ 2 * V ∧ U + V - 2 * Z - K ≤ w
  have hL₀ : 0 < L := by linarith only [show 2 ≤ L from hL2]
  have hU₀ : 0 < U := zero_lt_one.trans_le hU1
  have hV₀ : 0 < V := by
    have h := show 1 ≤ Real.log V from hW1
    by_contra! hV
    have hK₀ : 0 ≤ K := le_max_left _ _
    have hv := le_antisymm hV (hK₀.trans hVK)
    rw [hv, Real.log_zero] at h
    norm_num at h
  have hW₀ : 0 < W := zero_lt_one.trans_le hW1
  have hx2 : 2 ≤ x := (show 2 ≤ L from hL2).trans hScale.1
  have hx₀ : 0 < x := zero_lt_two.trans_le hx2
  have hQupper : (Q : ℝ) ≤ x := Nat.floor_le hx₀.le
  have hQlower : x / 2 ≤ (Q : ℝ) := by
    linarith only [hx2, show x < (Q : ℝ) + 1 from Nat.lt_floor_add_one x]
  have hQ₀ : 0 < (Q : ℝ) := (by positivity : 0 < x / 2).trans_le hQlower
  have hQsq : (Q : ℝ) ≤ L ^ 2 := hQupper.trans hScale.2
  have hwU : w ≤ 2 * U := by
    have h := Real.log_le_log hQ₀ hQsq
    rw [Real.log_pow] at h
    simpa only [Nat.cast_ofNat] using h
  have hUsmall : U ≤ (1 / 4 : ℝ) * L := by
    change ‖U‖ ≤ (1 / 4 : ℝ) * ‖L‖ at hFour
    simpa only [Real.norm_eq_abs, abs_of_nonneg hU₀.le, abs_of_nonneg hL₀.le] using hFour
  have hHalf : 2 * w ≤ L := by linarith only [hwU, hUsmall]
  have haForm : x = (a * L * U) / PaperA.iteratedLogA L := by
    simp only [x, L, U, PaperA.aliasScale, PaperA.aliasScaleFromLog]
    ring
  have hA₀ : 0 < PaperA.iteratedLogA L :=
    zero_lt_one.trans_le (PaperA.one_le_iteratedLogA _)
  have hLogA₁ : 0 ≤ Real.log (PaperA.iteratedLogA L) :=
    Real.log_nonneg (PaperA.one_le_iteratedLogA _)
  have hLogA₂ : Real.log (PaperA.iteratedLogA L) ≤ 2 * Z := by
    have ht := Real.log_le_log hA₀ (show PaperA.iteratedLogA L ≤ W ^ 2 from hA.2)
    rw [Real.log_pow] at ht
    simpa only [Nat.cast_ofNat] using ht
  have hLogx : Real.log x = Real.log a + U + V - Real.log (PaperA.iteratedLogA L) := by
    rw [haForm, Real.log_div (mul_ne_zero (mul_ne_zero ha.ne' hL₀.ne') hU₀.ne') hA₀.ne',
      Real.log_mul (mul_ne_zero ha.ne' hL₀.ne') hU₀.ne', Real.log_mul ha.ne' hL₀.ne']
  have hwUpper := Real.log_le_log hQ₀ hQupper
  have hwLower := Real.log_le_log (show 0 < x / 2 by positivity) hQlower
  rw [hLogx] at hwUpper
  rw [Real.log_div hx₀.ne' (by norm_num), hLogx] at hwLower
  have hWleV : W ≤ V :=
    (Real.log_le_sub_one_of_pos hV₀).trans (sub_le_self _ zero_le_one)
  have hZleV : Z ≤ V :=
    ((Real.log_le_sub_one_of_pos hW₀).trans (sub_le_self _ zero_le_one)).trans hWleV
  have hLow : U + V - 2 * Z - K ≤ w := by
    linarith only [hwLower, hLogA₂, le_max_right (0 : ℝ) (Real.log 2 - Real.log a)]
  have hAbs : |w - U| ≤ 2 * V := abs_le.mpr ⟨
    by linarith only [hLow,hZleV,show K ≤ V from hVK],
    by linarith only [hwUpper,hLogA₁,show Real.log a ≤ V from hVa]⟩
  exact ⟨by exact_mod_cast hQ₀,hQsq,hHalf,hAbs,hLow⟩

private theorem eventually_nextCapacity_necessary_of_localResidue (d : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      ∀ {m : ℕ} (r : Fin m → ℚ) (S : Fin m → Finset ℕ),
        Pairwise (fun i j => Disjoint (S i) (S j)) →
        (∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧
          ∀ p ∈ largePrimes N, localResidue p (S i) = 0) →
        let L := Real.log (N : ℝ)
        let U := Real.log L
        ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) -
          (U ^ 2 / (2 * L) + U * Real.log U / L -
            (U / L) * (2 * Real.log (Real.log (Real.log U)) + C)) := by
  obtain ⟨C₀,hC₀,hUpper⟩ := PaperA.intervalRenyi_le_iteratedLogB 1
  have hSupport : ∀ᶠ q : ℕ in atTop,
      PaperA.supportEntropy (interval 1 q) 1 ≤ C₀ * PaperA.iteratedLogB q := by
    exact Filter.Eventually.of_forall fun q => by
      simpa only [PaperA.intervalRenyi, PaperA.FiniteLaw.renyi_zero, PaperA.configurationLaw_hartley]
        using hUpper 0 q
  obtain ⟨a,ha,hShort⟩ :=
    PaperA.eventually_modular_short_of_support_upper C₀ (zero_lt_one.trans_le hC₀) hSupport
  obtain ⟨C₁,hC₁,hWindow⟩ := eventually_windowPrimeMass_error_loglog 2 (by norm_num)
  let K := max 0 (Real.log 2 - Real.log a)
  refine ⟨K + C₁ + 1, by linarith only [le_max_left (0 : ℝ) (Real.log 2 - Real.log a),hC₁], ?_⟩
  have hN : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hL := Real.tendsto_log_atTop.comp hN
  have hU := Real.tendsto_log_atTop.comp hL
  filter_upwards [hShort, hWindow, eventually_shortAliasLength_window a ha, hL.eventually_ge_atTop 1,
    hU.eventually_ge_atTop 1, eventually_ge_atTop 1, eventually_ge_atTop (d * d),
    Closure.eventually_log_pow_le_rpow 5 (show (0 : ℝ) < 1 / 2 by norm_num)]
    with N hShortN hWindowN hCutN hL1 hU1 hN1 hdN hSlow
  intro m r S hPair hAll
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let V := Real.log U
  let Z := Real.log (Real.log V)
  let Q := PaperA.shortAliasLength a N
  let w := Real.log (Q : ℝ)
  let E := PaperA.shortExceptional N Q
  change ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) -
    (U ^ 2 / (2 * L) + U * V / L - (U / L) * (2 * Z + (K + C₁ + 1)))
  have hN₀ : 0 < N := zero_lt_one.trans_le hN1
  have hNr₀ : 0 < (N : ℝ) := by exact_mod_cast hN₀
  have hL₀ : 0 < L := zero_lt_one.trans_le hL1
  have hU₀ : 0 < U := zero_lt_one.trans_le hU1
  obtain ⟨hQ,hQsq,hHalf,hClose,hCut⟩ := hCutN
  have hQr : 0 < (Q : ℝ) := by exact_mod_cast hQ
  have hInj (p : ℕ) [Fact p.Prime] (hp : p ≤ N)
      (hp' : (N : ℝ) / (Q : ℝ) < (p : ℝ)) (he : p ∉ E) :
      Function.Injective (PaperA.reduceOutput (q := N / p) (m := 1) (p := p)) := by
    have hp₀ : 0 < (p : ℝ) := by exact_mod_cast (Fact.out : Nat.Prime p).pos
    have hpq : (N : ℝ) < (p : ℝ) * Q := (div_lt_iff₀ hQr).mp hp'
    have hq : N / p ≤ Q := by
      have hQr' : ((N / p : ℕ) : ℝ) ≤ (Q : ℝ) :=
        Nat.cast_div_le.trans ((div_lt_iff₀ hp₀).mpr (by rwa [mul_comm])).le
      exact_mod_cast hQr'
    have hp'' : (N : ℝ) / ((Q : ℝ) + 1) < (p : ℝ) :=
      (div_le_div_of_nonneg_left hNr₀.le hQr (by linarith)).trans_lt hp'
    exact hShortN.2 p hp hp'' he (N / p) hq 1
  have hPack := packing_mass_le_sub_window_with_exceptions_of_localResidue hN₀ hQ
    (Nat.le_sqrt.mpr hdN) hHalf E hInj r S hPair hAll
  have hPower : L ^ (5 : ℕ) ≤ √(N : ℝ) := by simpa only [Real.sqrt_eq_rpow] using hSlow
  have hNum : (E.card : ℝ) * (Q : ℝ) ^ 2 * L ≤ (N : ℝ) := calc
    _ ≤ (√(N : ℝ) * (L ^ 2) ^ 2) * L := mul_le_mul_of_nonneg_right
      (mul_le_mul hShortN.1 (pow_le_pow_left₀ hQr.le hQsq 2) (sq_nonneg _)
        (Real.sqrt_nonneg _)) hL₀.le
    _ = √(N : ℝ) * L ^ 5 := by ring
    _ ≤ √(N : ℝ) * √(N : ℝ) := mul_le_mul_of_nonneg_left hPower (Real.sqrt_nonneg _)
    _ = N := Real.mul_self_sqrt hNr₀.le
  have hExcept : (E.card : ℝ) * (Q : ℝ) ^ 2 / N ≤ U / L :=
    ((div_le_div_iff₀ hNr₀ hL₀).mpr (by simpa only [one_mul] using hNum) :
      (E.card : ℝ) * (Q : ℝ) ^ 2 / N ≤ 1 / L).trans
      (div_le_div_of_nonneg_right hU1 hL₀.le)
  have hPrimeSum : w ^ 2 / (2 * L) - C₁ * U / L ≤ windowPrimeMass N w := by
    linarith only [(abs_le.mp (hWindowN w hClose)).1]
  have hSquare : U ^ 2 + 2 * U * (V - 2 * Z - K) ≤ w ^ 2 := by
    have hLower : V - 2 * Z - K ≤ w - U := by linarith only [hCut]
    nlinarith only [mul_le_mul_of_nonneg_left hLower (show 0 ≤ 2 * U by positivity),
      sq_nonneg (w - U)]
  have hMain : U ^ 2 / (2 * L) + U * V / L - (U / L) * (2 * Z + K) ≤
      w ^ 2 / (2 * L) := by
    convert div_le_div_of_nonneg_right hSquare (show 0 ≤ 2 * L by positivity) using 1
    field_simp [hL₀.ne']
    ring
  rw [show U / L * (2 * Z + (K + C₁ + 1)) =
    U / L * (2 * Z + K) + C₁ * U / L + U / L by ring]
  linarith only [hPack,hExcept,hPrimeSum,hMain]

/-- Next-order necessary side of the F2 capacity theorem, with targets whose
reduced denominators have no prime factor above floor sqrt N. -/
theorem eventually_nextCapacity_necessary (d : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      ∀ {m : ℕ} (r : Fin m → ℚ) (S : Fin m → Finset ℕ),
        Pairwise (fun i j => Disjoint (S i) (S j)) →
        (∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧
          ∀ p : ℕ, p.Prime → Nat.sqrt N < p → ¬p ∣ (r i).den) →
        let L := Real.log (N : ℝ)
        let U := Real.log L
        ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) -
          (U ^ 2 / (2 * L) + U * Real.log U / L -
            (U / L) * (2 * Real.log (Real.log (Real.log U)) + C)) := by
  obtain ⟨C,hC,hEventual⟩ := eventually_nextCapacity_necessary_of_localResidue d
  refine ⟨C,hC,hEventual.mono ?_⟩
  intro N hN m r S hPair hAll
  exact hN r S hPair (fun i => ⟨(hAll i).1, (hAll i).2.1,
    localResidue_eq_zero_of_interval_mass_den_ndvd (hAll i).1 (hAll i).2.1 (hAll i).2.2⟩)

/-- The local capacity deficit has the same next-order lower bound. -/
theorem eventually_nextCapacity_deficit_lower :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      let U := Real.log L
      U ^ 2 / (2 * L) + U * Real.log U / L - (U / L) *
        (2 * Real.log (Real.log (Real.log U)) + C) ≤
      (_root_.harmonic N : ℝ) - (capacity N : ℝ) := by
  obtain ⟨C,hC,hEventual⟩ := eventually_nextCapacity_necessary_of_localResidue 1
  refine ⟨C,hC,hEventual.mono ?_⟩
  intro N hN
  obtain ⟨S,hS,hMass⟩ := (capacity_isGreatest N).1
  have h := hN (m := 1) (fun _ => capacity N) (fun _ => S)
    (fun i j hij => (hij (Subsingleton.elim i j)).elim)
    (fun _ => ⟨hS.1,hMass,hS.2⟩)
  have hFull : (mass (interval 1 N) : ℝ) = (_root_.harmonic N : ℝ) := by
    exact_mod_cast mass_denominators_eq_harmonic N
  rw [Fin.sum_univ_one, hFull] at h
  dsimp only at h ⊢
  linarith only [h]

end LeanAB.PaperB
