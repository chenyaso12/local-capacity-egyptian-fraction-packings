module

public import PaperB.PrimeFrequencies
public import PaperB.Closure
public import PaperB.Obstruction.PrimeMass
public import Mathlib.Data.Nat.GCD.BigOperators
meta import Mathlib.Tactic

/-! Cleared representatives from the actual prime cofactor pools in the lifting step. -/

@[expose] public section

open Finset

namespace LeanAB.PaperB.Closure

/-- One cofactor interval for each prime in an auxiliary set. -/
def primeCofactorPool (P : Finset ℕ) (T : ℕ) : Finset ℕ :=
  P.biUnion fun p => mark p (interval 1 T)

private theorem primeCofactorBlock_disjoint {p q T : ℕ} (hp : p.Prime)
    (hq : q.Prime) (hpT : T < p) (hpq : p ≠ q) :
    Disjoint (mark p (interval 1 T)) (mark q (interval 1 T)) := by
  refine disjoint_left.mpr fun n hn hm => ?_
  obtain ⟨b,_,rfl⟩ := mem_image.mp hn
  obtain ⟨c,hc,he⟩ := mem_image.mp hm
  have hd : p ∣ q * c := he ▸ dvd_mul_right p b
  rcases hp.dvd_mul.mp hd with hd | hd
  · exact hpq ((Nat.prime_dvd_prime_iff_eq hp hq).mp hd)
  · obtain ⟨h₁,h₂⟩ := mem_Icc.mp hc
    exact hpT.not_ge ((Nat.le_of_dvd h₁ hd).trans h₂)

/-- Distinct auxiliary prime sets give disjoint denominator pools. -/
theorem primeCofactorPools_disjoint {P Q : Finset ℕ} {T : ℕ} (hPQ : Disjoint P Q)
    (hP : ∀ p ∈ P, p.Prime ∧ T < p) (hQ : ∀ q ∈ Q, q.Prime ∧ T < q) :
    Disjoint (primeCofactorPool P T) (primeCofactorPool Q T) := by
  refine disjoint_left.mpr fun n hn hm => ?_
  obtain ⟨p,hp,hb⟩ := mem_biUnion.mp hn
  obtain ⟨q,hq,hc⟩ := mem_biUnion.mp hm
  have hne : p ≠ q := fun e => disjoint_left.mp hPQ hp (e ▸ hq)
  exact disjoint_left.mp (primeCofactorBlock_disjoint (hP p hp).1 (hQ q hq).1 (hP p hp).2 hne) hb hc

private theorem dvd_lcmUpto_of_positive_le {b T : ℕ} (hb : 0 < b) (hT : b ≤ T) :
    b ∣ Nat.lcmUpto T := by
  unfold Nat.lcmUpto
  exact dvd_lcm (mem_Icc.mpr ⟨hb,hT⟩)


private theorem primeCofactorPool_crt_data {P : Finset ℕ} {T : ℕ}
    (hP : ∀ p ∈ P, p.Prime ∧ T < p)
    (hCover : ∀ p ∈ P, CoversResidues p (interval 1 T)) :
    let D := (∏ p ∈ P, p) * Nat.lcmUpto T
    let blocks (p : P) := mark (p : ℕ) (interval 1 T)
    (Pairwise (fun p q : P => Disjoint (blocks p) (blocks q))) ∧
    (∀ (p : P) (v : ZMod p.val), ∃ S ⊆ blocks p,
      (∑ n ∈ S, ((D / n : ℕ) : ZMod p.val)) = v) ∧
    (∀ (p q : P), p ≠ q → ∀ n ∈ blocks q, ((D / n : ℕ) : ZMod p.val) = 0) := by

  classical
  let M : ℕ := ∏ p ∈ P, p
  let L := Nat.lcmUpto T
  let D := M * L
  let blocks (p : P) := mark (p : ℕ) (interval 1 T)
  have hPair : Pairwise (fun p q : P => Disjoint (blocks p) (blocks q)) := by
    intro p q hpq
    exact primeCofactorBlock_disjoint (hP _ p.property).1 (hP _ q.property).1
      (hP _ p.property).2 (fun h => hpq (Subtype.ext h))
  have hDform (p : P) :
      D = (p : ℕ) * ((∏ q ∈ P.erase p, q) * L) := by
    dsimp only [D, M]
    have h : (∏ q ∈ P.erase p, q) * (p : ℕ) = (∏ q ∈ P, q) :=
      prod_erase_mul P (fun q : ℕ => q) p.property
    rw [← h]
    ring
  have hDiv (p : P) : (p : ℕ) ∣ D := by rw [hDform p]; exact dvd_mul_right _ _
  have hDivForm (p : P) :
      D / (p : ℕ) = (∏ q ∈ P.erase p, q) * L := by
    rw [hDform p, Nat.mul_div_cancel_left _ (hP _ p.property).1.pos]
  have hNoDiv (p : P) : ¬ (p : ℕ) ∣ D / (p : ℕ) := by
    let pp := hP _ p.property
    rw [hDivForm p]
    intro h
    rcases pp.1.dvd_mul.mp h with hf | hl
    · have hcp : (p : ℕ).Coprime (∏ q ∈ P.erase p, q) :=
        Nat.coprime_prod_right_iff.mpr fun q hq =>
          (Nat.coprime_primes pp.1 (hP q (mem_erase.mp hq).2).1).mpr (mem_erase.mp hq).1.symm
      exact (pp.1.coprime_iff_not_dvd).mp hcp hf
    · exact prime_not_dvd_smooth pp.1 pp.2 (show L ∣ Nat.lcmUpto T from dvd_rfl) hl
  have hCofDiv (p : P) {b : ℕ} (hb : b ∈ interval 1 T) : (p : ℕ) * b ∣ D :=
    Nat.mul_dvd_mul (Finset.dvd_prod_of_mem _ p.property)
      (dvd_lcmUpto_of_positive_le (mem_Icc.mp hb).1 (mem_Icc.mp hb).2)
  have hLocal (p : P) (v : ZMod p.val) :
      ∃ S ⊆ blocks p, (∑ n ∈ S, ((D / n : ℕ) : ZMod p.val)) = v := by
    have hp := hP _ p.property
    let _ : Fact p.val.Prime := ⟨hp.1⟩
    have hD0 : ((D / p.val : ℕ) : ZMod p.val) ≠ 0 := fun h =>
      hNoDiv p ((ZMod.natCast_eq_zero_iff _ _).mp h)
    obtain ⟨J,hJ,hv⟩ := hCover _ p.property (v * (((D / p.val : ℕ) : ZMod p.val))⁻¹)
    refine ⟨mark p.val J,image_subset_image hJ,?_⟩
    have hinj : Set.InjOn (fun b : ℕ => p.val * b) J :=
      fun _ _ _ _ h => Nat.eq_of_mul_eq_mul_left hp.1.pos h
    unfold mark
    rw [sum_image hinj]
    have hTerm (b : ℕ) (hb : b ∈ J) :
        ((D / (p.val * b) : ℕ) : ZMod p.val) = ((D / p.val : ℕ) : ZMod p.val) * (b : ZMod p.val)⁻¹ := by
      have hb₁ := mem_Icc.mp (hJ hb)
      have hb0 : (b : ZMod p.val) ≠ 0 := fun hz =>
        not_le_of_gt (hb₁.2.trans_lt hp.2)
          (Nat.le_of_dvd hb₁.1 ((ZMod.natCast_eq_zero_iff _ _).mp hz))
      have hNat : (D / (p.val * b)) * b = D / p.val := by
        apply Nat.eq_of_mul_eq_mul_right hp.1.pos
        calc
          _ = (D / (p.val * b)) * (p.val * b) := by ring
          _ = D := Nat.div_mul_cancel (hCofDiv p (hJ hb))
          _ = _ := (Nat.div_mul_cancel (hDiv p)).symm
      have hZ : ((D / (p.val * b) : ℕ) : ZMod p.val) * (b : ZMod p.val) = (D / p.val : ℕ) := by
        simpa only [Nat.cast_mul] using congrArg (fun n : ℕ => (n : ZMod p.val)) hNat
      calc
        _ = (((D / (p.val * b) : ℕ) : ZMod p.val) * (b : ZMod p.val)) * (b : ZMod p.val)⁻¹ := by
          rw [mul_assoc,mul_inv_cancel₀ hb0,mul_one]
        _ = _ := by rw [hZ]
    rw [sum_congr rfl hTerm, ← mul_sum, hv, mul_left_comm, mul_inv_cancel₀ hD0, mul_one]
  have hOther (p q : P) (hpq : p ≠ q) (n : ℕ) (hn : n ∈ blocks q) :
      ((D / n : ℕ) : ZMod p.val) = 0 := by
    obtain ⟨b,hb,rfl⟩ := mem_image.mp hn
    have hqmem : q.val ∈ P.erase p.val := mem_erase.mpr
      ⟨(fun h => hpq (Subtype.ext h.symm)), q.property⟩
    have hqdiv : q.val ∣ ∏ r ∈ P.erase p.val,r := Finset.dvd_prod_of_mem _ hqmem
    have hb' := mem_Icc.mp hb
    have hqD : q.val * b ∣ (∏ r ∈ P.erase p.val,r) * L :=
      Nat.mul_dvd_mul hqdiv (dvd_lcmUpto_of_positive_le hb'.1 hb'.2)
    have hh : (q.val * b) * p.val ∣ D := by
      rw [mul_comm, hDform p]
      exact Nat.mul_dvd_mul_left _ hqD
    apply (ZMod.natCast_eq_zero_iff _ _).mpr
    exact (Nat.dvd_div_iff_mul_dvd (hCofDiv q hb)).mpr (by simpa only [mul_comm] using hh)
  exact ⟨hPair,hLocal,hOther⟩

private theorem primeCofactorPool_eq_biUnion {P : Finset ℕ} {T : ℕ} :
    (univ : Finset P).biUnion (fun p => mark (p : ℕ) (interval 1 T)) = primeCofactorPool P T := by
  apply Finset.ext
  intro n
  constructor
  · intro hn
    obtain ⟨p,_,hb⟩ := mem_biUnion.mp hn
    exact mem_biUnion.mpr ⟨p.val,p.property,hb⟩
  · intro hn
    obtain ⟨p,hp,hb⟩ := mem_biUnion.mp hn
    exact mem_biUnion.mpr ⟨⟨p,hp⟩,mem_univ _,hb⟩

/-- Prescribed cleared residues are realized by a subset of the prime cofactor pool. -/
theorem primeCofactorPool_exists_subset_for_residues {P : Finset ℕ} {T : ℕ}
    (hP : ∀ q ∈ P, q.Prime ∧ T < q)
    (hCover : ∀ q ∈ P, CoversResidues q (interval 1 T))
    (r : ∀ q : P, ZMod q.val) :
    let D := (∏ q ∈ P, q) * Nat.lcmUpto T
    ∃ S ⊆ primeCofactorPool P T, ∀ q : P,
      (∑ b ∈ S, ((D / b : ℕ) : ZMod q.val)) = r q := by
  obtain ⟨hPair,hLocal,hOther⟩ := primeCofactorPool_crt_data hP hCover
  have h := exists_crt_subset_for_residues P (fun q => mark (q : ℕ) (interval 1 T)) hPair
    ((∏ q ∈ P, q) * Nat.lcmUpto T) hLocal hOther r
  rw [primeCofactorPool_eq_biUnion] at h
  exact h


/-- Auxiliary primes with pointwise covers yield a finite set of actual cleared
subsum representatives of cardinality equal to their prime product. -/
theorem primeCofactorPool_exists_representatives {P : Finset ℕ} {T W : ℕ}
    (hP : ∀ p ∈ P, p.Prime ∧ T < p ∧ p ≤ W)
    (hCover : ∀ p ∈ P, CoversResidues p (interval 1 T)) :
    let D := (∏ p ∈ P, p) * Nat.lcmUpto T
    ∃ A : Finset ℤ, A ⊆ clearedCodes D (primeCofactorPool P T) ∧
      A.card = ∏ p ∈ P, p ∧
      ∀ a ∈ A, 0 ≤ a ∧ (a : ℚ) ≤ (D : ℚ) * harmonic (W * T) := by
  classical
  let M : ℕ := ∏ p ∈ P, p
  let L := Nat.lcmUpto T
  let D := M * L
  obtain ⟨hPair,hLocal,hOther⟩ := primeCofactorPool_crt_data
    (fun p hp => ⟨(hP p hp).1,(hP p hp).2.1⟩) hCover
  obtain ⟨A,hA,hCard⟩ := exists_crt_residue_representatives P
    (fun p hp => (hP p hp).1.pos) (fun p => mark (p : ℕ) (interval 1 T)) hPair D hLocal hOther
  rw [primeCofactorPool_eq_biUnion] at hA

  refine ⟨A,hA,hCard,?_⟩
  intro z hz
  obtain ⟨S,hS,rfl⟩ := mem_image.mp (hA hz)
  have hSub : S ⊆ denominators (W * T) := by
    intro n hn
    obtain ⟨p,hp,hb⟩ := mem_biUnion.mp ((mem_powerset.mp hS) hn)
    obtain ⟨b,hb',rfl⟩ := mem_image.mp hb
    obtain ⟨hb₁,hb₂⟩ := mem_Icc.mp hb'
    exact mem_Icc.mpr ⟨Nat.mul_pos (hP p hp).1.pos hb₁,Nat.mul_le_mul (hP p hp).2.2 hb₂⟩
  constructor
  · positivity
  · simp only [Int.cast_sum, Int.cast_natCast]
    calc
      (∑ a ∈ S, ((D / a : ℕ) : ℚ)) ≤ ∑ a ∈ S, (D : ℚ) / (a : ℚ) :=
        sum_le_sum fun _ _ => Nat.cast_div_le
      _ = (D : ℚ) * mass S := by simp only [mass,div_eq_mul_inv,mul_sum]
      _ ≤ _ := by
        rw [← mass_denominators_eq_harmonic]
        exact mul_le_mul_of_nonneg_left (mass_mono hSub) (by positivity)

/-- Every term of the prime cofactor pool divides its common denominator. -/
theorem primeCofactorPool_dvd {P : Finset ℕ} {T n : ℕ}
    (hn : n ∈ primeCofactorPool P T) :
    n ∣ (∏ p ∈ P, p) * Nat.lcmUpto T := by
  obtain ⟨p,hp,ht⟩ := mem_biUnion.mp hn
  obtain ⟨b,hb,rfl⟩ := mem_image.mp ht
  exact Nat.mul_dvd_mul (Finset.dvd_prod_of_mem _ hp)
    (dvd_lcmUpto_of_positive_le (mem_Icc.mp hb).1 (mem_Icc.mp hb).2)

/-- Cleared subsums that occupy many residues give as many reciprocal
subsum residues at any prime coprime to their common denominator. -/
theorem card_integer_image_le_residueSupport {p D : ℕ} [Fact p.Prime] {E : Finset ℕ}
    {A : Finset ℤ} (hA : A ⊆ clearedCodes D E) (hD : ¬ p ∣ D)
    (hDiv : ∀ b ∈ E, b ∣ D) :
    (A.image fun a : ℤ => (a : ZMod p)).card ≤ (residueSupport p E).card := by
  classical
  let d := (D : ZMod p)
  have hd : d ≠ 0 := fun h => hD ((ZMod.natCast_eq_zero_iff _ _).mp h)
  have hSub : (A.image fun a : ℤ => (a : ZMod p)) ⊆
      (residueSupport p E).image (fun v => d * v) := by
    intro v hv
    obtain ⟨a,ha,rfl⟩ := mem_image.mp hv
    obtain ⟨J,hJ,rfl⟩ := mem_image.mp (hA ha)
    have hJE := mem_powerset.mp hJ
    refine mem_image.mpr ⟨cofactorResidue p J,mem_residueSupport.mpr ⟨J,hJE,rfl⟩,?_⟩
    unfold cofactorResidue
    rw [mul_sum]
    simp only [Int.cast_sum,Int.cast_natCast]
    apply sum_congr rfl
    intro b hb
    have hb₀ : (b : ZMod p) ≠ 0 := fun h =>
      hD (((ZMod.natCast_eq_zero_iff _ _).mp h).trans (hDiv b (hJE hb)))
    have hMul : ((D / b : ℕ) : ZMod p) * (b : ZMod p) = d := by
      simpa only [Nat.cast_mul] using
        congrArg (fun n : ℕ => (n : ZMod p)) (Nat.div_mul_cancel (hDiv b (hJE hb)))
    symm
    calc
      _ = (((D / b : ℕ) : ZMod p) * (b : ZMod p)) * (b : ZMod p)⁻¹ := by
        rw [mul_assoc,mul_inv_cancel₀ hb₀,mul_one]
      _ = _ := by rw [hMul]
  exact (card_le_card hSub).trans_eq (card_image_of_injective _ (fun _ _ h =>
    mul_left_cancel₀ hd h))

/-- Two disjoint prime cofactor pools whose cleared subsums each reach more
than half the target field supply every reciprocal residue. -/
theorem coversResidues_of_large_primeCofactor_images {p T : ℕ} [Fact p.Prime]
    {P Q : Finset ℕ} {A B : Finset ℤ} (hPQ : Disjoint P Q)
    (hP : ∀ q ∈ P, q.Prime ∧ T < q) (hQ : ∀ q ∈ Q, q.Prime ∧ T < q)
    (hPD : ¬ p ∣ (∏ q ∈ P,q) * Nat.lcmUpto T)
    (hQD : ¬ p ∣ (∏ q ∈ Q,q) * Nat.lcmUpto T)
    (hA : A ⊆ clearedCodes ((∏ q ∈ P,q) * Nat.lcmUpto T) (primeCofactorPool P T))
    (hB : B ⊆ clearedCodes ((∏ q ∈ Q,q) * Nat.lcmUpto T) (primeCofactorPool Q T))
    (hAlarge : p < 2 * (A.image (fun a : ℤ => (a : ZMod p))).card)
    (hBlarge : p < 2 * (B.image (fun a : ℤ => (a : ZMod p))).card) :
    CoversResidues p (primeCofactorPool P T ∪ primeCofactorPool Q T) := by
  apply coversResidues_union_of_large_images (primeCofactorPools_disjoint hPQ hP hQ)
  · exact hAlarge.trans_le (Nat.mul_le_mul_left _
      (card_integer_image_le_residueSupport hA hPD (fun _ hb => primeCofactorPool_dvd hb)))
  · exact hBlarge.trans_le (Nat.mul_le_mul_left _
      (card_integer_image_le_residueSupport hB hQD (fun _ hb => primeCofactorPool_dvd hb)))

/-- Target primes that have no reciprocal cover up to the given height. -/
noncomputable def reciprocalCoverExceptions (primes : Finset ℕ) (height : ℕ) : Finset ℕ := by
  classical
  exact primes.filter fun p => ¬ CoversResidues p (interval 1 height)

/-- Bound the exceptional target primes from a Fourier energy bound for the two
sets of cleared representatives. The covered denominators are at most `W * T`. -/
theorem card_primeCofactorCoverExceptions_le_of_energy
    {P Q primes : Finset ℕ} {T W : ℕ} {B : ℝ}
    (hPQ : Disjoint P Q)
    (hP : ∀ p ∈ P, p.Prime ∧ T < p ∧ p ≤ W)
    (hQ : ∀ p ∈ Q, p.Prime ∧ T < p ∧ p ≤ W)
    (hprim : ∀ p ∈ primes, p.Prime ∧ max W T < p)
    (hCoverP : ∀ p ∈ P, CoversResidues p (interval 1 T))
    (hCoverQ : ∀ p ∈ Q, CoversResidues p (interval 1 T))
    (henergy : ∀ A : Finset ℤ, (∀ a ∈ A, 0 ≤ a ∧
        (a : ℚ) ≤ (((max (∏ p ∈ P, p) (∏ p ∈ Q, p)) * Nat.lcmUpto T : ℕ) : ℚ)
          * harmonic (W * T)) →
      ∑ i ∈ primeFrequencyPairs primes, primeFrequencyPairEnergy A i ≤ B * (A.card : ℝ)) :
    ((reciprocalCoverExceptions primes (W * T)).card : ℝ) ≤
      B / ((∏ p ∈ P, p : ℕ) : ℝ) + B / ((∏ p ∈ Q, p : ℕ) : ℝ) := by
  classical
  obtain ⟨A, hA, hAc, hAb⟩ := primeCofactorPool_exists_representatives hP hCoverP
  obtain ⟨A', hA', hA'c, hA'b⟩ := primeCofactorPool_exists_representatives hQ hCoverQ
  have hfreq (R : Finset ℕ) (H : Finset ℤ) (hc : H.card = ∏ p ∈ R, p)
      (hp : ∀ p ∈ R, p.Prime ∧ T < p ∧ p ≤ W)
      (hR : ∏ p ∈ R, p ≤ max (∏ p ∈ P, p) (∏ p ∈ Q, p))
      (hb : ∀ a ∈ H, 0 ≤ a ∧ (a : ℚ) ≤
        (((∏ p ∈ R, p) * Nat.lcmUpto T : ℕ) : ℚ) * harmonic (W * T)) :
      ((smallPrimeImageExceptions primes H).card : ℝ) ≤ B / ((∏ p ∈ R, p : ℕ) : ℝ) := by
    have hpos : 0 < ∏ p ∈ R, p := Finset.prod_pos fun p h => (hp p h).1.pos
    rw [← hc]
    refine card_smallPrimeImageExceptions_le_of_pairEnergy primes
      (fun p hp => (hprim p hp).1) H (Finset.card_pos.mp (hc.symm ▸ hpos)) B (henergy H ?_)
    intro a ha
    exact ⟨(hb a ha).1, (hb a ha).2.trans <| mul_le_mul_of_nonneg_right
      (by exact_mod_cast Nat.mul_le_mul_right _ hR) (mass_nonneg _ |>.trans_eq
        (mass_denominators_eq_harmonic (W * T)))⟩
  have hD (R : Finset ℕ) (hR : ∀ q ∈ R, q.Prime ∧ T < q ∧ q ≤ W)
      {p : ℕ} (hp : p ∈ primes) : ¬ p ∣ (∏ q ∈ R, q) * Nat.lcmUpto T := by
    intro h
    rcases (hprim p hp).1.dvd_mul.mp h with hprod | hLcm
    · have hcp : p.Coprime (∏ q ∈ R, q) := Nat.coprime_prod_right_iff.mpr fun q hq =>
        (Nat.coprime_primes (hprim p hp).1 (hR q hq).1).mpr
          (((hR q hq).2.2.trans_lt ((le_max_left W T).trans_lt (hprim p hp).2)).ne.symm)
      exact ((hprim p hp).1.coprime_iff_not_dvd.mp hcp) hprod
    · exact prime_not_dvd_smooth (hprim p hp).1
        ((le_max_right W T).trans_lt (hprim p hp).2) dvd_rfl hLcm
  have hsub (R : Finset ℕ) (hR : ∀ q ∈ R, q.Prime ∧ T < q ∧ q ≤ W) :
      primeCofactorPool R T ⊆ interval 1 (W * T) := by
    intro n hn
    obtain ⟨q, hq, hm⟩ := mem_biUnion.mp hn
    obtain ⟨t, ht, rfl⟩ := mem_image.mp hm
    exact mem_Icc.mpr ⟨Nat.mul_pos (hR q hq).1.pos (mem_Icc.mp ht).1,
      Nat.mul_le_mul (hR q hq).2.2 (mem_Icc.mp ht).2⟩
  have hbad : reciprocalCoverExceptions primes (W * T) ⊆
      smallPrimeImageExceptions primes A ∪ smallPrimeImageExceptions primes A' := by
    intro p hp
    obtain ⟨hp, hn⟩ := mem_filter.mp (show p ∈ primes.filter _ from hp)
    by_contra h
    simp only [mem_union, smallPrimeImageExceptions, mem_filter, hp, true_and, not_or,
      not_le] at h
    let _ : Fact p.Prime := ⟨(hprim p hp).1⟩
    have hcover := coversResidues_of_large_primeCofactor_images hPQ
      (fun q hq => ⟨(hP q hq).1, (hP q hq).2.1⟩)
      (fun q hq => ⟨(hQ q hq).1, (hQ q hq).2.1⟩)
      (hD P hP hp) (hD Q hQ hp) hA hA' h.1 h.2
    apply hn
    intro v
    obtain ⟨J, hJ, hEq⟩ := hcover v
    exact ⟨J, hJ.trans (union_subset (hsub P hP) (hsub Q hQ)), hEq⟩
  have hcard := (card_le_card hbad).trans (card_union_le _ _)
  exact (by exact_mod_cast hcard : (_ : ℝ) ≤
    ((smallPrimeImageExceptions primes A).card : ℝ) +
      ((smallPrimeImageExceptions primes A').card : ℝ)).trans
    (add_le_add (hfreq P A hAc hP (le_max_left _ _) hAb)
      (hfreq Q A' hA'c hQ (le_max_right _ _) hA'b))

end LeanAB.PaperB.Closure
