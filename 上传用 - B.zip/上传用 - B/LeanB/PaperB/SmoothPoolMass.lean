module

public import PaperB.Closure
import Mathlib.Tactic

public section

/-! Preparing a wide pool for smooth closure from density in one dyadic window. -/

namespace LeanAB.PaperB.Closure

open Filter
open scoped BigOperators Topology

/-- The eligible denominators in the full interval for uniform smooth closure. -/
@[expose] noncomputable def smoothClosurePool (X C : ℕ) : Finset ℕ := by
  classical
  exact (interval X (C * X)).filter (fun b => b ∣ Nat.lcmUpto (Nat.nthRoot 5 X))

private noncomputable def sixthPowerSlab (X : ℕ) : Finset ℕ := by
  classical
  exact (Finset.Ioc X (2 * X)).filter (fun b => b ∣ Nat.lcmUpto (Nat.nthRoot 6 X))

private theorem nthRoot_six_mul_le_five {K X : ℕ} (hK : 0 < K) (hX : K ^ 5 ≤ X) :
    Nat.nthRoot 6 (K * X) ≤ Nat.nthRoot 5 X := by
  let a := Nat.nthRoot 6 (K * X)
  have ha : a ^ 6 ≤ K * X := Nat.pow_nthRoot_le (.inl (by decide))
  apply (Nat.le_nthRoot_iff (by decide : (5 : ℕ) ≠ 0)).mpr
  by_cases h : K ≤ a
  · apply le_of_mul_le_mul_left _ hK
    exact (calc
      K * a ^ 5 ≤ a * a ^ 5 := Nat.mul_le_mul_right _ h
      _ = a ^ 6 := by ring
      _ ≤ K * X := ha)
  · exact (Nat.pow_le_pow_left (le_of_not_ge h) _).trans hX

private theorem reciprocal_mass_of_half_open_slab {c : ℝ} {X : ℕ} (hX : 0 < X)
    (hCount : c * (X : ℝ) ≤ ((sixthPowerSlab X).card : ℝ)) :
    c / 2 ≤ (mass (sixthPowerSlab X) : ℝ) := by
  classical
  have hTop (b : ℕ) (hb : b ∈ sixthPowerSlab X) : b ≤ 2 * X :=
    (Finset.mem_Ioc.mp (Finset.mem_filter.mp hb).1).2
  have hPos (b : ℕ) (hb : b ∈ sixthPowerSlab X) : 0 < b :=
    hX.trans ((Finset.mem_Ioc.mp (Finset.mem_filter.mp hb).1).1)
  have hmass : (mass (sixthPowerSlab X) : ℝ) = ∑ b ∈ sixthPowerSlab X, (b : ℝ)⁻¹ := by
    simp only [mass, Rat.cast_sum, Rat.cast_inv, Rat.cast_natCast]
  have hxR : (0 : ℝ) < X := Nat.cast_pos.mpr hX
  calc
    c / 2 = c * (X : ℝ) / (2 * (X : ℝ)) := by field_simp
    _ ≤ ((sixthPowerSlab X).card : ℝ) / (2 * (X : ℝ)) :=
      div_le_div_of_nonneg_right hCount (by positivity)
    _ = ∑ _b ∈ sixthPowerSlab X, (2 * (X : ℝ))⁻¹ := by simp [div_eq_mul_inv]
    _ ≤ _ := by
      rw [hmass]
      exact Finset.sum_le_sum fun b hb =>
        inv_anti₀ (Nat.cast_pos.mpr (hPos b hb)) (by exact_mod_cast hTop b hb)

private theorem eventually_pool_mass_ge_of_slab_density (c : ℝ)
    (hDensity : ∀ᶠ X : ℕ in atTop, c * (X : ℝ) ≤ ((sixthPowerSlab X).card : ℝ))
    (k : ℕ) :
    ∀ᶠ X : ℕ in atTop, (k : ℝ) * (c / 2) ≤ (mass (smoothClosurePool X (2 ^ k)) : ℝ) := by
  classical
  obtain ⟨X₀, hX₀⟩ := eventually_atTop.mp hDensity
  induction k with
  | zero =>
      filter_upwards [] with X
      simpa using (Rat.cast_nonneg.mpr (mass_nonneg (smoothClosurePool X (2 ^ 0))) :
        (0 : ℝ) ≤ (mass (smoothClosurePool X (2 ^ 0)) : ℝ))
  | succ k ih =>
      let K : ℕ := 2 ^ k
      have hK : 0 < K := by dsimp [K]; positivity
      filter_upwards [ih, eventually_ge_atTop X₀, eventually_ge_atTop (K ^ 5),
        eventually_ge_atTop (1 : ℕ)] with X hLow hX hRoot hX₁
      let A := smoothClosurePool X K
      let B := sixthPowerSlab (K * X)
      have hXle : X ≤ K * X := Nat.le_mul_of_pos_left _ hK
      have hB : c / 2 ≤ (mass B : ℝ) :=
        reciprocal_mass_of_half_open_slab (Nat.mul_pos hK (by omega)) (hX₀ _ (hX.trans hXle))
      have hScale : 2 * (K * X) = 2 ^ (k + 1) * X := by
        rw [pow_succ']; simp [K, Nat.mul_assoc]
      have hAB : Disjoint A B := by
        apply Finset.disjoint_left.mpr
        intro b ha hb
        exact (Finset.mem_Ioc.mp (Finset.mem_filter.mp hb).1).1.not_ge
          (Finset.mem_Icc.mp (Finset.mem_filter.mp ha).1).2
      have hSub : A ∪ B ⊆ smoothClosurePool X (2 ^ (k + 1)) := by
        intro b hb
        rcases Finset.mem_union.mp hb with ha | hB'
        · obtain ⟨hm, hd⟩ := Finset.mem_filter.mp ha
          obtain ⟨hl, hu⟩ := Finset.mem_Icc.mp hm
          exact Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨hl,
            hu.trans (by rw [← hScale]; omega)⟩, hd⟩
        · obtain ⟨hm, hd⟩ := Finset.mem_filter.mp hB'
          obtain ⟨hl, hu⟩ := Finset.mem_Ioc.mp hm
          have hdiv := Nat.lcmUpto_dvd_lcmUpto (nthRoot_six_mul_le_five hK hRoot)
          exact Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr
            ⟨max_le (by omega) (hXle.trans hl.le), hScale ▸ hu⟩, hd.trans hdiv⟩
      have hMassUnion : mass (A ∪ B) = mass A + mass B := Finset.sum_union hAB
      have hMass : (mass A : ℝ) + (mass B : ℝ) ≤ (mass (smoothClosurePool X (2 ^ (k + 1))) : ℝ) := by
        rw [← Rat.cast_add, ← hMassUnion]
        exact Rat.cast_le.mpr (mass_mono hSub)
      change (k : ℝ) * (c / 2) ≤ (mass A : ℝ) at hLow
      push_cast
      linarith

/-- Positive density in sixth-root powersmooth dyadic intervals supplies enough
fifth-root powersmooth reciprocal mass in one uniformly enlarged interval. -/
theorem exists_wide_smooth_closure_pool (c : ℝ) (hc : 0 < c)
    (hDensity : ∀ᶠ X : ℕ in atTop,
      c * (X : ℝ) ≤
        (((Finset.Ioc X (2 * X)).filter (fun b => b ∣ Nat.lcmUpto (Nat.nthRoot 6 X))).card : ℝ)) :
    ∃ C : ℕ, 1 < C ∧ ∀ᶠ X : ℕ in atTop, (3 / 2 : ℚ) ≤ mass (smoothClosurePool X C) := by
  obtain ⟨k, hk⟩ := exists_nat_ge (3 / c)
  have hk₀ : 0 < k := Nat.cast_pos.mp ((div_pos (by norm_num) hc).trans_le hk)
  refine ⟨2 ^ k, one_lt_pow₀ (by decide : (1 : ℕ) < 2) hk₀.ne', ?_⟩
  filter_upwards [eventually_pool_mass_ge_of_slab_density c hDensity k] with X hX
  have hK : (3 : ℝ) ≤ (k : ℝ) * c := (div_le_iff₀ hc).mp hk
  have hh : (3 / 2 : ℝ) ≤ (mass (smoothClosurePool X (2 ^ k)) : ℝ) := by linarith
  apply (Rat.cast_le (K := ℝ)).mp
  simpa only [Rat.cast_div, Rat.cast_ofNat] using hh

end LeanAB.PaperB.Closure

