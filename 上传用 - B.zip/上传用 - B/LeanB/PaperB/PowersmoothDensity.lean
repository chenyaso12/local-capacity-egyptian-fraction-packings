module

public import PaperB.Closure
public import PaperB.PrimeWindows
public import Mathlib.Algebra.BigOperators.Ring.Finset
public import Mathlib.Algebra.Order.Floor.Semifield
public import Mathlib.Data.Nat.Cast.Order.Field
public import Mathlib.Data.Nat.GCD.BigOperators
meta import Mathlib.Tactic

/-! Counting powersmooth denominators by disjoint choices of large prime factors. -/

@[expose] public section

open Filter Finset
open scoped Topology

namespace LeanAB.PaperB

/-- All integers in this interval whose prime-power factors are at most y. -/
def powersmoothInterval (A B y : ℕ) : Finset ℕ :=
  (Finset.Ioc A B).filter (fun a => a ∣ Nat.lcmUpto y)

private theorem dvd_lcmUpto_of_pos_le {a y : ℕ} (ha : 0 < a) (hay : a ≤ y) :
    a ∣ Nat.lcmUpto y := by
  unfold Nat.lcmUpto
  exact dvd_lcm (mem_Icc.mpr ⟨ha, hay⟩)

private theorem prod_dvd_of_pairwise_coprime {ι : Type*} {F : ι → ℕ} {s : Finset ι} {a : ℕ}
    (hd : ∀ i ∈ s, F i ∣ a)
    (hc : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → (F i).Coprime (F j)) :
    (∏ i ∈ s, F i) ∣ a := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
    rw [prod_insert hi]
    have hcp : (F i).Coprime (∏ j ∈ s, F j) := Nat.coprime_prod_right_iff.mpr fun j hj =>
      hc i (mem_insert_self i s) j (mem_insert_of_mem hj) fun e => hi (e ▸ hj)
    exact hcp.mul_dvd_of_dvd_of_dvd (hd i (mem_insert_self i s)) (ih
      (fun j hj => hd j (mem_insert_of_mem hj))
      (fun j hj k hk => hc j (mem_insert_of_mem hj) k (mem_insert_of_mem hk)))

private theorem eq_of_prime_dvd_prime {p q : ℕ} (hp : p.Prime) (hq : q.Prime)
    (hd : p ∣ q) : p = q :=
  ((Nat.dvd_prime hq).mp hd).resolve_left hp.ne_one

/-- Products of a choice of one prime from each disjoint range and a smaller
integer factor give a lower bound for the count of distinct powersmooth integers. -/
theorem powersmoothInterval_card_ge_of_prime_pools {ι : Type*} [Fintype ι]
    (S : ι → Finset ℕ) (hPrime : ∀ i p, p ∈ S i → p.Prime) (hDis : Pairwise (fun i j => Disjoint (S i) (S j)))
    {X y : ℕ} (hSize : ∀ i p, p ∈ S i → p ≤ y)
    (hProd : ∀ f : ∀ i, {p // p ∈ S i}, 2 * (∏ i, (f i : ℕ)) ≤ X)
    (hSmall : ∀ (f : ∀ i, {p // p ∈ S i}) (a : ℕ), 0 < a →
      a * (∏ i, (f i : ℕ)) ≤ 2 * X → a ≤ y ∧ ∀ i, a < (f i : ℕ)) :
    (X : ℝ) / 2 * (∏ i, ∑ p ∈ S i, (p : ℝ)⁻¹) ≤ (powersmoothInterval X (2 * X) y).card := by
  classical
  let F := ∀ i, {p // p ∈ S i}
  let D (f : F) : ℕ := ∏ i, (f i : ℕ)
  have hD (f : F) : 0 < D f := Finset.prod_pos fun i _ => (hPrime i _ (f i).property).pos
  have hDF (f : F) (i : ι) : (f i : ℕ) ∣ D f :=
    Finset.dvd_prod_of_mem _ (mem_univ i)
  let A (f : F) := Ioc (X / D f) (2 * X / D f)
  let V (f : F) := (A f).image (fun a => a * D f)
  have hmul (f : F) (a : ℕ) (ha : a ∈ A f) : X < a * D f ∧ a * D f ≤ 2 * X := by
    obtain ⟨h₁, h₂⟩ := mem_Ioc.mp ha
    exact ⟨(Nat.div_lt_iff_lt_mul (hD f)).mp h₁, (Nat.le_div_iff_mul_le (hD f)).mp h₂⟩
  have haPos (f : F) (a : ℕ) (ha : a ∈ A f) : 0 < a :=
    (Nat.zero_le _).trans_lt (mem_Ioc.mp ha).1
  have hpUnique (f : F) (a : ℕ) (ha : a ∈ A f) {p : ℕ} (hp : p.Prime)
      (hpa : a < p) (hd : p ∣ a * D f) : ∃ i, p = (f i : ℕ) := by
    have hpd : p ∣ D f := (hp.dvd_mul.mp hd).resolve_left fun h =>
      (not_le_of_gt hpa) (Nat.le_of_dvd (haPos f a ha) h)
    by_contra! h
    exact ((hp.coprime_iff_not_dvd).mp (Nat.coprime_fintype_prod_right_iff.mpr
      fun i => (hp.coprime_iff_not_dvd).mpr fun hi =>
        h i (eq_of_prime_dvd_prime hp (hPrime i _ (f i).property) hi))) hpd
  have hVDis : (↑(univ : Finset F) : Set F).PairwiseDisjoint V := by
    intro f _ g _ hfg
    refine Finset.disjoint_left.mpr fun n hf hg => ?_
    obtain ⟨a, ha, rfl⟩ := mem_image.mp hf
    obtain ⟨b, hb, heq⟩ := mem_image.mp hg
    apply hfg
    funext i
    apply Subtype.ext
    have hsmallF := (hSmall f a (haPos f a ha) (hmul f a ha).2).2
    have hsmallG := (hSmall g b (haPos g b hb) (hmul g b hb).2).2
    by_cases h : (b : ℕ) < f i
    · have hd : (f i : ℕ) ∣ b * D g := heq ▸ Dvd.dvd.mul_left (hDF f i) a
      obtain ⟨j, hj⟩ := hpUnique g b hb (hPrime i _ (f i).property) h hd
      have hij : i = j := by
        by_contra hn
        exact (Finset.disjoint_left.mp (hDis hn)) (f i).property (hj ▸ (g j).property)
      subst j
      exact hj
    · have hd : (g i : ℕ) ∣ a * D f := heq ▸ Dvd.dvd.mul_left (hDF g i) b
      obtain ⟨j, hj⟩ := hpUnique f a ha (hPrime i _ (g i).property)
        (Nat.lt_trans (Nat.lt_of_lt_of_le (hsmallF i) (le_of_not_gt h)) (hsmallG i)) hd
      have hij : i = j := by
        by_contra hn
        exact (Finset.disjoint_left.mp (hDis hn)) (g i).property (hj ▸ (f j).property)
      subst j
      exact hj.symm
  have hSub : univ.biUnion V ⊆ powersmoothInterval X (2 * X) y := by
    intro n hn
    obtain ⟨f, _, hnf⟩ := mem_biUnion.mp hn
    obtain ⟨a, ha, rfl⟩ := mem_image.mp hnf
    obtain ⟨h₁, h₂⟩ := hmul f a ha
    obtain ⟨hay, has⟩ := hSmall f a (haPos f a ha) h₂
    have hd : D f ∣ Nat.lcmUpto y := prod_dvd_of_pairwise_coprime
      (fun i _ => dvd_lcmUpto_of_pos_le (hPrime i _ (f i).property).pos (hSize i _ (f i).property))
      (fun i _ j _ hij => ((hPrime i _ (f i).property).coprime_iff_not_dvd).mpr fun h =>
        (Finset.disjoint_left.mp (hDis hij)) (f i).property
          (eq_of_prime_dvd_prime (hPrime i _ (f i).property) (hPrime j _ (f j).property) h ▸
            (f j).property))
    have hcp : a.Coprime (D f) :=
      (Nat.coprime_fintype_prod_right_iff.mpr fun i =>
        Nat.coprime_comm.mp (((hPrime i _ (f i).property).coprime_iff_not_dvd).mpr fun h =>
          (not_le_of_gt (has i)) (Nat.le_of_dvd (haPos f a ha) h)))
    exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨h₁, h₂⟩,
      hcp.mul_dvd_of_dvd_of_dvd (dvd_lcmUpto_of_pos_le (haPos f a ha) hay) hd⟩
  have hVcard (f : F) : (X : ℝ) / 2 * ((D f : ℕ) : ℝ)⁻¹ ≤ (V f).card := by
    rw [show (V f).card = (A f).card from card_image_of_injective _ (fun a b h => by
        exact Nat.eq_of_mul_eq_mul_right (hD f) h)]
    change _ ≤ ((Ioc (X / D f) (2 * X / D f)).card : ℝ)
    rw [Nat.card_Ioc, Nat.cast_sub (Nat.div_le_div_right (by omega))]
    have hp : 0 < ((D f : ℕ) : ℝ) := by exact_mod_cast hD f
    have hUpper : ((X / D f : ℕ) : ℝ) ≤ (X : ℝ) / (D f : ℝ) := Nat.cast_div_le
    have hLower : (2 * (X : ℝ)) / (D f : ℝ) < ↑(2 * X / D f : ℕ) + 1 := by
      have hf : ⌊(2 * (X : ℝ)) / (D f : ℝ)⌋₊ = 2 * X / D f := by
        rw [Nat.floor_div_natCast]
        rw [← show ((2 * X : ℕ) : ℝ) = 2 * (X : ℝ) by push_cast; rfl, Nat.floor_natCast]
      rw [← hf]
      exact Nat.lt_floor_add_one _
    have hmargin : (2 : ℝ) ≤ (X : ℝ) / (D f : ℝ) :=
      (le_div_iff₀ hp).mpr (by exact_mod_cast hProd f)
    have hfactor : (2 * (X : ℝ)) / (D f : ℝ) = 2 * ((X : ℝ) / (D f : ℝ)) := by ring
    rw [hfactor] at hLower
    rw [show (X : ℝ) / 2 * (D f : ℝ)⁻¹ = ((X : ℝ) / (D f : ℝ)) / 2 by ring]
    linarith
  have hSum : (∑ f : F, ((D f : ℕ) : ℝ)⁻¹) = ∏ i, ∑ p ∈ S i, (p : ℝ)⁻¹ := by
    simp only [D, Nat.cast_prod, ← Finset.prod_inv_distrib]
    calc
      _ = ∏ i, ∑ p : {p // p ∈ S i}, ((p : ℕ) : ℝ)⁻¹ :=
        (Fintype.prod_sum (κ := fun i => {p // p ∈ S i}) (R := ℝ)
          (fun _ p => ((p : ℕ) : ℝ)⁻¹)).symm
      _ = _ := by
        apply Finset.prod_congr rfl
        intro i _
        exact Finset.sum_coe_sort (S i) (fun p => (p : ℝ)⁻¹)
  have hCount : (∑ f : F, (V f).card : ℕ) ≤ (powersmoothInterval X (2 * X) y).card := by
    rw [← card_biUnion hVDis]
    exact card_le_card hSub
  calc
    _ = ∑ f : F, (X : ℝ) / 2 * ((D f : ℕ) : ℝ)⁻¹ := by rw [← hSum, mul_sum]
    _ ≤ ∑ f : F, ((V f).card : ℝ) := sum_le_sum fun f _ => hVcard f
    _ ≤ _ := by exact_mod_cast hCount

/-- The positive density needed for the repair pools and for smooth closure.
Using a fixed number of disjoint prime windows gives a lower bound directly. -/
theorem eventually_powersmoothInterval_card_ge (u : ℕ) (hu : 0 < u) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ X : ℕ in atTop,
      c * (X : ℝ) ≤ (powersmoothInterval X (2 * X) (Nat.nthRoot u X)).card := by
  classical
  have huR : 0 < (u : ℝ) := by exact_mod_cast hu
  let lo : ℝ := 1 / ((u : ℝ) + 1)
  let hi : ℝ := 1 / (u : ℝ)
  have hlo : 0 < lo := by dsimp [lo]; positivity
  have hlohi : lo < hi := by
    rw [show lo = ((u : ℝ) + 1)⁻¹ by simp [lo], show hi = (u : ℝ)⁻¹ by simp [hi]]
    exact inv_strictAnti₀ huR (by linarith)
  let a := (lo + hi) / 2
  let b := (a + hi) / 2
  have hla : lo < a := by dsimp [a]; linarith
  have hab : a < b := by dsimp [b, a]; linarith
  have hbhi : b < hi := by dsimp [b, a]; linarith
  have ha : 0 < a := hlo.trans hla
  have hbu : b * (u : ℝ) < 1 := (lt_div_iff₀ huR).mp hbhi
  have haa : 1 < a * ((u : ℝ) + 1) := (div_lt_iff₀ (by linarith : 0 < (u : ℝ) + 1)).mp hla
  let t := (b - a) / (u : ℝ)
  have ht : 0 < t := div_pos (sub_pos.mpr hab) huR
  have htu : (u : ℝ) * t = b - a := by dsimp [t]; field_simp
  let A (i : Fin u) : ℝ := a + (i.val : ℝ) * t
  let B (i : Fin u) : ℝ := a + ((i.val : ℝ) + 1) * t
  have hA (i : Fin u) : a ≤ A i := le_add_of_nonneg_right (mul_nonneg (Nat.cast_nonneg _) ht.le)
  have hAB (i : Fin u) : A i < B i := by dsimp [A, B]; linarith
  have hB (i : Fin u) : B i ≤ b := by
    have hi : (i.val : ℝ) + 1 ≤ (u : ℝ) := by exact_mod_cast (Nat.succ_le_of_lt i.isLt)
    dsimp [B]
    linarith only [mul_le_mul_of_nonneg_right hi ht.le, htu]
  let c (i : Fin u) := (B i - A i) / (2 * B i)
  have hc (i : Fin u) : 0 < c i :=
    div_pos (sub_pos.mpr (hAB i)) (mul_pos (by norm_num) ((ha.trans_le (hA i)).trans (hAB i)))
  refine ⟨(∏ i, c i) / 2, div_pos (Finset.prod_pos fun i _ => hc i) (by norm_num), ?_⟩
  have hPrimeMass : ∀ᶠ x : ℝ in atTop, ∀ i : Fin u,
      c i ≤ ∑ p ∈ primesBetween (x ^ A i) (x ^ B i), (p : ℝ)⁻¹ :=
    Filter.eventually_all.mpr fun i => eventually_prime_power_window_mass (ha.trans_le (hA i)) (hAB i)
  have hXnat : Tendsto (fun X : ℕ => (X : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hpow₁ : Tendsto (fun x : ℝ => x ^ (1 - b * (u : ℝ))) atTop atTop :=
    tendsto_rpow_atTop (sub_pos.mpr hbu)
  have hpow₂ : Tendsto (fun x : ℝ => x ^ (a * (u : ℝ) + a - 1)) atTop atTop :=
    tendsto_rpow_atTop (by linarith only [haa])
  filter_upwards [hXnat.eventually (eventually_gt_atTop (1 : ℝ)), hXnat.eventually hPrimeMass,
    (hpow₁.comp hXnat).eventually_ge_atTop 2, (hpow₂.comp hXnat).eventually_gt_atTop 2]
    with X hX hmass hExp₁ hExp₂
  let x : ℝ := X
  have hx : 0 < x := zero_lt_one.trans hX
  let S (i : Fin u) := primesBetween (x ^ A i) (x ^ B i)
  have hmem {i : Fin u} {p : ℕ} (hp : p ∈ S i) :=
    (mem_primesBetween (Real.rpow_nonneg hx.le _) (Real.rpow_nonneg hx.le _)).mp hp
  have hSdis : Pairwise (fun i j => Disjoint (S i) (S j)) := by
    have haux (i j : Fin u) (hij : i.val < j.val) : Disjoint (S i) (S j) := by
      have hij' : (i.val : ℝ) + 1 ≤ (j.val : ℝ) := by exact_mod_cast (Nat.succ_le_of_lt hij)
      have hBA : B i ≤ A j := by
        dsimp [B, A]
        linarith only [mul_le_mul_of_nonneg_right hij' ht.le]
      exact disjoint_left.mpr fun p hpi hpj => (not_lt_of_ge ((hmem hpi).2.1.trans
        (Real.rpow_le_rpow_of_exponent_le hX.le hBA))) (hmem hpj).1
    intro i j hij
    have hv : i.val ≠ j.val := fun h => hij (Fin.ext h)
    rcases lt_or_gt_of_ne hv with h | h
    · exact haux i j h
    · exact (haux j i h).symm
  have hy (p : ℕ) (hp : (p : ℝ) ≤ x ^ hi) : p ≤ Nat.nthRoot u X := by
    refine (Nat.le_nthRoot_iff hu.ne').mpr ?_
    have heq : hi * (u : ℝ) = 1 := by dsimp [hi]; field_simp
    have hp' : (p : ℝ) ^ u ≤ x := calc
      _ ≤ (x ^ hi) ^ u := pow_le_pow_left₀ (Nat.cast_nonneg _) hp _
      _ = x := by rw [← Real.rpow_natCast, ← Real.rpow_mul hx.le, heq, Real.rpow_one]
    dsimp [x] at hp'
    exact_mod_cast hp'
  let F := ∀ i : Fin u, {p // p ∈ S i}
  let D (f : F) : ℕ := ∏ i, (f i : ℕ)
  have hD (f : F) : x ^ (a * (u : ℝ)) ≤ (D f : ℝ) ∧ (D f : ℝ) ≤ x ^ (b * (u : ℝ)) := by
    rw [Real.rpow_mul hx.le, Real.rpow_mul hx.le, Real.rpow_natCast, Real.rpow_natCast]
    change _ ≤ ((∏ i, (f i : ℕ) : ℕ) : ℝ) ∧ ((∏ i, (f i : ℕ) : ℕ) : ℝ) ≤ _
    rw [Nat.cast_prod, ← show (∏ _i : Fin u, x ^ a) = (x ^ a) ^ u by simp,
      ← show (∏ _i : Fin u, x ^ b) = (x ^ b) ^ u by simp]
    constructor
    · exact Finset.prod_le_prod₀ (fun _ _ => Real.rpow_nonneg hx.le _) (fun i _ => (Real.rpow_le_rpow_of_exponent_le hX.le (hA i)).trans
        (hmem (f i).property).1.le)
    · exact Finset.prod_le_prod₀ (fun _ _ => Nat.cast_nonneg _) (fun i _ => (hmem (f i).property).2.1.trans
        (Real.rpow_le_rpow_of_exponent_le hX.le (hB i)))
  have hProd (f : F) : 2 * D f ≤ X := by
    have hle : 2 * (D f : ℝ) ≤ x := calc
      _ ≤ 2 * x ^ (b * (u : ℝ)) := by linarith only [(hD f).2]
      _ ≤ x ^ (1 - b * (u : ℝ)) * x ^ (b * (u : ℝ)) :=
        mul_le_mul_of_nonneg_right hExp₁ (Real.rpow_nonneg hx.le _)
      _ = x := by rw [← Real.rpow_add hx, sub_add_cancel, Real.rpow_one]
    dsimp [x] at hle
    exact_mod_cast hle
  have hSmall (f : F) (m : ℕ) (_hm₀ : 0 < m) (hm : m * D f ≤ 2 * X) :
      m ≤ Nat.nthRoot u X ∧ ∀ i, m < (f i : ℕ) := by
    have hxm : (m : ℝ) < x ^ a := by
      have hl : 2 * x < x ^ a * (D f : ℝ) := calc
        _ < x ^ (a * (u : ℝ) + a - 1) * x := by
          exact mul_lt_mul_of_pos_right hExp₂ hx
        _ = x ^ (a * (u : ℝ) + a - 1) * x ^ (1 : ℝ) := by rw [Real.rpow_one]
        _ = x ^ a * x ^ (a * (u : ℝ)) := by
          rw [← Real.rpow_add hx, ← Real.rpow_add hx]
          congr 1
          ring
        _ ≤ _ := mul_le_mul_of_nonneg_left (hD f).1 (Real.rpow_nonneg hx.le _)
      by_contra! h
      exact (not_le_of_gt hl) ((mul_le_mul_of_nonneg_right h (Nat.cast_nonneg _)).trans
        (by change (m : ℝ) * (D f : ℝ) ≤ 2 * (X : ℝ); exact_mod_cast hm))
    exact ⟨hy m (hxm.le.trans (Real.rpow_le_rpow_of_exponent_le hX.le (hab.le.trans hbhi.le))),
      fun i => by exact_mod_cast (hxm.trans_le ((Real.rpow_le_rpow_of_exponent_le hX.le (hA i)).trans
        (hmem (f i).property).1.le))⟩
  have hC := powersmoothInterval_card_ge_of_prime_pools S (fun _ _ hp => (hmem hp).2.2)
    hSdis (fun i p hp => hy p ((hmem hp).2.1.trans
      (Real.rpow_le_rpow_of_exponent_le hX.le ((hB i).trans hbhi.le)))) hProd hSmall
  calc
    _ = x / 2 * ∏ i, c i := by ring
    _ ≤ x / 2 * ∏ i, ∑ p ∈ S i, (p : ℝ)⁻¹ :=
      mul_le_mul_of_nonneg_left (Finset.prod_le_prod₀ (fun i _ => (hc i).le) (fun i _ => hmass i)) (by positivity)
    _ ≤ _ := hC

/-- The interval above half the height contains linearly many powersmooth
denominators at every fixed positive power cutoff. -/
theorem eventually_powersmooth_half_card_ge (u : ℕ) (hu : 0 < u) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ N : ℕ in atTop,
      c * (N : ℝ) ≤ (powersmoothInterval (N / 2) N (Nat.nthRoot u N)).card := by
  obtain ⟨c, hc, h⟩ := eventually_powersmoothInterval_card_ge u hu
  have hHalf : Tendsto (fun N : ℕ => N / 2) atTop atTop := by
    apply tendsto_atTop.mpr
    intro n
    filter_upwards [eventually_ge_atTop (n * 2)] with N hN
    exact (Nat.le_div_iff_mul_le (by decide)).mpr hN
  refine ⟨c / 3, div_pos hc (by norm_num), ?_⟩
  filter_upwards [hHalf.eventually h, eventually_ge_atTop (3 : ℕ)] with N hN hLarge
  have hTwo : 2 * (N / 2) ≤ N := by omega
  have hThird : N ≤ 3 * (N / 2) := by omega
  have hRoot : u.nthRoot (N / 2) ≤ u.nthRoot N :=
    (Nat.le_nthRoot_iff hu.ne').mpr ((Nat.pow_nthRoot_le (.inl hu.ne')).trans (Nat.div_le_self _ _))
  have hInc : powersmoothInterval (N / 2) (2 * (N / 2)) (u.nthRoot (N / 2)) ⊆
      powersmoothInterval (N / 2) N (u.nthRoot N) := by
    intro k hk
    obtain ⟨hk, hd⟩ := mem_filter.mp hk
    exact mem_filter.mpr ⟨mem_Ioc.mpr ⟨(mem_Ioc.mp hk).1, (mem_Ioc.mp hk).2.trans hTwo⟩,
      hd.trans (Nat.lcmUpto_dvd_lcmUpto hRoot)⟩
  have hThirdR : (N : ℝ) ≤ 3 * ((N / 2 : ℕ) : ℝ) := by exact_mod_cast hThird
  calc
    _ ≤ c * ((N / 2 : ℕ) : ℝ) := by linarith only [mul_le_mul_of_nonneg_left hThirdR hc.le]
    _ ≤ _ := hN
    _ ≤ _ := by exact_mod_cast card_le_card hInc

/-- The carriers for the uniform closure have positive density, including
rounding of the real lower endpoint. -/
theorem eventually_powersmooth_carriers :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ X : ℕ in atTop, ∃ V : Finset ℕ,
      let M : ℝ := (X : ℝ) ^ (3 / 4 : ℝ) * (Real.log X) ^ 3
      c * M ≤ V.card ∧ ∀ v ∈ V, M ≤ (v : ℝ) ∧ (v : ℝ) ≤ 3 * M ∧
        v ∣ Nat.lcmUpto (Nat.nthRoot 5 X) := by
  let M (X : ℕ) : ℝ := (X : ℝ) ^ (3 / 4 : ℝ) * (Real.log X) ^ 3
  let Z (X : ℕ) : ℕ := ⌈M X⌉₊
  obtain ⟨c, hc, hcard⟩ := eventually_powersmoothInterval_card_ge 4 (by decide)
  have hcast : Tendsto (fun X : ℕ => (X : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hM : Tendsto M atTop atTop := by
    have h := (tendsto_rpow_atTop (show 0 < (3 / 4 : ℝ) by norm_num)).comp hcast
    have hlog := Real.tendsto_log_atTop.comp hcast
    apply tendsto_atTop.mpr
    intro a
    filter_upwards [h.eventually_ge_atTop (max a 1), hlog.eventually_ge_atTop 1] with X hpow hl
    exact (le_max_left a 1).trans (hpow.trans
      (le_mul_of_one_le_right (zero_le_one.trans ((le_max_right a 1).trans hpow))
        (one_le_pow₀ hl)))
  have hZ : Tendsto Z atTop atTop := by
    apply tendsto_atTop.mpr
    intro n
    filter_upwards [hM.eventually_ge_atTop (n : ℝ)] with X h
    have h' := h.trans (Nat.le_ceil (M X))
    exact_mod_cast h'
  have hsmall := (isLittleO_log_rpow_rpow_atTop (s := (1 / 20 : ℝ)) 3 (by norm_num)).bound
    (show 0 < (1 / 2 : ℝ) by norm_num)
  refine ⟨c, hc, ?_⟩
  filter_upwards [hZ.eventually hcard, hM.eventually_ge_atTop 2, hcast.eventually hsmall,
    hcast.eventually (eventually_gt_atTop (1 : ℝ))] with X hcardM hM₂ hSmall hX
  have hx : 0 < (X : ℝ) := zero_lt_one.trans hX
  have hlog : 0 ≤ Real.log (X : ℝ) := Real.log_nonneg hX.le
  have hZ₁ : M X ≤ (Z X : ℝ) := Nat.le_ceil _
  have hZ₂ : (Z X : ℝ) < M X + 1 := Nat.ceil_lt_add_one (by linarith)
  have hLogP : Real.log (X : ℝ) ^ 3 ≤ 1 / 2 * (X : ℝ) ^ (1 / 20 : ℝ) := by
    simpa only [Real.norm_eq_abs, show (3 : ℝ) = ((3 : ℕ) : ℝ) by norm_num, Real.rpow_natCast,
      abs_of_nonneg (pow_nonneg hlog _), abs_of_nonneg (Real.rpow_nonneg hx.le _)] using hSmall
  have hZx : (Z X : ℝ) ≤ (X : ℝ) ^ (4 / 5 : ℝ) := calc
    _ ≤ 2 * M X := by linarith
    _ = (X : ℝ) ^ (3 / 4 : ℝ) * (2 * Real.log (X : ℝ) ^ 3) := by dsimp [M]; ring
    _ ≤ (X : ℝ) ^ (3 / 4 : ℝ) * (X : ℝ) ^ (1 / 20 : ℝ) :=
      mul_le_mul_of_nonneg_left (by linarith only [hLogP]) (Real.rpow_nonneg hx.le _)
    _ = _ := by rw [← Real.rpow_add hx]; norm_num
  have hZpow : Z X ^ 5 ≤ X ^ 4 := by
    have h := pow_le_pow_left₀ (Nat.cast_nonneg (Z X)) hZx 5
    have hp : ((X : ℝ) ^ (4 / 5 : ℝ)) ^ (5 : ℕ) = (X : ℝ) ^ (4 : ℕ) := calc
      _ = ((X : ℝ) ^ (4 / 5 : ℝ)) ^ ((5 : ℕ) : ℝ) := (Real.rpow_natCast _ _).symm
      _ = (X : ℝ) ^ ((4 / 5 : ℝ) * ((5 : ℕ) : ℝ)) := (Real.rpow_mul hx.le _ _).symm
      _ = _ := by rw [show (4 / 5 : ℝ) * ((5 : ℕ) : ℝ) = ((4 : ℕ) : ℝ) by norm_num,
        Real.rpow_natCast]
    rw [hp] at h
    exact_mod_cast h
  have hRoot : Nat.nthRoot 4 (Z X) ≤ Nat.nthRoot 5 X := by
    apply (Nat.le_nthRoot_iff (by decide : (5 : ℕ) ≠ 0)).mpr
    have hR : (Nat.nthRoot 4 (Z X)) ^ 4 ≤ Z X := Nat.pow_nthRoot_le (.inl (by decide))
    have h := (Nat.pow_le_pow_left hR 5).trans hZpow
    apply (Nat.pow_left_strictMono (by decide : (4 : ℕ) ≠ 0)).le_iff_le.mp
    simpa only [← pow_mul, show (5 : ℕ) * 4 = 4 * 5 by decide] using h
  refine ⟨powersmoothInterval (Z X) (2 * Z X) (Nat.nthRoot 4 (Z X)),
    (mul_le_mul_of_nonneg_left hZ₁ hc.le).trans hcardM, ?_⟩
  intro v hv
  obtain ⟨hr, hd⟩ := mem_filter.mp hv
  obtain ⟨hvL, hvU⟩ := mem_Ioc.mp hr
  have hvL' : (Z X : ℝ) ≤ (v : ℝ) := by exact_mod_cast hvL.le
  have hvU' : (v : ℝ) ≤ 2 * (Z X : ℝ) := by exact_mod_cast hvU
  exact ⟨hZ₁.trans hvL', by linarith, hd.trans (Nat.lcmUpto_dvd_lcmUpto hRoot)⟩

end LeanAB.PaperB
