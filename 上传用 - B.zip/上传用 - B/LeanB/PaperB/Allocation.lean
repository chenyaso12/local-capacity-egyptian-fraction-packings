module

public import Common
public import Mathlib.Algebra.BigOperators.Module
public import Mathlib.Algebra.GCDMonoid.FinsetLemmas
public import Mathlib.Data.Fintype.Lattice
public import Mathlib.Algebra.Order.BigOperators.Group.Finset
meta import Mathlib.Tactic.FieldSimp
meta import Mathlib.Tactic.NormNum
meta import Mathlib.Tactic.Linarith
meta import Mathlib.Tactic.Positivity
meta import Mathlib.Tactic.Ring

/-! Greedy allocation of an ordered sequence of reciprocal-sum blocks. -/

@[expose] public section

namespace LeanAB.PaperB.Allocation

open scoped BigOperators
open Finset

variable {ι : Type*} [Fintype ι] [Nonempty ι]

/-- Pick a group with least normalized load. Any minimizer is valid. -/
noncomputable def leastGroup (u : ι → ℚ) : ι :=
  Classical.choose (Finite.exists_min u)

theorem leastGroup_le (u : ι → ℚ) (i : ι) : u (leastGroup u) ≤ u i :=
  Classical.choose_spec (Finite.exists_min u) i

variable [DecidableEq ι]

/-- The normalized load in each group after the first t assignments. -/
noncomputable def load (w : ℕ → ℚ) (r : ι → ℚ) : ℕ → ι → ℚ
  | 0 => fun _ => 0
  | t + 1 => fun i =>
    let u := load w r t
    u i + if leastGroup u = i then w t / r i else 0

/-- The group receiving block t, with block indices starting from zero. -/
noncomputable def assignedGroup (w : ℕ → ℚ) (r : ι → ℚ) (t : ℕ) : ι :=
  leastGroup (load w r t)

/-- The minimum normalized load after t assignments. -/
noncomputable def minLoad (w : ℕ → ℚ) (r : ι → ℚ) (t : ℕ) : ℚ :=
  load w r t (assignedGroup w r t)

theorem minLoad_le (w : ℕ → ℚ) (r : ι → ℚ) (t : ℕ) (i : ι) :
    minLoad w r t ≤ load w r t i :=
  leastGroup_le _ _

theorem le_minLoad {w : ℕ → ℚ} {r : ι → ℚ} {t : ℕ} {q : ℚ}
    (h : ∀ i, q ≤ load w r t i) : q ≤ minLoad w r t :=
  h _

theorem load_succ (w : ℕ → ℚ) (r : ι → ℚ) (t : ℕ) (i : ι) :
    load w r (t + 1) i = load w r t i +
      if assignedGroup w r t = i then w t / r i else 0 := by
  rw [load]
  rfl

theorem load_mono (w : ℕ → ℚ) (r : ι → ℚ)
    (hw : ∀ k, 0 ≤ w k) (hr : ∀ i, 0 < r i) (i : ι) :
    Monotone (fun t => load w r t i) := by
  apply monotone_nat_of_le_succ
  intro k
  rw [load_succ]
  have h : 0 ≤ (if assignedGroup w r k = i then w k / r i else 0) := by
    split <;> first | exact div_nonneg (hw k) (hr i).le | exact le_rfl
  exact le_add_of_nonneg_right h

theorem minLoad_mono (w : ℕ → ℚ) (r : ι → ℚ)
    (hw : ∀ k, 0 ≤ w k) (hr : ∀ i, 0 < r i) :
    Monotone (minLoad w r) := by
  intro s t hst
  exact le_minLoad (fun i => (minLoad_le w r s i).trans (load_mono w r hw hr i hst))

theorem mul_load_eq_sum (w : ℕ → ℚ) (r : ι → ℚ) (hr : ∀ i, 0 < r i)
    (t : ℕ) (i : ι) :
    r i * load w r t i = ∑ k ∈ range t, if assignedGroup w r k = i then w k else 0 := by
  induction t with
  | zero => simp [load]
  | succ t ht =>
    rw [load_succ, mul_add, ht, sum_range_succ]
    by_cases h : assignedGroup w r t = i
    · simp only [h, ite_true]
      rw [← mul_div_assoc, mul_comm (r i) (w t), mul_div_cancel_right₀ _ (hr i).ne']
    · simp [h]

theorem sum_mul_load (w : ℕ → ℚ) (r : ι → ℚ) (hr : ∀ i, 0 < r i) (t : ℕ) :
    ∑ i, r i * load w r t i = ∑ k ∈ range t, w k := by
  simp_rw [mul_load_eq_sum w r hr]
  rw [sum_comm]
  simp

theorem weighted_average_bound (w : ℕ → ℚ) (r : ι → ℚ) (hr : ∀ i, 0 < r i)
    (t : ℕ) {a : ℚ} (h : ∑ k ∈ range t, w k ≤ a * ∑ i, r i) :
    minLoad w r t ≤ a := by
  have htotal : 0 < ∑ i, r i := sum_pos (fun i _ => hr i) univ_nonempty
  have havg : minLoad w r t * ∑ i, r i ≤ ∑ k ∈ range t, w k := by
    rw [mul_sum, ← sum_mul_load w r hr]
    exact sum_le_sum fun i _ => by
      rw [mul_comm (minLoad w r t)]
      exact mul_le_mul_of_nonneg_left (minLoad_le w r t i) (hr i).le
  exact le_of_mul_le_mul_right (havg.trans h) htotal

theorem early_load_bound (w : ℕ → ℚ) (r : ι → ℚ) (hw : ∀ k, 0 ≤ w k)
    (hr : ∀ i, 0 < r i) {early : ℕ} {a b : ℚ} (ha : 0 ≤ a) (hb : 0 ≤ b)
    (hMass : ∑ k ∈ range early, w k ≤ a * ∑ i, r i) (i : ι)
    (hSteps : ∀ k < early, assignedGroup w r k = i → w k / r i ≤ b) :
    ∀ t ≤ early, load w r t i ≤ a + b := by
  intro t ht
  induction t with
  | zero =>
    rw [load]
    exact add_nonneg ha hb
  | succ t ih =>
    rw [load_succ]
    by_cases h : assignedGroup w r t = i
    · have hmin : load w r t i = minLoad w r t := congrArg (load w r t) h.symm
      rw [ite_eq_left h, hmin]
      have hPrefix : ∑ k ∈ range t, w k ≤ ∑ k ∈ range early, w k :=
        sum_le_sum_of_subset_of_nonneg (range_mono (by omega)) fun k _ _ => hw k
      exact add_le_add (weighted_average_bound w r hr t (hPrefix.trans hMass))
        (hSteps t (by omega) h)
    · simpa only [ite_eq_right h, add_zero] using ih (by omega)

theorem load_le_max (w : ℕ → ℚ) (r : ι → ℚ) (hw : ∀ k, 0 ≤ w k)
    (hr : ∀ i, 0 < r i) {s t : ℕ} (hst : s ≤ t) {η : ℚ}
    (hSteps : ∀ k, s ≤ k → k < t → ∀ i, w k / r i ≤ η) (i : ι) :
    load w r t i ≤ max (load w r s i) (minLoad w r t + η) := by
  induction t, hst using Nat.le_induction with
  | base => exact le_max_left _ _
  | succ t ht ih =>
    have hminMono : minLoad w r t ≤ minLoad w r (t + 1) :=
      minLoad_mono w r hw hr (Nat.le_succ t)
    rw [load_succ]
    by_cases h : assignedGroup w r t = i
    · have hmin : load w r t i = minLoad w r t := congrArg (load w r t) h.symm
      rw [ite_eq_left h, hmin]
      calc
        _ ≤ minLoad w r t + η := add_le_add le_rfl (hSteps t ht (by omega) i)
        _ ≤ minLoad w r (t + 1) + η :=
          add_le_add hminMono le_rfl
        _ ≤ _ := le_max_right _ _
    · rw [ite_eq_right h, add_zero]
      exact (ih (fun k hks hkt => hSteps k hks (by omega))).trans
        (max_le_max le_rfl (add_le_add hminMono le_rfl))

/-- The first prefix past the lower load threshold exists and stays below the upper
threshold in every group. The initial stage is allowed to contain larger singletons. -/
theorem exists_stopping_prefix (w : ℕ → ℚ) (r : ι → ℚ)
    (hr : ∀ i, 0 < r i) {early total : ℕ}
    (he : early ≤ total) {δ η : ℚ} (hδ : 0 < δ)
    (hEarly : ∀ i, load w r early i ≤ 1 - δ)
    (hLater : ∀ k, early ≤ k → k < total → ∀ i, w k / r i ≤ η)
    (hMass : ∑ i, r i ≤ ∑ k ∈ range total, w k) :
    ∃ t, early ≤ t ∧ t ≤ total ∧
      (∀ i, 1 - δ - η ≤ load w r t i ∧ load w r t i ≤ 1 - δ) ∧
      (∀ s, early ≤ s → s < t → minLoad w r s < 1 - δ - η) := by
  have cap_of_prefix {t : ℕ} (ht₀ : early ≤ t) (ht₁ : t ≤ total)
      (hbelow : ∀ s, early ≤ s → s < t → minLoad w r s < 1 - δ - η) :
      ∀ i, load w r t i ≤ 1 - δ := by
    induction t, ht₀ using Nat.le_induction with
    | base => exact hEarly
    | succ t ht ih =>
      intro i
      rw [load_succ]
      by_cases h : assignedGroup w r t = i
      · have hmin : load w r t i = minLoad w r t := congrArg (load w r t) h.symm
        rw [ite_eq_left h, hmin]
        linarith [hbelow t ht (Nat.lt_succ_self t), hLater t ht (by omega) i]
      · rw [ite_eq_right h, add_zero]
        exact ih (by omega) (fun s hs hst => hbelow s hs (by omega)) i
  let good (t : ℕ) : Prop := early ≤ t ∧ t ≤ total ∧ 1 - δ - η ≤ minLoad w r t
  have hex : ∃ t, good t := by
    by_contra! hnone
    have hb (s : ℕ) (hs₀ : early ≤ s) (hs₁ : s < total) :
        minLoad w r s < 1 - δ - η :=
      lt_of_not_ge (fun h => hnone s ⟨hs₀, hs₁.le, h⟩)
    have hcap := cap_of_prefix he le_rfl hb
    have hsum : ∑ k ∈ range total, w k ≤ (1 - δ) * ∑ i, r i := by
      rw [← sum_mul_load w r hr, mul_sum]
      exact sum_le_sum fun i _ => by
        rw [mul_comm (1 - δ)]
        exact mul_le_mul_of_nonneg_left (hcap i) (hr i).le
    have htotal : 0 < ∑ i, r i := sum_pos (fun i _ => hr i) univ_nonempty
    have hlt : (1 - δ) * (∑ i, r i) < ∑ i, r i := by
      simpa only [one_mul] using mul_lt_mul_of_pos_right (show 1 - δ < 1 by linarith) htotal
    exact (not_lt_of_ge (hMass.trans hsum)) hlt
  classical
  let t := Nat.find hex
  have ht : good t := Nat.find_spec hex
  have hb (s : ℕ) (hs₀ : early ≤ s) (hs₁ : s < t) :
      minLoad w r s < 1 - δ - η :=
    lt_of_not_ge (fun h => Nat.find_min hex hs₁ ⟨hs₀, hs₁.le.trans ht.2.1, h⟩)
  refine ⟨t, ht.1, ht.2.1, fun i => ⟨ht.2.2.trans (minLoad_le w r t i), ?_⟩, hb⟩
  exact cap_of_prefix ht.1 ht.2.1 hb i


/-- The sum of the block weights between two prefix lengths. -/
def tailWeight (w : ℕ → ℚ) (s t : ℕ) : ℚ :=
  ∑ k ∈ Ico s t, w k

/-- The part of the tail carried by group i. -/
noncomputable def groupTailWeight (w : ℕ → ℚ) (r : ι → ℚ) (s t : ℕ) (i : ι) : ℚ :=
  tailWeight (fun k => if assignedGroup w r k = i then w k else 0) s t

theorem groupTailWeight_eq (w : ℕ → ℚ) (r : ι → ℚ) (hr : ∀ i, 0 < r i)
    {s t : ℕ} (hst : s ≤ t) (i : ι) :
    groupTailWeight w r s t i = r i * (load w r t i - load w r s i) := by
  rw [mul_sub, mul_load_eq_sum w r hr, mul_load_eq_sum w r hr]
  unfold groupTailWeight tailWeight
  rw [← sum_range_add_sum_Ico _ hst]
  ring

theorem sum_groupTailWeight (w : ℕ → ℚ) (r : ι → ℚ) (s t : ℕ) :
    ∑ i, groupTailWeight w r s t i = tailWeight w s t := by
  unfold groupTailWeight tailWeight
  rw [sum_comm]
  simp

/-- A sufficient mass in the early part of the ordered list forces the least load past α.
The exceptional groups, including those that used a large singleton, have total load
mass bounded by specialMass. -/
theorem minLoad_gt_of_prefix_mass (w : ℕ → ℚ) (r : ι → ℚ)
    (hw : ∀ k, 0 ≤ w k) (hr : ∀ i, 0 < r i) {early s : ℕ}
    (hes : early ≤ s) {α η specialMass : ℚ} (hη : 0 ≤ η)
    (regular : Finset ι)
    (hEarly : ∀ i ∈ regular, load w r early i ≤ α)
    (hSmall : ∀ k, early ≤ k → k < s → ∀ i, w k / r i ≤ η)
    (hSpecial : ∑ i ∈ univ \ regular, r i * load w r s i ≤ specialMass)
    (hMass : (α + η) * (∑ i ∈ regular, r i) + specialMass < ∑ k ∈ range s, w k) :
    α < minLoad w r s := by
  by_contra! hle
  have hReg : ∑ i ∈ regular, r i * load w r s i ≤ (α + η) * ∑ i ∈ regular, r i := by
    rw [mul_sum]
    apply sum_le_sum
    intro i hi
    rw [mul_comm (α + η)]
    apply mul_le_mul_of_nonneg_left _ (hr i).le
    apply (load_le_max w r hw hr hes hSmall i).trans
    exact max_le ((hEarly i hi).trans (le_add_of_nonneg_right hη)) (add_le_add hle le_rfl)
  have hAll := add_le_add hSpecial hReg
  rw [sum_sdiff (subset_univ regular), sum_mul_load w r hr] at hAll
  linarith

/-- Once the least load passes the early regular-group cap, all regular loads
stay within one later increment of the least load. -/
theorem regular_load_le (w : ℕ → ℚ) (r : ι → ℚ)
    (hw : ∀ k, 0 ≤ w k) (hr : ∀ i, 0 < r i) {early base t : ℕ}
    (heb : early ≤ base) (hbt : base ≤ t) {α η : ℚ} (hη : 0 ≤ η)
    (regular : Finset ι) (hEarly : ∀ i ∈ regular, load w r early i ≤ α)
    (hCross : α ≤ minLoad w r base)
    (hSmall : ∀ k, early ≤ k → k < t → ∀ i, w k / r i ≤ η) :
    ∀ i ∈ regular, load w r t i ≤ minLoad w r t + η := by
  intro i hi
  refine (load_le_max w r hw hr (heb.trans hbt) hSmall i).trans (max_le ?_ le_rfl)
  exact (hEarly i hi).trans
    (hCross.trans ((minLoad_mono w r hw hr hbt).trans (le_add_of_nonneg_right hη)))

/-- The tail estimate holds for every group, including an exceptional group
not covered by the post-prefix load comparison. -/
theorem group_tail_le (w : ℕ → ℚ) (r : ι → ℚ)
    (hw : ∀ k, 0 ≤ w k) (hr : ∀ i, 0 < r i) {s t : ℕ} (hst : s ≤ t)
    {η : ℚ} (hη : 0 ≤ η)
    (hSmall : ∀ k, s ≤ k → k < t → ∀ i, w k / r i ≤ η)
    (regular : Finset ι) (hR : 0 < ∑ j ∈ regular, r j)
    (hClose : ∀ j ∈ regular, load w r s j ≤ minLoad w r s + η) (i : ι) :
    groupTailWeight w r s t i ≤
      (r i / (∑ j ∈ regular, r j)) * tailWeight w s t + 2 * r i * η := by
  let gap := minLoad w r t - minLoad w r s
  have hgap : 0 ≤ gap := sub_nonneg.mpr (minLoad_mono w r hw hr hst)
  have hLower : (gap - η) * (∑ j ∈ regular, r j) ≤ tailWeight w s t := calc
    _ = ∑ j ∈ regular, r j * (gap - η) := by simp_rw [mul_comm (gap - η), sum_mul]
    _ ≤ ∑ j ∈ regular, groupTailWeight w r s t j := by
      apply sum_le_sum
      intro j hj
      rw [groupTailWeight_eq w r hr hst j]
      exact mul_le_mul_of_nonneg_left (by
        dsimp [gap]
        linarith [hClose j hj, minLoad_le w r t j]) (hr j).le
    _ ≤ ∑ j, groupTailWeight w r s t j :=
      sum_le_sum_of_subset_of_nonneg (subset_univ regular) fun j _ _ => by
        unfold groupTailWeight tailWeight
        exact sum_nonneg fun k _ => by
          by_cases h : assignedGroup w r k = j <;> simp [h, hw k]
    _ = _ := sum_groupTailWeight w r s t
  have hGapBound := (le_div_iff₀ hR).2 hLower
  have hLoadUpper :
      load w r t i ≤ load w r s i + (gap + η) := by
    refine (load_le_max w r hw hr hst hSmall i).trans (max_le ?_ ?_)
    · exact le_add_of_nonneg_right (add_nonneg hgap hη)
    · dsimp [gap]
      linarith [minLoad_le w r s i]
  rw [groupTailWeight_eq w r hr hst]
  calc
    _ ≤ r i * (gap + η) := mul_le_mul_of_nonneg_left (by linarith) (hr i).le
    _ ≤ r i * (tailWeight w s t / (∑ j ∈ regular, r j) + 2 * η) :=
      mul_le_mul_of_nonneg_left (by linarith) (hr i).le
    _ = _ := by simp only [div_eq_mul_inv]; ring


/-- The tail form of discrete Abel summation, with weights at the left endpoint. -/
theorem sum_mul_eq_tail (x w : ℕ → ℚ) {s t : ℕ} (hst : s < t) :
    ∑ k ∈ Ico s t, x k * w k =
      x s * tailWeight w s t +
        ∑ k ∈ Ico s (t - 1), (x (k + 1) - x k) * tailWeight w (k + 1) t := by
  have hp (k : ℕ) (hk : k ≤ t) :
      ∑ j ∈ range k, w j = (∑ j ∈ range t, w j) - tailWeight w k t := by
    unfold tailWeight
    rw [← sum_range_add_sum_Ico _ hk]
    ring
  rw [show (∑ k ∈ Ico s t, x k * w k) =
      x (t - 1) * (∑ j ∈ range t, w j) - x s * (∑ j ∈ range s, w j) -
        ∑ k ∈ Ico s (t - 1), (x (k + 1) - x k) * ∑ j ∈ range (k + 1), w j by
        simpa only [smul_eq_mul] using sum_Ico_by_parts x w hst, hp s hst.le]
  rw [show (∑ k ∈ Ico s (t - 1), (x (k + 1) - x k) * ∑ j ∈ range (k + 1), w j) =
      ∑ k ∈ Ico s (t - 1), (x (k + 1) - x k) *
        ((∑ j ∈ range t, w j) - tailWeight w (k + 1) t) from
        sum_congr rfl fun k hk => by rw [hp (k + 1) (by have := (mem_Ico.mp hk).2; omega)]]
  simp only [mul_sub, sum_sub_distrib, ← sum_mul, sum_Ico_sub x (by omega : s ≤ t - 1)]
  ring

/-- A uniform tail comparison becomes a bound for the weighted sum when x is
nonnegative and nondecreasing. -/
theorem weighted_tail_le (x a b : ℕ → ℚ) {s t : ℕ} (hst : s < t)
    (hx : MonotoneOn x (Set.Ico s t)) (hx₀ : 0 ≤ x s) {c err : ℚ}
    (hTail : ∀ k, s ≤ k → k < t → tailWeight a k t ≤ c * tailWeight b k t + err) :
    ∑ k ∈ Ico s t, x k * a k ≤ c * (∑ k ∈ Ico s t, x k * b k) + err * x (t - 1) := by
  rw [sum_mul_eq_tail x a hst, sum_mul_eq_tail x b hst]
  calc
    _ ≤ x s * (c * tailWeight b s t + err) +
        ∑ k ∈ Ico s (t - 1), (x (k + 1) - x k) * (c * tailWeight b (k + 1) t + err) := by
      apply add_le_add (mul_le_mul_of_nonneg_left (hTail s le_rfl hst) hx₀)
      apply sum_le_sum
      intro k hk
      have hk₀ := (mem_Ico.mp hk).1
      have hk₁ := (mem_Ico.mp hk).2
      have hxk : x k ≤ x (k + 1) :=
        hx ⟨hk₀, by omega⟩ ⟨by omega, by omega⟩ (Nat.le_succ _)
      exact mul_le_mul_of_nonneg_left (hTail (k + 1) (by omega) (by omega)) (sub_nonneg.mpr hxk)
    _ = _ := by
      have hExpand : (∑ k ∈ Ico s (t - 1),
          (x (k + 1) - x k) * (c * tailWeight b (k + 1) t + err)) =
          (∑ k ∈ Ico s (t - 1), c * ((x (k + 1) - x k) * tailWeight b (k + 1) t)) +
            err * (x (t - 1) - x s) := calc
        _ = ∑ k ∈ Ico s (t - 1),
            (c * ((x (k + 1) - x k) * tailWeight b (k + 1) t) +
              (x (k + 1) - x k) * err) := sum_congr rfl fun _ _ => by ring
        _ = _ := by rw [sum_add_distrib, ← sum_mul, sum_Ico_sub x (by omega), mul_comm err]
      rw [hExpand, ← mul_sum]
      ring


/-- The nonempty, pairwise disjoint blocks in increasing effective-denominator
order. Only indices strictly below length are used. -/
structure BlockList (d N : ℕ) where
  length : ℕ
  block : ℕ → Finset ℕ
  nonempty : ∀ k < length, (block k).Nonempty
  subset : ∀ k < length, block k ⊆ interval d N
  disjoint : (↑(range length) : Set ℕ).PairwiseDisjoint block
  ordered : MonotoneOn (fun k => ((block k).card : ℚ) / mass (block k)) {k | k < length}

namespace BlockList

variable {d N : ℕ} (B : BlockList d N)

/-- Reciprocal mass of one block. -/
def weight (k : ℕ) : ℚ := mass (B.block k)

/-- Harmonic mean of the denominators in a block. -/
def effective (k : ℕ) : ℚ := ((B.block k).card : ℚ) / B.weight k

theorem weight_nonneg (k : ℕ) : 0 ≤ B.weight k :=
  mass_nonneg _

theorem weight_pos {k : ℕ} (hk : k < B.length) : 0 < B.weight k := by
  unfold weight mass
  refine sum_pos (fun a ha => inv_pos.mpr ?_) (B.nonempty k hk)
  have ia := mem_Icc.mp (B.subset k hk ha)
  exact Nat.cast_pos.mpr (lt_of_lt_of_le (by omega : 0 < max 1 d) ia.1)

theorem effective_nonneg (k : ℕ) : 0 ≤ B.effective k :=
  div_nonneg (Nat.cast_nonneg _) (B.weight_nonneg k)

theorem effective_mul_weight {k : ℕ} (hk : k < B.length) :
    B.effective k * B.weight k = ((B.block k).card : ℚ) :=
  div_mul_cancel₀ _ (B.weight_pos hk).ne'

theorem effective_le {k : ℕ} (hk : k < B.length) : B.effective k ≤ (N : ℚ) := by
  unfold effective
  apply (div_le_iff₀ (B.weight_pos hk)).2
  unfold weight mass
  rw [mul_sum]
  calc
    _ = ∑ a ∈ B.block k, (1 : ℚ) := by simp
    _ ≤ _ := sum_le_sum fun a ha => by
      have ia := mem_Icc.mp (B.subset k hk ha)
      have hapos : (0 : ℚ) < a := Nat.cast_pos.mpr (by omega)
      rw [← div_eq_mul_inv]
      exact (le_div_iff₀ hapos).2 (by simpa using (Nat.cast_le.mpr ia.2 : (a : ℚ) ≤ N))

theorem sum_card_le {t : ℕ} (ht : t ≤ B.length) :
    ∑ k ∈ range t, (B.block k).card ≤ N := by
  have hd : (↑(range t) : Set ℕ).PairwiseDisjoint B.block :=
    B.disjoint.subset fun _ hk => mem_range.mpr ((mem_range.mp hk).trans_le ht)
  rw [← Finset.card_biUnion hd]
  calc
    _ ≤ (interval 1 N).card := by
      apply card_le_card
      intro a ha
      obtain ⟨k, hk, ha⟩ := mem_biUnion.mp ha
      have h := mem_Icc.mp (B.subset k ((mem_range.mp hk).trans_le ht) ha)
      exact mem_Icc.mpr ⟨by omega, h.2⟩
    _ = N := by simp [interval, Nat.card_Icc]

/-- The actual denominators assigned to group i in the first t blocks. -/
noncomputable def allocated (r : ι → ℚ) (t : ℕ) (i : ι) : Finset ℕ :=
  ((range t).filter (fun k => assignedGroup B.weight r k = i)).biUnion B.block

theorem allocated_subset (r : ι → ℚ) {t : ℕ} (ht : t ≤ B.length) (i : ι) :
    B.allocated r t i ⊆ interval d N := by
  intro a ha
  obtain ⟨k, hk, ha⟩ := mem_biUnion.mp ha
  exact B.subset k ((mem_range.mp (mem_filter.mp hk).1).trans_le ht) ha

theorem allocated_disjoint (r : ι → ℚ) {t : ℕ} (ht : t ≤ B.length) :
    Pairwise (fun i j => Disjoint (B.allocated r t i) (B.allocated r t j)) := by
  intro i j hij
  apply disjoint_left.mpr
  intro a hi hj
  obtain ⟨k, hk, hai⟩ := mem_biUnion.mp hi
  obtain ⟨l, hl, haj⟩ := mem_biUnion.mp hj
  have hki := (mem_filter.mp hk).2
  have hlj := (mem_filter.mp hl).2
  have hkl : k ≠ l := fun h => hij (hki.symm.trans (h ▸ hlj))
  exact disjoint_left.mp
    (B.disjoint (mem_range.mpr ((mem_range.mp (mem_filter.mp hk).1).trans_le ht))
      (mem_range.mpr ((mem_range.mp (mem_filter.mp hl).1).trans_le ht)) hkl)
    hai haj

theorem allocated_mass_eq_sum (r : ι → ℚ) {t : ℕ} (ht : t ≤ B.length) (i : ι) :
    mass (B.allocated r t i) =
      ∑ k ∈ (range t).filter (fun k => assignedGroup B.weight r k = i), B.weight k :=
  sum_biUnion (B.disjoint.subset fun _ hk =>
    mem_range.mpr ((mem_range.mp (mem_filter.mp hk).1).trans_le ht))

theorem allocated_mass (r : ι → ℚ) (hr : ∀ i, 0 < r i) {t : ℕ} (ht : t ≤ B.length)
    (i : ι) :
    mass (B.allocated r t i) = r i * load B.weight r t i := by
  rw [B.allocated_mass_eq_sum r ht, mul_load_eq_sum B.weight r hr, sum_filter]

theorem allocated_card (r : ι → ℚ) {t : ℕ} (ht : t ≤ B.length) (i : ι) :
    ((B.allocated r t i).card : ℚ) =
      ∑ k ∈ range t, if assignedGroup B.weight r k = i then ((B.block k).card : ℚ) else 0 := by
  rw [allocated, card_biUnion (B.disjoint.subset fun _ hk =>
    mem_range.mpr ((mem_range.mp (mem_filter.mp hk).1).trans_le ht)),
    Nat.cast_sum, sum_filter]

/-- Reduced denominators of the residuals still divide any common denominator
of the block masses and the targets. -/
theorem residual_den_dvd (r : ι → ℚ) {D t : ℕ} (ht : t ≤ B.length)
    (hBlocks : ∀ k < B.length, (B.weight k).den ∣ D) (hTargets : ∀ i, (r i).den ∣ D)
    (i : ι) : (r i - mass (B.allocated r t i)).den ∣ D := by
  have hm : (mass (B.allocated r t i)).den ∣ D := by
    rw [B.allocated_mass_eq_sum r ht]
    exact (Rat.den_sum_dvd_lcm_den _ _).trans (lcm_dvd fun k hk =>
      hBlocks k ((mem_range.mp (mem_filter.mp hk).1).trans_le ht))
  exact (Rat.sub_den_dvd_lcm _ _).trans (Nat.lcm_dvd (hTargets i) hm)

theorem allocated_card_prefix_le (r : ι → ℚ) (hr : ∀ i, 0 < r i)
    {t : ℕ} (ht : t ≤ B.length) {X : ℚ} (hX : 0 ≤ X)
    (hPrefix : ∀ k < t, B.effective k ≤ X) (i : ι)
    (hLoad : load B.weight r t i ≤ 1) :
    ((B.allocated r t i).card : ℚ) ≤ r i * X := by
  rw [B.allocated_card r ht]
  calc
    _ ≤ ∑ k ∈ range t, X * (if assignedGroup B.weight r k = i then B.weight k else 0) := by
      apply sum_le_sum
      intro k hk
      by_cases h : assignedGroup B.weight r k = i
      · rw [ite_eq_left h, ite_eq_left h, ← B.effective_mul_weight ((mem_range.mp hk).trans_le ht)]
        exact mul_le_mul_of_nonneg_right (hPrefix k (mem_range.mp hk)) (B.weight_nonneg k)
      · simp [h]
    _ = X * (r i * load B.weight r t i) := by rw [mul_load_eq_sum B.weight r hr, mul_sum]
    _ ≤ r i * X := by
      have hg := mul_le_mul_of_nonneg_left hLoad (hr i).le
      rw [mul_one] at hg
      rw [mul_comm (r i) X]
      exact mul_le_mul_of_nonneg_left hg hX

/-- Convert all-group tail mass comparisons into a bound on actual denominator
cardinality, using the harmonic means and the disjointness of the blocks. -/
theorem allocated_card_tail_le (r : ι → ℚ) (hr : ∀ i, 0 < r i)
    {s t : ℕ} (hst : s < t) (ht : t ≤ B.length) {η : ℚ} (hη : 0 ≤ η)
    (regular : Finset ι) (hR : 0 < ∑ j ∈ regular, r j)
    (hSmall : ∀ k, s ≤ k → k < t → ∀ i, B.weight k / r i ≤ η)
    (hClose : ∀ k, s ≤ k → k < t → ∀ j ∈ regular,
      load B.weight r k j ≤ minLoad B.weight r k + η) (i : ι) :
    ((B.allocated r t i).card : ℚ) ≤ ((B.allocated r s i).card : ℚ) +
      (r i / (∑ j ∈ regular, r j)) * N + 2 * r i * η * N := by
  let a (k : ℕ) := if assignedGroup B.weight r k = i then B.weight k else 0
  have hMon : MonotoneOn B.effective (Set.Ico s t) :=
    B.ordered.mono fun _ hk => (hk.2.trans_le ht)
  have hAbel := weighted_tail_le B.effective a B.weight hst hMon (B.effective_nonneg s)
    (c := r i / ∑ j ∈ regular, r j) (err := 2 * r i * η) fun k hsk hkt =>
      group_tail_le B.weight r B.weight_nonneg hr hkt.le hη
        (fun l hkl hlt => hSmall l (hsk.trans hkl) hlt)
        regular hR (hClose k hsk hkt) i
  have hTerm : (∑ k ∈ Ico s t, B.effective k * a k) =
      ∑ k ∈ Ico s t, if assignedGroup B.weight r k = i then ((B.block k).card : ℚ) else 0 :=
    sum_congr rfl fun k hk => by
      by_cases h : assignedGroup B.weight r k = i
      · simp only [a, ite_eq_left h, B.effective_mul_weight ((mem_Ico.mp hk).2.trans_le ht)]
      · simp [a, h]
  have hCard : (∑ k ∈ Ico s t, B.effective k * B.weight k) ≤ (N : ℚ) := calc
    _ = ∑ k ∈ Ico s t, ((B.block k).card : ℚ) :=
      sum_congr rfl fun k hk => B.effective_mul_weight ((mem_Ico.mp hk).2.trans_le ht)
    _ ≤ ∑ k ∈ range t, ((B.block k).card : ℚ) :=
      sum_le_sum_of_subset_of_nonneg (fun k hk => mem_range.mpr (mem_Ico.mp hk).2)
        (fun _ _ _ => Nat.cast_nonneg _)
    _ ≤ _ := by exact_mod_cast B.sum_card_le ht
  have hTail : (∑ k ∈ Ico s t, if assignedGroup B.weight r k = i then
      ((B.block k).card : ℚ) else 0) ≤
      (r i / (∑ j ∈ regular, r j)) * N + 2 * r i * η * N :=
    hTerm ▸ hAbel.trans (add_le_add (mul_le_mul_of_nonneg_left hCard (div_nonneg (hr i).le hR.le))
      (mul_le_mul_of_nonneg_left (B.effective_le (by omega))
        (mul_nonneg (mul_nonneg (by norm_num : (0 : ℚ) ≤ 2) (hr i).le) hη)))
  rw [B.allocated_card r ht, B.allocated_card r (hst.le.trans ht), ← sum_range_add_sum_Ico _ hst.le]
  linarith


/-- Groups that have received one of the denominators at most D by time t. -/
noncomputable def specialGroups (r : ι → ℚ) (t D : ℕ) : Finset ι :=
  univ.filter (fun i => ((B.allocated r t i).filter (fun a => a ≤ D)).Nonempty)

theorem mem_specialGroups (r : ι → ℚ) (t D : ℕ) (i : ι) :
    i ∈ B.specialGroups r t D ↔ ∃ a ∈ B.allocated r t i, a ≤ D := by
  simp [specialGroups, Finset.Nonempty]

theorem card_specialGroups_le (r : ι → ℚ) {t : ℕ} (ht : t ≤ B.length) (D : ℕ) :
    (B.specialGroups r t D).card ≤ D := by
  let small (i : ι) := (B.allocated r t i).filter (fun a => a ≤ D)
  have hd : (↑(B.specialGroups r t D) : Set ι).PairwiseDisjoint small := by
    intro i _ j _ hij
    exact Disjoint.mono (filter_subset _ _) (filter_subset _ _) (B.allocated_disjoint r ht hij)
  calc
    _ = ∑ i ∈ B.specialGroups r t D, (1 : ℕ) := by simp
    _ ≤ ∑ i ∈ B.specialGroups r t D, (small i).card :=
      sum_le_sum fun i hi => one_le_card.mpr (mem_filter.mp hi).2
    _ = ((B.specialGroups r t D).biUnion small).card := (card_biUnion hd).symm
    _ ≤ (interval 1 D).card := by
      apply card_le_card
      intro a ha
      obtain ⟨i, _, hi⟩ := mem_biUnion.mp ha
      have ha' : a ∈ B.allocated r t i ∧ a ≤ D := mem_filter.mp hi
      have hpos := (mem_Icc.mp (B.allocated_subset r ht i ha'.1)).1
      exact mem_Icc.mpr ⟨by omega, ha'.2⟩
    _ = D := by simp [interval, Nat.card_Icc]

theorem sum_targets_specialGroups_le (r : ι → ℚ) {t : ℕ} (ht : t ≤ B.length)
    (D : ℕ) {A : ℚ} (hA : 0 ≤ A) (hr : ∀ i, r i ≤ A) :
    ∑ i ∈ B.specialGroups r t D, r i ≤ (D : ℚ) * A := calc
  _ ≤ ∑ _i ∈ B.specialGroups r t D, A := sum_le_sum fun i _ => hr i
  _ = ((B.specialGroups r t D).card : ℚ) * A := by simp
  _ ≤ _ := mul_le_mul_of_nonneg_right (by exact_mod_cast B.card_specialGroups_le r ht D) hA

omit [Fintype ι] [Nonempty ι] [DecidableEq ι] in
private theorem singleton_increment_le (r : ι → ℚ) (i : ι) {a : ℚ} (ha : 0 < a)
    (hri : a ≤ r i) {k b D : ℕ} (hD : 0 < D) (hDb : D ≤ b)
    (hSingleton : B.block k = {b}) :
    B.weight k / r i ≤ 1 / (a * D) := by
  rw [weight, mass, hSingleton, sum_singleton, ← one_div, div_div, mul_comm (b : ℚ)]
  apply one_div_le_one_div_of_le (mul_pos ha (Nat.cast_pos.mpr hD))
  exact mul_le_mul hri (Nat.cast_le.mpr hDb) (Nat.cast_nonneg _) (ha.le.trans hri)

theorem initial_singleton_load_le (r : ι → ℚ) (hr : ∀ i, 0 < r i)
    {early : ℕ} (he : early ≤ B.length) {mean a : ℚ} (hm : 0 ≤ mean) (ha : 0 < a)
    (hMass : ∑ k ∈ range early, B.weight k ≤ mean * ∑ j, r j)
    (hSingleton : ∀ k < early, ∃ b : ℕ, B.block k = {b})
    (i : ι) (hri : a ≤ r i) :
    load B.weight r early i ≤ mean + 1 / (a * (max 1 d : ℕ)) := by
  have hD : 0 < max 1 d := by omega
  refine early_load_bound B.weight r B.weight_nonneg hr hm
    (one_div_nonneg.mpr (mul_nonneg ha.le (Nat.cast_nonneg _))) hMass i ?_ early le_rfl
  intro k hk _
  obtain ⟨b, hb⟩ := hSingleton k hk
  have hmem : b ∈ interval d N :=
    B.subset k (hk.trans_le he) (by simp [hb])
  exact B.singleton_increment_le r i ha hri hD (mem_Icc.mp hmem).1 hb

theorem regular_initial_singleton_load_le (r : ι → ℚ) (hr : ∀ i, 0 < r i)
    {early D : ℕ} (hD : 0 < D) {mean a : ℚ} (hm : 0 ≤ mean) (ha : 0 < a)
    (hMass : ∑ k ∈ range early, B.weight k ≤ mean * ∑ j, r j)
    (hSingleton : ∀ k < early, ∃ b : ℕ, B.block k = {b})
    (i : ι) (hri : a ≤ r i) (hRegular : i ∉ B.specialGroups r early D) :
    load B.weight r early i ≤ mean + 1 / (a * D) := by
  refine early_load_bound B.weight r B.weight_nonneg hr hm
    (one_div_nonneg.mpr (mul_nonneg ha.le (Nat.cast_nonneg _))) hMass i ?_ early le_rfl
  intro k hk hki
  obtain ⟨b, hb⟩ := hSingleton k hk
  have hbmem : b ∈ B.allocated r early i :=
    mem_biUnion.mpr ⟨k, mem_filter.mpr ⟨mem_range.mpr hk, hki⟩, by simp [hb]⟩
  have hbD : D < b := lt_of_not_ge fun h => hRegular ((B.mem_specialGroups r early D i).mpr ⟨b, hbmem, h⟩)
  exact B.singleton_increment_le r i ha hri hD hbD.le hb

end BlockList


/-- Quantitative greedy allocation for the actual denominator sets.
The early prefix may contain larger blocks. The regular groups enter the
tail with loads close to the minimum, but the length bound applies to every group.
The denominator D may be the paper's common denominator involving the smooth cutoff
and the medium primes. -/
theorem greedy_reciprocal_allocation {d N : ℕ} (B : BlockList d N)
    (r : ι → ℚ) (hr : ∀ i, 0 < r i) {D : ℕ}
    (hBlockDen : ∀ k < B.length, (B.weight k).den ∣ D)
    (hTargetDen : ∀ i, (r i).den ∣ D)
    {early base : ℕ} (he : early ≤ base) (hb : base ≤ B.length)
    {δ η α X : ℚ} (hδ : 0 < δ) (hη : 0 ≤ η) (hX : 0 ≤ X)
    (hEarly : ∀ i, load B.weight r early i ≤ 1 - δ)
    (hLater : ∀ k, early ≤ k → k < B.length → ∀ i, B.weight k / r i ≤ η)
    (hMass : ∑ i, r i ≤ ∑ k ∈ range B.length, B.weight k)
    (hCutoff : ∀ k < base, B.effective k ≤ X)
    (regular : Finset ι) (hRegular : 0 < ∑ j ∈ regular, r j)
    (hRegularEarly : ∀ i ∈ regular, load B.weight r early i ≤ α)
    (hCross : (α + η) * (∑ i ∈ regular, r i) + (∑ i ∈ univ \ regular, r i) <
      ∑ k ∈ range base, B.weight k) :
    ∃ t, early ≤ t ∧ t ≤ B.length ∧
      (∀ s, early ≤ s → s < t → minLoad B.weight r s < 1 - δ - η) ∧
      Pairwise (fun i j => Disjoint (B.allocated r t i) (B.allocated r t j)) ∧
      ∀ i, B.allocated r t i ⊆ interval d N ∧
        0 < r i - mass (B.allocated r t i) ∧
        r i * δ ≤ r i - mass (B.allocated r t i) ∧
        r i - mass (B.allocated r t i) ≤ r i * (δ + η) ∧
        (r i - mass (B.allocated r t i)).den ∣ D ∧
        ((B.allocated r t i).card : ℚ) ≤ r i * X +
          (r i / (∑ j ∈ regular, r j)) * N + 2 * r i * η * N := by
  obtain ⟨t, ht₀, ht, hLoad, hFirst⟩ :=
    exists_stopping_prefix B.weight r hr (he.trans hb) hδ hEarly hLater hMass
  refine ⟨t, ht₀, ht, hFirst, B.allocated_disjoint r ht, fun i => ?_⟩
  have hGap : r i - mass (B.allocated r t i) = r i * (1 - load B.weight r t i) := by
    rw [B.allocated_mass r hr ht]
    ring
  have hLow : r i * δ ≤ r i - mass (B.allocated r t i) := by
    rw [hGap]
    exact mul_le_mul_of_nonneg_left (by linarith [(hLoad i).2]) (hr i).le
  have hHigh : r i - mass (B.allocated r t i) ≤ r i * (δ + η) := by
    rw [hGap]
    exact mul_le_mul_of_nonneg_left (by linarith [(hLoad i).1]) (hr i).le
  refine ⟨B.allocated_subset r ht i, (mul_pos (hr i) hδ).trans_le hLow, hLow, hHigh,
    B.residual_den_dvd r ht hBlockDen hTargetDen i, ?_⟩
  have hCap (s : ℕ) (hst : s ≤ t) (j : ι) : load B.weight r s j ≤ 1 :=
    (load_mono B.weight r B.weight_nonneg hr j hst).trans ((hLoad j).2.trans (by linarith))
  by_cases hShort : t ≤ base
  · have hPrefix := B.allocated_card_prefix_le r hr ht hX
      (fun k hk => hCutoff k (hk.trans_le hShort)) i (hCap t le_rfl i)
    exact hPrefix.trans (by
      have hN : (0 : ℚ) ≤ N := Nat.cast_nonneg _
      have hSlope := div_nonneg (hr i).le hRegular.le
      have hErr := mul_nonneg (mul_nonneg (mul_nonneg (by norm_num : (0 : ℚ) ≤ 2) (hr i).le) hη) hN
      linarith [mul_nonneg hSlope hN])
  · have hbt : base < t := lt_of_not_ge hShort
    have hSpecial : ∑ j ∈ univ \ regular, r j * load B.weight r base j ≤
        ∑ j ∈ univ \ regular, r j := by
      apply sum_le_sum
      intro j _
      simpa only [mul_one] using mul_le_mul_of_nonneg_left (hCap base hbt.le j) (hr j).le
    have hv := minLoad_gt_of_prefix_mass B.weight r B.weight_nonneg hr he hη regular
      hRegularEarly (fun k hk hkb => hLater k hk (hkb.trans_le hb)) hSpecial hCross
    have hnonspecial (s : ℕ) (hbs : base ≤ s) (hst : s < t) :
        ∀ j ∈ regular, load B.weight r s j ≤ minLoad B.weight r s + η :=
      regular_load_le B.weight r B.weight_nonneg hr he hbs hη regular hRegularEarly hv.le
        (fun k hek hks => hLater k hek (hks.trans (hst.trans_le ht)))
    have hTail := B.allocated_card_tail_le r hr hbt ht hη regular hRegular
      (fun k hbk hkt => hLater k (he.trans hbk) (hkt.trans_le ht)) hnonspecial i
    have hPrefix := B.allocated_card_prefix_le r hr hb hX hCutoff i (hCap base hbt.le i)
    linarith

/-- Expose the loss from the excluded groups in the length estimate as an exact term
with the full total R in the main denominator. -/
theorem length_bound_with_total_targets (r R₀ R N : ℚ) (hR₀ : R₀ ≠ 0) (hR : R ≠ 0) :
    (r / R₀) * N = (r / R) * N + (r * N * (R - R₀)) / (R₀ * R) := by
  field_simp [hR₀, hR]
  ring

end LeanAB.PaperB.Allocation
