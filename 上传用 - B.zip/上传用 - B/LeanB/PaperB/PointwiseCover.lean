module

public import PaperB.Coverage
public import Mathlib.NumberTheory.LSeries.WeakPNT
import Mathlib.Algebra.Order.Floor.Semifield
import Mathlib.Tactic

public section

/-! The phase-counting argument behind the pointwise logarithmic cover. -/

namespace LeanAB.PaperB.Closure

open Filter Asymptotics
open scoped BigOperators Topology

/-- The primes in the top half of a positive integer cutoff. -/
@[expose] def halfPrimes (T : ℕ) : Finset ℕ :=
  Nat.primesLE T \ Nat.primesLE (T / 2)

theorem mem_halfPrimes {T b : ℕ} :
    b ∈ halfPrimes T ↔ b.Prime ∧ T / 2 < b ∧ b ≤ T := by
  simp only [halfPrimes, Finset.mem_sdiff, Nat.mem_primesLE]
  constructor
  · rintro ⟨⟨hU, hp⟩, hnot⟩
    exact ⟨hp, lt_of_not_ge (fun h => hnot ⟨h, hp⟩), hU⟩
  · rintro ⟨hp, hlo, hU⟩
    exact ⟨⟨hU, hp⟩, fun h => hlo.not_ge h.1⟩

private theorem cast_natAbs (x : ℤ) : (x.natAbs : ℝ) = |(x : ℝ)| := by
  rw [← Int.cast_natCast, ← Int.abs_eq_natAbs, Int.cast_abs]

private theorem mul_div_factorization {p b : ℕ} [Fact p.Prime] (hb₀ : b ≠ 0)
    (hb : b < p) (h : ZMod p) :
    ∃ j : ℤ, (b : ℤ) * (h * (b : ZMod p)⁻¹).valMinAbs = (h.val : ℤ) + j * p := by
  have hunit : (b : ZMod p) ≠ 0 := fun hz =>
    hb.not_ge (Nat.le_of_dvd (Nat.pos_of_ne_zero hb₀) ((ZMod.natCast_eq_zero_iff _ _).mp hz))
  let r := (h * (b : ZMod p)⁻¹).valMinAbs
  have he : (((h.val : ℤ)) : ZMod p) = (((b : ℤ) * r : ℤ) : ZMod p) := by
    rw [Int.cast_mul, Int.cast_natCast, Int.cast_natCast, ZMod.natCast_zmod_val, ZMod.coe_valMinAbs,
      mul_left_comm, mul_inv_cancel₀ hunit, mul_one]
  obtain ⟨j, hj⟩ := (ZMod.intCast_eq_intCast_iff_dvd_sub _ _ _).mp he
  exact ⟨j, by linarith [mul_comm (p : ℤ) j]⟩

private theorem primes_dividing_card_log_le (T : ℕ) (hT : 4 ≤ T) {a : ℤ} (ha : a ≠ 0) :
    (((halfPrimes T ∩ a.natAbs.primeFactors).card : ℝ) * (Real.log T / 2)) ≤
      Real.log (a.natAbs : ℝ) := by
  let D := halfPrimes T ∩ a.natAbs.primeFactors
  have hT₀ : (0 : ℝ) < T := by exact_mod_cast (show 0 < T by omega)
  have hLog : Real.log (4 : ℝ) ≤ Real.log (T : ℝ) :=
    Real.log_le_log (by norm_num) (by exact_mod_cast hT)
  have hlogHalf : Real.log (T : ℝ) / 2 ≤ Real.log ((T : ℝ) / 2) := by
    rw [Real.log_div hT₀.ne' (by norm_num)]
    have hEq : Real.log (4 : ℝ) = 2 * Real.log 2 := by
      rw [show (4 : ℝ) = 2 ^ (2 : ℕ) by norm_num, Real.log_pow]
      norm_num
    linarith
  have hprod : ∏ b ∈ D, b ≤ a.natAbs := Nat.le_of_dvd (Int.natAbs_pos.mpr ha)
    ((Finset.prod_dvd_prod_of_subset _ _ id (show D ⊆ a.natAbs.primeFactors from
      Finset.inter_subset_right)).trans (Nat.prod_primeFactors_dvd _))
  have hreal : ∏ b ∈ D, (b : ℝ) ≤ (a.natAbs : ℝ) := by
    rw [← Nat.cast_prod]
    exact Nat.cast_le.mpr hprod
  have hbpos (b : ℕ) (hb : b ∈ D) : (0 : ℝ) < b := by
    exact_mod_cast (mem_halfPrimes.mp (Finset.mem_inter.mp hb).1).1.pos
  change (D.card : ℝ) * (Real.log (T : ℝ) / 2) ≤ _
  calc
    _ = ∑ _b ∈ D, Real.log (T : ℝ) / 2 := by simp
    _ ≤ ∑ b ∈ D, Real.log (b : ℝ) := by
      apply Finset.sum_le_sum
      intro b hb
      have hl := (mem_halfPrimes.mp (Finset.mem_inter.mp hb).1).2.1
      have hlr : (T : ℝ) / 2 ≤ b := (div_le_iff₀ (by norm_num)).mpr (by
        exact_mod_cast ((Nat.div_lt_iff_lt_mul (by decide : 0 < 2)).mp hl).le)
      exact hlogHalf.trans (Real.log_le_log (by positivity) hlr)
    _ = Real.log (∏ b ∈ D, (b : ℝ)) := (Real.log_prod (fun b hb => (hbpos b hb).ne')).symm
    _ ≤ _ := Real.log_le_log (Finset.prod_pos hbpos) hreal

/-- Uniform count of primes for which the Fourier phase is close to an integer. -/
theorem small_phase_card_le (p T : ℕ) [Fact p.Prime] (hT : 4 ≤ T) (hTp : T + 2 ≤ p)
    (δ : ℝ) (hδ : 0 ≤ δ) (hδ₁ : δ ≤ 1) (h : ZMod p) (hh : h ≠ 0) :
    (((halfPrimes T).filter (fun b : ℕ =>
      phaseDistance (h * (b : ZMod p)⁻¹) ≤ δ)).card : ℝ) ≤
      (2 * (T : ℝ) * δ + 3) * (4 * Real.log p / Real.log T) := by
  classical
  let M := ⌊(T : ℝ) * δ + 1⌋₊
  let I := Finset.Icc (-(M : ℤ)) (M : ℤ)
  let a (j : ℤ) : ℤ := h.val + j * p
  let R (j : ℤ) := halfPrimes T ∩ (a j).natAbs.primeFactors
  let bad := (halfPrimes T).filter (fun b : ℕ => phaseDistance (h * (b : ZMod p)⁻¹) ≤ δ)
  have hp₀ : (0 : ℝ) < p := by exact_mod_cast (Fact.out : p.Prime).pos
  have hTl : 0 < Real.log (T : ℝ) := Real.log_pos (by exact_mod_cast (show 1 < T by omega))
  have hpl : 0 ≤ Real.log (p : ℝ) :=
    Real.log_nonneg (by exact_mod_cast (Fact.out : p.Prime).one_le)
  have hM : (M : ℝ) ≤ (T : ℝ) * δ + 1 := Nat.floor_le (by positivity)
  have hM' : (M : ℝ) ≤ (T : ℝ) + 1 :=
    hM.trans (add_le_add_left (mul_le_of_le_one_right (Nat.cast_nonneg T) hδ₁) 1)
  have cast_h_val : (h.val : ℝ) < p := by exact_mod_cast ZMod.val_lt h
  have ha (j : ℤ) : a j ≠ 0 := by
    intro hz
    have hd := congrArg (fun x : ℤ => (x : ZMod p)) hz
    change (((h.val : ℤ) + j * (p : ℤ) : ℤ) : ZMod p) = (0 : ℤ) at hd
    simp only [Int.cast_add, Int.cast_mul, Int.cast_natCast, ZMod.natCast_zmod_val,
      ZMod.natCast_self, mul_zero, add_zero, Int.cast_zero, hh] at hd
  have hsubset : bad ⊆ I.biUnion R := by
    intro b hb
    have hp := mem_halfPrimes.mp (Finset.mem_filter.mp hb).1
    have hbp : b < p := hp.2.2.trans_lt (by omega)
    obtain ⟨j, hj⟩ := mul_div_factorization hp.1.ne_zero hbp h
    let r := (h * (b : ZMod p)⁻¹).valMinAbs
    have hr : |(r : ℝ)| ≤ δ * p := by
      have h' := (Finset.mem_filter.mp hb).2
      change (r.natAbs : ℝ) / p ≤ δ at h'
      rw [cast_natAbs] at h'
      exact (div_le_iff₀ hp₀).mp h'
    have hj' : (b : ℝ) * (r : ℝ) - (h.val : ℝ) = (j : ℝ) * p := by
      have hg : (b : ℝ) * (r : ℝ) = (h.val : ℝ) + (j : ℝ) * p := by exact_mod_cast hj
      linarith
    have hjabs : |(j : ℝ)| ≤ (T : ℝ) * δ + 1 := by
      have hmul : |(j : ℝ)| * p ≤ ((T : ℝ) * δ + 1) * p := calc
        _ = |(b : ℝ) * (r : ℝ) - (h.val : ℝ)| := by rw [hj', abs_mul, abs_of_nonneg hp₀.le]
        _ ≤ |(b : ℝ) * (r : ℝ)| + |(h.val : ℝ)| := abs_sub _ _
        _ = (b : ℝ) * |(r : ℝ)| + h.val := by
          simp only [abs_mul, abs_of_nonneg (show 0 ≤ (b : ℝ) from Nat.cast_nonneg b),
            abs_of_nonneg (show 0 ≤ (h.val : ℝ) from Nat.cast_nonneg h.val)]
        _ ≤ (T : ℝ) * (δ * p) + p := by
          exact add_le_add (mul_le_mul (by exact_mod_cast hp.2.2) hr (abs_nonneg _) (Nat.cast_nonneg _))
            cast_h_val.le
        _ = _ := by ring
      exact (mul_le_mul_iff_left₀ hp₀).mp hmul
    have hjM : j.natAbs ≤ M := Nat.le_floor (by simpa only [cast_natAbs] using hjabs)
    have hjI : j ∈ I := by
      have hI : |j| ≤ (M : ℤ) := by rw [Int.abs_eq_natAbs]; exact_mod_cast hjM
      exact Finset.mem_Icc.mpr (abs_le.mp hI)
    have hdiv : (b : ℤ) ∣ a j := ⟨r, hj.symm⟩
    have hndiv : b ∣ (a j).natAbs := by simpa using Int.natAbs_dvd_natAbs.mpr hdiv
    exact Finset.mem_biUnion.mpr ⟨j, hjI, Finset.mem_inter.mpr
      ⟨(Finset.mem_filter.mp hb).1, hp.1.mem_primeFactors hndiv (Int.natAbs_ne_zero.mpr (ha j))⟩⟩
  have hper (j : ℤ) (hj : j ∈ I) : ((R j).card : ℝ) ≤ 4 * Real.log p / Real.log T := by
    have hjAbs : |(j : ℝ)| ≤ (M : ℝ) := by
      apply abs_le.mpr
      obtain ⟨hlo, hhi⟩ := Finset.mem_Icc.mp hj
      exact ⟨by exact_mod_cast hlo, by exact_mod_cast hhi⟩
    have habs : ((a j).natAbs : ℝ) ≤ (p : ℝ) * p := by
      rw [cast_natAbs]
      dsimp only [a]
      push_cast
      calc
        _ ≤ |(h.val : ℝ)| + |(j : ℝ) * p| := abs_add_le _ _
        _ ≤ (p : ℝ) + ((T : ℝ) + 1) * p := by
          rw [abs_of_nonneg (Nat.cast_nonneg h.val), abs_mul, abs_of_nonneg hp₀.le]
          exact add_le_add cast_h_val.le (mul_le_mul_of_nonneg_right (hjAbs.trans hM') hp₀.le)
        _ = ((T : ℝ) + 2) * p := by ring
        _ ≤ _ := mul_le_mul_of_nonneg_right (by exact_mod_cast hTp) hp₀.le
    have hθ := primes_dividing_card_log_le T hT (ha j)
    have hlog := Real.log_le_log (by exact_mod_cast Int.natAbs_pos.mpr (ha j)) habs
    rw [Real.log_mul hp₀.ne' hp₀.ne'] at hlog
    apply (le_div_iff₀ hTl).mpr
    change ((R j).card : ℝ) * (Real.log (T : ℝ) / 2) ≤ _ at hθ
    linarith
  have hIC : I.card = 2 * M + 1 := by
    simp only [I, Int.card_Icc]
    omega
  have hIC' : (I.card : ℝ) ≤ 2 * (T : ℝ) * δ + 3 := by
    rw [hIC]
    push_cast
    linarith
  calc
    _ ≤ ((I.biUnion R).card : ℝ) := Nat.cast_le.mpr (Finset.card_le_card hsubset)
    _ ≤ ∑ j ∈ I, ((R j).card : ℝ) := by exact_mod_cast Finset.card_biUnion_le
    _ ≤ ∑ _j ∈ I, 4 * Real.log (p : ℝ) / Real.log T := Finset.sum_le_sum hper
    _ = (I.card : ℝ) * (4 * Real.log (p : ℝ) / Real.log T) := by simp
    _ ≤ _ := mul_le_mul_of_nonneg_right hIC' (div_nonneg (mul_nonneg (by norm_num) hpl) hTl.le)


theorem eventually_halfPrimes_card_ge :
    ∀ᶠ T : ℕ in atTop, (T : ℝ) / (3 * Real.log T) ≤ ((halfPrimes T).card : ℝ) := by
  have hc : Tendsto (fun T : ℕ => (T : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hhi := Chebyshev.tendsto_theta_div_atTop.comp hc
  have hlo := Chebyshev.tendsto_theta_div_atTop.comp (hc.atTop_div_const (by norm_num : (0 : ℝ) < 2))
  filter_upwards [hhi.eventually_const_lt (show (9 / 10 : ℝ) < 1 by norm_num),
    hlo.eventually_lt_const (show (1 : ℝ) < 11 / 10 by norm_num),
    eventually_ge_atTop (2 : ℕ)] with T hh hl hT
  have hT₁ : (1 : ℝ) < T := by exact_mod_cast (show 1 < T by omega)
  have hT₀ := zero_lt_one.trans hT₁
  have hhi' : (9 / 10 : ℝ) * T < Chebyshev.theta (T : ℝ) :=
    (lt_div_iff₀ hT₀).mp hh
  have hlo' : Chebyshev.theta ((T : ℝ) / 2) < (11 / 10 : ℝ) * ((T : ℝ) / 2) :=
    (div_lt_iff₀ (by positivity)).mp hl
  have hmain : (T : ℝ) / 3 ≤ Chebyshev.theta (T : ℝ) - Chebyshev.theta ((T : ℝ) / 2) := by
    linarith
  have hfloor : ⌊(T : ℝ) / 2⌋₊ = T / 2 := by
    simpa using (Nat.floor_div_natCast (T : ℝ) 2)
  have hsub := Nat.primesLE_mono (Nat.div_le_self T 2)
  rw [Chebyshev.theta_eq_sum_primesLE_log, Chebyshev.theta_eq_sum_primesLE, hfloor,
    ← Finset.sum_sdiff hsub, add_sub_cancel_right] at hmain
  have htop : (∑ b ∈ halfPrimes T, Real.log (b : ℝ)) ≤
      ((halfPrimes T).card : ℝ) * Real.log T := by
    calc
      _ ≤ ∑ _b ∈ halfPrimes T, Real.log (T : ℝ) := Finset.sum_le_sum fun b hb =>
        Real.log_le_log (by exact_mod_cast (mem_halfPrimes.mp hb).1.pos)
          (by exact_mod_cast (mem_halfPrimes.mp hb).2.2)
      _ = _ := by simp
  apply (div_le_iff₀ (mul_pos (by norm_num) (Real.log_pos hT₁))).mpr
  linarith [hmain.trans htop]

private theorem coversResidues_of_halfPrimes_bounds (p T : ℕ) [Fact p.Prime]
    (hTp : T + 2 ≤ p) (hT : 4 ≤ T)
    (hz : 7 ≤ Real.log (p : ℝ)) (hfour : Real.log (p : ℝ) ^ 4 ≤ T)
    (hlog : 2 * (192 : ℝ)^2 * Real.log T ≤ Real.log p)
    (hTcard : (T : ℝ) / (3 * Real.log T) ≤ ((halfPrimes T).card : ℝ)) :
    CoversResidues p (interval 1 T) := by
  classical
  let z := Real.log (p : ℝ)
  let δ : ℝ := 1 / (192 * z)
  have hz₀ : 0 < z := by linarith
  have hT₁ : (1 : ℝ) < T := by exact_mod_cast (show 1 < T by omega)
  have hlogT := Real.log_pos hT₁
  have hδ : 0 ≤ δ := by dsimp only [δ]; positivity
  have hδ₁ : δ ≤ 1 := by
    dsimp only [δ]
    apply (div_le_one (by positivity)).mpr
    have hh : 7 ≤ z := hz
    linarith
  have hcover : CoversResidues p (halfPrimes T) := by
    apply coversResidues_of_separated_phases (halfPrimes T) δ hδ
    intro h hn
    let phase (b : ℕ) := phaseDistance (h * (b : ZMod p)⁻¹)
    let bad := (halfPrimes T).filter fun b => phase b ≤ δ
    let good := (halfPrimes T).filter fun b => δ ≤ phase b
    have hpart : bad ∪ good = halfPrimes T := by
      ext b
      simp only [bad, good, Finset.mem_union, Finset.mem_filter]
      constructor
      · exact fun hb => hb.elim And.left And.left
      · intro hb
        exact (le_total (phase b) δ).elim (fun hh => Or.inl ⟨hb, hh⟩) (fun hh => Or.inr ⟨hb, hh⟩)
    have hcount : ((halfPrimes T).card : ℝ) ≤ (bad.card : ℝ) + (good.card : ℝ) := by
      have hh := Finset.card_union_le bad good
      rw [hpart] at hh
      exact_mod_cast hh
    have hBad : (bad.card : ℝ) ≤ (T : ℝ) / (12 * Real.log T) := calc
      _ ≤ (2 * (T : ℝ) * δ + 3) * (4 * z / Real.log T) :=
        small_phase_card_le p T hT hTp δ hδ hδ₁ h hn
      _ = (8 * (T : ℝ) / 192 + 12 * z) / Real.log T := by
        dsimp only [δ]
        field_simp
        ring
      _ ≤ _ := by
        rw [← div_div]
        apply div_le_div_of_nonneg_right _ hlogT.le
        have hz3 : (288 : ℝ) ≤ z ^ 3 :=
          (by norm_num : (288 : ℝ) ≤ 7 ^ 3).trans (pow_le_pow_left₀ (by norm_num) hz _)
        have htz : 288 * z ≤ T := (mul_le_mul_of_nonneg_right hz3 hz₀.le).trans
          (by simpa only [← pow_succ] using hfour)
        linarith
    have hGood : (T : ℝ) / (4 * Real.log T) ≤ (good.card : ℝ) := by
      have he : (T : ℝ) / (3 * Real.log T) - (T : ℝ) / (12 * Real.log T) =
          (T : ℝ) / (4 * Real.log T) := by field_simp; ring
      rw [← he]
      linarith
    have hlarge : 2 * (192 : ℝ) ^ 2 * z ^ 3 * Real.log T ≤ T := calc
      _ = (2 * (192 : ℝ) ^ 2 * Real.log T) * z ^ 3 := by ring
      _ ≤ z * z ^ 3 := mul_le_mul_of_nonneg_right hlog (by positivity)
      _ = z ^ 4 := by ring
      _ ≤ _ := hfour
    calc
      z ≤ (T : ℝ) / (2 * (192 : ℝ) ^ 2 * z ^ 2 * Real.log T) :=
        (le_div_iff₀ (by positivity)).mpr (by nlinarith)
      _ = 2 * δ ^ 2 * ((T : ℝ) / (4 * Real.log T)) := by
        dsimp only [δ]
        field_simp
        ring
      _ ≤ _ := mul_le_mul_of_nonneg_left hGood (by positivity)
  intro v
  obtain ⟨J, hJ, hv⟩ := hcover v
  refine ⟨J, hJ.trans ?_, hv⟩
  intro b hb
  have h := mem_halfPrimes.mp hb
  exact Finset.mem_Icc.mpr ⟨h.1.one_le, h.2.2⟩

/-- Every sufficiently large prime has a cover using cofactors at most ceil((log p)^4). -/
theorem eventually_pointwise_reciprocal_cover :
    ∀ᶠ p : ℕ in atTop, p.Prime →
      CoversResidues p (interval 1 ⌈Real.log (p : ℝ) ^ 4⌉₊) := by
  have hc : Tendsto (fun p : ℕ => (p : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hz : Tendsto (fun p : ℕ => Real.log (p : ℝ)) atTop atTop := Real.tendsto_log_atTop.comp hc
  let Q (p : ℕ) := ⌈Real.log (p : ℝ) ^ 4⌉₊
  have hQ : Tendsto Q atTop atTop := by
    apply tendsto_atTop.2
    intro k
    filter_upwards [hz.eventually_ge_atTop (max 1 (k : ℝ))] with p hp
    have hp₁ := (le_max_left (1 : ℝ) (k : ℝ)).trans hp
    have hpK := (le_max_right (1 : ℝ) (k : ℝ)).trans hp
    have hh : (k : ℝ) ≤ (Q p : ℝ) := hpK.trans
      ((le_self_pow₀ hp₁ (by decide : (4 : ℕ) ≠ 0)).trans (Nat.le_ceil _))
    exact_mod_cast hh
  have hl4 := (isLittleO_log_rpow_rpow_atTop (s := (1 : ℝ)) 4 (by norm_num)).bound
    (show (0 : ℝ) < 1 / 2 by norm_num)
  let C : ℝ := 2 * (192 : ℝ) ^ 2
  have hC : 0 < C := by dsimp only [C]; positivity
  have hl1 := Real.isLittleO_log_id_atTop.bound (one_div_pos.mpr (show 0 < 5 * C by positivity))
  filter_upwards [hz.eventually_ge_atTop 7, hQ.eventually_ge_atTop 4,
    hQ.eventually eventually_halfPrimes_card_ge, hc.eventually hl4, hz.eventually hl1,
    eventually_ge_atTop (6 : ℕ)] with p hz7 hQ4 hcount hSmall hLogSmall hp6 hp
  let _ : Fact p.Prime := ⟨hp⟩
  let z := Real.log (p : ℝ)
  have hnz : 0 < z := by linarith
  have hQlo : z ^ 4 ≤ (Q p : ℝ) := Nat.le_ceil _
  have hQhi : (Q p : ℝ) < z ^ 4 + 1 := Nat.ceil_lt_add_one (by positivity)
  have hsmall : z ^ 4 ≤ (1 / 2 : ℝ) * p := by
    rw [show (4 : ℝ) = ((4 : ℕ) : ℝ) by norm_num, Real.rpow_natCast, Real.rpow_one,
      Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg (pow_nonneg hnz.le _),
      abs_of_nonneg (Nat.cast_nonneg p)] at hSmall
    exact hSmall
  have hp6' : (6 : ℝ) ≤ p := by exact_mod_cast hp6
  have hqp : Q p + 2 ≤ p := by
    have h : (Q p : ℝ) + 2 ≤ p := by linarith
    exact_mod_cast h
  have hz2 : 2 ≤ z := by linarith
  have hz4 : 1 ≤ z ^ 4 := le_self_pow₀ (by linarith : 1 ≤ z) (by decide : (4 : ℕ) ≠ 0) |>.trans' (by linarith)
  have hLogBound : Real.log (Q p : ℝ) ≤ 5 * Real.log z := by
    have h := Real.log_le_log (by exact_mod_cast (show 0 < Q p by omega))
      (show (Q p : ℝ) ≤ 2 * z ^ 4 by linarith)
    rw [Real.log_mul (by norm_num) (by positivity), Real.log_pow] at h
    have hTwo := Real.log_le_log (by norm_num : (0 : ℝ) < 2) hz2
    norm_num at h
    linarith
  have hLogSmall' : Real.log z ≤ (1 / (5 * C)) * z := by
    change ‖Real.log z‖ ≤ (1 / (5 * C)) * ‖z‖ at hLogSmall
    simpa only [Real.norm_eq_abs, abs_of_nonneg hnz.le,
      abs_of_nonneg (Real.log_pos (show 1 < z by linarith)).le] using hLogSmall
  have hLog : C * Real.log (Q p) ≤ z := calc
    _ ≤ C * (5 * Real.log z) := mul_le_mul_of_nonneg_left hLogBound hC.le
    _ ≤ C * (5 * ((1 / (5 * C)) * z)) :=
      mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hLogSmall' (by norm_num)) hC.le
    _ = _ := by field_simp
  exact coversResidues_of_halfPrimes_bounds p (Q p) hqp hQ4 hz7 hQlo hLog hcount

end LeanAB.PaperB.Closure
