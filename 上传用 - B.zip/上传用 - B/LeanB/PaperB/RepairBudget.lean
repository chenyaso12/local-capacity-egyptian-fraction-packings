module

public import PaperB.PowersmoothDensity
public import PaperB.RepairPools
meta import Mathlib.Tactic

/-! Smooth reserves and the mass accounting for the initial exclusions in F2. -/

@[expose] public section

open Filter Finset Asymptotics
open scoped Topology

namespace LeanAB.PaperB.Closure

/-- A reserve of exactly w powersmooth denominators in the upper half of
the height range, with its reciprocal mass bounded on both sides. -/
def SmoothReserveAt (d N y w : ℕ) : Prop :=
  ∃ R : Finset ℕ, R ⊆ interval d N ∧ R.card = w ∧
    (∀ a ∈ R, N ≤ 2 * a ∧ a ∣ Nat.lcmUpto y) ∧
    (w : ℚ) / N ≤ mass R ∧ mass R ≤ 2 * (w : ℚ) / N

/-- A sublinear request can be met using actual powersmooth denominators,
uniformly for large N. -/
theorem eventually_smoothReserveAt_of_sublinear (d u : ℕ) (hu : 0 < u)
    (f : ℕ → ℝ) (hf : f =o[atTop] fun N : ℕ => (N : ℝ)) :
    ∀ᶠ N : ℕ in atTop, SmoothReserveAt d N (Nat.nthRoot u N) ⌈f N⌉₊ := by
  obtain ⟨c, hc, hcount⟩ := eventually_powersmooth_half_card_ge u hu
  filter_upwards [hcount, hf.bound hc, eventually_ge_atTop (2 * d + 1)] with N hN hF hLarge
  let V := powersmoothInterval (N / 2) N (Nat.nthRoot u N)
  have hW : ⌈f N⌉₊ ≤ V.card := by
    apply Nat.ceil_le.mpr
    calc
      f N ≤ |f N| := le_abs_self _
      _ ≤ c * (N : ℝ) := by
        simpa only [Real.norm_eq_abs, abs_of_nonneg (show 0 ≤ (N : ℝ) from Nat.cast_nonneg N)] using hF
      _ ≤ _ := hN
  have hSub : V ⊆ (interval d N).filter (fun a =>
      N ≤ 2 * a ∧ a ∣ Nat.lcmUpto (Nat.nthRoot u N)) := by
    intro a ha
    obtain ⟨hI, hD⟩ := mem_filter.mp ha
    obtain ⟨hL, hU⟩ := mem_Ioc.mp hI
    have hI' : a ∈ interval d N := mem_Icc.mpr ⟨by omega, hU⟩
    exact mem_filter.mpr ⟨hI', by omega, hD⟩
  exact exists_smooth_reserve (by omega) (hW.trans (card_le_card hSub))

/-- The baseline's shared reserve contains exactly ceil(N/(log N)^4) terms. -/
theorem eventually_baselineSmoothReserve (d : ℕ) :
    ∀ᶠ N : ℕ in atTop, SmoothReserveAt d N (Nat.nthRoot 20 N)
      ⌈(N : ℝ) / (Real.log N) ^ 4⌉₊ := by
  apply eventually_smoothReserveAt_of_sublinear d 20 (by decide)
  apply isLittleO_iff.mpr
  intro ε hε
  have hlog := Real.tendsto_log_atTop.comp
    (tendsto_natCast_atTop_atTop : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop)
  filter_upwards [hlog.eventually_ge_atTop (max 1 (1 / ε))] with N hN
  have hL : 1 ≤ Real.log (N : ℝ) := (le_max_left _ _).trans hN
  have hL₀ : 0 < Real.log (N : ℝ) := zero_lt_one.trans_le hL
  have hLpow : Real.log (N : ℝ) ≤ (Real.log N) ^ 4 := le_self_pow₀ hL (by decide)
  have hεL : 1 / ε ≤ (Real.log (N : ℝ)) ^ 4 := ((le_max_right _ _).trans hN).trans hLpow
  rw [Real.norm_of_nonneg (by positivity), Real.norm_of_nonneg (Nat.cast_nonneg N)]
  calc
    _ = (N : ℝ) * (1 / (Real.log N) ^ 4) := by ring
    _ ≤ (N : ℝ) * ε := mul_le_mul_of_nonneg_left
      ((div_le_iff₀ (pow_pos hL₀ 4)).mpr (by
        nlinarith only [(div_le_iff₀ hε).mp hεL])) (Nat.cast_nonneg _)
    _ = _ := mul_comm _ _

/-- The near-capacity proof's larger shared reserve, with delta=N^(-1/8). -/
theorem eventually_nearCapacitySmoothReserve :
    ∀ᶠ N : ℕ in atTop, SmoothReserveAt 2 N (Nat.nthRoot 20 N)
      ⌈8 * Real.log N * (N : ℝ) ^ (7 / 8 : ℝ)⌉₊ := by
  apply eventually_smoothReserveAt_of_sublinear 2 20 (by decide)
  apply isLittleO_iff.mpr
  intro ε hε
  have hlog := (isLittleO_log_rpow_atTop (show 0 < (1 / 8 : ℝ) by norm_num)).bound
    (show 0 < ε / 8 by positivity)
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  filter_upwards [hcast.eventually hlog, hcast.eventually (eventually_gt_atTop (1 : ℝ))]
    with N hLog hN
  have hx : 0 < (N : ℝ) := zero_lt_one.trans hN
  have hl₀ : 0 ≤ Real.log (N : ℝ) := Real.log_nonneg hN.le
  have hl : Real.log (N : ℝ) ≤ ε / 8 * (N : ℝ) ^ (1 / 8 : ℝ) := by
    simpa only [Real.norm_eq_abs, abs_of_nonneg hl₀, abs_of_nonneg (Real.rpow_nonneg hx.le _)]
      using hLog
  rw [Real.norm_of_nonneg (by positivity), Real.norm_of_nonneg hx.le]
  calc
    _ ≤ (ε * (N : ℝ) ^ (1 / 8 : ℝ)) * (N : ℝ) ^ (7 / 8 : ℝ) := by
      exact mul_le_mul_of_nonneg_right (by linarith only [hl]) (Real.rpow_nonneg hx.le _)
    _ = _ := by
      rw [mul_assoc, ← Real.rpow_add hx, show (1 / 8 : ℝ) + 7 / 8 = 1 by norm_num,
        Real.rpow_one]

private theorem mass_union_le_add (A B : Finset ℕ) :
    mass (A ∪ B) ≤ mass A + mass B := by
  have h := sum_union_inter (s₁ := A) (s₂ := B) (f := fun a : ℕ => (a : ℚ)⁻¹)
  change mass (A ∪ B) + mass (A ∩ B) = mass A + mass B at h
  linarith only [h, mass_nonneg (A ∩ B)]

/-- The actual combined discarded set is charged at most once to each
reservation or family of excluded multiples. -/
theorem mass_repair_exclusions_le (H M S R : Finset ℕ) :
    mass (H ∪ M ∪ S ∪ R) ≤ mass H + mass M + mass S + mass R := by
  linarith only [mass_union_le_add H M, mass_union_le_add (H ∪ M) S,
    mass_union_le_add (H ∪ M ∪ S) R]

theorem eventually_log_pow_le_rpow (k : ℕ) {e : ℝ} (he : 0 < e) :
    ∀ᶠ N : ℕ in atTop, Real.log (N : ℝ) ^ k ≤ (N : ℝ) ^ e := by
  have h := (isLittleO_log_rpow_rpow_atTop (k : ℝ) he).bound (show 0 < (1 : ℝ) by norm_num)
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  filter_upwards [hcast.eventually h, hcast.eventually (eventually_ge_atTop (1 : ℝ))] with N hB hN
  have hl : 0 ≤ Real.log (N : ℝ) := Real.log_nonneg hN
  simpa only [Real.norm_eq_abs, Real.rpow_natCast, abs_of_nonneg (pow_nonneg hl k),
    abs_of_nonneg (Real.rpow_nonneg (Nat.cast_nonneg N) e), one_mul] using hB

/-- The two actual reserves of the near-capacity proof cost O(N^(-1/12))
even after rounding the advertised sizes up to an integer. -/
theorem eventually_nearCapacity_reserve_cost :
    ∀ᶠ N : ℕ in atTop,
      692 * ((⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) / Real.sqrt N +
          2 * ((⌈8 * Real.log N * (N : ℝ) ^ (7 / 8 : ℝ)⌉₊ : ℕ) : ℝ) / N ≤
        1402 / (N : ℝ) ^ (1 / 12 : ℝ) := by
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hlog := Real.tendsto_log_atTop.comp hcast
  filter_upwards [hlog.eventually_ge_atTop 1, hcast.eventually (eventually_ge_atTop (1 : ℝ)),
    eventually_log_pow_le_rpow 12 (show 0 < (5 / 12 : ℝ) by norm_num),
    eventually_log_pow_le_rpow 1 (show 0 < (1 / 24 : ℝ) by norm_num)]
    with N hL hN hMedium hSmooth
  let x : ℝ := N
  have hx : 0 < x := zero_lt_one.trans_le hN
  change 1 ≤ Real.log x at hL
  have hL₀ : 0 ≤ Real.log x := zero_le_one.trans hL
  let Q := ⌈Real.log x ^ (12 : ℕ)⌉₊
  let w := ⌈8 * Real.log x * x ^ (7 / 8 : ℝ)⌉₊
  have hQ : (Q : ℝ) ≤ 2 * x ^ (5 / 12 : ℝ) := by
    have hCeil := (Nat.ceil_lt_add_one (pow_nonneg hL₀ 12)).le
    have hOne := (one_le_pow₀ hL : 1 ≤ Real.log x ^ (12 : ℕ))
    change Real.log x ^ (12 : ℕ) ≤ x ^ (5 / 12 : ℝ) at hMedium
    dsimp [Q]
    linarith only [hCeil, hOne, hMedium]
  have hQcost : 692 * (Q : ℝ) / Real.sqrt x ≤ 1384 / x ^ (1 / 12 : ℝ) := calc
    _ ≤ 1384 * x ^ (5 / 12 : ℝ) / Real.sqrt x :=
      div_le_div_of_nonneg_right (by linarith only [hQ]) (Real.sqrt_nonneg _)
    _ = _ := by
      rw [Real.sqrt_eq_rpow, mul_div_assoc, ← Real.rpow_sub hx,
        show (5 / 12 : ℝ) - 1 / 2 = -(1 / 12) by norm_num, Real.rpow_neg hx.le,
        div_eq_mul_inv]
      rfl
  have hWpre : 8 * Real.log x * x ^ (7 / 8 : ℝ) ≤ 8 * x ^ (11 / 12 : ℝ) := calc
    _ ≤ 8 * x ^ (1 / 24 : ℝ) * x ^ (7 / 8 : ℝ) := by
      exact mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left (by simpa only [pow_one] using hSmooth) (by norm_num))
        (Real.rpow_nonneg hx.le _)
    _ = _ := by rw [mul_assoc, ← Real.rpow_add hx]; congr 2; norm_num
  have hW : 2 * (w : ℝ) ≤ 18 * x ^ (11 / 12 : ℝ) := by
    have hCeil := (Nat.ceil_lt_add_one (show 0 ≤ 8 * Real.log x * x ^ (7 / 8 : ℝ) by positivity)).le
    have hOne := Real.one_le_rpow hN (show 0 ≤ (11 / 12 : ℝ) by norm_num)
    dsimp [w]
    linarith only [hCeil, hOne, hWpre]
  have hWcost : 2 * (w : ℝ) / x ≤ 18 / x ^ (1 / 12 : ℝ) := calc
    _ ≤ 18 * x ^ (11 / 12 : ℝ) / x := div_le_div_of_nonneg_right hW hx.le
    _ = 18 * (x ^ (11 / 12 : ℝ) / x ^ (1 : ℝ)) := by rw [Real.rpow_one, mul_div_assoc]
    _ = _ := by
      rw [← Real.rpow_sub hx, show (11 / 12 : ℝ) - 1 = -(1 / 12) by norm_num,
        Real.rpow_neg hx.le, div_eq_mul_inv]
      rfl
  change 692 * (Q : ℝ) / Real.sqrt x + 2 * (w : ℝ) / x ≤ 1402 / x ^ (1 / 12 : ℝ)
  exact (add_le_add hQcost hWcost).trans_eq (by ring)

/-- The four actual families taken out before the large-prime blocks are
formed. The set union automatically handles any overlaps. -/
noncomputable def repairExclusions (d N : ℕ) (z : ℝ) (M S R : Finset ℕ) : Finset ℕ :=
  ((highPrimePowers N z).biUnion fun q => primePart q (interval d N)) ∪
    (M.biUnion fun p => primePart p (interval d N)) ∪ S ∪ R

/-- The paper's O(N^(-1/12)) initial deletion budget for the near-capacity
construction, including both reserves and the two families of multiples. -/
theorem eventually_nearCapacity_repair_budget {D K : ℝ} (hD : 0 < D) (hK : 0 < K) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ (d : ℕ) (M S R : Finset ℕ),
      (M.card : ℝ) ≤ K * Real.log N →
      (∀ p ∈ M, (N : ℝ) ^ (1 / 6 : ℝ) ≤ (p : ℝ)) →
      (mass S : ℝ) ≤ 692 * ((⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) / Real.sqrt N →
      (mass R : ℝ) ≤ 2 * ((⌈8 * Real.log N * (N : ℝ) ^ (7 / 8 : ℝ)⌉₊ : ℕ) : ℝ) / N →
      (mass (repairExclusions d N ((D * (N : ℝ) ^ (1 / 12 : ℝ)) ^ 2) M S R) : ℝ) ≤
        C / (N : ℝ) ^ (1 / 12 : ℝ) := by
  obtain ⟨C, hC, hPow⟩ := eventually_mass_high_power_multiples
    (show 0 < (1 / 12 : ℝ) by norm_num) hD
  have hMarker := eventually_mass_marker_multiples
    (show 0 < (1 / 12 : ℝ) by norm_num) (show (1 / 12 : ℝ) < 1 / 6 by norm_num) hK
  refine ⟨C + 2 * K + 1402, by positivity, ?_⟩
  filter_upwards [hPow, hMarker, eventually_nearCapacity_reserve_cost]
    with N hPowN hMarkerN hCost d M S R hm hp hS hR
  let H := (highPrimePowers N ((D * (N : ℝ) ^ (1 / 12 : ℝ)) ^ 2)).biUnion
    fun q => primePart q (interval d N)
  let P := M.biUnion fun p => primePart p (interval d N)
  have hUnion : (mass (repairExclusions d N ((D * (N : ℝ) ^ (1 / 12 : ℝ)) ^ 2) M S R) : ℝ) ≤
      (mass H : ℝ) + (mass P : ℝ) + (mass S : ℝ) + (mass R : ℝ) := by
    unfold repairExclusions
    exact_mod_cast mass_repair_exclusions_le H P S R
  calc
    _ ≤ _ := hUnion
    _ = (mass H : ℝ) + (mass P : ℝ) + ((mass S : ℝ) + (mass R : ℝ)) := by ring
    _ ≤ C / (N : ℝ) ^ (1 / 12 : ℝ) + (2 * K) / (N : ℝ) ^ (1 / 12 : ℝ) +
            1402 / (N : ℝ) ^ (1 / 12 : ℝ) :=
      add_le_add (add_le_add (hPowN d) (hMarkerN d M hm hp)) ((add_le_add hS hR).trans hCost)
    _ = _ := by ring

/-- The paper's two baseline reserves together cost O((log N)^(-4)). -/
theorem eventually_baseline_reserve_cost :
    ∀ᶠ N : ℕ in atTop,
      692 * ((⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) / Real.sqrt N +
          2 * ((⌈(N : ℝ) / (Real.log N) ^ 4⌉₊ : ℕ) : ℝ) / N ≤
        1388 / (Real.log (N : ℝ)) ^ 4 := by
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hlog := Real.tendsto_log_atTop.comp hcast
  filter_upwards [hlog.eventually_ge_atTop 1, hcast.eventually (eventually_gt_atTop (1 : ℝ)),
    eventually_log_pow_le_rpow 16 (show 0 < (1 / 2 : ℝ) by norm_num),
    eventually_log_pow_le_rpow 4 (show 0 < (1 : ℝ) by norm_num)]
    with N hLog hNat hMedium hSmooth
  let L := Real.log (N : ℝ)
  have hL : 1 ≤ L := hLog
  have hL₀ : 0 < L := zero_lt_one.trans_le hL
  have hN : 0 < (N : ℝ) := zero_lt_one.trans hNat
  let Q := ⌈L ^ (12 : ℕ)⌉₊
  let w := ⌈(N : ℝ) / L ^ 4⌉₊
  have hQ : (Q : ℝ) ≤ 2 * L ^ 12 := by
    have hCeil := (Nat.ceil_lt_add_one (pow_nonneg hL₀.le 12)).le
    have hOne := (one_le_pow₀ hL : 1 ≤ L ^ (12 : ℕ))
    dsimp only [Q]
    linarith only [hCeil, hOne]
  have hQcost : 692 * (Q : ℝ) / Real.sqrt N ≤ 1384 / L ^ 4 := calc
    _ ≤ 1384 * L ^ 12 / Real.sqrt N :=
      div_le_div_of_nonneg_right (by linarith only [hQ]) (Real.sqrt_nonneg _)
    _ ≤ _ := by
      apply (div_le_div_iff₀ (Real.sqrt_pos.2 hN) (pow_pos hL₀ _)).mpr
      have hS : L ^ (16 : ℕ) ≤ Real.sqrt N := by simpa only [Real.sqrt_eq_rpow] using hMedium
      rw [mul_assoc, ← pow_add]
      norm_num
      exact hS
  have hW : (w : ℝ) ≤ 2 * ((N : ℝ) / L ^ 4) := by
    have hCeil := (Nat.ceil_lt_add_one (div_nonneg hN.le (pow_nonneg hL₀.le 4))).le
    have hOne : 1 ≤ (N : ℝ) / L ^ 4 := (le_div_iff₀ (pow_pos hL₀ _)).mpr (by
      simpa only [Real.rpow_one, one_mul] using hSmooth)
    dsimp only [w]
    linarith only [hCeil, hOne]
  have hWcost : 2 * (w : ℝ) / N ≤ 4 / L ^ 4 := calc
    _ ≤ 4 * ((N : ℝ) / L ^ 4) / N :=
      div_le_div_of_nonneg_right (by linarith only [hW]) hN.le
    _ = _ := by field_simp
  change 692 * (Q : ℝ) / Real.sqrt N + 2 * (w : ℝ) / N ≤ 1388 / L ^ 4
  exact (add_le_add hQcost hWcost).trans_eq (by ring)

/-- The initial repair reservations and excluded multiples in the baseline
cost O((log N)^(-4)), apart from the later large-prime cutoff and block repairs. -/
theorem eventually_baseline_repair_budget (K : ℝ) (hK : 0 < K) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ (d : ℕ) (M S R : Finset ℕ),
      (M.card : ℝ) ≤ K * Real.log N →
      (∀ p ∈ M, (N : ℝ) ^ (1 / 2 : ℝ) ≤ (p : ℝ)) →
      (mass S : ℝ) ≤ 692 * ((⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) / Real.sqrt N →
      (mass R : ℝ) ≤ 2 * ((⌈(N : ℝ) / (Real.log N) ^ 4⌉₊ : ℕ) : ℝ) / N →
      (mass (repairExclusions d N ((N : ℝ) ^ (1 / 20 : ℝ)) M S R) : ℝ) ≤
        C / (Real.log (N : ℝ)) ^ 4 := by
  obtain ⟨C, hC, hPow⟩ := eventually_mass_high_power_multiples (D := 1)
    (show 0 < (1 / 40 : ℝ) by norm_num) (by norm_num)
  have hMarker := eventually_mass_marker_multiples
    (show 0 < (1 / 40 : ℝ) by norm_num) (show (1 / 40 : ℝ) < 1 / 2 by norm_num) hK
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hlog := Real.tendsto_log_atTop.comp hcast
  refine ⟨C + 2 * K + 1388, by positivity, ?_⟩
  filter_upwards [hPow, hMarker, eventually_baseline_reserve_cost,
    hlog.eventually_ge_atTop 1,
    eventually_log_pow_le_rpow 4 (show 0 < (1 / 40 : ℝ) by norm_num)]
    with N hPowN hMarkerN hCost hLog hCompared d M S R hm hp hS hR
  have hL : 0 < Real.log (N : ℝ) := zero_lt_one.trans_le hLog
  have hN₀ : 0 ≤ (N : ℝ) := Nat.cast_nonneg N
  have hz : (1 * (N : ℝ) ^ (1 / 40 : ℝ)) ^ (2 : ℕ) = (N : ℝ) ^ (1 / 20 : ℝ) := by
    rw [one_mul, ← Real.rpow_natCast, ← Real.rpow_mul hN₀]
    congr 1
    norm_num
  let H := (highPrimePowers N ((N : ℝ) ^ (1 / 20 : ℝ))).biUnion
    fun q => primePart q (interval d N)
  let P := M.biUnion fun p => primePart p (interval d N)
  have hUnion : (mass (repairExclusions d N ((N : ℝ) ^ (1 / 20 : ℝ)) M S R) : ℝ) ≤
      (mass H : ℝ) + (mass P : ℝ) + (mass S : ℝ) + (mass R : ℝ) := by
    unfold repairExclusions
    exact_mod_cast mass_repair_exclusions_le H P S R
  have hH : (mass H : ℝ) ≤ C / (Real.log (N : ℝ)) ^ 4 := by
    have h := hPowN d
    rw [hz] at h
    exact h.trans (div_le_div_of_nonneg_left hC.le (pow_pos hL _) hCompared)
  have hP : (mass P : ℝ) ≤ 2 * K / (Real.log (N : ℝ)) ^ 4 :=
    (hMarkerN d M hm hp).trans (div_le_div_of_nonneg_left (by positivity) (pow_pos hL _) hCompared)
  calc
    _ ≤ _ := hUnion
    _ = (mass H : ℝ) + (mass P : ℝ) + ((mass S : ℝ) + (mass R : ℝ)) := by ring
    _ ≤ C / (Real.log (N : ℝ)) ^ 4 + (2 * K) / (Real.log (N : ℝ)) ^ 4 +
            1388 / (Real.log (N : ℝ)) ^ 4 :=
      add_le_add (add_le_add hH hP) ((add_le_add hS hR).trans hCost)
    _ = _ := by ring

theorem nthRoot_eq_floor_rpow (u X : ℕ) (hu : 0 < u) :
    Nat.nthRoot u X = ⌊(X : ℝ) ^ (1 / (u : ℝ))⌋₊ := by
  have hx : 0 ≤ (X : ℝ) := Nat.cast_nonneg X
  have hu₀ : (u : ℝ) ≠ 0 := by exact_mod_cast hu.ne'
  have hpow : ((X : ℝ) ^ (1 / (u : ℝ))) ^ u = X := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul hx, div_mul_cancel₀ _ hu₀, Real.rpow_one]
  refine eq_of_forall_le_iff fun m => ?_
  rw [Nat.le_nthRoot_iff hu.ne', Nat.le_floor_iff (Real.rpow_nonneg hx _),
    ← pow_le_pow_iff_left₀ (Nat.cast_nonneg m) (Real.rpow_nonneg hx _) hu.ne', hpow]
  exact_mod_cast (show m ^ u ≤ X ↔ m ^ u ≤ X from Iff.rfl)

/-- Choose actual near-capacity repair reserves. This retains every cofactor
set, marker and denominator for the rest of the construction. -/
theorem eventually_nearCapacity_repair_reserves {D K : ℝ} (hD : 0 < D) (hK : 0 < K) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ m : ℕ, (m : ℝ) ≤ K * Real.log N →
      ∃ P : Fin m → ℕ, Function.Injective P ∧
        (∀ i, (P i).Prime ∧ (N : ℝ) ^ (1 / 6 : ℝ) < (P i : ℝ) ∧
          (P i : ℝ) ≤ 2 * (N : ℝ) ^ (1 / 6 : ℝ)) ∧
        ∀ Q : Finset ℕ, (∀ p ∈ Q, p.Prime ∧ ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ < p ∧ p ≤ Nat.sqrt N) →
          (∀ p ∈ Q, ∀ i, p ≠ P i) →
          ∃ Cof : Fin m → ℕ → Finset ℕ, ∃ S R : Finset ℕ,
            (∀ i p, p ∈ Q → (Cof i p).card = ⌊Real.log (N : ℝ) ^ (10 : ℕ)⌋₊ ∧
              (∀ b ∈ Cof i p, b ∣ Nat.lcmUpto ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊) ∧
              CoversResidues p (Cof i p)) ∧
            (∀ p ∈ Q, Pairwise (fun i j => Disjoint (Cof i p) (Cof j p))) ∧
            (∀ i, mediumPool Q (Cof i) ⊆ S) ∧ S ⊆ interval 2 N ∧
            R ⊆ interval 2 N ∧ R.card = ⌈8 * Real.log N * (N : ℝ) ^ (7 / 8 : ℝ)⌉₊ ∧
            (∀ a ∈ R, N ≤ 2 * a ∧ a ∣ Nat.lcmUpto ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊) ∧
            Disjoint S R ∧
            ((R.card : ℚ) / N ≤ mass R) ∧
            (∀ a ∈ S, ∀ i, ¬ P i ∣ a) ∧
            (∀ a ∈ S, ∃ p ∈ Q, ∃ b, b ∣ Nat.lcmUpto ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ ∧ a = p * b) ∧
            (mass S : ℝ) ≤ 692 * ((⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) / Real.sqrt N ∧
            (mass (repairExclusions 2 N ((D * (N : ℝ) ^ (1 / 12 : ℝ)) ^ 2)
              (univ.image P) S R) : ℝ) ≤ C / (N : ℝ) ^ (1 / 12 : ℝ) := by
  obtain ⟨C, hC, hBudget⟩ := eventually_nearCapacity_repair_budget hD hK
  refine ⟨C, hC, ?_⟩
  have hMarkers := eventually_marker_primes (show 0 < (1 / 6 : ℝ) by norm_num)
    (show (1 / 6 : ℝ) ≤ 1 by norm_num) hK
  filter_upwards [hMarkers, eventually_medium_repair_pools 2 K hK, eventually_nearCapacitySmoothReserve,
    hBudget, eventually_ge_atTop (1 : ℕ)] with N hMark hMed hReserve hCost hN m hm
  obtain ⟨P, hInj, hP⟩ := hMark m hm
  refine ⟨P, hInj, hP, ?_⟩
  intro Q hQ hNoMarker
  let M := (univ : Finset (Fin m)).image P
  have hx : 1 ≤ (N : ℝ) := by exact_mod_cast hN
  have hy : (N : ℝ) ^ (1 / 20 : ℝ) ≤ (N : ℝ) ^ (1 / 6 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hx (by norm_num)
  have hM (p : ℕ) (hp : p ∈ M) : p.Prime ∧ ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ < p := by
    obtain ⟨i, _, rfl⟩ := mem_image.mp hp
    exact ⟨(hP i).1, (Nat.floor_lt (by positivity)).mpr (hy.trans_lt (hP i).2.1)⟩
  have hDis : Disjoint M Q := by
    refine disjoint_left.mpr fun p hp hpQ => ?_
    obtain ⟨i, _, rfl⟩ := mem_image.mp hp
    exact hNoMarker _ hpQ i rfl
  obtain ⟨Cof, S, hCof, hCPair, _, hSContains, hS, hSAvoid, hSFactor, _, hSCost⟩ :=
    hMed m hm Q M hQ hM hDis
  obtain ⟨R, hR, hRSize, hRPower, hRLower, hRUpper⟩ := hReserve
  have hMC : (M.card : ℝ) ≤ K * Real.log N := by
    simpa only [M, card_image_of_injective _ hInj, card_fin] using hm
  have hMP (p : ℕ) (hp : p ∈ M) : (N : ℝ) ^ (1 / 6 : ℝ) ≤ (p : ℝ) := by
    obtain ⟨i, _, rfl⟩ := mem_image.mp hp
    exact (hP i).2.1.le
  have hRPower' (a : ℕ) (ha : a ∈ R) :
      N ≤ 2 * a ∧ a ∣ Nat.lcmUpto ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ := by
    simpa only [nthRoot_eq_floor_rpow 20 N (by decide), Nat.cast_ofNat] using hRPower a ha
  refine ⟨Cof, S, R, hCof, hCPair, hSContains, hS, hR, hRSize, hRPower', ?_, ?_, ?_, hSFactor, hSCost, ?_⟩
  · exact disjoint_left.mpr fun a ha hb => (hSAvoid a ha).2 (hRPower' a hb).2
  · rw [hRSize]
    exact hRLower
  · exact fun a ha i => (hSAvoid a ha).1 (P i) (mem_image.mpr ⟨i, mem_univ i, rfl⟩)
  · apply hCost 2 M S R hMC hMP hSCost
    calc
      _ ≤ ((2 * (⌈8 * Real.log N * (N : ℝ) ^ (7 / 8 : ℝ)⌉₊ : ℚ) / N : ℚ) : ℝ) :=
        Rat.cast_le.mpr hRUpper
      _ = _ := by push_cast; rfl

end LeanAB.PaperB.Closure
