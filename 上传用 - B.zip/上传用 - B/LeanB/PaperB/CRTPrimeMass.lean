module

public import PaperB.PrimeWindows
meta import Mathlib.Tactic

/-! The product of retained primes in each of the two F2 lifting windows. -/

public section

namespace LeanAB.PaperB

open Filter Finset Asymptotics
open scoped Interval Topology

/-- The full Chebyshev log mass of a fixed-shape window, with uniform relative error. -/
theorem eventually_prime_window_log_mass {a b ε : ℝ} (ha : 0 < a) (hab : a < b) (hε : 0 < ε) :
    ∀ᶠ x : ℝ in atTop,
      |(∑ p ∈ primesBetween (a * x) (b * x), Real.log (p : ℝ)) - (b - a) * x| ≤ ε * x := by
  obtain ⟨C,hC,hTheta⟩ := thetaLogSquaredError_pntPlus
  have hb := ha.trans hab
  let δ := ε / (b + a)
  have hδ : 0 < δ := div_pos hε (add_pos hb ha)
  have hax : Tendsto (fun x : ℝ => a * x) atTop atTop := tendsto_id.const_mul_atTop ha
  obtain ⟨T,hT⟩ := eventually_atTop.mp hTheta
  filter_upwards [eventually_gt_atTop (1 : ℝ), hax.eventually_ge_atTop T,
    (Real.tendsto_log_atTop.comp hax).eventually_ge_atTop (C / δ + 1)] with x hx hxT hLog
  have hx₀ := zero_lt_one.trans hx
  have ha₀ := mul_pos ha hx₀
  have habx := mul_le_mul_of_nonneg_right hab.le hx₀.le
  have hErr (t : ℝ) (ht : t ∈ Set.Icc (a * x) (b * x)) :
      |Chebyshev.theta t - t| ≤ δ * t := by
    have hLogt : C / δ + 1 ≤ Real.log t := hLog.trans (Real.log_le_log ha₀ ht.1)
    have hDiv₀ : 0 ≤ C / δ := div_nonneg hC hδ.le
    have ht1 : 1 ≤ Real.log t := by linarith only [hLogt,hDiv₀]
    have htSq : Real.log t ≤ Real.log t ^ 2 := by
      have hprod := mul_nonneg (sub_nonneg.mpr ht1) (zero_le_one.trans ht1)
      nlinarith only [hprod]
    have hSmall : C / Real.log t ^ 2 ≤ δ := by
      apply (div_le_iff₀ (sq_pos_of_pos (zero_lt_one.trans_le ht1))).mpr
      have hC' : C / δ ≤ Real.log t ^ 2 :=
        (by linarith only [hLogt] : C / δ ≤ Real.log t).trans htSq
      simpa only [mul_comm] using (div_le_iff₀ hδ).mp hC'
    calc
      _ ≤ C * t / Real.log t ^ 2 := hT t (hxT.trans ht.1)
      _ = (C / Real.log t ^ 2) * t := by ring
      _ ≤ δ * t := mul_le_mul_of_nonneg_right hSmall (ha₀.le.trans ht.1)
  have h := abs_weighted_prime_sum_sub_integral_le (f := fun _ => 1) (f' := fun _ => 0)
    ha₀.le habx (fun t _ => hasDerivAt_const t 1) continuousOn_const
    (fun _ _ => zero_le_one) (fun _ _ => le_rfl) hErr
  simp only [one_mul, mul_one, intervalIntegral.integral_const, smul_eq_mul] at h
  rw [show b * x - a * x = (b - a) * x by ring] at h
  convert h using 1
  dsimp only [δ]
  field_simp [(add_pos hb ha).ne']
  ring

/-- Dropping at most x^(3/4) primes does not change the leading log product. -/
theorem eventually_retained_prime_window_log_product {a b ε : ℝ}
    (ha : 0 < a) (hab : a < b) (hε : 0 < ε) :
    ∀ᶠ x : ℝ in atTop, ∀ S : Finset ℕ, S ⊆ primesBetween (a * x) (b * x) →
      (((primesBetween (a * x) (b * x) \ S).card : ℝ) ≤ x ^ (3 / 4 : ℝ)) →
      |Real.log ((∏ p ∈ S, p : ℕ) : ℝ) - (b - a) * x| ≤ ε * x := by
  have hb := ha.trans hab
  let k := ε / (2 * b ^ (1 / 4 : ℝ))
  have hk : 0 < k := div_pos hε (mul_pos (by norm_num) (Real.rpow_pos_of_pos hb _))
  have hbx : Tendsto (fun x : ℝ => b * x) atTop atTop := tendsto_id.const_mul_atTop hb
  have hSlow := (isLittleO_log_rpow_atTop (show (0 : ℝ) < 1 / 4 by norm_num)).bound hk
  filter_upwards [eventually_prime_window_log_mass ha hab (half_pos hε), eventually_gt_atTop (1 : ℝ),
    hbx.eventually (eventually_ge_atTop 1), hbx.eventually hSlow] with x hFull hx hb1 hSlowX
  intro S hS hCard
  let P := primesBetween (a * x) (b * x)
  have hx₀ := zero_lt_one.trans hx
  have ha₀ := mul_nonneg ha.le hx₀.le
  have hb₀ := mul_pos hb hx₀
  have hLog : Real.log (b * x) ≤ k * (b * x) ^ (1 / 4 : ℝ) := by
    change ‖Real.log (b * x)‖ ≤ k * ‖(b * x) ^ (1 / 4 : ℝ)‖ at hSlowX
    simpa only [Real.norm_eq_abs, abs_of_nonneg (Real.log_nonneg hb1),
      abs_of_nonneg (Real.rpow_nonneg hb₀.le _)] using hSlowX
  have hTerm (p : ℕ) (hp : p ∈ P) : 0 ≤ Real.log (p : ℝ) ∧ Real.log (p : ℝ) ≤ Real.log (b * x) := by
    obtain ⟨_,hUpper,hPrime⟩ := (mem_primesBetween ha₀ hb₀.le).mp hp
    exact ⟨Real.log_nonneg (by exact_mod_cast hPrime.one_lt.le),
      Real.log_le_log (by exact_mod_cast hPrime.pos) hUpper⟩
  have hDropped : (∑ p ∈ P \ S, Real.log (p : ℝ)) ≤ (ε / 2) * x := calc
    _ ≤ ∑ _p ∈ P \ S, Real.log (b * x) := sum_le_sum fun p hp => (hTerm p (mem_sdiff.mp hp).1).2
    _ = ((P \ S).card : ℝ) * Real.log (b * x) := by rw [sum_const,nsmul_eq_mul]
    _ ≤ x ^ (3 / 4 : ℝ) * (k * (b * x) ^ (1 / 4 : ℝ)) :=
      mul_le_mul hCard hLog (Real.log_nonneg hb1) (Real.rpow_nonneg hx₀.le _)
    _ = _ := by
      rw [Real.mul_rpow hb.le hx₀.le]
      calc
        _ = (k * b ^ (1 / 4 : ℝ)) * (x ^ (3 / 4 : ℝ) * x ^ (1 / 4 : ℝ)) := by ring
        _ = _ := by
          rw [← Real.rpow_add hx₀]
          norm_num
          dsimp only [k]
          field_simp [(Real.rpow_pos_of_pos hb (1 / 4 : ℝ)).ne']
          exact Or.inl True.intro
  have hDropped₀ : 0 ≤ ∑ p ∈ P \ S, Real.log (p : ℝ) :=
    sum_nonneg fun p hp => (hTerm p (mem_sdiff.mp hp).1).1
  have hSplit : (∑ p ∈ P \ S, Real.log (p : ℝ)) + ∑ p ∈ S, Real.log (p : ℝ) =
      ∑ p ∈ P, Real.log (p : ℝ) := sum_sdiff hS
  rw [Nat.cast_prod, Real.log_prod]
  · change |(∑ p ∈ P, Real.log (p : ℝ)) - (b - a) * x| ≤ ε / 2 * x at hFull
    obtain ⟨hLow,hHigh⟩ := abs_le.mp hFull
    exact abs_le.mpr ⟨by linarith only [hLow,hSplit,hDropped],
      by linarith only [hHigh,hSplit,hDropped₀,mul_nonneg hε.le hx₀.le]⟩
  · intro p hp
    exact_mod_cast ((mem_primesBetween ha₀ hb₀.le).mp (hS hp)).2.2.ne_zero

/-- The two disjoint lifting windows both have retained log product (3/2 + o(1)) x. -/
theorem eventually_crt_retained_window_log_products {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ x : ℝ in atTop, ∀ S₁ S₂ : Finset ℕ,
      S₁ ⊆ primesBetween x ((5 / 2 : ℝ) * x) →
      S₂ ⊆ primesBetween (3 * x) ((9 / 2 : ℝ) * x) →
      (((primesBetween x ((5 / 2 : ℝ) * x) \ S₁).card : ℝ) ≤ x ^ (3 / 4 : ℝ)) →
      (((primesBetween (3 * x) ((9 / 2 : ℝ) * x) \ S₂).card : ℝ) ≤ x ^ (3 / 4 : ℝ)) →
      |Real.log ((∏ p ∈ S₁, p : ℕ) : ℝ) - (3 / 2 : ℝ) * x| ≤ ε * x ∧
      |Real.log ((∏ p ∈ S₂, p : ℕ) : ℝ) - (3 / 2 : ℝ) * x| ≤ ε * x := by
  filter_upwards [eventually_retained_prime_window_log_product (a := 1) (b := 5 / 2)
    (by norm_num) (by norm_num) hε,
    eventually_retained_prime_window_log_product (a := 3) (b := 9 / 2)
      (by norm_num) (by norm_num) hε] with x hOne hTwo
  intro S₁ S₂ hSub₁ hSub₂ hCard₁ hCard₂
  exact ⟨by simpa only [one_mul, show (5 / 2 : ℝ) - 1 = 3 / 2 by norm_num]
    using hOne S₁ (by simpa only [one_mul] using hSub₁) (by simpa only [one_mul] using hCard₁),
    by simpa only [show (9 / 2 : ℝ) - 3 = 3 / 2 by norm_num] using hTwo S₂ hSub₂ hCard₂⟩

end LeanAB.PaperB
