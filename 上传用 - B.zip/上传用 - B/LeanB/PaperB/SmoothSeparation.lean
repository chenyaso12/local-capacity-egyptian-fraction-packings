module

public import Common
public import PaperB.PrimeWindows
public import PaperB.PowersmoothDensity
public import Mathlib.Algebra.GCDMonoid.FinsetLemmas
public import Mathlib.Data.Nat.Factorization.Divisors
public import Mathlib.Analysis.SpecialFunctions.Log.Basic
public import Mathlib.NumberTheory.ArithmeticFunction.Misc
public import Mathlib.NumberTheory.Chebyshev
public import Mathlib.Analysis.Real.Sqrt
public import Mathlib.Analysis.SpecialFunctions.Pow.NthRootLemmas
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
meta import Mathlib.Tactic

/-! The separation of frequencies by powersmooth denominators in the smooth closure argument. -/

@[expose] public section

namespace LeanAB.PaperB.SmoothSeparation

open Finset Filter
open scoped Topology

private theorem le_abs_of_natCast_dvd {v : ℕ} {a : ℤ} (hdiv : (v : ℤ) ∣ a)
    (ha : a ≠ 0) : (v : ℝ) ≤ |(a : ℝ)| := by
  obtain ⟨k, rfl⟩ := hdiv
  have hk : k ≠ 0 := by
    intro h
    exact ha (by simp [h])
  have hk' : (1 : ℝ) ≤ |(k : ℝ)| := by exact_mod_cast Int.one_le_abs hk
  push_cast
  rw [abs_mul, abs_of_nonneg (Nat.cast_nonneg v)]
  exact le_mul_of_one_le_right (Nat.cast_nonneg v) hk'

/-- The interval with center `h` and radius `R` excludes every multiple of `P`. -/
theorem multiple_outside_interval {P : ℕ} {h R : ℝ} (hR : R ≤ |h|)
    (hHalf : 2 * |h| ≤ P) :
    ∀ a : ℤ, (P : ℤ) ∣ a → R ≤ |(a : ℝ) - h| := by
  intro a ha
  by_cases h0 : a = 0
  · simpa [h0] using hR
  have hb := le_abs_of_natCast_dvd ha h0
  have ht := abs_sub_le (a : ℝ) h 0
  rw [sub_zero, sub_zero] at ht
  linarith

private theorem eq_of_close_multiples {v : ℕ} {a b : ℤ} {h R : ℝ}
    (hv : 2 * R < (v : ℝ)) (ha : (v : ℤ) ∣ a) (hb : (v : ℤ) ∣ b)
    (haDist : |(a : ℝ) - h| < R) (hbDist : |(b : ℝ) - h| < R) : a = b := by
  by_contra hne
  have hsep := le_abs_of_natCast_dvd (dvd_sub ha hb) (sub_ne_zero.mpr hne)
  push_cast at hsep
  have ht := abs_sub_le (a : ℝ) h b
  rw [abs_sub_comm h (b : ℝ)] at ht
  linarith

/-- If the trusted multiples of one carrier have least common multiple `P`,
at least one of them witnesses separation of any frequency in the stated range. -/
theorem exists_witness_of_lcm {T : Finset ℕ} {P v : ℕ} {h R : ℝ}
    (hP : 1 < P) (hLcm : T.lcm id = P) (hDiv : ∀ n ∈ T, v ∣ n)
    (hv : 2 * R < (v : ℝ)) (hR : R ≤ |h|) (hHalf : 2 * |h| ≤ P) :
    ∃ n ∈ T, ∀ a : ℤ, (n : ℤ) ∣ a → R ≤ |(a : ℝ) - h| := by
  classical
  have hT : T.Nonempty := by
    by_contra hn
    rw [Finset.not_nonempty_iff_eq_empty.mp hn] at hLcm
    simp at hLcm
    omega
  by_contra! hNo
  obtain ⟨n₀, hn₀⟩ := hT
  obtain ⟨a₀, ha₀, ha₀Dist⟩ := hNo n₀ hn₀
  have hAll : ∀ n ∈ T, n ∣ a₀.natAbs := by
    intro n hn
    obtain ⟨a, ha, haDist⟩ := hNo n hn
    have ha' : a = a₀ := eq_of_close_multiples hv
      ((Int.natCast_dvd_natCast.mpr (hDiv n hn)).trans ha)
      ((Int.natCast_dvd_natCast.mpr (hDiv n₀ hn₀)).trans ha₀)
      haDist ha₀Dist
    exact Int.natCast_dvd.mp (ha' ▸ ha)
  have hPDvd : (P : ℤ) ∣ a₀ :=
    Int.natCast_dvd.mpr (hLcm ▸ Finset.lcm_dvd_iff.mpr hAll)
  exact (not_lt_of_ge (multiple_outside_interval hR hHalf a₀ hPDvd)) ha₀Dist

/-- Convert separation of multiples into separation of the normalized phase. -/
theorem normalized_separation {n : ℕ} {h R Y : ℝ} (hn : 0 < n)
    (hnY : (n : ℝ) ≤ Y) (hR : 0 ≤ R)
    (hSep : ∀ a : ℤ, (n : ℤ) ∣ a → R ≤ |(a : ℝ) - h|) (j : ℤ) :
    R / Y ≤ |h / n - j| := by
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  have hY : 0 < Y := hn'.trans_le hnY
  have hNear := hSep ((n : ℤ) * j) (dvd_mul_right _ _)
  push_cast at hNear
  have hprod : h / n - (j : ℝ) = (h - (n : ℝ) * j) / n := by
    rw [sub_div, mul_comm (n : ℝ) (j : ℝ), mul_div_cancel_right₀ _ hn'.ne']
  rw [hprod, abs_div, abs_of_pos hn', abs_sub_comm]
  exact (div_le_div_of_nonneg_left hR hn' hnY).trans
    (div_le_div_of_nonneg_right hNear hn'.le)

/-- Count distinct witnesses using a uniform bound for the number of carriers
that can be associated with any one denominator. -/
theorem exists_separated_denominators (V Y₀ : Finset ℕ) (T : ℕ → Finset ℕ)
    {P K : ℕ} {h R Y : ℝ} (hP : 1 < P) (hR₀ : 0 ≤ R)
    (hR : R ≤ |h|) (hHalf : 2 * |h| ≤ P)
    (hY₀ : ∀ n ∈ Y₀, 0 < n ∧ (n : ℝ) ≤ Y)
    (hT : ∀ v ∈ V, T v ⊆ Y₀ ∧ (T v).lcm id = P ∧ 2 * R < (v : ℝ) ∧
      ∀ n ∈ T v, v ∣ n)
    (hMult : ∀ n ∈ Y₀, (V.filter fun v => n ∈ T v).card ≤ K) :
    ∃ W ⊆ Y₀, V.card ≤ K * W.card ∧
      ∀ n ∈ W, ∀ j : ℤ, R / Y ≤ |h / n - j| := by
  classical
  let w (v : V) : ℕ := (exists_witness_of_lcm hP (hT v v.property).2.1
    (hT v v.property).2.2.2 (hT v v.property).2.2.1 hR hHalf).choose
  have hw (v : V) : w v ∈ T v ∧
      ∀ a : ℤ, ((w v : ℕ) : ℤ) ∣ a → R ≤ |(a : ℝ) - h| :=
    (exists_witness_of_lcm hP (hT v v.property).2.1
      (hT v v.property).2.2.2 (hT v v.property).2.2.1 hR hHalf).choose_spec
  let W := V.attach.image w
  have hWY : W ⊆ Y₀ := by
    intro n hn
    obtain ⟨v, _, rfl⟩ := Finset.mem_image.mp hn
    exact (hT v v.property).1 (hw v).1
  refine ⟨W, hWY, ?_, ?_⟩
  · rw [← Finset.card_attach (s := V), Finset.card_eq_sum_card_image w]
    calc
      _ ≤ ∑ _n ∈ W, K := by
        apply Finset.sum_le_sum
        intro n hn
        have hBound := hMult n (hWY hn)
        refine le_trans ?_ hBound
        apply Finset.card_le_card_of_injOn Subtype.val
        · intro v hv
          have he := (Finset.mem_filter.mp hv).2
          exact Finset.mem_filter.mpr ⟨v.property, he ▸ (hw v).1⟩
        · exact Subtype.val_injective.injOn
      _ = K * W.card := by rw [Finset.sum_const, smul_eq_mul, Nat.mul_comm]
  · intro n hn j
    have ⟨ hn₀, hnY ⟩ := hY₀ n (hWY hn)
    obtain ⟨v, _, rfl⟩ := Finset.mem_image.mp hn
    exact normalized_separation hn₀ hnY hR₀ (hw v).2 j

private theorem exists_product_with_padding {α : Type*} (S : Finset ℕ)
    (hOne : 1 ∈ S) (f : α → ℕ) (k : ℕ) (T : Finset α)
    (hT : T.card ≤ k) (hf : ∀ x ∈ T, f x ∈ S) :
    ∃ u : Fin k → S, (∏ i, (u i : ℕ)) = ∏ x ∈ T, f x := by
  classical
  induction k generalizing T with
  | zero =>
    have hEmpty : T = ∅ := Finset.card_eq_zero.mp (Nat.eq_zero_of_le_zero hT)
    subst T
    exact ⟨Fin.elim0, by simp⟩
  | succ k ih =>
    by_cases he : T = ∅
    · subst T
      exact ⟨fun _ => ⟨1,hOne⟩, by simp⟩
    obtain ⟨x, hx⟩ := Finset.nonempty_iff_ne_empty.mpr he
    have hSize : (T.erase x).card ≤ k := by
      rw [Finset.card_erase_of_mem hx]
      omega
    obtain ⟨u, hu⟩ := ih (T.erase x) hSize fun y hy => hf y (Finset.mem_of_mem_erase hy)
    refine ⟨Fin.cons ⟨f x,hf x hx⟩ u, ?_⟩
    rw [Fin.prod_univ_succ]
    simp only [Fin.cons_zero, Fin.cons_succ]
    rw [hu, Finset.mul_prod_erase _ _ hx]

/-- A positive integer has at most this many positive divisors with at most
three distinct prime factors. Exponents may vary freely. -/
theorem card_divisors_at_most_three (n : ℕ) (hn : n ≠ 0) :
    (n.divisors.filter fun q => q.primeFactors.card ≤ 3).card ≤ (1 + Nat.log 2 n) ^ 3 := by
  classical
  let S := insert 1 (n.primeFactors.biUnion fun p =>
    (Finset.Icc 1 (n.factorization p)).image (p ^ ·))
  have hOne : 1 ∈ S := Finset.mem_insert_self _ _
  have hS : S.card ≤ 1 + Nat.log 2 n := by
    have hCount : (n.primeFactors.biUnion fun p =>
        (Finset.Icc 1 (n.factorization p)).image (p ^ ·)).card ≤
        n.primeFactorsList.length := by
      calc
        _ ≤ ∑ p ∈ n.primeFactors, ((Finset.Icc 1 (n.factorization p)).image (p ^ ·)).card :=
          Finset.card_biUnion_le
        _ ≤ ∑ p ∈ n.primeFactors, n.factorization p := by
          apply Finset.sum_le_sum
          intro p hp
          exact Finset.card_image_le.trans (by simp)
        _ = _ := by
          simpa only [Finsupp.sum, Nat.support_factorization, ArithmeticFunction.cardFactors_apply] using
            (ArithmeticFunction.cardFactors_eq_sum_factorization (n := n)).symm
    have hLog : n.primeFactorsList.length ≤ Nat.log 2 n := by
      apply Nat.le_log_of_pow_le (by decide)
      exact (List.pow_length_le_prod n.primeFactorsList 2
        (fun p hp => (Nat.prime_of_mem_primeFactorsList hp).two_le)).trans_eq (Nat.prod_primeFactorsList hn)
    have hc := Finset.card_insert_le (a := 1) (s := n.primeFactors.biUnion fun p =>
      (Finset.Icc 1 (n.factorization p)).image (p ^ ·))
    dsimp only [S]
    omega
  let All := (Finset.univ : Finset (Fin 3 → S)).image fun u => ∏ i, (u i : ℕ)
  calc
    _ ≤ All.card := by
      apply Finset.card_le_card
      intro q hq
      obtain ⟨hd, hqSize⟩ := Finset.mem_filter.mp hq
      have hqd := (Nat.mem_divisors.mp hd).1
      have hq₀ : q ≠ 0 := by
        intro h
        simp [h, hn] at hqd
      have hf (p : ℕ) (hp : p ∈ q.primeFactors) :
          p ^ q.factorization p ∈ S := by
        have hP := Nat.prime_of_mem_primeFactors hp
        have hp1 : 1 ≤ q.factorization p := by
          have hPos : q.factorization p ≠ 0 := Finsupp.mem_support_iff.mp (by simpa using hp)
          omega
        have hp2 := (Nat.factorization_le_iff_dvd hq₀ hn).mpr hqd p
        refine Finset.mem_insert_of_mem ?_
        apply Finset.mem_biUnion.mpr
        refine ⟨p, Nat.mem_primeFactors.mpr ⟨hP, (Nat.dvd_of_mem_primeFactors hp).trans hqd, hn⟩, ?_⟩
        exact Finset.mem_image.mpr ⟨q.factorization p, Finset.mem_Icc.mpr ⟨hp1,hp2⟩, rfl⟩
      obtain ⟨u, hu⟩ := exists_product_with_padding S hOne _ 3 q.primeFactors hqSize hf
      refine Finset.mem_image.mpr ⟨u, Finset.mem_univ _, ?_⟩
      rw [hu, ← Nat.prod_factorization_eq_prod_primeFactors, Nat.prod_factorization_pow_eq_self hq₀]
    _ ≤ (Finset.univ : Finset (Fin 3 → S)).card := Finset.card_image_le
    _ = S.card ^ 3 := by simp
    _ ≤ _ := Nat.pow_le_pow_left hS 3

/-- The carrier multiplicity in F2 follows from the bound for small-prime-support
divisors, since the cofactor uniquely determines any positive divisor carrier. -/
theorem carrier_multiplicity (V : Finset ℕ) {n B : ℕ} (hn : n ≠ 0) (hnB : n ≤ B) :
    (V.filter fun v => v ∣ n ∧ (n / v).primeFactors.card ≤ 3).card ≤
      (1 + Nat.log 2 B) ^ 3 := by
  calc
    _ ≤ (n.divisors.filter fun q => q.primeFactors.card ≤ 3).card := by
      apply Finset.card_le_card_of_injOn (fun v => n / v)
      · intro v hv
        have h := (Finset.mem_filter.mp hv).2
        exact Finset.mem_filter.mpr ⟨Nat.mem_divisors.mpr ⟨Nat.div_dvd_of_dvd h.1, hn⟩, h.2⟩
      · intro v hv w hw he
        have hvd := (Finset.mem_filter.mp hv).2.1
        have hwd := (Finset.mem_filter.mp hw).2.1
        have hc : n / v ≠ 0 := by
          intro h
          have := Nat.div_mul_cancel hvd
          exact hn (by simpa [h] using this.symm)
        apply Nat.eq_of_mul_eq_mul_left (Nat.pos_of_ne_zero hc)
        calc
          n / v * v = n := Nat.div_mul_cancel hvd
          _ = n / w * w := (Nat.div_mul_cancel hwd).symm
          _ = n / v * w := congrArg (· * w) he.symm
    _ ≤ (1 + Nat.log 2 n) ^ 3 := card_divisors_at_most_three n hn
    _ ≤ _ := Nat.pow_le_pow_left (Nat.add_le_add_left (Nat.log_mono_right hnB) 1) 3

/-- The eligible denominators for a carrier, with no more than three
distinct prime factors in its attached cofactor. -/
def carrierDenominators (Y₀ : Finset ℕ) (v : ℕ) : Finset ℕ :=
  Y₀.filter fun n => v ∣ n ∧ (n / v).primeFactors.card ≤ 3

/-- The pre-factor used to impose the maximal power of a prime on a carrier. -/
def carrierPrefactor (Z v p : ℕ) : ℕ :=
  v * p ^ (p.log Z - v.factorization p)

/-- The location of the two auxiliary primes for a given imposed prime power. -/
noncomputable def carrierPrimeScale (X Z v p : ℕ) : ℝ :=
  Real.sqrt ((X : ℝ) / carrierPrefactor Z v p)

private theorem carrierPrefactor_dvd {Z v p : ℕ} (hv : 0 < v)
    (hvd : v ∣ Nat.lcmUpto Z) (hp : p.Prime) :
    carrierPrefactor Z v p ∣ Nat.lcmUpto Z ∧
      p ^ p.log Z ∣ carrierPrefactor Z v p := by
  have hvLe := (Nat.factorization_le_iff_dvd hv.ne' (Nat.lcmUpto_ne_zero Z)).mpr hvd
  have hBase : (carrierPrefactor Z v p).factorization =
      v.factorization + Finsupp.single p (p.log Z - v.factorization p) := by
    rw [carrierPrefactor, Nat.factorization_mul hv.ne' (pow_ne_zero _ hp.ne_zero), hp.factorization_pow]
  have hpLe : v.factorization p ≤ p.log Z := by
    simpa only [Nat.factorization_lcmUpto Z hp] using hvLe p
  have hAt : (carrierPrefactor Z v p).factorization p = p.log Z := by
    rw [hBase, Finsupp.add_apply, Finsupp.single_eq_same]
    omega
  have hBase₀ : carrierPrefactor Z v p ≠ 0 := mul_ne_zero hv.ne' (pow_ne_zero _ hp.ne_zero)
  refine ⟨(Nat.factorization_le_iff_dvd hBase₀ (Nat.lcmUpto_ne_zero Z)).mp ?_,
    (hp.pow_dvd_iff_le_factorization hBase₀).mpr hAt.ge⟩
  intro q
  by_cases hqp : q = p
  · subst q
    rw [hAt, Nat.factorization_lcmUpto Z hp]
  · simpa only [hBase, Finsupp.add_apply, Finsupp.single_eq_of_ne hqp, add_zero] using hvLe q

/-- The prime pair in the short interval supplies a denominator divisible by the
prescribed maximal prime power and obeying the cofactor multiplicity restriction. -/
theorem exists_carrier_multiple {X Z v p : ℕ} {c : ℝ} (hv : 0 < v)
    (hvd : v ∣ Nat.lcmUpto Z) (hp : p.Prime)
    (hPrimes : ∃ a b : ℕ, a.Prime ∧ b.Prime ∧ a ≠ b ∧ ¬ a ∣ v * p ∧ ¬ b ∣ v * p ∧
      a ≤ Z ∧ b ≤ Z ∧
      carrierPrimeScale X Z v p ≤ a ∧ (a : ℝ) ≤ carrierPrimeScale X Z v p * c ∧
      carrierPrimeScale X Z v p ≤ b ∧ (b : ℝ) ≤ carrierPrimeScale X Z v p * c) :
    ∃ n : ℕ, X ≤ n ∧ (n : ℝ) ≤ (X : ℝ) * c ^ 2 ∧ n ∣ Nat.lcmUpto Z ∧
      v ∣ n ∧ (n / v).primeFactors.card ≤ 3 ∧ p ^ p.log Z ∣ n := by
  classical
  obtain ⟨a,b,ha,hb,hab,haAvoid,hbAvoid,haZ,hbZ,haLo,haHi,hbLo,hbHi⟩ := hPrimes
  let k := p.log Z - v.factorization p
  let n := carrierPrefactor Z v p * a * b
  let z := carrierPrimeScale X Z v p
  have hBase₀ : 0 < carrierPrefactor Z v p := Nat.mul_pos hv (pow_pos hp.pos _)
  have hBaseReal : (0 : ℝ) < carrierPrefactor Z v p := by exact_mod_cast hBase₀
  have hz₀ : 0 ≤ z := Real.sqrt_nonneg _
  have hzSq : z * z = (X : ℝ) / carrierPrefactor Z v p :=
    Real.mul_self_sqrt (div_nonneg (Nat.cast_nonneg _) hBaseReal.le)
  have hBounds : (X : ℝ) ≤ n ∧ (n : ℝ) ≤ (X : ℝ) * c ^ 2 := by
    have hzB : (carrierPrefactor Z v p : ℝ) * (z * z) = X := by
      rw [hzSq, mul_comm, div_mul_cancel₀ _ hBaseReal.ne']
    have habLo : z * z ≤ (a : ℝ) * (b : ℝ) :=
      mul_le_mul haLo hbLo hz₀ (Nat.cast_nonneg _)
    have habHi : (a : ℝ) * (b : ℝ) ≤ (z * c) * (z * c) :=
      mul_le_mul haHi hbHi (Nat.cast_nonneg _) ((Nat.cast_nonneg a).trans haHi)
    constructor
    · calc
        (X : ℝ) = carrierPrefactor Z v p * (z * z) := hzB.symm
        _ ≤ carrierPrefactor Z v p * ((a : ℝ) * b) :=
          mul_le_mul_of_nonneg_left habLo hBaseReal.le
        _ = n := by dsimp only [n]; push_cast; ring
    · calc
        (n : ℝ) = carrierPrefactor Z v p * ((a : ℝ) * b) := by
          dsimp only [n]; push_cast; ring
        _ ≤ carrierPrefactor Z v p * ((z * c) * (z * c)) :=
          mul_le_mul_of_nonneg_left habHi hBaseReal.le
        _ = (carrierPrefactor Z v p : ℝ) * (z * z) * c ^ 2 := by ring
        _ = _ := by rw [hzB]
  have hCoprime (l : ℕ) (hl : l.Prime) (hAvoid : ¬ l ∣ v * p) :
      Nat.Coprime (carrierPrefactor Z v p) l := by
    apply Nat.Coprime.symm
    apply hl.coprime_iff_not_dvd.mpr
    intro h
    apply hAvoid
    rcases hl.dvd_mul.mp h with h | h
    · exact h.trans (dvd_mul_right _ _)
    · exact (hl.dvd_of_dvd_pow h).trans (dvd_mul_left _ _)
  have hBase := carrierPrefactor_dvd hv hvd hp
  have haDvd : a ∣ Nat.lcmUpto Z :=
    Finset.dvd_lcm (f := id) (Finset.mem_Icc.mpr ⟨ha.one_le,haZ⟩)
  have hbDvd : b ∣ Nat.lcmUpto Z :=
    Finset.dvd_lcm (f := id) (Finset.mem_Icc.mpr ⟨hb.one_le,hbZ⟩)
  have hDvd : n ∣ Nat.lcmUpto Z :=
    ((hCoprime b hb hbAvoid).mul_left ((Nat.coprime_primes ha hb).mpr hab)).mul_dvd_of_dvd_of_dvd
      ((hCoprime a ha haAvoid).mul_dvd_of_dvd_of_dvd hBase.1 haDvd) hbDvd
  have hProd : n = (p ^ k * a * b) * v := by
    dsimp only [n, carrierPrefactor, k]
    ac_rfl
  have hQuot : n / v = p ^ k * a * b := by
    rw [hProd, Nat.mul_div_cancel _ hv]
  have hSmall : (n / v).primeFactors.card ≤ 3 := by
    rw [hQuot, Nat.primeFactors_mul (mul_ne_zero (pow_ne_zero _ hp.ne_zero) ha.ne_zero) hb.ne_zero,
      Nat.primeFactors_mul (pow_ne_zero _ hp.ne_zero) ha.ne_zero, ha.primeFactors, hb.primeFactors]
    have hPow : (p ^ k).primeFactors.card ≤ 1 := by
      by_cases h : k = 0
      · simp [h]
      · rw [Nat.primeFactors_pow p h, hp.primeFactors]
        simp
    calc
      _ ≤ ((p ^ k).primeFactors ∪ {a}).card + ({b} : Finset ℕ).card :=
        Finset.card_union_le _ _
      _ ≤ ((p ^ k).primeFactors.card + ({a} : Finset ℕ).card) + ({b} : Finset ℕ).card :=
        Nat.add_le_add_right (Finset.card_union_le _ _) _
      _ ≤ 3 := by simp; omega
  refine ⟨n, by exact_mod_cast hBounds.1, hBounds.2, hDvd, ?_, hSmall, ?_⟩
  · rw [hProd]; exact dvd_mul_left _ _
  · exact hBase.2.trans ((dvd_mul_right _ a).trans (dvd_mul_right _ b))

/-- Supplying the two short-interval auxiliary primes for every prime up to the
cutoff suffices to prove that a single carrier's eligible denominators have the
full least common multiple of the powersmooth range. -/
theorem lcm_carrier_denominators {X Z v : ℕ} {c : ℝ} {Y₀ : Finset ℕ}
    (hv : 0 < v) (hvd : v ∣ Nat.lcmUpto Z)
    (hYSmooth : ∀ n ∈ Y₀, n ∣ Nat.lcmUpto Z)
    (hYWindow : ∀ n : ℕ, X ≤ n → (n : ℝ) ≤ (X : ℝ) * c ^ 2 →
      n ∣ Nat.lcmUpto Z → n ∈ Y₀)
    (hPrimes : ∀ p : ℕ, p.Prime → p ≤ Z →
      ∃ a b : ℕ, a.Prime ∧ b.Prime ∧ a ≠ b ∧ ¬ a ∣ v * p ∧ ¬ b ∣ v * p ∧
        a ≤ Z ∧ b ≤ Z ∧
        carrierPrimeScale X Z v p ≤ a ∧ (a : ℝ) ≤ carrierPrimeScale X Z v p * c ∧
        carrierPrimeScale X Z v p ≤ b ∧ (b : ℝ) ≤ carrierPrimeScale X Z v p * c) :
    (carrierDenominators Y₀ v).lcm id = Nat.lcmUpto Z := by
  classical
  let T := carrierDenominators Y₀ v
  have hTDvd : T.lcm id ∣ Nat.lcmUpto Z := Finset.lcm_dvd fun n hn =>
    hYSmooth n (Finset.mem_filter.mp hn).1
  have hT₀ : T.lcm id ≠ 0 := by
    intro h; simp [h, Nat.lcmUpto_ne_zero] at hTDvd
  apply Nat.dvd_antisymm hTDvd
  apply (Nat.factorization_le_iff_dvd (Nat.lcmUpto_ne_zero Z) hT₀).mp
  intro p
  by_cases hp : p ∈ (Nat.lcmUpto Z).primeFactors
  · rw [Nat.primeFactors_lcmUpto] at hp
    obtain ⟨hpZ,hpPrime⟩ := Nat.mem_primesLE.mp hp
    obtain ⟨n,hnLo,hnHi,hnDvd,hvn,hnSmall,hnMax⟩ :=
      exists_carrier_multiple hv hvd hpPrime (hPrimes p hpPrime hpZ)
    have hnT : n ∈ T := Finset.mem_filter.mpr ⟨hYWindow n hnLo hnHi hnDvd,hvn,hnSmall⟩
    have hdvd : p ^ p.log Z ∣ T.lcm id := hnMax.trans (Finset.dvd_lcm (f := id) hnT)
    rw [Nat.factorization_lcmUpto Z hpPrime]
    exact (hpPrime.pow_dvd_iff_le_factorization hT₀).mp hdvd
  · rw [← Nat.support_factorization] at hp
    rw [Finsupp.notMem_support_iff.mp hp]
    exact Nat.zero_le _

/-- The exact short interval of powersmooth denominators from the separation lemma. -/
noncomputable def closureShortDenominators (X : ℕ) : Finset ℕ := by
  classical
  exact (Finset.Icc X (2 * X)).filter fun n =>
    n ∣ Nat.lcmUpto (Nat.nthRoot 5 X) ∧
      (n : ℝ) ≤ (X : ℝ) * (1 + 1 / Real.log X)

private theorem log_bound_short_window {X : ℕ} (hX : 2 ≤ X) :
    ((1 + Nat.log 2 (2 * X) : ℕ) : ℝ) ≤ (3 / Real.log 2) * Real.log X := by
  have hx : (0 : ℝ) < X := by exact_mod_cast (by omega : 0 < X)
  have hx2 : (2 : ℝ) ≤ X := by exact_mod_cast hX
  have hlog2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hlogX := Real.log_le_log (by norm_num : (0 : ℝ) < 2) hx2
  have hb : 2 ^ Nat.log 2 (2 * X) ≤ 2 * X :=
    Nat.pow_log_le_self _ (by omega : 2 * X ≠ 0)
  have hbReal : (2 : ℝ) ^ Nat.log 2 (2 * X) ≤ 2 * (X : ℝ) := by exact_mod_cast hb
  have hLog := Real.log_le_log (by positivity) hbReal
  rw [Real.log_pow, Real.log_mul (by norm_num) hx.ne'] at hLog
  push_cast
  rw [div_mul_eq_mul_div]
  apply (le_div_iff₀ hlog2).mpr
  nlinarith only [hLog, hlogX]

/-- The exact short-interval separation rate in F2, uniformly in the
frequency. The two inputs are a density bound for carriers and the required
two distinct auxiliary primes in each short interval. -/
theorem short_interval_separation {X : ℕ} (hX : 32 ≤ X) (hLogX : 1 ≤ Real.log X)
    (V : Finset ℕ) {c : ℝ}
    (hDensity : c * ((X : ℝ) ^ (3/4 : ℝ) * Real.log X ^ 3) ≤ (V.card : ℝ))
    (hV : ∀ v ∈ V, 2 * (X : ℝ) ^ (3/4 : ℝ) < (v : ℝ) ∧
      v ∣ Nat.lcmUpto (Nat.nthRoot 5 X))
    (hPrimes : ∀ v ∈ V, ∀ p : ℕ, p.Prime → p ≤ Nat.nthRoot 5 X →
      ∃ a b : ℕ, a.Prime ∧ b.Prime ∧ a ≠ b ∧ ¬ a ∣ v * p ∧ ¬ b ∣ v * p ∧
        a ≤ Nat.nthRoot 5 X ∧ b ≤ Nat.nthRoot 5 X ∧
        carrierPrimeScale X (Nat.nthRoot 5 X) v p ≤ a ∧
        (a : ℝ) ≤ carrierPrimeScale X (Nat.nthRoot 5 X) v p * Real.sqrt (1 + 1 / Real.log X) ∧
        carrierPrimeScale X (Nat.nthRoot 5 X) v p ≤ b ∧
        (b : ℝ) ≤ carrierPrimeScale X (Nat.nthRoot 5 X) v p * Real.sqrt (1 + 1 / Real.log X))
    {h : ℝ} (hLow : (X : ℝ) / 2 ≤ |h|)
    (hHigh : 2 * |h| ≤ (Nat.lcmUpto (Nat.nthRoot 5 X) : ℝ)) :
    ∃ W ⊆ closureShortDenominators X,
      (c / (3 / Real.log 2) ^ 3) * (X : ℝ) ^ (3/4 : ℝ) ≤ (W.card : ℝ) ∧
      ∀ b ∈ W, ∀ j : ℤ, (X : ℝ) ^ (-(1/4) : ℝ) / 2 ≤ |h / b - j| := by
  classical
  let Z := Nat.nthRoot 5 X
  let Y₀ := closureShortDenominators X
  let R := (X : ℝ) ^ (3/4 : ℝ)
  let w := Real.sqrt (1 + 1 / Real.log X)
  have hx : (0 : ℝ) < X := by exact_mod_cast (by omega : 0 < X)
  have hLogX₀ : 0 < Real.log X := zero_lt_one.trans_le hLogX
  have hZ : 2 ≤ Z := (Nat.le_nthRoot_iff (by decide : 5 ≠ 0)).mpr (by norm_num; omega)
  have hP : 1 < Nat.lcmUpto Z := by
    have hd : 2 ∣ Nat.lcmUpto Z := Finset.dvd_lcm (f := id) (Finset.mem_Icc.mpr ⟨by decide,hZ⟩)
    exact (by decide : 1 < 2).trans_le (Nat.le_of_dvd (Nat.lcmUpto_pos Z) hd)
  have hR : 0 ≤ R := Real.rpow_nonneg hx.le _
  have h16 : (16 : ℝ) = (2 : ℝ) ^ (4 : ℝ) := by
    rw [show (4 : ℝ) = (4 : ℕ) by norm_num, Real.rpow_natCast]
    norm_num
  have h16X : (16 : ℝ) ≤ X := by exact_mod_cast (by omega : 16 ≤ X)
  have hQ : (2 : ℝ) ≤ (X : ℝ) ^ (1/4 : ℝ) := by
    have hAux := Real.rpow_le_rpow (by norm_num : (0 : ℝ) ≤ 16) h16X (by norm_num : (0 : ℝ) ≤ 1/4)
    rw [h16, ← Real.rpow_mul (by norm_num : (0 : ℝ) ≤ 2),
      show (4 : ℝ) * (1 / 4) = 1 by norm_num, Real.rpow_one] at hAux
    exact hAux
  have hRP : R * (X : ℝ) ^ (1 / 4 : ℝ) = X := by
    dsimp only [R]
    rw [← Real.rpow_add hx, show (3 / 4 : ℝ) + 1 / 4 = 1 by norm_num, Real.rpow_one]
  have hRX : R ≤ (X : ℝ) / 2 := by
    have hAux := mul_le_mul_of_nonneg_left hQ hR
    rw [hRP] at hAux
    linarith
  have hY₀ (n : ℕ) (hn : n ∈ Y₀) :
      0 < n ∧ (n : ℝ) ≤ 2 * (X : ℝ) := by
    obtain ⟨hlo,hhi⟩ := Finset.mem_Icc.mp (Finset.mem_filter.mp hn).1
    exact ⟨by omega, by exact_mod_cast hhi⟩
  obtain ⟨W,hW,hCards,hSep⟩ := exists_separated_denominators V Y₀
    (carrierDenominators Y₀) (P := Nat.lcmUpto Z) (K := (1 + Nat.log 2 (2 * X)) ^ 3) hP hR
    (hRX.trans hLow) hHigh hY₀
    (by
      intro v hv
      have hv₀ : 0 < v := by
        have h := (mul_nonneg (by norm_num : (0 : ℝ) ≤ 2) hR).trans_lt (hV v hv).1
        exact_mod_cast h
      have hWSq : w ^ 2 = 1 + 1 / Real.log X :=
        Real.sq_sqrt (by positivity)
      refine ⟨Finset.filter_subset _ _, lcm_carrier_denominators hv₀ (hV v hv).2
        (fun n hn => (Finset.mem_filter.mp hn).2.1) ?_ (hPrimes v hv),
        (hV v hv).1, fun n hn => (Finset.mem_filter.mp hn).2.1⟩
      intro n hnLo hnHi hnDvd
      rw [hWSq] at hnHi
      have hInv : 1 / Real.log X ≤ 1 := (div_le_iff₀ hLogX₀).mpr (by simpa using hLogX)
      have hHi : (n : ℝ) ≤ 2 * (X : ℝ) :=
        hnHi.trans (by nlinarith only [mul_le_mul_of_nonneg_left hInv hx.le])
      exact Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨hnLo, by exact_mod_cast hHi⟩, hnDvd, hnHi⟩)
    (by
      intro n hn
      exact (Finset.card_le_card (fun v hv =>
        Finset.mem_filter.mpr ⟨(Finset.mem_filter.mp hv).1,
          (Finset.mem_filter.mp (Finset.mem_filter.mp hv).2).2⟩)).trans
        (carrier_multiplicity V (Nat.ne_of_gt (hY₀ n hn).1) (by exact_mod_cast (hY₀ n hn).2)))
  have hK : (((1 + Nat.log 2 (2 * X)) ^ 3 : ℕ) : ℝ) ≤
      (3 / Real.log 2) ^ 3 * Real.log X ^ 3 := by
    push_cast
    rw [← mul_pow]
    exact pow_le_pow_left₀ (by positivity) (by simpa using log_bound_short_window (X := X) (by omega)) _
  refine ⟨W,hW,?_ ,?_⟩
  · have hCast : (V.card : ℝ) ≤ (((1 + Nat.log 2 (2 * X)) ^ 3 : ℕ) : ℝ) * (W.card : ℝ) := by
      exact_mod_cast hCards
    have hCore := hDensity.trans (hCast.trans (mul_le_mul_of_nonneg_right hK (Nat.cast_nonneg _)))
    have hLogCube : 0 < Real.log X ^ 3 := pow_pos hLogX₀ _
    have hC₁ : 0 < (3 / Real.log 2) ^ 3 := by positivity
    have hCanc : c * R ≤ (W.card : ℝ) * (3 / Real.log 2) ^ 3 := by
      apply (mul_le_mul_iff_right₀ hLogCube).mp
      calc
        Real.log X ^ 3 * (c * R) = c * (R * Real.log X ^ 3) := by ring
        _ ≤ (3 / Real.log 2) ^ 3 * Real.log X ^ 3 * (W.card : ℝ) := hCore
        _ = _ := by ring
    change c / (3 / Real.log 2) ^ 3 * R ≤ (W.card : ℝ)
    rw [show c / (3 / Real.log 2) ^ 3 * R = c * R / (3 / Real.log 2) ^ 3 by ring]
    exact (div_le_iff₀ hC₁).mpr hCanc
  · intro b hb j
    have hEq : R / (2 * (X : ℝ)) = (X : ℝ) ^ (-(1/4) : ℝ) / 2 := by
      dsimp only [R]
      rw [show (-(1 / 4) : ℝ) = 3/4 - 1 by norm_num, Real.rpow_sub hx, Real.rpow_one]
      ring
    rw [← hEq]
    exact hSep b hb j

private theorem card_primeFactors_le_log (n : ℕ) (hn : n ≠ 0) :
    n.primeFactors.card ≤ Nat.log 2 n := by
  calc
    _ ≤ n.primeFactorsList.length := List.toFinset_card_le _
    _ ≤ Nat.log 2 n := by
      apply Nat.le_log_of_pow_le (by decide)
      exact (List.pow_length_le_prod n.primeFactorsList 2
        (fun p hp => (Nat.prime_of_mem_primeFactorsList hp).two_le)).trans_eq (Nat.prod_primeFactorsList hn)

private theorem cast_nthRoot_five_le (X : ℕ) :
    (Nat.nthRoot 5 X : ℝ) ≤ (X : ℝ) ^ (1/5 : ℝ) := by
  apply (Real.rpow_le_rpow_iff (Nat.cast_nonneg _) (by positivity) (by norm_num : (0 : ℝ) < 5)).mp
  rw [← Real.rpow_mul (Nat.cast_nonneg X), show (1/5 : ℝ) * 5 = 1 by norm_num, Real.rpow_one,
    show (5 : ℝ) = (5 : ℕ) by norm_num, Real.rpow_natCast]
  exact_mod_cast Nat.pow_nthRoot_le (Or.inl (by decide : 5 ≠ 0) : 5 ≠ 0 ∨ X ≠ 0)

private theorem le_nthRoot_five_of_cast {X n : ℕ}
    (hn : (n : ℝ) ≤ (X : ℝ) ^ (1/5 : ℝ)) : n ≤ Nat.nthRoot 5 X := by
  apply (Nat.le_nthRoot_iff (by decide : 5 ≠ 0)).mpr
  have hPower : ((X : ℝ) ^ (1/5 : ℝ)) ^ (5 : ℕ) = X := by
    rw [← Real.rpow_natCast, ← Real.rpow_mul (Nat.cast_nonneg X),
      show (1 / 5 : ℝ) * ↑(5 : ℕ) = 1 by norm_num, Real.rpow_one]
  have h := (pow_le_pow_left₀ (Nat.cast_nonneg n) hn (5 : ℕ)).trans_eq hPower
  exact_mod_cast h

/-- The two primes needed in constructing each carrier's denominators,
with the derivation uniform over the prime power and carrier. -/
theorem eventually_carrier_prime_pairs :
    ∀ᶠ X : ℕ in atTop, ∀ v p : ℕ, p.Prime → p ≤ Nat.nthRoot 5 X →
      (X : ℝ) ^ (3/4 : ℝ) * Real.log X ^ 3 ≤ (v : ℝ) →
      (v : ℝ) ≤ 3 * ((X : ℝ) ^ (3/4 : ℝ) * Real.log X ^ 3) →
      ∃ a b : ℕ, a.Prime ∧ b.Prime ∧ a ≠ b ∧ ¬ a ∣ v * p ∧ ¬ b ∣ v * p ∧
        a ≤ Nat.nthRoot 5 X ∧ b ≤ Nat.nthRoot 5 X ∧
        carrierPrimeScale X (Nat.nthRoot 5 X) v p ≤ a ∧
        (a : ℝ) ≤ carrierPrimeScale X (Nat.nthRoot 5 X) v p * Real.sqrt (1 + 1 / Real.log X) ∧
        carrierPrimeScale X (Nat.nthRoot 5 X) v p ≤ b ∧
        (b : ℝ) ≤ carrierPrimeScale X (Nat.nthRoot 5 X) v p * Real.sqrt (1 + 1 / Real.log X) := by
  let A : ℝ := 36 * (1 + 1 / Real.log 2)
  have hlog2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hA : 0 < A := by dsimp only [A]; positivity
  have hA3 : 3 ≤ A := by dsimp only [A]; linarith [one_div_pos.mpr hlog2]
  have hGrowth :
      ∀ᶠ x : ℝ in atTop, A * Real.log x ^ 3 ≤ x ^ (1/100 : ℝ) := by
    have hb := (isLittleO_log_rpow_rpow_atTop 3 (by norm_num : (0 : ℝ) < 1/100)).bound
      (one_div_pos.mpr hA)
    filter_upwards [hb, eventually_gt_atTop (1 : ℝ)] with x hB hx
    have hLog₀ : 0 ≤ Real.log x := Real.log_nonneg hx.le
    rw [show (3 : ℝ) = ((3 : ℕ) : ℝ) by norm_num, Real.rpow_natCast,
      Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg (pow_nonneg hLog₀ _),
      abs_of_nonneg (Real.rpow_nonneg (zero_lt_one.trans hx).le _)] at hB
    have hC := mul_le_mul_of_nonneg_left hB hA.le
    rwa [← mul_assoc, mul_one_div_cancel hA.ne', one_mul] at hC
  have hCast : Tendsto (fun X : ℕ => (X : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hCast
  have hSmallPow := (tendsto_rpow_atTop (by norm_num : (0 : ℝ) < 3/40)).comp hCast
  have hPrime := hCast.eventually
    (eventually_short_prime_window_count (by norm_num : (0 : ℝ) < 1/50) (by norm_num : (0 : ℝ) < 3))
  filter_upwards [hPrime, hCast.eventually hGrowth, hLog.eventually_ge_atTop 1,
    hSmallPow.eventually_ge_atTop 2, eventually_ge_atTop (2 : ℕ)] with X hPr hG hLogX hXP hX
  intro v p hp hpZ hvLo hvHi
  let x : ℝ := X
  let Z := Nat.nthRoot 5 X
  let B := carrierPrefactor Z v p
  let z := carrierPrimeScale X Z v p
  let C := Real.sqrt (1 + 1 / Real.log x)
  have hx : (1 : ℝ) < x := by change (1 : ℝ) < (X : ℝ); exact_mod_cast (by omega : 1 < X)
  change 1 ≤ Real.log x at hLogX
  have hL : 0 < Real.log x := zero_lt_one.trans_le hLogX
  have hThree : 3 * Real.log x ^ 3 ≤ x ^ (1/100 : ℝ) :=
    (mul_le_mul_of_nonneg_right hA3 (by positivity)).trans hG
  have hlogCube : (1 : ℝ) ≤ Real.log x ^ 3 := one_le_pow₀ hLogX
  have hvPow : x ^ (3/4 : ℝ) ≤ (v : ℝ) := (le_mul_of_one_le_right (by positivity) hlogCube).trans hvLo
  have hv₀ : 0 < v := by exact_mod_cast (lt_of_lt_of_le (by positivity : 0 < x ^ (3/4 : ℝ)) hvPow)
  have hZ : (Z : ℝ) ≤ x ^ (1/5 : ℝ) := cast_nthRoot_five_le X
  have hpZ' : p ≤ Z := hpZ
  have hZ₀ : Z ≠ 0 := (hp.pos.trans_le hpZ').ne'
  have hpPow : p ^ (p.log Z - v.factorization p) ≤ Z :=
    (Nat.pow_le_pow_right hp.pos (Nat.sub_le _ _)).trans
      (Nat.pow_log_le_self _ hZ₀)
  have hBv : v ≤ B := le_mul_of_one_le_right' (Nat.one_le_iff_ne_zero.mpr (pow_ne_zero _ hp.ne_zero))
  have hB₀ : (0 : ℝ) < B := by exact_mod_cast (hv₀.trans_le hBv)
  have hBLo : x ^ (3/4 : ℝ) ≤ (B : ℝ) := hvPow.trans (by exact_mod_cast hBv)
  have hBHi : (B : ℝ) ≤ x ^ (24/25 : ℝ) := by
    have hPowR : (p ^ (p.log Z - v.factorization p) : ℕ) ≤ Z := hpPow
    have hMul : (B : ℝ) ≤ (v : ℝ) * x ^ (1/5 : ℝ) := by
      dsimp only [B, carrierPrefactor]
      push_cast
      have hPowCast : (p : ℝ) ^ (p.log Z - v.factorization p) ≤ (Z : ℝ) := by exact_mod_cast hPowR
      exact mul_le_mul_of_nonneg_left (hPowCast.trans hZ) (Nat.cast_nonneg v)
    calc
      _ ≤ _ := hMul
      _ ≤ (3 * (x ^ (3/4 : ℝ) * Real.log x ^ 3)) * x ^ (1/5 : ℝ) :=
        mul_le_mul_of_nonneg_right hvHi (by positivity)
      _ = x ^ (3/4 : ℝ) * (3 * Real.log x ^ 3) * x ^ (1/5 : ℝ) := by ring
      _ ≤ x ^ (3/4 : ℝ) * x ^ (1/100 : ℝ) * x ^ (1/5 : ℝ) := by gcongr
      _ = _ := by rw [← Real.rpow_add (zero_lt_one.trans hx), ← Real.rpow_add (zero_lt_one.trans hx)]
                  norm_num
  have hz₀ : 0 ≤ z := Real.sqrt_nonneg _
  have hzSq : z ^ 2 = x / (B : ℝ) := Real.sq_sqrt (div_nonneg (Nat.cast_nonneg X) hB₀.le)
  have hzLo : x ^ (1/50 : ℝ) ≤ z := by
    have hb : (x ^ (1/50 : ℝ)) ^ 2 * (B : ℝ) ≤ x := by
      calc
        _ ≤ (x ^ (1/50 : ℝ)) ^ 2 * x ^ (24/25 : ℝ) :=
          mul_le_mul_of_nonneg_left hBHi (by positivity)
        _ = x := by rw [← Real.rpow_natCast, ← Real.rpow_mul (zero_lt_one.trans hx).le,
            ← Real.rpow_add (zero_lt_one.trans hx)]
                    norm_num
    have hq := (le_div_iff₀ hB₀).mpr hb
    rw [← hzSq] at hq
    nlinarith [Real.rpow_nonneg (zero_lt_one.trans hx).le (1/50 : ℝ)]
  have hzHi : z ≤ x ^ (1/8 : ℝ) := by
    have hb : x ≤ (x ^ (1/8 : ℝ)) ^ 2 * (B : ℝ) := by
      calc
        _ = (x ^ (1/8 : ℝ)) ^ 2 * x ^ (3/4 : ℝ) := by
          rw [← Real.rpow_natCast, ← Real.rpow_mul (zero_lt_one.trans hx).le,
             ← Real.rpow_add (zero_lt_one.trans hx)]
          norm_num
        _ ≤ _ := mul_le_mul_of_nonneg_left hBLo (by positivity)
    have hq := (div_le_iff₀ hB₀).mpr hb
    rw [← hzSq] at hq
    nlinarith [Real.rpow_nonneg (zero_lt_one.trans hx).le (1/8 : ℝ)]
  have hPowLe (r : ℝ) (hr : r ≤ 1) : x ^ r ≤ x :=
    (Real.rpow_le_rpow_of_exponent_le hx.le hr).trans_eq (Real.rpow_one x)
  have hzX : z ≤ x := hzHi.trans (hPowLe _ (by norm_num))
  have hC : 1 ≤ C := by
    calc
      1 = Real.sqrt 1 := Real.sqrt_one.symm
      _ ≤ C := Real.sqrt_le_sqrt (le_add_of_nonneg_right (by positivity))
  have hCSq : C ^ 2 = 1 + 1/Real.log x := Real.sq_sqrt (by positivity)
  have hInv : 1 / Real.log x ≤ 1 := (div_le_iff₀ hL).mpr (by simpa using hLogX)
  have hC2 : C ≤ 2 := by nlinarith
  have hCW : 1 / (3 * Real.log x) ≤ C - 1 := by
    apply (div_le_iff₀ (by positivity : 0 < 3 * Real.log x)).mpr
    have hFact : (C - 1) * ((C + 1) * Real.log x) = 1 := by
      rw [← mul_assoc, show (C - 1) * (C + 1) = C ^ 2 - 1 by ring, hCSq,
        add_sub_cancel_left, one_div_mul_cancel hL.ne']
    calc
      _ = (C - 1) * ((C + 1) * Real.log x) := hFact.symm
      _ ≤ _ := by gcongr; linarith
  have hWin := hPr z (z * C - z) hzLo hzX
    (by calc
      _ = z * (1 / (3 * Real.log x)) := by ring
      _ ≤ z * (C - 1) := mul_le_mul_of_nonneg_left hCW hz₀
      _ = _ := by ring) (by nlinarith only [mul_le_mul_of_nonneg_left hC2 hz₀])
  rw [show z + (z * C - z) = z * C by ring] at hWin
  have hCN : z * C ≤ x ^ (1/5 : ℝ) := by
    calc
      _ ≤ x ^ (1/8 : ℝ) * 2 := mul_le_mul hzHi hC2 (by linarith) (by positivity)
      _ ≤ x ^ (1/8 : ℝ) * x ^ (3/40 : ℝ) := mul_le_mul_of_nonneg_left hXP (by positivity)
      _ = _ := by rw [← Real.rpow_add (zero_lt_one.trans hx)]; norm_num
  have hvX : (v : ℝ) ≤ x := (show (v : ℝ) ≤ (B : ℝ) by exact_mod_cast hBv).trans
    (hBHi.trans (hPowLe _ (by norm_num)))
  have hpX : (p : ℝ) ≤ x := ((by exact_mod_cast hpZ : (p : ℝ) ≤ Z).trans hZ).trans
    (hPowLe _ (by norm_num))
  have hvp₀ : v * p ≠ 0 := mul_ne_zero hv₀.ne' hp.ne_zero
  have hFactors : ((v*p).primeFactors.card : ℝ) ≤ 2 * Real.log x / Real.log 2 := by
    have hCard := card_primeFactors_le_log _ hvp₀
    have hb := (Nat.pow_log_le_self 2 hvp₀).trans (show v * p ≤ X ^ 2 by
      have hbReal : (v : ℝ) * p ≤ (X : ℝ) ^ (2 : ℕ) := by
        change (v : ℝ) * p ≤ x ^ (2 : ℕ)
        rw [pow_two]
        exact mul_le_mul hvX hpX (Nat.cast_nonneg _) (zero_lt_one.trans hx).le
      exact_mod_cast hbReal)
    have hb' : (2 : ℝ) ^ Nat.log 2 (v * p) ≤ x ^ (2 : ℕ) := by
      change (2 : ℝ) ^ Nat.log 2 (v * p) ≤ (X : ℝ) ^ (2 : ℕ)
      exact_mod_cast hb
    have hlog := Real.log_le_log (by positivity) hb'
    rw [Real.log_pow, Real.log_pow] at hlog
    apply (le_div_iff₀ hlog2).mpr
    have hCR : ((v*p).primeFactors.card : ℝ) ≤ Nat.log 2 (v*p) := by exact_mod_cast hCard
    exact (mul_le_mul_of_nonneg_right hCR hlog2.le).trans (by simpa using hlog)
  have hMany : ((v*p).primeFactors.card : ℝ) + 1 < (primesBetween z (z * C)).card := by
    have hxPow : x ^ (1/100 : ℝ) ≤ x ^ (1/50 : ℝ) :=
      Real.rpow_le_rpow_of_exponent_le hx.le (by norm_num)
    have hComp : A * Real.log x / 12 ≤ z / (4 * 3 * Real.log x ^ 2) := by
      apply (le_div_iff₀ (by positivity : 0 < 4 * 3 * Real.log x ^ 2)).mpr
      calc
        _ = A * Real.log x ^ 3 := by ring
        _ ≤ _ := hG.trans (hxPow.trans hzLo)
    have hCmp : 2 * Real.log x / Real.log 2 + 1 < A * Real.log x / 12 := by
      dsimp only [A]
      have hPos : 0 < Real.log x / Real.log 2 := by positivity
      rw [show 36 * (1 + 1 / Real.log 2) * Real.log x / 12 =
        3 * Real.log x + 3 * (Real.log x / Real.log 2) by ring,
        show 2 * Real.log x / Real.log 2 = 2 * (Real.log x / Real.log 2) by ring]
      linarith only [hLogX, hPos]
    exact lt_of_le_of_lt (add_le_add_left hFactors 1)
      (hCmp.trans_le (hComp.trans hWin))
  let S := primesBetween z (z * C) \ (v*p).primeFactors
  have hS : 1 < S.card := by
    have hBound := Finset.card_le_card_sdiff_add_card (s := primesBetween z (z * C))
      (t := (v*p).primeFactors)
    have hManyNat : (v*p).primeFactors.card + 1 < (primesBetween z (z * C)).card := by
      exact_mod_cast hMany
    change 1 < (primesBetween z (z * C) \ (v*p).primeFactors).card
    omega
  obtain ⟨a,b,ha,hb,hab⟩ := Finset.one_lt_card_iff.mp hS
  obtain ⟨ha',haAvoid⟩ := Finset.mem_sdiff.mp ha
  obtain ⟨hb',hbAvoid⟩ := Finset.mem_sdiff.mp hb
  obtain ⟨haLo,haHi,haP⟩ := (mem_primesBetween hz₀ (by positivity)).mp ha'
  obtain ⟨hbLo,hbHi,hbP⟩ := (mem_primesBetween hz₀ (by positivity)).mp hb'
  refine ⟨a,b,haP,hbP,hab,?_,?_,le_nthRoot_five_of_cast (haHi.trans hCN),
    le_nthRoot_five_of_cast (hbHi.trans hCN),haLo.le,haHi,hbLo.le,hbHi⟩
  · intro hd; exact haAvoid (Nat.mem_primeFactors.mpr ⟨haP,hd,hvp₀⟩)
  · intro hd; exact hbAvoid (Nat.mem_primeFactors.mpr ⟨hbP,hd,hvp₀⟩)

/-- The real scale of the powersmooth carriers used to separate each frequency. -/
noncomputable def closureCarrierScale (X : ℕ) : ℝ :=
  (X : ℝ) ^ (3/4 : ℝ) * Real.log X ^ 3

/-- The powersmooth carrier count required by the separation argument. The wider
upper bound permits rounding the real carrier scale up to an integer. -/
def ClosureCarrierDensity : Prop :=
  ∃ c : ℝ, 0 < c ∧ ∀ᶠ X : ℕ in atTop, ∃ V : Finset ℕ,
    c * closureCarrierScale X ≤ (V.card : ℝ) ∧
    ∀ v ∈ V, closureCarrierScale X ≤ (v : ℝ) ∧ (v : ℝ) ≤ 3 * closureCarrierScale X ∧
      v ∣ Nat.lcmUpto (Nat.nthRoot 5 X)

/-- All large frequencies have the separated powersmooth denominators needed
by Fourier closure, assuming only positive density of the carriers. -/
theorem eventually_smooth_separation_of_density (hDensity : ClosureCarrierDensity) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ X : ℕ in atTop, ∀ h : ℤ,
      (X : ℝ) / 2 < |(h : ℝ)| → |(h : ℝ)| ≤ (Nat.lcmUpto (Nat.nthRoot 5 X) : ℝ) / 2 →
      ∃ W ⊆ closureShortDenominators X,
        c * (X : ℝ) ^ (3/4 : ℝ) ≤ (W.card : ℝ) ∧
        ∀ b ∈ W, ∀ j : ℤ, (X : ℝ) ^ (-(1/4) : ℝ) / 2 ≤ |(h : ℝ) / b - j| := by
  obtain ⟨c,hc,hV⟩ := hDensity
  refine ⟨c / (3 / Real.log 2) ^ 3, by positivity, ?_⟩
  have hCast : Tendsto (fun X : ℕ => (X : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := (Real.tendsto_log_atTop.comp hCast).eventually_ge_atTop 2
  filter_upwards [hV, hLog, eventually_ge_atTop (32 : ℕ), eventually_carrier_prime_pairs]
    with X hV hLog hX hP
  obtain ⟨V,hVcard,hVmem⟩ := hV
  intro h hLo hHi
  change 2 ≤ Real.log (X : ℝ) at hLog
  apply short_interval_separation hX (by linarith) V hVcard ?_ ?_ hLo.le (by linarith)
  · intro v hv
    obtain ⟨hvLo,_,hvDvd⟩ := hVmem v hv
    refine ⟨?_,hvDvd⟩
    apply lt_of_lt_of_le _ hvLo
    dsimp only [closureCarrierScale]
    have hR : 0 < (X : ℝ) ^ (3/4 : ℝ) := by
      apply Real.rpow_pos_of_pos
      exact_mod_cast (by omega : 0 < X)
    have hL : (2 : ℝ) < Real.log X ^ 3 := by
      exact (by norm_num : (2 : ℝ) < 2 ^ 3).trans_le (pow_le_pow_left₀ (by norm_num) hLog _)
    rw [mul_comm (2 : ℝ)]
    exact mul_lt_mul_of_pos_left hL hR
  · intro v hv p hp hpZ
    exact hP v p hp hpZ (hVmem v hv).1 (hVmem v hv).2.1


/-- The frequency separation estimate used in the uniform powersmooth
closure, with both the carrier count and auxiliary prime inputs discharged. -/
theorem eventually_smooth_separation :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ X : ℕ in atTop, ∀ h : ℤ,
      (X : ℝ) / 2 < |(h : ℝ)| → |(h : ℝ)| ≤ (Nat.lcmUpto (Nat.nthRoot 5 X) : ℝ) / 2 →
      ∃ W ⊆ closureShortDenominators X,
        c * (X : ℝ) ^ (3/4 : ℝ) ≤ (W.card : ℝ) ∧
        ∀ b ∈ W, ∀ j : ℤ, (X : ℝ) ^ (-(1/4) : ℝ) / 2 ≤ |(h : ℝ) / b - j| :=
  eventually_smooth_separation_of_density
    (by simpa only [ClosureCarrierDensity, closureCarrierScale] using eventually_powersmooth_carriers)

end LeanAB.PaperB.SmoothSeparation

