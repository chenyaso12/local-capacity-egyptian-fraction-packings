module

public import PaperB.CRTPrimeMass
meta import Mathlib.Tactic

/-! Collect dyadic exceptional-prime counts in the F2 lifting windows. -/

public section

namespace LeanAB.PaperB

open Filter Finset
open scoped Topology

/-- Three dyadic exceptional counts at exponent 5/8 bound any subwindow of
(x, 8x] at exponent 3/4, with a threshold uniform in the predicate. -/
theorem eventually_dyadic_bad_count_on_subwindow :
    ∀ᶠ x : ℝ in atTop, ∀ (bad : ℕ → Prop) [DecidablePred bad],
      ((primesBetween x (2 * x)).filter bad).card ≤ x ^ (5 / 8 : ℝ) →
      ((primesBetween (2 * x) (4 * x)).filter bad).card ≤ (2 * x) ^ (5 / 8 : ℝ) →
      ((primesBetween (4 * x) (8 * x)).filter bad).card ≤ (4 * x) ^ (5 / 8 : ℝ) →
      ∀ u v : ℝ, x ≤ u → u ≤ v → v ≤ 8 * x →
        ((primesBetween u v).filter bad).card ≤ x ^ (3 / 4 : ℝ) := by
  let C : ℝ := 1 + (2 : ℝ) ^ (5 / 8 : ℝ) + (4 : ℝ) ^ (5 / 8 : ℝ)
  have hGrowth : Tendsto (fun x : ℝ => x ^ (1 / 8 : ℝ)) atTop atTop :=
    tendsto_rpow_atTop (by norm_num)
  filter_upwards [eventually_gt_atTop (0 : ℝ), hGrowth.eventually_ge_atTop C]
    with x hx hLarge
  intro bad inst hOne hTwo hThree u v hU hUV hV
  let A := (primesBetween x (2 * x)).filter bad
  let B := (primesBetween (2 * x) (4 * x)).filter bad
  let D := (primesBetween (4 * x) (8 * x)).filter bad
  have hx₂ : 0 ≤ 2 * x := by positivity
  have hx₄ : 0 ≤ 4 * x := by positivity
  have hx₈ : 0 ≤ 8 * x := by positivity
  have hSub : (primesBetween u v).filter bad ⊆ (A ∪ B) ∪ D := by
    intro p hp
    obtain ⟨hp,hBad⟩ := mem_filter.mp hp
    obtain ⟨hpU,hpV,hPrime⟩ := (mem_primesBetween (hx.le.trans hU) (hx.le.trans (hU.trans hUV))).mp hp
    by_cases hp₂ : (p : ℝ) ≤ 2 * x
    · exact mem_union_left _ (mem_union_left _ (mem_filter.mpr
        ⟨(mem_primesBetween hx.le hx₂).mpr ⟨hU.trans_lt hpU,hp₂,hPrime⟩,hBad⟩))
    by_cases hp₄ : (p : ℝ) ≤ 4 * x
    · exact mem_union_left _ (mem_union_right _ (mem_filter.mpr
        ⟨(mem_primesBetween hx₂ hx₄).mpr ⟨lt_of_not_ge hp₂,hp₄,hPrime⟩,hBad⟩))
    · exact mem_union_right _ (mem_filter.mpr
        ⟨(mem_primesBetween hx₄ hx₈).mpr ⟨lt_of_not_ge hp₄,hpV.trans hV,hPrime⟩,hBad⟩)
  have hCount : ((primesBetween u v).filter bad).card ≤ A.card + B.card + D.card :=
    (card_le_card hSub).trans ((card_union_le _ _).trans
      (Nat.add_le_add_right (card_union_le _ _) _))
  calc
    _ ≤ (A.card : ℝ) + B.card + D.card := by exact_mod_cast hCount
    _ ≤ x ^ (5 / 8 : ℝ) + (2 * x) ^ (5 / 8 : ℝ) + (4 * x) ^ (5 / 8 : ℝ) :=
      add_le_add (add_le_add hOne hTwo) hThree
    _ = C * x ^ (5 / 8 : ℝ) := by
      rw [Real.mul_rpow (by norm_num : (0 : ℝ) ≤ 2) hx.le,
        Real.mul_rpow (by norm_num : (0 : ℝ) ≤ 4) hx.le]
      dsimp only [C]
      ring
    _ ≤ x ^ (1 / 8 : ℝ) * x ^ (5 / 8 : ℝ) :=
      mul_le_mul_of_nonneg_right hLarge (Real.rpow_nonneg hx.le _)
    _ = _ := by rw [← Real.rpow_add hx]; norm_num

/-- The bad-prime count bound for the two exact F2 windows. -/
theorem eventually_dyadic_bad_count :
    ∀ᶠ x : ℝ in atTop, ∀ (bad : ℕ → Prop) [DecidablePred bad],
      ((primesBetween x (2 * x)).filter bad).card ≤ x ^ (5 / 8 : ℝ) →
      ((primesBetween (2 * x) (4 * x)).filter bad).card ≤ (2 * x) ^ (5 / 8 : ℝ) →
      ((primesBetween (4 * x) (8 * x)).filter bad).card ≤ (4 * x) ^ (5 / 8 : ℝ) →
      ((primesBetween x ((5 / 2 : ℝ) * x)).filter bad).card ≤ x ^ (3 / 4 : ℝ) ∧
      ((primesBetween (3 * x) ((9 / 2 : ℝ) * x)).filter bad).card ≤ x ^ (3 / 4 : ℝ) := by
  filter_upwards [eventually_dyadic_bad_count_on_subwindow, eventually_gt_atTop (0 : ℝ)]
    with x hCount hx
  intro bad inst hOne hTwo hThree
  have h := hCount bad hOne hTwo hThree
  exact ⟨h _ _ le_rfl (by linarith) (by linarith), h _ _ (by linarith) (by linarith) (by linarith)⟩

end LeanAB.PaperB
