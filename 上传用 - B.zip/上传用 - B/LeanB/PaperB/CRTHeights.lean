module

public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

meta import Mathlib.Tactic

@[expose] public section

namespace LeanAB.PaperB.Closure

open Filter Asymptotics

/-- The pointwise height valid throughout the dyadic window at scale \(x\). -/
noncomputable def pointwiseCoverHeight (x : ℝ) : ℕ := ⌈Real.log (2 * x) ^ 4⌉₊

/-- The height after one CRT lifting step. -/
noncomputable def liftedCoverHeight (f : ℝ → ℕ) (P : ℝ) : ℕ :=
  ⌈5 * Real.log P⌉₊ * f (4 * Real.log P)

theorem pointwiseCoverHeight_monotoneOn :
    MonotoneOn pointwiseCoverHeight (Set.Ici (1 : ℝ)) := by
  intro x hx y _ hxy
  have hx' : 1 ≤ 2 * x := by
    change 1 ≤ x at hx
    linarith
  apply Nat.ceil_mono
  exact pow_le_pow_left₀ (Real.log_nonneg hx')
    (Real.log_le_log (zero_lt_one.trans_le hx')
      (mul_le_mul_of_nonneg_left hxy (by norm_num))) 4

theorem liftedCoverHeight_monotoneOn {f : ℝ → ℕ} {T : ℝ}
    (hf : MonotoneOn f (Set.Ici T)) :
    MonotoneOn (liftedCoverHeight f) (Set.Ici (Real.exp (T / 4))) := by
  intro x hx y hy hxy
  have hxPos : 0 < x := (Real.exp_pos _).trans_le hx
  have hArg {t : ℝ} (ht : Real.exp (T / 4) ≤ t) : T ≤ 4 * Real.log t := by
    have h := Real.log_le_log (Real.exp_pos _) ht
    rw [Real.log_exp] at h
    linarith
  have hLog := Real.log_le_log hxPos hxy
  apply Nat.mul_le_mul
  · exact Nat.ceil_mono (mul_le_mul_of_nonneg_left hLog (by norm_num))
  · exact hf (hArg hx) (hArg hy) (mul_le_mul_of_nonneg_left hLog (by norm_num))

private theorem pointwiseCoverHeight_cast_le {x B : ℝ} (hB : 1 ≤ B)
    (hLog : 0 ≤ Real.log (2 * x)) (hBound : Real.log (2 * x) ≤ B) :
    (pointwiseCoverHeight x : ℝ) ≤ 2 * B ^ 4 := by
  have hpow := pow_le_pow_left₀ hLog hBound 4
  have hOne : (1 : ℝ) ≤ B ^ 4 := by
    simpa only [one_pow] using pow_le_pow_left₀ (show (0 : ℝ) ≤ 1 by norm_num) hB 4
  have hCeil := (Nat.ceil_lt_add_one (pow_nonneg hLog 4)).le
  unfold pointwiseCoverHeight
  linarith only [hpow, hOne, hCeil]

private theorem ceil_five_log_cast_le {x : ℝ} (hL : 1 ≤ Real.log x) :
    (⌈5 * Real.log x⌉₊ : ℝ) ≤ 6 * Real.log x := by
  have hCeil := (Nat.ceil_lt_add_one
    (mul_nonneg (by norm_num : (0 : ℝ) ≤ 5) (zero_le_one.trans hL))).le
  linarith only [hCeil, hL]

private theorem eventually_log_four_mul_pow_le (k : ℕ) {C ε : ℝ}
    (hC : 0 < C) (hε : 0 < ε) :
    ∀ᶠ x : ℝ in atTop, C * Real.log (4 * x) ^ k ≤ ε * x := by
  have hScale : Tendsto (fun x : ℝ => 4 * x) atTop atTop :=
    tendsto_id.const_mul_atTop (by norm_num)
  have hSmall :=
    (isLittleO_log_rpow_rpow_atTop (k : ℝ) (s := 1) one_pos).bound
      (div_pos hε (mul_pos (by norm_num : (0 : ℝ) < 4) hC))
  filter_upwards [hScale.eventually hSmall, hScale.eventually (eventually_ge_atTop (1 : ℝ))]
    with x h hScaleX
  have hLog := Real.log_nonneg hScaleX
  have h := by
    simpa only [Real.norm_eq_abs, Real.rpow_natCast, Real.rpow_one,
      abs_of_nonneg (pow_nonneg hLog k), abs_of_nonneg (zero_le_one.trans hScaleX)] using h
  calc
    _ ≤ C * (ε / (4 * C) * (4 * x)) := mul_le_mul_of_nonneg_left h hC.le
    _ = _ := by field_simp [hC.ne']

theorem eventually_pointwiseCoverHeight_four_mul_le :
    ∀ᶠ x : ℝ in atTop, (pointwiseCoverHeight (4 * x) : ℝ) ≤ x / 100 := by
  have hScale : Tendsto (fun x : ℝ => 4 * x) atTop atTop :=
    tendsto_id.const_mul_atTop (by norm_num)
  filter_upwards [(Real.tendsto_log_atTop.comp hScale).eventually_ge_atTop 1,
    hScale.eventually (eventually_ge_atTop (1 : ℝ)),
    eventually_log_four_mul_pow_le 4 (C := 32) (ε := 1 / 100) (by norm_num) (by norm_num)]
    with x hL hx hSlow
  have hL' : 1 ≤ Real.log (4 * x) := hL
  have hArg : 1 ≤ 2 * (4 * x) := by linarith only [hx]
  have hLog : Real.log (2 * (4 * x)) ≤ 2 * Real.log (4 * x) := by
    rw [Real.log_mul (by norm_num) (zero_lt_one.trans_le hx).ne']
    linarith only [Real.log_le_sub_one_of_pos (show (0 : ℝ) < 2 by norm_num), hL']
  calc
    _ ≤ 2 * (2 * Real.log (4 * x)) ^ 4 :=
      pointwiseCoverHeight_cast_le (by linarith only [hL']) (Real.log_nonneg hArg) hLog
    _ = 32 * Real.log (4 * x) ^ 4 := by ring
    _ ≤ x / 100 := by linarith only [hSlow]

theorem eventually_liftedPointwiseCoverHeight_four_mul_le :
    ∀ᶠ x : ℝ in atTop, (liftedCoverHeight pointwiseCoverHeight (4 * x) : ℝ) ≤ x / 100 := by
  have hScale : Tendsto (fun x : ℝ => 4 * x) atTop atTop :=
    tendsto_id.const_mul_atTop (by norm_num)
  filter_upwards [(Real.tendsto_log_atTop.comp hScale).eventually_ge_atTop 1,
    eventually_log_four_mul_pow_le 5 (C := 49152) (ε := 1 / 100) (by norm_num) (by norm_num)]
    with x hL hSlow
  let L := Real.log (4 * x)
  have hL' : 1 ≤ L := hL
  have hArg : 1 ≤ 2 * (4 * L) := by linarith only [hL']
  have hLog : Real.log (2 * (4 * L)) ≤ 8 * L := by
    have h := Real.log_le_sub_one_of_pos (zero_lt_one.trans_le hArg)
    linarith only [h]
  have hPoint : (pointwiseCoverHeight (4 * L) : ℝ) ≤ 2 * (8 * L) ^ 4 :=
    pointwiseCoverHeight_cast_le (by linarith only [hL']) (Real.log_nonneg hArg) hLog
  calc
    _ = (⌈5 * L⌉₊ : ℝ) * (pointwiseCoverHeight (4 * L) : ℝ) := by
      rw [liftedCoverHeight, Nat.cast_mul]
    _ ≤ (6 * L) * (2 * (8 * L) ^ 4) :=
      mul_le_mul (ceil_five_log_cast_le hL) hPoint (by positivity)
        (mul_nonneg (by norm_num) (zero_le_one.trans hL'))
    _ = 49152 * L ^ 5 := by ring
    _ ≤ x / 100 := by linarith only [hSlow]

/-- The height after two lifting steps has the iterated-logarithm bound used
for the average cover. -/
theorem eventually_twiceLiftedPointwiseCoverHeight_le :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ x : ℝ in atTop,
      (liftedCoverHeight (liftedCoverHeight pointwiseCoverHeight) x : ℝ) ≤
        C * Real.log x * Real.log (Real.log x) * Real.log (Real.log (Real.log x)) ^ 4 := by
  refine ⟨288 * 32 ^ 4, by positivity, ?_⟩
  have hLog := Real.tendsto_log_atTop
  have hLogLog := Real.tendsto_log_atTop.comp hLog
  have hLogLogLog := Real.tendsto_log_atTop.comp hLogLog
  filter_upwards [hLog.eventually_ge_atTop 1, hLogLog.eventually_ge_atTop 1,
    hLogLogLog.eventually_ge_atTop 1] with x hL hU hV
  let L := Real.log x
  let U := Real.log L
  let V := Real.log U
  let M := Real.log (4 * L)
  have hL' : 1 ≤ L := hL
  have hU' : 1 ≤ U := hU
  have hV' : 1 ≤ V := hV
  have hM : M = Real.log 4 + U := Real.log_mul (by norm_num) (zero_lt_one.trans_le hL').ne'
  have hMlo : 1 ≤ M := by
    linarith only [hM, hU', Real.log_nonneg (show (1 : ℝ) ≤ 4 by norm_num)]
  have hMhi : M ≤ 4 * U := by
    linarith only [hM, hU', Real.log_le_sub_one_of_pos (show (0 : ℝ) < 4 by norm_num)]
  have hArg : 1 ≤ 2 * (4 * M) := by linarith only [hMlo]
  have hPointLog : Real.log (2 * (4 * M)) ≤ 32 * V := calc
    _ ≤ Real.log (32 * U) :=
      Real.log_le_log (zero_lt_one.trans_le hArg) (by linarith only [hMhi])
    _ = Real.log 32 + V := Real.log_mul (by norm_num) (zero_lt_one.trans_le hU').ne'
    _ ≤ 32 * V := by
      linarith only [hV', Real.log_le_sub_one_of_pos (show (0 : ℝ) < 32 by norm_num)]
  have hPoint := pointwiseCoverHeight_cast_le
    (x := 4 * M) (B := 32 * V) (by linarith only [hV']) (Real.log_nonneg hArg) hPointLog
  have hInner : (⌈5 * M⌉₊ : ℝ) ≤ 24 * U :=
    (ceil_five_log_cast_le hMlo).trans (by linarith only [hMhi])
  calc
    _ = (⌈5 * L⌉₊ : ℝ) * ((⌈5 * M⌉₊ : ℝ) * (pointwiseCoverHeight (4 * M) : ℝ)) := by
      simp only [liftedCoverHeight, Nat.cast_mul, L, M]
    _ ≤ (6 * L) * ((24 * U) * (2 * (32 * V) ^ 4)) := by
      gcongr
      exact ceil_five_log_cast_le hL'
    _ = 288 * 32 ^ 4 * L * U * V ^ 4 := by ring

end LeanAB.PaperB.Closure
