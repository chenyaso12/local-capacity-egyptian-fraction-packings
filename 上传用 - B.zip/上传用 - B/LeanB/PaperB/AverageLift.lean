module

public import PaperB.CRTCoverPools
public import PaperB.CRTPrimeMass
public import PaperB.CRTSupport
public import PaperB.CRTDyadic
public import PaperB.CRTHeights
public import PaperB.PointwiseCover
meta import Mathlib.Tactic

/-! One scale lift for the average reciprocal cover. -/

public section

open Filter Finset Asymptotics
open scoped Topology

namespace LeanAB.PaperB.Closure

/-- If the two auxiliary windows each lose at most `(log P)^(3/4)` primes
and all retained primes admit a cover of height `T ≤ log P/100`, the
resulting height is at most `ceil (5 log P) * T` for all but
`P^(1/2 + ε)` target primes in `(P, 2P]`. -/
theorem eventually_reciprocalCoverExceptions_le_of_window_covers {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ P : ℝ in atTop, ∀ T : ℕ, (T : ℝ) ≤ Real.log P / 100 →
      ∀ S₁ S₂ : Finset ℕ,
      S₁ ⊆ primesBetween (Real.log P) ((5 / 2 : ℝ) * Real.log P) →
      S₂ ⊆ primesBetween (3 * Real.log P) ((9 / 2 : ℝ) * Real.log P) →
      (((primesBetween (Real.log P) ((5 / 2 : ℝ) * Real.log P) \ S₁).card : ℕ) : ℝ) ≤
        Real.log P ^ (3 / 4 : ℝ) →
      (((primesBetween (3 * Real.log P) ((9 / 2 : ℝ) * Real.log P) \ S₂).card : ℕ) : ℝ) ≤
        Real.log P ^ (3 / 4 : ℝ) →
      (∀ p ∈ S₁, CoversResidues p (interval 1 T)) →
      (∀ p ∈ S₂, CoversResidues p (interval 1 T)) →
      ((reciprocalCoverExceptions (primesBetween P (2 * P))
        (⌈5 * Real.log P⌉₊ * T)).card : ℝ) ≤ P ^ (1 / 2 + ε) := by
  let δ := min (ε / 2) (1 / 4)
  let K := 3 * (4 + 8 * Real.pi)
  have hδ : 0 < δ := lt_min (half_pos hε) (by norm_num)
  have hδ₁ : δ ≤ 1 / 4 := min_le_right _ _
  have hδε : δ < ε := (min_le_left _ _).trans_lt (by linarith)
  have hK : 0 ≤ K := by dsimp [K]; positivity
  have hcut := Real.isLittleO_log_id_atTop.bound (show (0 : ℝ) < 1 / 12 by norm_num)
  filter_upwards [eventually_gt_atTop (1 : ℝ),
    Real.tendsto_log_atTop.eventually_ge_atTop 1, hcut,
    Real.tendsto_log_atTop.eventually (eventually_crt_retained_window_log_products hδ),
    Real.tendsto_log_atTop.eventually eventually_crt_support_le,
    (tendsto_rpow_atTop (sub_pos.mpr hδε)).eventually_ge_atTop (2 * K)]
    with P hP hx hcut hprod hsupp hKlarge
  let x := Real.log P
  let W := ⌈5 * x⌉₊
  let primes := primesBetween P (2 * P)
  have hP₀ := zero_lt_one.trans hP
  have hx₀ : 0 < x := zero_lt_one.trans_le hx
  have hW : (W : ℝ) ≤ 6 * x := by
    have := Nat.ceil_lt_add_one (show 0 ≤ 5 * x by positivity)
    dsimp only [W]
    linarith
  have hTₓ (T : ℕ) (hT : (T : ℝ) ≤ x / 100) : (T : ℝ) < x := by linarith
  have hSmall : 6 * x < P := by
    change |Real.log P| ≤ (1 / 12 : ℝ) * |P| at hcut
    rw [abs_of_nonneg hx₀.le, abs_of_pos hP₀] at hcut
    dsimp only [x] at *
    linarith
  intro T hT S₁ S₂ hS₁ hS₂ hBad₁ hBad₂ hCover₁ hCover₂
  have hmem₁ (p : ℕ) (hp : p ∈ S₁) :
      x < (p : ℝ) ∧ (p : ℝ) ≤ (5 / 2) * x ∧ p.Prime :=
    (mem_primesBetween hx₀.le (by positivity)).mp (hS₁ hp)
  have hmem₂ (p : ℕ) (hp : p ∈ S₂) :
      3 * x < (p : ℝ) ∧ (p : ℝ) ≤ (9 / 2) * x ∧ p.Prime :=
    (mem_primesBetween (by positivity) (by positivity)).mp (hS₂ hp)
  have hDisj : Disjoint S₁ S₂ := disjoint_left.mpr fun p h₁ h₂ => by
    linarith [(hmem₁ p h₁).2.1, (hmem₂ p h₂).1]
  have hBound (p : ℕ) (hpx : x < (p : ℝ)) (hpx' : (p : ℝ) ≤ 5 * x) :
      T < p ∧ p ≤ W := by
    constructor
    · exact_mod_cast (hTₓ T hT).trans hpx
    · exact_mod_cast hpx'.trans (Nat.le_ceil _)
  have hS₁' (p : ℕ) (hp : p ∈ S₁) : p.Prime ∧ T < p ∧ p ≤ W := by
    refine ⟨(hmem₁ p hp).2.2, hBound p (hmem₁ p hp).1 ?_⟩
    linarith [(hmem₁ p hp).2.1]
  have hS₂' (p : ℕ) (hp : p ∈ S₂) : p.Prime ∧ T < p ∧ p ≤ W := by
    refine ⟨(hmem₂ p hp).2.2, hBound p ?_ ?_⟩
    · linarith [(hmem₂ p hp).1]
    · linarith [(hmem₂ p hp).2.1]
  have hmem (p : ℕ) (hp : p ∈ primes) : P < (p : ℝ) ∧ (p : ℝ) ≤ 2 * P ∧ p.Prime :=
    (mem_primesBetween hP₀.le (by positivity)).mp hp
  have hprim (p : ℕ) (hp : p ∈ primes) : p.Prime ∧ max W T < p := by
    refine ⟨(hmem p hp).2.2, max_lt (by exact_mod_cast hW.trans_lt (hSmall.trans (hmem p hp).1)) ?_⟩
    exact_mod_cast (hTₓ T hT).trans (by linarith [(hmem p hp).1] : x < (p : ℝ))
  let M₁ := ∏ p ∈ S₁, p
  let M₂ := ∏ p ∈ S₂, p
  obtain ⟨hM₁, hM₂⟩ := hprod S₁ S₂ hS₁ hS₂ hBad₁ hBad₂
  have hM₁₀ : 0 < M₁ := Finset.prod_pos fun p hp => (hS₁' p hp).1.pos
  have hM₂₀ : 0 < M₂ := Finset.prod_pos fun p hp => (hS₂' p hp).1.pos
  have hMH {M : ℕ} (hM : |Real.log (M : ℝ) - (3 / 2 : ℝ) * x| ≤ δ * x) :
      Real.log (M : ℝ) ≤ (7 / 4 : ℝ) * x := by
    linarith only [(abs_le.mp hM).2, mul_le_mul_of_nonneg_right hδ₁ hx₀.le]
  have hMLo {M : ℕ} (hM₀ : 0 < M)
      (hM : |Real.log (M : ℝ) - (3 / 2 : ℝ) * x| ≤ δ * x) :
      P ^ (3 / 2 - δ) ≤ (M : ℝ) := by
    rw [Real.rpow_def_of_pos hP₀, ← Real.le_log_iff_exp_le (by exact_mod_cast hM₀)]
    change x * (3 / 2 - δ) ≤ _
    linarith only [(abs_le.mp hM).1]
  have hmax : Real.log (↑(max M₁ M₂) : ℝ) ≤ (7 / 4 : ℝ) * x := by
    rcases le_total M₁ M₂ with h | h
    · simpa only [max_eq_right h] using hMH hM₂
    · simpa only [max_eq_left h] using hMH hM₁
  have hsupp' := hsupp T W (max M₁ M₂) hT hW (hM₁₀.trans_le (le_max_left _ _)) hmax
  have hExp : Real.exp (2 * x) = P ^ 2 := by
    rw [← Real.rpow_natCast P 2, Real.rpow_def_of_pos hP₀]
    norm_num [x, mul_comm]
  rw [hExp] at hsupp'
  have hP₂ : 1 ≤ P ^ 2 := one_le_pow₀ hP.le
  have henergy (A : Finset ℤ) (hA : ∀ a ∈ A, 0 ≤ a ∧
      (a : ℚ) ≤ ((max M₁ M₂ * Nat.lcmUpto T : ℕ) : ℚ) * harmonic (W * T)) :
      ∑ i ∈ primeFrequencyPairs primes, primeFrequencyPairEnergy A i ≤ (K * P ^ 2) * (A.card : ℝ) := by
    refine (sum_primeFrequencyPairEnergy_le hP.le primes (fun p hp => (hmem p hp).2.2)
      (fun p hp => (hmem p hp).2.1) A (sq_nonneg P) (fun a ha => ?_)).trans ?_
    · rw [abs_of_nonneg (by exact_mod_cast (hA a ha).1)]
      have ha' : (a : ℝ) ≤
          ((max M₁ M₂ * Nat.lcmUpto T : ℕ) : ℝ) * (harmonic (W * T) : ℝ) := by
        exact_mod_cast (hA a ha).2
      exact ha'.trans hsupp'
    · apply mul_le_mul_of_nonneg_right _ (by positivity)
      dsimp only [K]
      nlinarith only [mul_nonneg Real.pi_pos.le (sub_nonneg.mpr hP₂)]
  have hCount := card_primeCofactorCoverExceptions_le_of_energy hDisj hS₁' hS₂'
    hprim hCover₁ hCover₂ henergy
  have hDiv {M : ℕ} (hM : P ^ (3 / 2 - δ) ≤ (M : ℝ)) :
      K * P ^ 2 / (M : ℝ) ≤ K * P ^ (1 / 2 + δ) := calc
    _ ≤ K * P ^ 2 / (P ^ (3 / 2 - δ)) :=
      div_le_div_of_nonneg_left (mul_nonneg hK (sq_nonneg P)) (Real.rpow_pos_of_pos hP₀ _) hM
    _ = _ := by
      rw [mul_div_assoc, ← Real.rpow_natCast P 2, ← Real.rpow_sub hP₀]
      norm_num
      ring_nf
      trivial
  exact hCount.trans ((add_le_add (hDiv (hMLo hM₁₀ hM₁)) (hDiv (hMLo hM₂₀ hM₂))).trans (calc
    K * P ^ (1 / 2 + δ) + K * P ^ (1 / 2 + δ) = (2 * K) * P ^ (1 / 2 + δ) := by ring
    _ ≤ P ^ (ε - δ) * P ^ (1 / 2 + δ) := mul_le_mul_of_nonneg_right hKlarge (by positivity)
    _ = P ^ (1 / 2 + ε) := by rw [← Real.rpow_add hP₀]; ring_nf))

/-- The dyadic exception bound for a height function. -/
def HasAverageReciprocalCover (height : ℝ → ℕ) : Prop :=
  ∀ ε : ℝ, 0 < ε → ∀ᶠ P : ℝ in atTop,
    ((reciprocalCoverExceptions (primesBetween P (2 * P)) (height P)).card : ℝ) ≤
      P ^ (1 / 2 + ε)

private theorem reciprocalCover_mono {p a b : ℕ} (hab : a ≤ b)
    (h : CoversResidues p (interval 1 a)) : CoversResidues p (interval 1 b) := by
  intro v
  obtain ⟨S, hS, hsum⟩ := h v
  exact ⟨S, hS.trans (Icc_subset_Icc_right hab), hsum⟩

/-- The pointwise Fourier bound provides the base of the dyadic lift. -/
theorem hasAverageReciprocalCover_pointwise : HasAverageReciprocalCover pointwiseCoverHeight := by
  intro ε _
  obtain ⟨n, h⟩ := eventually_atTop.mp eventually_pointwise_reciprocal_cover
  filter_upwards [eventually_ge_atTop (max 1 (n : ℝ))] with P hP
  have hP₁ := (le_max_left (1 : ℝ) n).trans hP
  have hzero : reciprocalCoverExceptions (primesBetween P (2 * P)) (pointwiseCoverHeight P) = ∅ := by
    classical
    apply eq_empty_iff_forall_notMem.mpr
    intro p hp
    obtain ⟨hp, hbad⟩ := mem_filter.mp (show p ∈ (primesBetween P (2 * P)).filter _ from hp)
    obtain ⟨hlo, hhi, hprime⟩ := (mem_primesBetween (zero_le_one.trans hP₁) (by positivity)).mp hp
    have hn : n ≤ p := by exact_mod_cast (le_max_right (1 : ℝ) n).trans (hP.trans hlo.le)
    have hpLog : 0 ≤ Real.log (p : ℝ) := Real.log_nonneg (hP₁.trans hlo.le)
    have hlog := Real.log_le_log (zero_lt_one.trans_le (hP₁.trans hlo.le)) hhi
    exact hbad (reciprocalCover_mono (Nat.ceil_le_ceil (pow_le_pow_left₀ hpLog hlog 4))
      (h p hn hprime))
  rw [hzero, card_empty, Nat.cast_zero]
  exact Real.rpow_nonneg (zero_le_one.trans hP₁) _

/-- A height with the dyadic exception bound can be lifted through both
auxiliary windows, provided it is nondecreasing on a tail and grows slowly. -/
theorem HasAverageReciprocalCover.lift {f : ℝ → ℕ} (hf : HasAverageReciprocalCover f)
    {Y : ℝ} (hmono : MonotoneOn f (Set.Ici Y))
    (hGrowth : ∀ᶠ x : ℝ in atTop, (f (4 * x) : ℝ) ≤ x / 100) :
    HasAverageReciprocalCover (liftedCoverHeight f) := by
  classical
  intro ε hε
  have hBase : ∀ᶠ P : ℝ in atTop,
      ((reciprocalCoverExceptions (primesBetween P (2 * P)) (f P)).card : ℝ) ≤
        P ^ (5 / 8 : ℝ) := by
    simpa only [show (1 / 2 + 1 / 8 : ℝ) = 5 / 8 by norm_num] using
      hf (1 / 8) (by norm_num)
  have hLog := Real.tendsto_log_atTop
  have hLog2 : Tendsto (fun P : ℝ => 2 * Real.log P) atTop atTop :=
    hLog.const_mul_atTop (by norm_num)
  have hLog4 : Tendsto (fun P : ℝ => 4 * Real.log P) atTop atTop :=
    hLog.const_mul_atTop (by norm_num)
  filter_upwards [hLog.eventually_ge_atTop (max (1 : ℝ) Y), hLog.eventually hGrowth,
    hLog.eventually hBase, hLog2.eventually hBase, hLog4.eventually hBase,
    hLog.eventually eventually_dyadic_bad_count,
    eventually_reciprocalCoverExceptions_le_of_window_covers hε]
    with P hY hg h₁ h₂ h₄ hd hLift
  let x := Real.log P
  have hx₁ : 1 ≤ x := (le_max_left _ _).trans hY
  have hxY : Y ≤ x := (le_max_right _ _).trans hY
  let T := f (4 * x)
  let bad (p : ℕ) : Prop := ¬ CoversResidues p (interval 1 T)
  have hCount {l r : ℝ} (hl : Y ≤ l) (hr : l ≤ 4 * x)
      (h : ((reciprocalCoverExceptions (primesBetween l r) (f l)).card : ℝ) ≤
        l ^ (5 / 8 : ℝ)) : (((primesBetween l r).filter bad).card : ℝ) ≤ l ^ (5 / 8 : ℝ) := by
    have hle : f l ≤ T := hmono hl (hl.trans hr) hr
    have hsub : (primesBetween l r).filter bad ⊆
        reciprocalCoverExceptions (primesBetween l r) (f l) := by
      intro p hp
      obtain ⟨hp, hn⟩ := mem_filter.mp hp
      show p ∈ (primesBetween l r).filter _
      exact mem_filter.mpr ⟨hp, fun hc => hn (reciprocalCover_mono hle hc)⟩
    exact (by exact_mod_cast card_le_card hsub : (_ : ℝ) ≤ (_ : ℝ)).trans h
  have h₂' : ((reciprocalCoverExceptions (primesBetween (2 * x) (4 * x)) (f (2 * x))).card : ℝ) ≤
      (2 * x) ^ (5 / 8 : ℝ) := by
    simpa only [x, show (2 : ℝ) * (2 * Real.log P) = 4 * Real.log P by ring] using h₂
  have h₄' : ((reciprocalCoverExceptions (primesBetween (4 * x) (8 * x)) (f (4 * x))).card : ℝ) ≤
      (4 * x) ^ (5 / 8 : ℝ) := by
    simpa only [x, show (2 : ℝ) * (4 * Real.log P) = 8 * Real.log P by ring] using h₄
  have hWindow := hd bad (hCount hxY (by linarith) h₁)
    (hCount (by linarith) (by linarith) h₂') (hCount (by linarith) le_rfl h₄')
  let W₁ := primesBetween x ((5 / 2 : ℝ) * x)
  let W₂ := primesBetween (3 * x) ((9 / 2 : ℝ) * x)
  let S₁ := W₁.filter fun p => CoversResidues p (interval 1 T)
  let S₂ := W₂.filter fun p => CoversResidues p (interval 1 T)
  have hdiff (S : Finset ℕ) : S \ (S.filter fun p => CoversResidues p (interval 1 T)) =
      S.filter bad := by
    ext p
    constructor
    · intro hp
      obtain ⟨hp, hn⟩ := Finset.mem_sdiff.mp hp
      exact mem_filter.mpr ⟨hp, fun hc => hn (mem_filter.mpr ⟨hp, hc⟩)⟩
    · intro hp
      obtain ⟨hp, hn⟩ := mem_filter.mp hp
      exact Finset.mem_sdiff.mpr ⟨hp, fun hk => hn (mem_filter.mp hk).2⟩
  exact hLift T hg S₁ S₂ (filter_subset _ _) (filter_subset _ _)
    (by rw [hdiff]; exact hWindow.1) (by rw [hdiff]; exact hWindow.2)
    (fun _ hp => (mem_filter.mp hp).2) (fun _ hp => (mem_filter.mp hp).2)

/-- Two lifts give the average cover at the twice-lifted explicit height. -/
theorem hasAverageReciprocalCover_twice :
    HasAverageReciprocalCover (liftedCoverHeight (liftedCoverHeight pointwiseCoverHeight)) :=
  (hasAverageReciprocalCover_pointwise.lift pointwiseCoverHeight_monotoneOn
    eventually_pointwiseCoverHeight_four_mul_le).lift
    (liftedCoverHeight_monotoneOn pointwiseCoverHeight_monotoneOn)
    eventually_liftedPointwiseCoverHeight_four_mul_le

/-- The F2 almost-all-primes cover, with the dyadic endpoints, exponent
`1/2 + ε` for every `ε > 0`, and the stated iterated logarithmic height. -/
theorem eventually_average_reciprocal_cover :
    ∃ C : ℝ, 0 < C ∧ ∀ ε : ℝ, 0 < ε → ∀ᶠ P : ℝ in atTop,
      ∃ B : Finset ℕ, (B.card : ℝ) ≤ P ^ (1 / 2 + ε) ∧
        ∀ p : ℕ, p.Prime → P ≤ (p : ℝ) → (p : ℝ) ≤ 2 * P → p ∉ B →
          ∃ q : ℕ, q < p ∧
            (q : ℝ) ≤ C * Real.log P * Real.log (Real.log P) *
              Real.log (Real.log (Real.log P)) ^ 4 ∧
            CoversResidues p (interval 1 q) := by
  obtain ⟨C, hC, hGrowth⟩ := eventually_twiceLiftedPointwiseCoverHeight_le
  refine ⟨C, hC, ?_⟩
  intro ε hε
  let f := liftedCoverHeight (liftedCoverHeight pointwiseCoverHeight)
  have hSmall := (isLittleO_log_rpow_rpow_atTop (s := (1 : ℝ)) 2 one_pos).bound
    (show (0 : ℝ) < 1 by norm_num)
  filter_upwards [hGrowth, hasAverageReciprocalCover_twice (ε / 2) (half_pos hε), hSmall,
    eventually_ge_atTop (1 : ℝ), Real.tendsto_log_atTop.eventually_ge_atTop 1,
    Real.tendsto_log_atTop.eventually eventually_liftedPointwiseCoverHeight_four_mul_le,
    (tendsto_rpow_atTop (half_pos hε)).eventually_ge_atTop 2]
    with P hG hExc hS hP hLog hF hEl
  classical
  let E := reciprocalCoverExceptions (primesBetween P (2 * P)) (f P)
  refine ⟨insert ⌈P⌉₊ E, ?_, ?_⟩
  · have hCard : ((insert ⌈P⌉₊ E).card : ℝ) ≤ (E.card : ℝ) + 1 := by
      exact_mod_cast card_insert_le ⌈P⌉₊ E
    have hPow : 1 ≤ P ^ (1 / 2 + ε / 2) := calc
      1 = (1 : ℝ) ^ (1 / 2 + ε / 2) := (Real.one_rpow _).symm
      _ ≤ _ := Real.rpow_le_rpow zero_le_one hP (by positivity)
    calc
      _ ≤ (E.card : ℝ) + 1 := hCard
      _ ≤ P ^ (1 / 2 + ε / 2) + 1 := add_le_add hExc le_rfl
      _ ≤ P ^ (1 / 2 + ε / 2) * 2 := by linarith
      _ ≤ P ^ (1 / 2 + ε / 2) * P ^ (ε / 2) :=
        mul_le_mul_of_nonneg_left hEl (zero_le_one.trans hPow)
      _ = _ := by rw [← Real.rpow_add (zero_lt_one.trans_le hP)]; ring_nf
  · intro p hp h₁ h₂ hnot
    have h₁' : P < (p : ℝ) := by
      refine lt_of_le_of_ne h₁ fun hEq => hnot ?_
      rw [hEq, Nat.ceil_natCast]
      exact mem_insert_self _ _
    have hpE : p ∉ E := fun h => hnot (mem_insert_of_mem h)
    have hcover : CoversResidues p (interval 1 (f P)) := by
      by_contra h
      apply hpE
      show p ∈ (primesBetween P (2 * P)).filter _
      exact mem_filter.mpr ⟨(mem_primesBetween (zero_le_one.trans hP) (by positivity)).mpr
        ⟨h₁', h₂, hp⟩, h⟩
    refine ⟨f P, ?_, hG, hcover⟩
    have hU : (⌈5 * Real.log P⌉₊ : ℝ) ≤ 6 * Real.log P := by
      have := Nat.ceil_lt_add_one (show 0 ≤ 5 * Real.log P by positivity)
      linarith
    have hLog₂ : Real.log P ^ 2 ≤ P := by
      change |Real.log P ^ 2| ≤ 1 * |P ^ (1 : ℝ)| at hS
      rw [Real.rpow_one, abs_of_nonneg (zero_le_one.trans hP), one_mul] at hS
      exact (le_abs_self _).trans (by
        simpa only [Real.rpow_two] using hS)
    have hlt : (f P : ℝ) < P := calc
      _ = (⌈5 * Real.log P⌉₊ : ℝ) *
          (liftedCoverHeight pointwiseCoverHeight (4 * Real.log P) : ℝ) := by
        simp only [f, liftedCoverHeight, Nat.cast_mul]
      _ ≤ (6 * Real.log P) * (Real.log P / 100) :=
        mul_le_mul hU hF (Nat.cast_nonneg _) (by positivity)
      _ < Real.log P ^ 2 := by nlinarith
      _ ≤ P := hLog₂
    exact_mod_cast hlt.trans h₁'

end LeanAB.PaperB.Closure
