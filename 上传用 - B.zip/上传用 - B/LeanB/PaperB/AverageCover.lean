module

public import PaperB.Coverage
import Mathlib.Algebra.Order.Chebyshev
import Mathlib.Basic.Complex.BigOperators
import Mathlib.Tactic

@[expose] public section

/-! Finite Fourier energy and the exceptional-count deduction used in the average cover. -/

namespace LeanAB.PaperB.Closure

open AddChar
open scoped BigOperators ComplexConjugate

/-- Unnormalized Fourier coefficients of the residue multiplicities. -/
noncomputable def residueFourier {p : ℕ} [NeZero p] (f : ZMod p → ℝ) (h : ZMod p) : ℂ :=
  ∑ x : ZMod p, ZMod.stdAddChar (h * x) * (f x : ℂ)

private theorem conj_stdAddChar {p : ℕ} [NeZero p] (x : ZMod p) :
    conj (ZMod.stdAddChar x) = ZMod.stdAddChar (-x) := by
  rw [map_neg_eq_inv]
  let w := ZMod.stdAddChar x
  change conj w = w⁻¹
  have hw₁ : ‖w‖ = 1 := AddChar.norm_apply _ _
  have hw₀ : w ≠ 0 := fun hz => by simp [hz] at hw₁
  have h := Complex.mul_conj w
  rw [Complex.normSq_eq_norm_sq, hw₁, one_pow, Complex.ofReal_one] at h
  calc
    _ = w⁻¹ * (w * conj w) := by rw [← mul_assoc, inv_mul_cancel₀ hw₀, one_mul]
    _ = _ := by rw [h, mul_one]

private theorem orthogonal_char_sum {p : ℕ} [NeZero p] (w : ZMod p) :
    ∑ h : ZMod p, ZMod.stdAddChar (h * w) = if w = 0 then (p : ℂ) else 0 := by
  split_ifs with hw
  · simp [hw, ZMod.card, map_zero_eq_one]
  · simpa only [mulShift_apply, mul_comm] using sum_eq_zero_of_ne_one
      (ZMod.isPrimitive_stdAddChar p hw)

theorem residueFourier_parseval {p : ℕ} [NeZero p] (f : ZMod p → ℝ) :
    ∑ h : ZMod p, ‖residueFourier f h‖ ^ 2 = (p : ℝ) * ∑ x : ZMod p, f x ^ 2 := by
  classical
  have hcoeff (h : ZMod p) :
      ((‖residueFourier f h‖ ^ 2 : ℝ) : ℂ) =
        ∑ x : ZMod p, ∑ y : ZMod p, ((f x : ℂ) * (f y : ℂ)) *
          ZMod.stdAddChar (h * (x - y)) := by
    rw [Complex.sq_norm, ← Complex.mul_conj, residueFourier, map_sum, Finset.sum_mul]
    refine Finset.sum_congr rfl fun x _ => ?_
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun y _ => ?_
    rw [map_mul (starRingEnd ℂ), Complex.conj_ofReal, conj_stdAddChar,
      show h * (x - y) = h * x + -(h * y) by ring, map_add_eq_mul]
    ring
  apply Complex.ofReal_injective
  simp only [Complex.ofReal_sum, Complex.ofReal_mul, Complex.ofReal_natCast, Complex.ofReal_pow,
    hcoeff]
  calc
    _ = ∑ x : ZMod p, ∑ y : ZMod p, ∑ h : ZMod p,
          ((f x : ℂ) * (f y : ℂ)) * ZMod.stdAddChar (h * (x - y)) := by
      rw [Finset.sum_comm]
      exact Finset.sum_congr rfl fun _ _ => Finset.sum_comm
    _ = ∑ x : ZMod p, (f x : ℂ) ^ 2 * p := by
      simp only [← Finset.mul_sum, orthogonal_char_sum, sub_eq_zero, mul_ite, mul_zero, pow_two]
      simp
    _ = _ := by rw [Finset.mul_sum]; simp only [mul_comm]

/-- An image of at most half the residues implies at least the squared total
mass in nonzero-frequency energy, as used in the large-sieve step. -/
theorem residueFourier_nonzero_energy_ge {p : ℕ} [NeZero p]
    (f : ZMod p → ℝ) (S : Finset (ZMod p))
    (hSupp : ∀ x ∉ S, f x = 0) (hS : 2 * S.card ≤ p) :
    (∑ x : ZMod p, f x) ^ 2 ≤
      ∑ h ∈ (Finset.univ : Finset (ZMod p)).erase 0, ‖residueFourier f h‖ ^ 2 := by
  classical
  have hsum : ∑ x ∈ S, f x = ∑ x : ZMod p, f x :=
    Finset.sum_subset (Finset.subset_univ _) (fun x _ hx => hSupp x hx)
  have hsq : ∑ x ∈ S, f x ^ 2 = ∑ x : ZMod p, f x ^ 2 :=
    Finset.sum_subset (Finset.subset_univ _) (fun x _ hx => by simp [hSupp x hx])
  have hc := sq_sum_le_card_mul_sum_sq (s := S) (f := f)
  rw [hsum, hsq] at hc
  have hSq : 2 * (∑ x : ZMod p, f x) ^ 2 ≤ (p : ℝ) * ∑ x : ZMod p, f x ^ 2 := calc
    _ ≤ 2 * ((S.card : ℝ) * ∑ x : ZMod p, f x ^ 2) :=
      mul_le_mul_of_nonneg_left hc zero_le_two
    _ = (2 * (S.card : ℝ)) * ∑ x : ZMod p, f x ^ 2 := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_right (by exact_mod_cast hS)
      (Finset.sum_nonneg fun x _ => sq_nonneg (f x))
  have hzero : ‖residueFourier f 0‖ ^ 2 = (∑ x : ZMod p, f x) ^ 2 := by
    rw [residueFourier]
    simp only [zero_mul, map_zero_eq_one, one_mul, ← Complex.ofReal_sum,
      Complex.norm_real, Real.norm_eq_abs, sq_abs]
  have hSplit := Finset.sum_erase_add (s := (Finset.univ : Finset (ZMod p)))
    (fun h => ‖residueFourier f h‖ ^ 2) (Finset.mem_univ 0)
  rw [residueFourier_parseval, hzero] at hSplit
  linarith

/-- The finite counting deduction from a large-sieve energy bound. -/
theorem card_exceptions_le_of_energy {ι : Type*} (indices : Finset ι)
    (energy : ι → ℝ) (mass : ℝ) (hmass : 0 < mass) (B : ℝ)
    (hbudget : ∑ i ∈ indices, energy i ≤ B * mass)
    (hlower : ∀ i ∈ indices, mass ^ 2 ≤ energy i) :
    (indices.card : ℝ) ≤ B / mass := by
  have hsum : (indices.card : ℝ) * mass ^ 2 ≤ B * mass := calc
    _ = ∑ _i ∈ indices, mass ^ 2 := by simp
    _ ≤ _ := (Finset.sum_le_sum hlower).trans hbudget
  apply (le_div_iff₀ hmass).mpr
  exact (mul_le_mul_iff_left₀ hmass).mp (by nlinarith)


/-- Multiplicity of a residue in an actual finite set of cleared integers. -/
noncomputable def integerResidueMultiplicity (p : ℕ) (A : Finset ℤ) (v : ZMod p) : ℝ :=
  ((A.filter fun x : ℤ => (x : ZMod p) = v).card : ℝ)

theorem sum_integerResidueMultiplicity (p : ℕ) [NeZero p] (A : Finset ℤ) :
    ∑ v : ZMod p, integerResidueMultiplicity p A v = A.card := by
  have h := Finset.card_eq_sum_card_fiberwise (s := A) (t := (Finset.univ : Finset (ZMod p)))
    (f := fun x : ℤ => (x : ZMod p)) (fun _ _ => Finset.mem_univ _)
  unfold integerResidueMultiplicity
  exact_mod_cast h.symm

theorem residueFourier_integerResidueMultiplicity (p : ℕ) [NeZero p] (A : Finset ℤ) (h : ZMod p) :
    residueFourier (integerResidueMultiplicity p A) h =
      ∑ a ∈ A, ZMod.stdAddChar (h * (a : ZMod p)) := by
  rw [residueFourier]
  calc
    _ = ∑ j : ZMod p, ∑ a ∈ A.filter (fun a : ℤ => (a : ZMod p) = j),
        ZMod.stdAddChar (h * j) := by
      apply Finset.sum_congr rfl
      intro j _
      simp [integerResidueMultiplicity, nsmul_eq_mul, mul_comm]
    _ = _ := Finset.sum_fiberwise_of_maps_to'
      (s := A) (t := (Finset.univ : Finset (ZMod p))) (g := fun a : ℤ => (a : ZMod p))
      (fun _ _ => Finset.mem_univ _) _

/-- The finite lower energy bound for a prime with at most half the residues occupied. -/
theorem integerSet_nonzero_energy_ge {p : ℕ} [NeZero p] (A : Finset ℤ)
    (hsmall : 2 * (A.image fun a : ℤ => (a : ZMod p)).card ≤ p) :
    (A.card : ℝ) ^ 2 ≤ ∑ h ∈ (Finset.univ : Finset (ZMod p)).erase 0,
      ‖∑ a ∈ A, ZMod.stdAddChar (h * (a : ZMod p))‖ ^ 2 := by
  have hs (v : ZMod p) (hv : v ∉ A.image fun a : ℤ => (a : ZMod p)) :
      integerResidueMultiplicity p A v = 0 := by
    have he : A.filter (fun a : ℤ => (a : ZMod p) = v) = ∅ := by
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro a ha
      obtain ⟨hA, he⟩ := Finset.mem_filter.mp ha
      exact hv (Finset.mem_image.mpr ⟨a, hA, he⟩)
    simp [integerResidueMultiplicity, he]
  have hf := residueFourier_nonzero_energy_ge _ _ hs hsmall
  rw [sum_integerResidueMultiplicity] at hf
  simpa only [residueFourier_integerResidueMultiplicity] using hf


/-- An integer code obtained by clearing the denominators of an actual subset. -/
def clearedCodes (D : ℕ) (pool : Finset ℕ) : Finset ℤ :=
  pool.powerset.image (fun S => ∑ a ∈ S, ((D / a : ℕ) : ℤ))

/-- Independent choices in disjoint blocks realize every prescribed vector
of cleared residues by a single subset of the actual pool. -/
theorem exists_crt_subset_for_residues (P : Finset ℕ)
    (blocks : P → Finset ℕ) (hDisjoint : Pairwise (fun p q => Disjoint (blocks p) (blocks q)))
    (D : ℕ)
    (hLocal : ∀ (p : P) (v : ZMod p.val), ∃ S ⊆ blocks p,
      (∑ a ∈ S, ((D / a : ℕ) : ZMod p.val)) = v)
    (hOther : ∀ (p q : P), p ≠ q → ∀ a ∈ blocks q, ((D / a : ℕ) : ZMod p.val) = 0)
    (r : ∀ p : P, ZMod p.val) :
    ∃ T ⊆ (Finset.univ : Finset P).biUnion blocks,
      ∀ p : P, (∑ a ∈ T, ((D / a : ℕ) : ZMod p.val)) = r p := by
  classical
  choose S hS hSub using fun p => hLocal p (r p)
  let T := (Finset.univ : Finset P).biUnion S
  have hpair : (↑(Finset.univ : Finset P) : Set P).PairwiseDisjoint S :=
    fun q _ p _ hqp => (hDisjoint hqp).mono (hS q) (hS p)
  refine ⟨T, Finset.biUnion_mono (fun p _ => hS p), fun p => ?_⟩
  dsimp only [T]
  rw [Finset.sum_biUnion hpair, Finset.sum_eq_single p]
  · exact hSub p
  · intro q _ hpq
    exact Finset.sum_eq_zero fun a ha => hOther p q hpq.symm a (hS q ha)
  · exact fun h => (h (Finset.mem_univ _)).elim



/-- Independent modular choices in disjoint blocks give a representative for
every vector of residues, with one distinct integer code for each vector. -/
theorem exists_crt_residue_representatives (P : Finset ℕ) (hP : ∀ p ∈ P, 0 < p)
    (blocks : P → Finset ℕ) (hDisjoint : Pairwise (fun p q => Disjoint (blocks p) (blocks q)))
    (D : ℕ)
    (hLocal : ∀ (p : P) (v : ZMod p.val), ∃ S ⊆ blocks p,
      (∑ a ∈ S, ((D / a : ℕ) : ZMod p.val)) = v)
    (hOther : ∀ (p q : P), p ≠ q → ∀ a ∈ blocks q, ((D / a : ℕ) : ZMod p.val) = 0) :
    ∃ A : Finset ℤ, A ⊆ clearedCodes D ((Finset.univ : Finset P).biUnion blocks) ∧
      A.card = ∏ p ∈ P, p := by
  classical
  let _ : ∀ p : P, NeZero p.val := fun p => ⟨(hP p.val p.property).ne'⟩
  let pool := (Finset.univ : Finset P).biUnion blocks
  let codes := clearedCodes D pool
  let residueOf (z : codes) (p : P) : ZMod p.val := (z.val : ZMod p.val)
  have hR : Function.Surjective residueOf := by
    intro x
    obtain ⟨T, hT, hResidues⟩ := exists_crt_subset_for_residues P blocks hDisjoint D hLocal hOther x
    let z : ℤ := ∑ a ∈ T, ((D / a : ℕ) : ℤ)
    have hz : z ∈ codes := Finset.mem_image.mpr ⟨T, Finset.mem_powerset.mpr hT, rfl⟩
    refine ⟨⟨z, hz⟩, funext fun p => ?_⟩
    change (z : ZMod p.val) = x p
    simpa only [z, Int.cast_sum, Int.cast_natCast] using hResidues p

  let repr (x : ∀ p : P, ZMod p.val) : codes := Classical.choose (hR x)
  have hrepr (x : ∀ p : P, ZMod p.val) : residueOf (repr x) = x :=
    Classical.choose_spec (hR x)
  have hinj : Function.Injective (fun x => (repr x).val) := by
    intro x y h
    have hh := congrArg residueOf (Subtype.ext h : repr x = repr y)
    rwa [hrepr, hrepr] at hh
  refine ⟨Finset.univ.image (fun x => (repr x).val), ?_, ?_⟩
  · intro z hz
    obtain ⟨x, _, rfl⟩ := Finset.mem_image.mp hz
    exact (repr x).property
  · rw [Finset.card_image_of_injective _ hinj, Finset.card_univ, Fintype.card_pi]
    simp only [ZMod.card]
    exact Finset.prod_coe_sort P id

end LeanAB.PaperB.Closure
