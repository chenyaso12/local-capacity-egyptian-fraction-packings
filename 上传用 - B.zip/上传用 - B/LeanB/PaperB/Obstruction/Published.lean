module

public import PaperB.Obstruction
public import Common.StrongPNT

/-! The necessary side of the packing theorem, with the quantitative prime
number theorem supplied by the pinned PNT+ proof. -/

public section

open Filter Asymptotics
open scoped BigOperators Topology

namespace LeanAB.PaperB

/-- The quantitative large-prime mass estimate on eligible logarithmic windows. -/
theorem eventually_windowPrimeMass_error :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ w : ℝ,
      1 ≤ w → 2 * w ≤ Real.log N → w ^ 2 ≤ Real.log N →
      |windowPrimeMass N w - w ^ 2 / (2 * Real.log N)| ≤ C * w / Real.log N :=
  eventually_windowPrimeMass_error_of_theta thetaLogSquaredError_pntPlus

/-- Necessary side of the F2 simultaneous rational packing theorem.
The estimate is uniform in the target list, including its length and reduced denominators. -/
theorem eventually_packing_necessary (d : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      ∀ {m : ℕ} (r : Fin m → ℚ) (S : Fin m → Finset ℕ),
      Pairwise (fun i j => Disjoint (S i) (S j)) →
      (∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧ (r i).den ∣ permittedDenominator N) →
      ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) -
        (Real.log (Real.log N)) ^ 2 / (2 * Real.log N) +
          C * Real.log (Real.log N) / Real.log N :=
  eventually_packing_necessary_of_theta thetaLogSquaredError_pntPlus d


/-- The F2 large-prime mass estimate, with the constant chosen before the
height and all windows satisfying the given logarithmic bound. -/
theorem eventually_windowPrimeMass_error_loglog (K : ℝ) (hK : 0 ≤ K) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ w : ℝ,
      |w - Real.log (Real.log N)| ≤ K * Real.log (Real.log (Real.log N)) →
      |windowPrimeMass N w - w ^ 2 / (2 * Real.log N)| ≤
        C * Real.log (Real.log N) / Real.log N :=
  eventually_windowPrimeMass_error_loglog_of_theta thetaLogSquaredError_pntPlus K hK

end LeanAB.PaperB
