module

public import PaperB.Capacity
public import Common.PrimeBounds
public import Mathlib.NumberTheory.AbelSummation
public import Mathlib.MeasureTheory.Integral.IntervalIntegral.IntegrationByParts
public import Mathlib.NumberTheory.Harmonic.Bounds
import Mathlib.Algebra.Order.Floor.Semifield
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
meta import Mathlib.Tactic

/-! Quantitative summation tools for the mass of the high-prime blocks. -/

@[expose] public section

open Finset Filter MeasureTheory
open scoped BigOperators Interval Topology

namespace LeanAB.PaperB

/-- The primes in the interval (a,b]. For nonnegative a, the floors retain the
open left boundary and closed right boundary. -/
noncomputable def primesBetween (a b : ℝ) : Finset ℕ :=
  (Finset.Ioc ⌊a⌋₊ ⌊b⌋₊).filter Nat.Prime

theorem mem_primesBetween {a b : ℝ} {p : ℕ} (ha : 0 ≤ a) (hb : 0 ≤ b) :
    p ∈ primesBetween a b ↔ a < (p : ℝ) ∧ (p : ℝ) ≤ b ∧ p.Prime := by
  rw [primesBetween, mem_filter, mem_Ioc, Nat.floor_lt ha, Nat.le_floor_iff hb, and_assoc]

/-- Quantitative Abel summation for a nonnegative decreasing weight. An
error at most δt in the Chebyshev function gives an explicit bound
including the left endpoint. -/
theorem abs_weighted_prime_sum_sub_integral_le {a b δ : ℝ} {f f' : ℝ → ℝ}
    (ha : 0 ≤ a) (hab : a ≤ b)
    (hDeriv : ∀ t ∈ Set.Icc a b, HasDerivAt f (f' t) t)
    (hDerivCont : ContinuousOn f' (Set.Icc a b))
    (hF : ∀ t ∈ Set.Icc a b, 0 ≤ f t)
    (hF' : ∀ t ∈ Set.Icc a b, f' t ≤ 0)
    (hθ : ∀ t ∈ Set.Icc a b, |Chebyshev.theta t - t| ≤ δ * t) :
    |(∑ p ∈ primesBetween a b, f p * Real.log p) - ∫ t in a..b, f t| ≤
      δ * ((∫ t in a..b, f t) + 2 * a * f a) := by
  classical
  let c (k : ℕ) : ℝ := if k.Prime then Real.log k else 0
  have hC (t : ℝ) : (∑ k ∈ Icc 0 ⌊t⌋₊, c k) = Chebyshev.theta t := by
    rw [Chebyshev.theta_eq_sum_Icc, sum_filter]
  have hD (t : ℝ) (ht : t ∈ Set.Icc a b) : deriv f t = f' t := (hDeriv t ht).deriv
  have hContD : ContinuousOn (deriv f) (Set.Icc a b) :=
    hDerivCont.congr (fun t ht => hD t ht)
  have hFcont : ContinuousOn f (Set.Icc a b) :=
    fun t ht => (hDeriv t ht).continuousAt.continuousWithinAt
  have hIntD : IntegrableOn (deriv f) (Set.Icc a b) := hContD.integrableOn_Icc
  have hAbel := sum_mul_eq_sub_sub_integral_mul c ha hab
    (fun t ht => (hDeriv t ht).differentiableAt) hIntD
  rw [← intervalIntegral.integral_of_le hab] at hAbel
  simp_rw [hC] at hAbel
  have hSum :
      (∑ p ∈ primesBetween a b, f p * Real.log p) =
        f b * Chebyshev.theta b - f a * Chebyshev.theta a -
          ∫ t in a..b, deriv f t * Chebyshev.theta t := by
    simpa only [primesBetween, sum_filter, c, mul_ite, mul_zero] using hAbel
  have hIntTheta : IntervalIntegrable (fun t => deriv f t * Chebyshev.theta t) volume a b := by
    rw [intervalIntegrable_iff_integrableOn_Icc_of_le hab]
    simpa only [hC] using integrableOn_mul_sum_Icc c (m := 0) ha hIntD
  have hIntDT : IntervalIntegrable (fun t => deriv f t * t) volume a b :=
    (hContD.mul continuous_id.continuousOn).intervalIntegrable_of_Icc hab
  have hIntF : IntervalIntegrable f volume a b := hFcont.intervalIntegrable_of_Icc hab
  have hIntD' : IntervalIntegrable (deriv f) volume a b := hContD.intervalIntegrable_of_Icc hab
  have hParts :
      (∫ t in a..b, deriv f t * t) = f b * b - f a * a - ∫ t in a..b, f t := by
    have h := intervalIntegral.integral_deriv_mul_eq_sub_of_hasDerivAt
      (by rwa [Set.uIcc_of_le hab]) (show ContinuousOn (fun t : ℝ => t) [[a,b]] from
        continuous_id.continuousOn)
      (fun t (ht : t ∈ Set.Ioo (min a b) (max a b)) => by
        have hcc : t ∈ Set.Icc a b := by
          rw [min_eq_left hab, max_eq_right hab] at ht
          exact Set.Ioo_subset_Icc_self ht
        rw [hD t hcc]
        exact hDeriv t hcc)
      (fun t _ => hasDerivAt_id t) hIntD'
      (intervalIntegrable_const (c := (1 : ℝ)))
    simp only [mul_one] at h
    rw [intervalIntegral.integral_add hIntDT hIntF] at h
    exact eq_sub_of_add_eq h
  have hErr (t : ℝ) (ht : t ∈ Set.Icc a b) :
      (1 - δ) * t ≤ Chebyshev.theta t ∧ Chebyshev.theta t ≤ (1 + δ) * t := by
    obtain ⟨hl, hu⟩ := abs_le.mp (hθ t ht)
    constructor
    · nlinarith only [hl]
    · nlinarith only [hu]
  have hUpper :
      (1 + δ) * (∫ t in a..b, deriv f t * t) ≤
        ∫ t in a..b, deriv f t * Chebyshev.theta t := by
    rw [← intervalIntegral.integral_const_mul]
    exact intervalIntegral.integral_mono_on hab (hIntDT.const_mul _) hIntTheta fun t ht => by
      rw [mul_left_comm]
      exact mul_le_mul_of_nonpos_left (hErr t ht).2 (by simpa only [hD t ht] using hF' t ht)
  have hLower :
      (∫ t in a..b, deriv f t * Chebyshev.theta t) ≤
        (1 - δ) * (∫ t in a..b, deriv f t * t) := by
    rw [← intervalIntegral.integral_const_mul]
    exact intervalIntegral.integral_mono_on hab hIntTheta (hIntDT.const_mul _) fun t ht => by
      rw [mul_left_comm (1 - δ)]
      exact mul_le_mul_of_nonpos_left (hErr t ht).1 (by simpa only [hD t ht] using hF' t ht)
  have hFa := hF a ⟨le_rfl, hab⟩
  have hFb := hF b ⟨hab, le_rfl⟩
  obtain ⟨hθal, hθau⟩ := hErr a ⟨le_rfl, hab⟩
  obtain ⟨hθbl, hθbu⟩ := hErr b ⟨hab, le_rfl⟩
  rw [hSum, abs_le, hParts] at *
  constructor
  · nlinarith only [mul_le_mul_of_nonneg_left hθbl hFb, mul_le_mul_of_nonneg_left hθau hFa, hLower]
  · nlinarith only [mul_le_mul_of_nonneg_left hθbu hFb, mul_le_mul_of_nonneg_left hθal hFa, hUpper]


private noncomputable def blockWeight (x bonus t : ℝ) : ℝ :=
  (bonus + Real.log x - Real.log t) / (t * Real.log t)

private noncomputable def blockWeightDeriv (x bonus t : ℝ) : ℝ :=
  (-t⁻¹ * (t * Real.log t) - (bonus + Real.log x - Real.log t) * (Real.log t + 1)) /
    (t * Real.log t) ^ 2

private theorem hasDerivAt_blockWeight (x bonus t : ℝ) (ht : 1 < t) :
    HasDerivAt (blockWeight x bonus) (blockWeightDeriv x bonus t) t := by
  have ht₀ : t ≠ 0 := (zero_lt_one.trans ht).ne'
  have hd : HasDerivAt (fun s : ℝ => s * Real.log s) (Real.log t + 1) t := by
    have h := (hasDerivAt_id t).mul (Real.hasDerivAt_log ht₀)
    change HasDerivAt (fun s : ℝ => s * Real.log s) (1 * Real.log t + t * t⁻¹) t at h
    simpa only [one_mul, mul_inv_cancel₀ ht₀] using h
  have hn : HasDerivAt (fun s => bonus + Real.log x - Real.log s) (-t⁻¹) t := by
    have h := (hasDerivAt_const t (bonus + Real.log x)).sub (Real.hasDerivAt_log ht₀)
    change HasDerivAt (fun s : ℝ => bonus + Real.log x - Real.log s) (0 - t⁻¹) t at h
    simpa only [zero_sub] using h
  exact hn.div hd (mul_ne_zero ht₀ (Real.log_pos ht).ne')

private theorem continuousOn_blockWeightDeriv {x bonus a : ℝ} (ha : 1 < a) :
    ContinuousOn (blockWeightDeriv x bonus) (Set.Icc a x) := by
  unfold blockWeightDeriv
  have ht₀ (t : ℝ) (ht : t ∈ Set.Icc a x) : t ≠ 0 :=
    (zero_lt_one.trans (ha.trans_le ht.1)).ne'
  have hlog : ContinuousOn Real.log (Set.Icc a x) :=
    fun t ht => (Real.continuousAt_log (ht₀ t ht)).continuousWithinAt
  have hid : ContinuousOn (fun t : ℝ => t) (Set.Icc a x) := continuous_id.continuousOn
  have hinv := hid.inv₀ (fun t ht => ht₀ t ht)
  exact ((hinv.neg.mul (hid.mul hlog)).sub
    ((continuousOn_const.sub hlog).mul (hlog.add continuousOn_const))).div
      ((hid.mul hlog).pow _) (fun t ht =>
        pow_ne_zero _ (mul_ne_zero (ht₀ t ht) (Real.log_pos (ha.trans_le ht.1)).ne'))

private theorem blockWeight_nonneg {x bonus a t : ℝ} (ha : 1 < a) (hbonus : 0 ≤ bonus)
    (ht : t ∈ Set.Icc a x) : 0 ≤ blockWeight x bonus t := by
  have htt : 1 < t := ha.trans_le ht.1
  have hlog := Real.log_le_log (zero_lt_one.trans htt) ht.2
  exact div_nonneg (by linarith) (mul_nonneg (zero_lt_one.trans htt).le (Real.log_pos htt).le)

private theorem blockWeightDeriv_nonpos {x bonus a t : ℝ} (ha : 1 < a) (hbonus : 0 ≤ bonus)
    (ht : t ∈ Set.Icc a x) : blockWeightDeriv x bonus t ≤ 0 := by
  have htt : 1 < t := ha.trans_le ht.1
  have ht₀ : 0 < t := zero_lt_one.trans htt
  have hl := Real.log_pos htt
  have hlog := Real.log_le_log ht₀ ht.2
  apply div_nonpos_of_nonpos_of_nonneg _ (sq_nonneg _)
  exact sub_nonpos.mpr ((mul_nonpos_of_nonpos_of_nonneg
    (neg_nonpos.mpr (inv_nonneg.mpr ht₀.le)) (by positivity)).trans
      (mul_nonneg (by linarith) (by positivity)))

private theorem integral_blockWeight_bounds {x a bonus : ℝ} (ha : 1 < a) (hax : a ≤ x)
    (hbonus : 0 ≤ bonus) :
    let w := Real.log x - Real.log a
    let J := bonus * w + w ^ 2 / 2
    J / Real.log x ≤ (∫ t in a..x, blockWeight x bonus t) ∧
      (∫ t in a..x, blockWeight x bonus t) ≤ J / Real.log a := by
  dsimp
  let g (t : ℝ) := (bonus + Real.log x - Real.log t) / t
  have hlogCont : ContinuousOn Real.log (Set.Icc a x) :=
    fun t ht => (Real.continuousAt_log (zero_lt_one.trans (ha.trans_le ht.1)).ne').continuousWithinAt
  have hgCont : ContinuousOn g (Set.Icc a x) :=
    (continuousOn_const.sub hlogCont).div continuous_id.continuousOn
      (fun t ht => (zero_lt_one.trans (ha.trans_le ht.1)).ne')
  have hgInt : IntervalIntegrable g volume a x := hgCont.intervalIntegrable_of_Icc hax
  have hfCont : ContinuousOn (blockWeight x bonus) (Set.Icc a x) := fun t ht =>
    (hasDerivAt_blockWeight x bonus t (ha.trans_le ht.1)).continuousAt.continuousWithinAt
  have hfInt : IntervalIntegrable (blockWeight x bonus) volume a x :=
    hfCont.intervalIntegrable_of_Icc hax
  have hgDeriv : ∀ t ∈ Set.uIcc a x,
      HasDerivAt (fun s => (bonus + Real.log x) * Real.log s - (Real.log s)^2 / 2) (g t) t := by
    intro t ht
    rw [Set.uIcc_of_le hax] at ht
    have ht₀ : t ≠ 0 := (zero_lt_one.trans (ha.trans_le ht.1)).ne'
    have hlog := Real.hasDerivAt_log ht₀
    convert (hlog.const_mul (bonus + Real.log x)).sub ((hlog.pow 2).div_const 2) using 1
    simp only [g]
    ring
  have hIntegral : (∫ t in a..x, g t) =
      bonus * (Real.log x - Real.log a) + (Real.log x - Real.log a) ^ 2 / 2 := by
    rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hgDeriv hgInt]
    ring
  simp only [← hIntegral, ← intervalIntegral.integral_div]
  constructor
  · apply intervalIntegral.integral_mono_on hax (hgInt.div_const _) hfInt
    intro t ht
    have ht' : 1 < t := ha.trans_le ht.1
    have hlog := Real.log_le_log (zero_lt_one.trans ht') ht.2
    rw [blockWeight, ← div_div]
    apply div_le_div_of_nonneg_left _ (Real.log_pos ht') hlog
    exact div_nonneg (by linarith) (by positivity)
  · apply intervalIntegral.integral_mono_on hax hfInt (hgInt.div_const _)
    intro t ht
    have hlog := Real.log_le_log (zero_lt_one.trans ha) ht.1
    have hlog' := Real.log_le_log (zero_lt_one.trans (ha.trans_le ht.1)) ht.2
    rw [blockWeight, ← div_div]
    apply div_le_div_of_nonneg_left _ (Real.log_pos ha) hlog
    exact div_nonneg (by linarith) (zero_lt_one.trans (ha.trans_le ht.1)).le

private theorem weighted_prime_window_bounds {x a bonus δ : ℝ} (ha : 1 < a) (hax : a ≤ x)
    (hbonus : 0 ≤ bonus) (hδ : 0 ≤ δ) (hθ : ∀ t ∈ Set.Icc a x, |Chebyshev.theta t - t| ≤ δ * t) :
    let w := Real.log x - Real.log a
    let J := bonus * w + w ^ 2 / 2
    let Err := δ * (J / Real.log a + 2 * (bonus + w) / Real.log a)
    let S := ∑ p ∈ primesBetween a x, (bonus + Real.log x - Real.log p) / (p : ℝ)
    J / Real.log x - Err ≤ S ∧ S ≤ J / Real.log a + Err := by
  dsimp
  have ha₀ : 0 ≤ a := zero_le_one.trans ha.le
  have habs := abs_weighted_prime_sum_sub_integral_le (f := blockWeight x bonus)
    (f' := blockWeightDeriv x bonus) ha₀ hax
    (fun t ht => hasDerivAt_blockWeight _ _ _ (ha.trans_le ht.1))
    (continuousOn_blockWeightDeriv ha)
    (fun _ ht => blockWeight_nonneg ha hbonus ht)
    (fun _ ht => blockWeightDeriv_nonpos ha hbonus ht) hθ
  have hS : (∑ p ∈ primesBetween a x, blockWeight x bonus p * Real.log p) =
      ∑ p ∈ primesBetween a x, (bonus + Real.log x - Real.log p) / (p : ℝ) := by
    apply Finset.sum_congr rfl
    intro p hp
    have hlt := (mem_primesBetween ha₀ (ha₀.trans hax)).mp hp |>.1
    unfold blockWeight
    field_simp [(Real.log_pos (ha.trans hlt)).ne']
  have haWeight : 2 * a * blockWeight x bonus a = 2 * (bonus + (Real.log x - Real.log a)) / Real.log a := by
    unfold blockWeight
    field_simp [(zero_lt_one.trans ha).ne', (Real.log_pos ha).ne']
    ring
  rw [hS, haWeight] at habs
  obtain ⟨hIl, hIu⟩ := integral_blockWeight_bounds ha hax hbonus
  have herr := mul_le_mul_of_nonneg_left (add_le_add_left hIu
    (2 * (bonus + (Real.log x - Real.log a)) / Real.log a)) hδ
  obtain ⟨hSl, hSu⟩ := abs_le.mp (habs.trans herr)
  constructor <;> linarith only [hIl, hIu, hSl, hSu]

theorem mass_denominators_eq_harmonic (k : ℕ) : mass (denominators k) = harmonic k := by
  rw [mass, denominators, interval, max_self, harmonic]
  refine Finset.sum_bij' (fun a _ => a - 1) (fun a _ => a + 1) ?_ ?_ ?_ ?_ ?_
  · intro a ha
    obtain ⟨h₁, h₂⟩ := Finset.mem_Icc.mp ha
    exact Finset.mem_range.mpr (by omega)
  · intro a ha
    have := Finset.mem_range.mp ha
    exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩
  · intro a ha
    have := (Finset.mem_Icc.mp ha).1
    omega
  · intro a _
    omega
  · intro a ha
    have ha' := (Finset.mem_Icc.mp ha).1
    rw [show a - 1 + 1 = a by omega]

/-- The mass of all cofactor blocks of primes in (N exp(-w),N]. The prime blocks are
pairwise disjoint in the window used by the obstruction. -/
noncomputable def windowPrimeMass (N : ℕ) (w : ℝ) : ℝ :=
  ∑ p ∈ primesBetween ((N : ℝ) * Real.exp (-w)) N,
    (mass (cofactorBlock N p) : ℝ) / p

/-- Finite quantitative mass bound. The input is a pointwise relative error
bound for θ on the same interval; it is compatible with the PNT+ error estimate. -/
theorem abs_windowPrimeMass_sub_main_le {N : ℕ} {w δ : ℝ}
    (hw : 1 ≤ w) (hδ : 0 ≤ δ)
    (hHalf : 2 * w ≤ Real.log N) (hSmall : w ^ 2 ≤ Real.log N)
    (hθ : ∀ t ∈ Set.Icc ((N : ℝ) * Real.exp (-w)) N, |Chebyshev.theta t - t| ≤ δ * t) :
    |windowPrimeMass N w - w ^ 2 / (2 * Real.log N)| ≤ 3 * w / Real.log N + 7 * δ := by
  let x : ℝ := N
  let a := x * Real.exp (-w)
  let L := Real.log x
  have hL : 0 < L := by linarith
  have hx₀ : 0 < x := Nat.cast_pos.mpr (by
    by_contra! h
    have hn : N = 0 := by omega
    simp [L, x, hn] at hL)
  have ha₀ : 0 < a := by dsimp [a]; positivity
  have hlowa : L / 2 ≤ L - w := by linarith
  have haLog : Real.log a = L - w := by
    change Real.log (x * Real.exp (-w)) = L - w
    rw [Real.log_mul hx₀.ne' (Real.exp_pos _).ne', Real.log_exp]
    ring
  have ha : 1 < a := Real.log_pos_iff ha₀.le |>.mp (by rw [haLog]; linarith)
  have hax : a ≤ x := by
    apply mul_le_of_le_one_right hx₀.le
    exact Real.exp_le_one_iff.mpr (by linarith)
  have hwt : Real.log x - Real.log a = w := by rw [haLog]; ring
  have hLw : 0 < L - w := by linarith
  have hsumBounds :
      (∑ p ∈ primesBetween a x, (Real.log x - Real.log p) / (p : ℝ)) ≤ windowPrimeMass N w ∧
      windowPrimeMass N w ≤ (∑ p ∈ primesBetween a x,
        (1 + Real.log x - Real.log p) / (p : ℝ)) := by
    have hterm (p : ℕ) (hp : p ∈ primesBetween a x) :
        Real.log x - Real.log p ≤ (mass (cofactorBlock N p) : ℝ) ∧
          (mass (cofactorBlock N p) : ℝ) ≤ 1 + Real.log x - Real.log p := by
      obtain ⟨hap, hpN, _⟩ := (mem_primesBetween ha₀.le hx₀.le).mp hp
      have hp₀ : 0 < (p : ℝ) := ha₀.trans hap
      have hyr : 1 ≤ x / p := (le_div_iff₀ hp₀).mpr (by simpa using hpN)
      have hlog : Real.log (x / p) = Real.log x - Real.log p := Real.log_div hx₀.ne' hp₀.ne'
      rw [cofactorBlock, mass_denominators_eq_harmonic, ← Nat.floor_div_eq_div (K := ℝ), ← hlog]
      refine ⟨log_le_harmonic_floor _ (by positivity), ?_⟩
      rw [add_sub_assoc, ← hlog]
      exact harmonic_floor_le_one_add_log _ hyr
    exact ⟨Finset.sum_le_sum fun p hp => div_le_div_of_nonneg_right (hterm p hp).1 (by positivity),
      Finset.sum_le_sum fun p hp => div_le_div_of_nonneg_right (hterm p hp).2 (by positivity)⟩
  have hθ' : ∀ t ∈ Set.Icc a x, |Chebyshev.theta t - t| ≤ δ * t := hθ
  have hLo := (weighted_prime_window_bounds ha hax (bonus := 0) (by positivity) hδ hθ').1
  have hHi := (weighted_prime_window_bounds ha hax (bonus := 1) (by positivity) hδ hθ').2
  rw [hwt, haLog] at hLo hHi
  simp only [zero_mul, zero_add, one_mul] at hLo hHi
  have hsq : 0 ≤ w ^ 2 := sq_nonneg _
  have hW : 0 ≤ w := by linarith
  have hTerm : (w + w ^ 2 / 2) / (L - w) ≤ 3 := by
    apply (div_le_iff₀ hLw).mpr
    nlinarith only [hSmall, hHalf, sq_nonneg (w - 1)]
  have hEndpoint : 2 * (1 + w) / (L - w) ≤ 4 := by
    apply (div_le_iff₀ hLw).mpr
    nlinarith only [hHalf, hw]
  have hE1 := mul_le_mul_of_nonneg_left (add_le_add hTerm hEndpoint) hδ
  have hE0 : δ * (w ^ 2 / 2 / (L - w) + 2 * w / (L - w)) ≤ 7 * δ := by
    calc
      _ ≤ δ * ((w + w ^ 2 / 2) / (L - w) + 2 * (1 + w) / (L - w)) := by
        gcongr
        · exact le_add_of_nonneg_left hW
        · linarith
      _ ≤ _ := by linarith only [hE1]
  have hrecip : 1 / (L - w) ≤ 2 / L := by
    apply (div_le_div_iff₀ hLw hL).mpr
    linarith only [hHalf]
  have hMainUp : (w + w ^ 2 / 2) / (L - w) - w ^ 2 / (2 * L) ≤ 3 * w / L := by
    have hsplit : (w + w ^ 2 / 2) / (L - w) - w ^ 2 / (2 * L) =
        w / (L - w) + (w ^ 2 / L) * (w / (2 * (L - w))) := by
      field_simp [hL.ne', hLw.ne']
      ring
    have hWrat : w / (L - w) ≤ 2 * w / L := by
      rw [← mul_one_div, show 2 * w = w * 2 by ring, mul_div_assoc]
      exact mul_le_mul_of_nonneg_left hrecip hW
    have hWrat' : w / (2 * (L - w)) ≤ w / L :=
      div_le_div_of_nonneg_left hW hL (by linarith only [hHalf])
    rw [hsplit]
    refine (add_le_add hWrat (mul_le_mul ((div_le_one hL).mpr hSmall) hWrat'
      (by positivity) zero_le_one)).trans_eq ?_
    ring
  have hMainEq : w ^ 2 / 2 / L = w ^ 2 / (2 * L) := div_div ..
  rw [hMainEq] at hLo
  have hcoef : 0 ≤ 3 * w / L := by positivity
  obtain ⟨hSl, hSu⟩ := hsumBounds
  apply abs_le.mpr
  constructor
  · linarith only [hE0, hLo, hSl, hcoef]
  · linarith only [hE1, hHi, hSu, hMainUp]


/-- The left endpoint of a logarithmic half-window is at least the square root. -/
theorem sqrt_le_windowLeft {x w : ℝ} (hx : 0 < x) (hw : 2 * w ≤ Real.log x) :
    Real.sqrt x ≤ x * Real.exp (-w) := by
  calc
    Real.sqrt x = Real.exp (Real.log x / 2) := by
      rw [Real.sqrt_eq_rpow, Real.rpow_def_of_pos hx]
      congr 1
      ring
    _ ≤ Real.exp (Real.log x - w) :=
      Real.exp_le_exp.mpr (by linarith)
    _ = _ := by rw [sub_eq_add_neg, Real.exp_add, Real.exp_log hx]

/-- A single uniform constant controls the mass estimate for all eligible
logarithmic windows. The θ error is an explicit quantitative analytic input. -/
theorem eventually_windowPrimeMass_error_of_theta (h : ThetaLogSquaredError) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ w : ℝ,
      1 ≤ w → 2 * w ≤ Real.log N → w ^ 2 ≤ Real.log N →
      |windowPrimeMass N w - w ^ 2 / (2 * Real.log N)| ≤ C * w / Real.log N := by
  obtain ⟨B, hB, hev⟩ := h
  obtain ⟨T, hT⟩ := eventually_atTop.mp hev
  let T₀ := max T 0
  have hT₀ : 0 ≤ T₀ := le_max_right _ _
  refine ⟨3 + 28 * B, by positivity, ?_⟩
  filter_upwards [eventually_ge_atTop ⌈T₀ ^ 2⌉₊, eventually_ge_atTop (2 : ℕ)]
    with N hNT hN w hw hHalf hSmall
  let x : ℝ := N
  let L := Real.log x
  let a := x * Real.exp (-w)
  have hx₀ : 0 < x := by
    change (0 : ℝ) < (N : ℝ)
    exact_mod_cast (by omega : 0 < N)
  have hL : 0 < L := by linarith
  have hL₂ : 2 ≤ L := by linarith
  have hNBound : T₀ ^ 2 ≤ x := (Nat.le_ceil _).trans (by
    change ((⌈T₀ ^ 2⌉₊ : ℕ) : ℝ) ≤ (N : ℝ)
    exact_mod_cast hNT)
  have hleft : T ≤ a := (le_max_left T 0).trans
    (calc T₀ ≤ Real.sqrt x := (Real.le_sqrt hT₀ hx₀.le).mpr hNBound
          _ ≤ a := sqrt_le_windowLeft hx₀ hHalf)
  have ha₀ : 0 < a := mul_pos hx₀ (Real.exp_pos _)
  have haLog : Real.log a = L - w := by
    change Real.log (x * Real.exp (-w)) = L - w
    rw [Real.log_mul hx₀.ne' (Real.exp_pos _).ne', Real.log_exp, sub_eq_add_neg]
  have htheta (t : ℝ) (ht : t ∈ Set.Icc a x) :
      |Chebyshev.theta t - t| ≤ 4 * B / L ^ 2 * t := by
    have ht₀ := ha₀.trans_le ht.1
    have hLog₀ : 0 < L / 2 := by positivity
    have hLog : L / 2 ≤ Real.log t := by
      have := Real.log_le_log ha₀ ht.1
      linarith [haLog, hHalf]
    calc
      _ ≤ B * t / (Real.log t)^2 := hT t (hleft.trans ht.1)
      _ ≤ B * t / (L / 2)^2 := div_le_div_of_nonneg_left (mul_nonneg hB ht₀.le)
        (pow_pos hLog₀ _) (pow_le_pow_left₀ hLog₀.le hLog _)
      _ = _ := by ring
  have he := abs_windowPrimeMass_sub_main_le hw
    (show 0 ≤ 4 * B / L ^ 2 by positivity) hHalf hSmall htheta
  have hLt : 1 / L ≤ w :=
    (div_le_iff₀ hL).mpr (by nlinarith only [mul_le_mul_of_nonneg_right hw hL.le, hL₂])
  have h28 : (0 : ℝ) ≤ 28 * B / L := by positivity
  calc
    _ ≤ 3 * w / L + 7 * (4 * B / L ^ 2) := he
    _ = 3 * w / L + (1 / L) * (28 * B / L) := by ring
    _ ≤ 3 * w / L + w * (28 * B / L) :=
      add_le_add_right (mul_le_mul_of_nonneg_right hLt h28) _
    _ = _ := by ring


/-- In the logarithmic half-window the exact removed mass is the prime sum,
since every denominator belongs to at most one selected prime block. -/
theorem windowPrimeMass_eq_union_mass {N : ℕ} {w : ℝ} (hN : 0 < N)
    (hHalf : 2 * w ≤ Real.log N) :
    windowPrimeMass N w =
      (mass ((primesBetween ((N : ℝ) * Real.exp (-w)) N).biUnion
        (fun p => primePart p (denominators N))) : ℝ) := by
  let P := primesBetween ((N : ℝ) * Real.exp (-w)) N
  have hN₀ : (0 : ℝ) < N := by exact_mod_cast hN
  have hLeft := sqrt_le_windowLeft hN₀ hHalf
  have hP (p : ℕ) (hp : p ∈ P) : p ∈ largePrimes N := by
    obtain ⟨hpa, hpN, hp'⟩ := (mem_primesBetween (by positivity) hN₀.le).mp hp
    have hsp := hLeft.trans_lt hpa
    have hp₀ : (0 : ℝ) ≤ p := Nat.cast_nonneg p
    have hsq : (N : ℝ) < (p : ℝ) * p := by
      rw [← pow_two]
      exact (Real.sqrt_lt hN₀.le hp₀).mp hsp
    exact mem_largePrimes.mpr ⟨hp', by exact_mod_cast hpN, Nat.sqrt_lt.mpr (by exact_mod_cast hsq)⟩
  have hD : (↑P : Set ℕ).PairwiseDisjoint (fun p => primePart p (denominators N)) := by
    intro p hp q hq hne
    exact primePart_disjoint (hP p hp) (hP q hq) hne
  change (∑ p ∈ P, (mass (cofactorBlock N p) : ℝ) / p) = _
  rw [show mass (P.biUnion (fun p => primePart p (denominators N))) =
      ∑ p ∈ P, mass (primePart p (denominators N)) from Finset.sum_biUnion hD, Rat.cast_sum]
  apply Finset.sum_congr rfl
  intro p hp
  rw [mass_primePart (mem_largePrimes.mp (hP p hp)).1.pos, Rat.cast_div, Rat.cast_natCast]

/-- Quantified form of the F2 logarithmic window condition w = U + O(log U).
The error constant is chosen before N and w. -/
theorem eventually_windowPrimeMass_error_loglog_of_theta (hθ : ThetaLogSquaredError)
    (K : ℝ) (hK : 0 ≤ K) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ w : ℝ,
      |w - Real.log (Real.log N)| ≤ K * Real.log (Real.log (Real.log N)) →
      |windowPrimeMass N w - w ^ 2 / (2 * Real.log N)| ≤
        C * Real.log (Real.log N) / Real.log N := by
  obtain ⟨C, hC, hM⟩ := eventually_windowPrimeMass_error_of_theta hθ
  have hL : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hU := Real.tendsto_log_atTop.comp hL
  let ε := 1 / (2 * (K + 1))
  have hε : 0 < ε := by dsimp [ε]; positivity
  have hLogU := Real.isLittleO_log_id_atTop.bound hε
  have hLogL := (isLittleO_log_rpow_atTop (r := (1 / 2 : ℝ)) (by norm_num)).bound
    (show (0 : ℝ) < 1 / 2 by norm_num)
  refine ⟨2 * C, by positivity, ?_⟩
  filter_upwards [hM, hL.eventually_ge_atTop 4, hU.eventually_ge_atTop 2,
    hL.eventually hLogL, hU.eventually hLogU] with N hM hFour hTwo hq hRel w hClose
  let L := Real.log (N : ℝ)
  let U := Real.log L
  change 4 ≤ L at hFour
  change 2 ≤ U at hTwo
  change ‖U‖ ≤ (1 / 2 : ℝ) * ‖L ^ (1 / 2 : ℝ)‖ at hq
  change ‖Real.log U‖ ≤ ε * ‖U‖ at hRel
  have hL₀ : 0 ≤ L := by linarith only [hFour]
  have hU₀ : 0 ≤ U := by linarith only [hTwo]
  have hLogU₀ : 0 ≤ Real.log U := Real.log_nonneg (by linarith only [hTwo])
  have hq' : U ≤ (1 / 2 : ℝ) * Real.sqrt L := by
    simpa only [Real.norm_eq_abs, ← Real.sqrt_eq_rpow, abs_of_nonneg hU₀,
      abs_of_nonneg (Real.sqrt_nonneg L)] using hq
  have hRel' : Real.log U ≤ ε * U := by
    simpa only [Real.norm_eq_abs, abs_of_nonneg hLogU₀, abs_of_nonneg hU₀] using hRel
  have hKε : K * ε ≤ 1 / 2 := by
    dsimp [ε]
    rw [mul_one_div]
    exact (div_le_iff₀ (show (0 : ℝ) < 2 * (K + 1) by positivity)).mpr (by ring_nf; linarith)
  have hTol : K * Real.log U ≤ U / 2 := calc
    _ ≤ K * (ε * U) := mul_le_mul_of_nonneg_left hRel' hK
    _ = (K * ε) * U := by ring
    _ ≤ (1 / 2 : ℝ) * U := mul_le_mul_of_nonneg_right hKε hU₀
    _ = _ := by ring
  change |w - U| ≤ K * Real.log U at hClose
  obtain ⟨hLo, hHi⟩ := abs_le.mp hClose
  have hw : 1 ≤ w := by linarith only [hLo, hTol, hTwo]
  have hwU : w ≤ 2 * U := by linarith only [hHi, hTol, hU₀]
  have hws : w ≤ Real.sqrt L := by linarith only [hwU, hq']
  have hS : 2 ≤ Real.sqrt L := by
    have h := Real.sqrt_le_sqrt hFour
    simpa [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (show (0 : ℝ) ≤ 2 by norm_num)]
      using h
  have hs := Real.mul_self_sqrt hL₀
  have hHalf : 2 * w ≤ L := by
    linarith only [hws, hs,
      mul_le_mul_of_nonneg_right hS (Real.sqrt_nonneg L)]
  have hSmall : w ^ 2 ≤ L :=
    (pow_le_pow_left₀ (zero_le_one.trans hw) hws _).trans_eq (Real.sq_sqrt hL₀)
  calc
    _ ≤ C * w / L := hM w hw hHalf hSmall
    _ ≤ C * (2 * U) / L :=
      div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hwU hC.le) hL₀
    _ = _ := by ring


end LeanAB.PaperB
