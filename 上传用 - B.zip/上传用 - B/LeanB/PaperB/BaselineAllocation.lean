module

public import PaperB.NearCapacityAllocation
public import PaperB.RepairBudget
public import PaperB.TargetPadding
meta import Mathlib.Tactic

/-! Normalized greedy allocation for the baseline's changing list of targets. -/

@[expose] public section

open Finset Filter Asymptotics
open scoped Topology

namespace LeanAB.PaperB.Baseline

open Allocation Closure FixedTargets

/-- Allocate actual retained blocks under the two prefix bounds. The loss
from special groups is charged against their full target mass. -/
theorem allocate_of_prefix_bounds {d N m Q : ℕ} (hm : 0 < m)
    (F : Finset (Finset ℕ)) (E : Finset ℕ) (r : Fin m → ℚ)
    {a A δ η mean : ℚ} (ha : 0 < a) (hA : 0 ≤ A)
    (hr : ∀ i, a ≤ r i ∧ r i ≤ A ∧ (r i).den ∣ Q)
    (hδ : 0 < δ) (hη : 0 ≤ η) (hMean : 0 ≤ mean)
    (hGood : ∀ T ∈ F, T.Nonempty ∧ T ⊆ interval d N \ E ∧ (mass T).den ∣ Q ∧
      ((∃ n : ℕ, T = {n}) ∨ ((∀ n ∈ T, Nat.sqrt N < n) ∧ mass T ≤ a * η)))
    (hDisjoint : (↑F : Set (Finset ℕ)).PairwiseDisjoint id)
    (hTotal : ∑ i, r i ≤ ∑ T ∈ F, mass T)
    {X₁ X₂ D : ℕ} (hX₁ : 0 < X₁) (hX₁₂ : X₁ ≤ X₂) (hX₂ : X₂ ≤ Nat.sqrt N)
    (hD : 0 < D) (hEtaInv : 1 / (X₁ : ℚ) ≤ a * η)
    (hSurvivors : ∀ n ∈ interval d X₂ \ E, ∃ T ∈ F, n ∈ T)
    (hEarlyMass : mass (interval d X₁) ≤ mean * ∑ i, r i)
    (hEarlyLoad : mean + 1 / (a * (max 1 d : ℕ)) ≤ 1 - δ)
    (hRegularLoad : mean + 1 / (a * (D : ℚ)) ≤ 1 / 8)
    (hTargetMass : (D : ℚ) * A < ∑ i, r i)
    (hBaseMass : (1 / 8 + η) * (∑ i, r i) + (D : ℚ) * A <
      mass (interval d X₂) - mass E) :
    ∃ Base : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (Base i) (Base j)) ∧
      ∀ i, Base i ⊆ interval d N ∧ Disjoint (Base i) E ∧
        (r i - mass (Base i)).den ∣ Q ∧
        r i * δ ≤ r i - mass (Base i) ∧ r i - mass (Base i) ≤ r i * (δ + η) ∧
        ((Base i).card : ℚ) ≤ r i * (X₂ : ℚ) +
          (r i / ((∑ j, r j) - (D : ℚ) * A)) * N + 2 * r i * η * N := by
  classical
  let _ : Nonempty (Fin m) := ⟨⟨0,hm⟩⟩
  have hr₀ (i : Fin m) : 0 < r i := ha.trans_le (hr i).1
  obtain ⟨B, hImage, hInj⟩ := exists_sorted_blockList F
    (fun T hT => ⟨(hGood T hT).1, (hGood T hT).2.1.trans sdiff_subset⟩) hDisjoint
  have hMember (k : ℕ) (hk : k < B.length) : B.block k ∈ F :=
    hImage ▸ mem_image.mpr ⟨k, mem_range.mpr hk, rfl⟩
  have hShape (k : ℕ) (hk : k < B.length) :
      (∃ n : ℕ, B.block k = {n}) ∨
        ((∀ n ∈ B.block k, Nat.sqrt N < n) ∧ B.weight k ≤ a * η) :=
    (hGood _ (hMember k hk)).2.2.2
  have hSurv' (n : ℕ) (hn : n ∈ interval d X₂ \ E) : ∃ k < B.length, n ∈ B.block k := by
    obtain ⟨T,hT,hmem⟩ := hSurvivors n hn
    rw [← hImage] at hT
    obtain ⟨k, hk, rfl⟩ := mem_image.mp hT
    exact ⟨k,mem_range.mp hk,hmem⟩
  obtain ⟨early, base, he, hb, hSingleton, hEarly, hLater, hEffective, hLower⟩ :=
    nearCapacity_prefix_estimates B E hX₁ hX₁₂ hX₂ hEtaInv hShape hSurv'
  let special := B.specialGroups r early D
  let regular := (univ : Finset (Fin m)) \ special
  let R := ∑ i, r i
  let R₀ := ∑ i ∈ regular, r i
  let W := ∑ i ∈ special, r i
  let K := (D : ℚ) * A
  have hS : W ≤ K := B.sum_targets_specialGroups_le r (he.trans hb) D hA (fun i => (hr i).2.1)
  have hComplement : univ \ regular = special := by
    ext i
    simp [regular]
  have hSplit : R₀ + W = R := sum_sdiff (subset_univ special)
  have hW : 0 ≤ W := sum_nonneg (fun i _ => (hr₀ i).le)
  have hR₀ : R₀ ≤ R := by linarith only [hSplit,hW]
  have hR₀K : R - K ≤ R₀ := by linarith only [hSplit,hS]
  have hR₀pos : 0 < R₀ := (sub_pos.mpr hTargetMass).trans_le hR₀K
  have hCross : (1 / 8 + η) * R₀ + (∑ i ∈ univ \ regular, r i) <
      ∑ k ∈ range base, B.weight k := by
    rw [hComplement]
    exact (add_le_add (mul_le_mul_of_nonneg_left hR₀ (by positivity)) hS).trans_lt
      (hBaseMass.trans_le hLower)
  have hStored : (∑ i, r i) ≤ ∑ k ∈ range B.length, B.weight k := by
    have hh := sum_image (f := mass) hInj
    rw [hImage] at hh
    exact hTotal.trans_eq hh
  obtain ⟨t, _, ht, _, hDis, hOut⟩ := greedy_reciprocal_allocation B r hr₀
    (fun k hk => (hGood _ (hMember k hk)).2.2.1) (fun i => (hr i).2.2)
    he hb hδ hη (Nat.cast_nonneg X₂)
    (fun i => (B.initial_singleton_load_le r hr₀ (he.trans hb) hMean ha
      (hEarly.trans hEarlyMass) hSingleton i (hr i).1).trans hEarlyLoad)
    (fun k hek hk i => (div_le_iff₀ (hr₀ i)).mpr
      ((hLater k hek hk).trans (by
        rw [mul_comm a η]
        exact mul_le_mul_of_nonneg_left (hr i).1 hη)))
    hStored hEffective regular hR₀pos
    (fun i hi => (B.regular_initial_singleton_load_le r hr₀ hD hMean ha
      (hEarly.trans hEarlyMass) hSingleton i (hr i).1 ((mem_sdiff.mp hi).2)).trans hRegularLoad)
    hCross
  refine ⟨B.allocated r t, hDis, fun i => ⟨(hOut i).1, ?_, (hOut i).2.2.2.2.1,
    (hOut i).2.2.1, (hOut i).2.2.2.1, ?_⟩⟩
  · refine disjoint_left.mpr fun b hb hBE => ?_
    obtain ⟨k,hk,hbk⟩ := mem_biUnion.mp hb
    have hk' := (mem_range.mp (mem_filter.mp hk).1).trans_le ht
    exact (mem_sdiff.mp ((hGood _ (hMember k hk')).2.1 hbk)).2 hBE
  · have hx : r i / R₀ ≤ r i / (R - K) :=
      div_le_div_of_nonneg_left (hr₀ i).le (sub_pos.mpr hTargetMass) hR₀K
    exact (hOut i).2.2.2.2.2.trans (by
      linarith only [mul_le_mul_of_nonneg_right hx (Nat.cast_nonneg (α := ℚ) N)])

/-- The stopping margin is the reciprocal of the rounded L^6 scale. -/
noncomputable def delta (N : ℕ) : ℚ := (⌈(Real.log (N : ℝ)) ^ (6 : ℕ)⌉₊ : ℚ)⁻¹

/-- An upper bound on later increments, with room for the fixed lower target bound. -/
noncomputable def eta (N : ℕ) : ℚ := (⌊(Real.log (N : ℝ)) ^ (9 : ℕ)⌋₊ : ℚ)⁻¹

theorem eventually_residual_parameters :
    ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      0 < delta N ∧ 0 < eta N ∧ eta N ≤ delta N ∧
        1 / (2 * L ^ 6) ≤ (delta N : ℝ) ∧ (delta N : ℝ) ≤ 1 / L ^ 6 ∧
        1 / L ^ 9 ≤ (eta N : ℝ) ∧ (eta N : ℝ) ≤ 2 / L ^ 9 := by
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [hLog.eventually_ge_atTop 2] with N hN
  let L := Real.log (N : ℝ)
  let Z := ⌈L ^ (6 : ℕ)⌉₊
  let Y := ⌊L ^ (9 : ℕ)⌋₊
  have hL : 2 ≤ L := hN
  have hL₀ : 0 < L := by linarith
  have hL₁ : 1 ≤ L := by linarith
  have h2 (k : ℕ) (hk : k ≠ 0) : 2 ≤ L ^ k :=
    hL.trans (le_self_pow₀ hL₁ hk)
  have hZlow : L ^ (6 : ℕ) ≤ (Z : ℝ) := Nat.le_ceil _
  have hZhigh : (Z : ℝ) ≤ 2 * L ^ 6 := by
    have hZ := Nat.ceil_lt_add_one (pow_nonneg hL₀.le 6)
    dsimp only [Z]
    linarith only [hZ, h2 6 (by decide)]
  have hYhigh : (Y : ℝ) ≤ L ^ 9 := Nat.floor_le (pow_nonneg hL₀.le 9)
  have hYlow : L ^ 9 / 2 ≤ (Y : ℝ) := by
    have hY := Nat.lt_floor_add_one (L ^ (9 : ℕ))
    dsimp only [Y]
    linarith only [hY, h2 9 (by decide)]
  have hZ : 0 < Z := by
    have hz : 0 < (Z : ℝ) := (pow_pos hL₀ 6).trans_le hZlow
    exact_mod_cast hz
  have hY : 0 < Y := by
    have hy : 0 < (Y : ℝ) := (div_pos (pow_pos hL₀ 9) (by norm_num)).trans_le hYlow
    exact_mod_cast hy
  have hStep : 2 * L ^ (6 : ℕ) ≤ L ^ 9 / 2 := by
    rw [show (9 : ℕ) = 6 + 3 by decide, pow_add]
    have h3 : 4 ≤ L ^ (3 : ℕ) := by
      have h := pow_le_pow_left₀ (show 0 ≤ (2 : ℝ) by norm_num) hL 3
      norm_num at h
      linarith only [h]
    nlinarith only [mul_le_mul_of_nonneg_left h3 (pow_nonneg hL₀.le 6)]
  have hZY : Z ≤ Y := by
    exact_mod_cast (hZhigh.trans (hStep.trans hYlow))
  change 0 < ((Z : ℚ))⁻¹ ∧ 0 < ((Y : ℚ))⁻¹ ∧ ((Y : ℚ))⁻¹ ≤ ((Z : ℚ))⁻¹ ∧
    1 / (2 * L ^ 6) ≤ ((((Z : ℚ))⁻¹ : ℚ) : ℝ) ∧
    ((((Z : ℚ))⁻¹ : ℚ) : ℝ) ≤ 1 / L ^ 6 ∧
    1 / L ^ 9 ≤ ((((Y : ℚ))⁻¹ : ℚ) : ℝ) ∧
    ((((Y : ℚ))⁻¹ : ℚ) : ℝ) ≤ 2 / L ^ 9
  refine ⟨inv_pos.mpr (by exact_mod_cast hZ), inv_pos.mpr (by exact_mod_cast hY),
    inv_anti₀ (by exact_mod_cast hZ) (by exact_mod_cast hZY), ?_, ?_, ?_, ?_⟩
  · simpa only [Rat.cast_inv, Rat.cast_natCast, one_div] using
      (inv_anti₀ (show 0 < (Z : ℝ) by exact_mod_cast hZ) hZhigh)
  · simpa only [Rat.cast_inv, Rat.cast_natCast, one_div] using
      (inv_anti₀ (pow_pos hL₀ 6) hZlow)
  · simpa only [Rat.cast_inv, Rat.cast_natCast, one_div] using
      (inv_anti₀ (show 0 < (Y : ℝ) by exact_mod_cast hY) hYhigh)
  · push_cast
    calc
      _ ≤ (L ^ (9 : ℕ) / 2)⁻¹ := inv_anti₀ (by positivity) hYlow
      _ = _ := by rw [inv_div]

/-- Both baseline residual parameters eventually fall below any fixed positive number. -/
theorem eventually_residual_le {ε : ℚ} (hε : 0 < ε) :
    ∀ᶠ N : ℕ in atTop, delta N ≤ ε ∧ eta N ≤ ε := by
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hεR : 0 < (ε : ℝ) := by exact_mod_cast hε
  filter_upwards [eventually_residual_parameters,
    hLog.eventually_ge_atTop (max 1 ((ε : ℝ)⁻¹))] with N hP hN
  let L := Real.log (N : ℝ)
  have hL : 1 ≤ L := (le_max_left _ _).trans hN
  have hLow : (ε : ℝ)⁻¹ ≤ L ^ (6 : ℕ) :=
    ((le_max_right _ _).trans hN).trans (le_self_pow₀ hL (by decide))
  have hD : (delta N : ℝ) ≤ (ε : ℝ) :=
    hP.2.2.2.2.1.trans (by
      rw [one_div, ← inv_inv (ε : ℝ)]
      exact inv_anti₀ (inv_pos.mpr hεR) hLow)
  have hd : delta N ≤ ε := by exact_mod_cast hD
  exact ⟨hd,hP.2.2.1.trans hd⟩

private theorem interval_mass_lower {d X : ℕ} (h : d - 1 ≤ X) :
    mass (interval d X) = harmonic X - harmonic (d - 1) := by
  have hsub : interval 1 (d - 1) ⊆ interval 1 X :=
    fun n hn => mem_Icc.mpr ⟨(mem_Icc.mp hn).1,(mem_Icc.mp hn).2.trans h⟩
  have heq : interval d X = interval 1 X \ interval 1 (d - 1) := by
    apply Finset.ext
    intro n
    constructor
    · intro hn
      obtain ⟨hlo,hhi⟩ := mem_Icc.mp hn
      refine mem_sdiff.mpr ⟨mem_Icc.mpr ⟨(le_max_left _ _).trans hlo,hhi⟩, ?_⟩
      intro hh
      have hd := (mem_Icc.mp hh).2
      have hd' := (le_max_right 1 d).trans hlo
      have hn' := (le_max_left 1 d).trans hlo
      omega
    · intro hn
      obtain ⟨hi,hn'⟩ := mem_sdiff.mp hn
      obtain ⟨hlo,hhi⟩ := mem_Icc.mp hi
      have hd : d ≤ n := by
        by_contra! hh
        exact hn' (mem_Icc.mpr ⟨hlo,by omega⟩)
      exact mem_Icc.mpr ⟨max_le hlo hd,hhi⟩
  rw [heq]
  have hsum := sum_sdiff (f := fun n : ℕ => (n : ℚ)⁻¹) hsub
  change mass (interval 1 X \ interval 1 (d - 1)) + mass (denominators (d - 1)) =
    mass (denominators X) at hsum
  simpa only [mass_denominators_eq_harmonic] using (eq_sub_of_add_eq hsum)

/-- Allocate for the entire high-total range. The length error is explicit
in the fixed target bound and special-group cutoff. -/
theorem eventually_allocate (d D : ℕ) (hD : 0 < D) {a A mean : ℚ}
    (ha : 0 < a) (hA : 0 < A) (hMean : 0 < mean)
    (hβ : mean + 1 / (a * (max 1 d : ℕ)) < 1)
    (hRegular : mean + 1 / (a * (D : ℚ)) ≤ 1 / 8) :
    ∀ᶠ N : ℕ in atTop, ∀ {m Q : ℕ}, 0 < m → ∀ (r : Fin m → ℚ),
      (∀ i, a ≤ r i ∧ r i ≤ A ∧ (r i).den ∣ Q) →
      Real.log (N : ℝ) / 2 ≤ (↑(∑ i, r i : ℚ) : ℝ) →
      (↑(∑ i, r i : ℚ) : ℝ) ≤ Real.log (N : ℝ) + 1 →
      ∀ (F : Finset (Finset ℕ)) (E : Finset ℕ), mass E ≤ 1 →
      (∀ T ∈ F, T.Nonempty ∧ T ⊆ interval d N \ E ∧ (mass T).den ∣ Q ∧
        ((∃ n : ℕ, T = {n}) ∨ ((∀ n ∈ T, Nat.sqrt N < n) ∧
          mass T ≤ harmonic N / (Nat.sqrt N : ℚ)))) →
      (↑F : Set (Finset ℕ)).PairwiseDisjoint id →
      (∑ i, r i) ≤ ∑ T ∈ F, mass T →
      (∀ n ∈ interval d (Nat.nthRoot 3 N) \ E, ∃ T ∈ F, n ∈ T) →
      ∃ Base : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (Base i) (Base j)) ∧
        ∀ i, Base i ⊆ interval d N ∧ Disjoint (Base i) E ∧
          (r i - mass (Base i)).den ∣ Q ∧
          r i * delta N ≤ r i - mass (Base i) ∧
          r i - mass (Base i) ≤ r i * (delta N + eta N) ∧
          ((Base i).card : ℝ) ≤ (N : ℝ) * (r i : ℝ) / (↑(∑ j,r j : ℚ) : ℝ) +
            (A : ℝ) * (5 + 8 * (D : ℝ) * (A : ℝ)) * ((N : ℝ) / (Real.log N) ^ 2) := by
  let K : ℝ := (D : ℝ) * (A : ℝ)
  let W : ℝ := harmonic (d - 1)
  have haR : 0 < (a : ℝ) := by exact_mod_cast ha
  have hAR : 0 < (A : ℝ) := by exact_mod_cast hA
  have hMeanR : 0 < (mean : ℝ) := by exact_mod_cast hMean
  have hK : 0 ≤ K := by dsimp only [K]; positivity
  have hδε : 0 < 1 - (mean + 1 / (a * (max 1 d : ℕ))) := sub_pos.mpr hβ
  have hNat : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  have hSlow := Real.isLittleO_log_id_atTop.bound (show 0 < (mean : ℝ) / 40 by positivity)
  have hBlock := (isLittleO_log_rpow_rpow_atTop 10 (show 0 < (1 / 2 : ℝ) by norm_num)).bound
    (show 0 < (a : ℝ) / 4 by positivity)
  filter_upwards [hLog.eventually_ge_atTop (max 2 (max (2 / (a : ℝ)) (max (4 / (mean : ℝ))
      (max (4 * K + 4) (12 * (|W| + K + 3)))))),
    hLog.eventually hSlow, hNat.eventually hBlock,
    eventually_residual_parameters, eventually_residual_le hδε,
    eventually_residual_le (show (0 : ℚ) < 1 / 24 by norm_num),
    eventually_log_pow_le_rpow 10 (show 0 < (1 / 3 : ℝ) by norm_num),
    eventually_log_pow_le_rpow 2 (show 0 < (2 / 3 : ℝ) by norm_num),
    eventually_ge_atTop (max 8 (d ^ 3))]
    with N hLraw hSlowN hBlockN hParams hδbound hηbound hEarlyCut hLength hNlarge
  intro m Q hm r hr hRT₁ hRT₂ F E hE hF hPair hMass hSurv
  let L := Real.log (N : ℝ)
  let X₁ : ℕ := ⌊L ^ (10 : ℕ)⌋₊
  let X₂ : ℕ := Nat.nthRoot 3 N
  let R : ℝ := (↑(∑ i, r i : ℚ) : ℝ)
  have hLall : max 2 (max (2 / (a : ℝ)) (max (4 / (mean : ℝ))
      (max (4 * K + 4) (12 * (|W| + K + 3))))) ≤ L := hLraw
  have hL : 2 ≤ L := (le_max_left _ _).trans hLall
  have hLa : 2 / (a : ℝ) ≤ L := (le_max_left _ _).trans ((le_max_right _ _).trans hLall)
  have hLmean : 4 / (mean : ℝ) ≤ L :=
    (le_max_left _ _).trans ((le_max_right _ _).trans ((le_max_right _ _).trans hLall))
  have hLrest := (le_max_right (4 / (mean : ℝ)) _).trans
    ((le_max_right (2 / (a : ℝ)) _).trans ((le_max_right (2 : ℝ) _).trans hLall))
  have hLK : 4 * K + 4 ≤ L := (le_max_left _ _).trans hLrest
  have hLW : 12 * (|W| + K + 3) ≤ L := (le_max_right _ _).trans hLrest
  have hL₀ : 0 < L := by linarith
  have hL₁ : 1 ≤ L := by linarith
  have hNnat : 8 ≤ N := (le_max_left _ _).trans hNlarge
  have hN₁ : (1 : ℝ) ≤ N := by exact_mod_cast (show 1 ≤ N by omega)
  have hN₀ : (0 : ℝ) < N := zero_lt_one.trans_le hN₁
  have hDpow : d ^ 3 ≤ N := (le_max_right _ _).trans hNlarge
  have hR₀ : 0 < R := (div_pos hL₀ (by norm_num)).trans_le hRT₁
  have hRlower : L / 4 ≤ R - K := by linarith only [hLK,hRT₁]
  have hRK : 0 < R - K := (div_pos hL₀ (by norm_num)).trans_le hRlower
  have hRlow : L / 2 ≤ R := hRT₁
  have hRupper : R ≤ L + 1 := hRT₂
  have hX₁real : L ^ (10 : ℕ) / 2 ≤ (X₁ : ℝ) := by
    have h := Nat.lt_floor_add_one (L ^ (10 : ℕ))
    have hp := hL.trans (le_self_pow₀ hL₁ (show (10 : ℕ) ≠ 0 by decide))
    dsimp only [X₁]
    linarith only [h,hp]
  have hX₁ : 0 < X₁ := by
    have hx : 0 < (X₁ : ℝ) := (div_pos (pow_pos hL₀ 10) (by norm_num)).trans_le hX₁real
    exact_mod_cast hx
  have hX₁₀ : 0 < (X₁ : ℝ) := Nat.cast_pos.mpr hX₁
  have hX₂floor : X₂ = ⌊(N : ℝ) ^ (1 / 3 : ℝ)⌋₊ := by
    dsimp only [X₂]
    simpa only [Nat.cast_ofNat] using nthRoot_eq_floor_rpow 3 N (by decide)
  have hX₁₂ : X₁ ≤ X₂ := by
    rw [hX₂floor]
    exact Nat.floor_mono hEarlyCut
  have hX₂max : X₂ ≤ Nat.sqrt N := by
    apply Nat.le_sqrt'.mpr
    have hX₃ : X₂ ^ 3 ≤ N := Nat.pow_nthRoot_le (.inl (by decide))
    exact (pow_le_pow_right' (show 1 ≤ X₂ from hX₁.trans_le hX₁₂) (by decide : (2 : ℕ) ≤ 3)).trans hX₃
  have hX₂bounds : (N : ℝ) ^ (1 / 3 : ℝ) / 2 ≤ (X₂ : ℝ) ∧
      (X₂ : ℝ) ≤ (N : ℝ) ^ (1 / 3 : ℝ) := by
    rw [hX₂floor]
    have h2 : (2 : ℝ) ≤ (N : ℝ) ^ (1 / 3 : ℝ) := by
      have hn8 : (8 : ℝ) ≤ N := by exact_mod_cast hNnat
      have hh := Real.rpow_le_rpow (by norm_num : 0 ≤ (8 : ℝ)) hn8 (by norm_num : 0 ≤ (1 / 3 : ℝ))
      have he : (8 : ℝ) ^ (1 / 3 : ℝ) = 2 := calc
        _ = ((2 : ℝ) ^ (3 : ℕ)) ^ (1 / 3 : ℝ) := by norm_num
        _ = _ := by rw [← Real.rpow_natCast, ← Real.rpow_mul (by norm_num : 0 ≤ (2 : ℝ))]
                    norm_num
      exact he ▸ hh
    refine ⟨?_,Nat.floor_le (Real.rpow_nonneg hN₀.le _)⟩
    linarith only [Nat.lt_floor_add_one ((N : ℝ) ^ (1 / 3 : ℝ)), h2]
  have hEta : (a : ℝ) / L ^ (9 : ℕ) ≤ (a : ℝ) * (eta N : ℝ) :=
    (mul_le_mul_of_nonneg_left hParams.2.2.2.2.2.1 haR.le).trans_eq' (by ring)
  have hEtaInv : 1 / (X₁ : ℚ) ≤ a * eta N := by
    have hInv : 1 / (X₁ : ℝ) ≤ (a : ℝ) * (eta N : ℝ) := calc
      _ ≤ (1 : ℝ) / (L ^ (10 : ℕ) / 2) :=
        one_div_le_one_div_of_le (by positivity) hX₁real
      _ = 2 / L ^ (10 : ℕ) := by ring
      _ ≤ (a : ℝ) / L ^ (9 : ℕ) := by
        rw [show (10 : ℕ) = 9 + 1 by decide, pow_add, pow_one]
        apply (div_le_div_iff₀ (mul_pos (pow_pos hL₀ 9) hL₀) (pow_pos hL₀ 9)).mpr
        exact (by
          have hh := mul_le_mul_of_nonneg_right ((div_le_iff₀ haR).mp hLa) (pow_nonneg hL₀.le 9)
          nlinarith only [hh])
      _ ≤ _ := hEta
    apply (Rat.cast_le (K := ℝ)).mp
    push_cast
    exact hInv
  have hSqrtHalf : Real.sqrt (N : ℝ) / 2 ≤ (Nat.sqrt N : ℝ) := by
    have hq : Real.sqrt (N : ℝ) ≤ (Nat.sqrt N : ℝ) + 1 := by
      apply Real.sqrt_le_iff.mpr
      refine ⟨by positivity, ?_⟩
      have hnR : (N : ℝ) ≤ (((Nat.sqrt N + 1) * (Nat.sqrt N + 1) : ℕ) : ℝ) := by
        exact_mod_cast (Nat.lt_succ_sqrt N).le
      simpa only [Nat.cast_mul, Nat.cast_add, Nat.cast_one, pow_two] using hnR
    have hr : 2 ≤ Real.sqrt (N : ℝ) := (Real.le_sqrt (by norm_num) hN₀.le).mpr
      (by exact_mod_cast (show 2 ^ 2 ≤ N by omega))
    linarith only [hq,hr]
  have hSqrt₀ : 0 < (Nat.sqrt N : ℝ) := (div_pos (Real.sqrt_pos.mpr hN₀) (by norm_num)).trans_le hSqrtHalf
  have hBlockWeight : harmonic N / (Nat.sqrt N : ℚ) ≤ a * eta N := by
    have hb : L ^ (10 : ℕ) ≤ (a : ℝ) / 4 * Real.sqrt N := by
      have hPow : Real.log (N : ℝ) ^ (10 : ℝ) = L ^ (10 : ℕ) := Real.rpow_natCast L 10
      rw [hPow] at hBlockN
      have hh : ‖L ^ (10 : ℕ)‖ ≤ (a : ℝ) / 4 * ‖Real.sqrt N‖ := by
        simpa only [Real.sqrt_eq_rpow] using hBlockN
      simpa only [Real.norm_of_nonneg (pow_nonneg hL₀.le 10), Real.norm_of_nonneg (Real.sqrt_nonneg _)]
        using hh
    have hh : (harmonic N : ℝ) ≤ 2 * L := by
      linarith only [harmonic_le_one_add_log N, hL]
    have hab : (harmonic N : ℝ) / (Nat.sqrt N : ℝ) ≤ (a : ℝ) * (eta N : ℝ) := calc
      _ ≤ (2 * L) / (Real.sqrt (N : ℝ) / 2) :=
        div_le_div_of_nonneg_left (by positivity : 0 ≤ (2 : ℝ) * L)
          (by positivity : 0 < Real.sqrt (N : ℝ) / 2) hSqrtHalf |>.trans'
        (div_le_div_of_nonneg_right hh hSqrt₀.le)
      _ = 4 * L / Real.sqrt N := by ring
      _ ≤ (a : ℝ) / L ^ (9 : ℕ) := by
        apply (div_le_div_iff₀ (Real.sqrt_pos.2 hN₀) (pow_pos hL₀ 9)).mpr
        rw [mul_assoc, ← pow_succ']
        change 4 * L ^ (10 : ℕ) ≤ (a : ℝ) * Real.sqrt N
        linarith only [hb]
      _ ≤ _ := hEta
    exact_mod_cast hab
  have hEarlyMass : mass (interval d X₁) ≤ mean * ∑ i, r i := by
    have hSub : interval d X₁ ⊆ denominators X₁ := fun b hb =>
      mem_Icc.mpr ⟨(le_max_left _ _).trans (mem_Icc.mp hb).1,(mem_Icc.mp hb).2⟩
    have hMassR : (mass (interval d X₁) : ℝ) ≤ (harmonic X₁ : ℝ) := by
      rw [← mass_denominators_eq_harmonic]; exact_mod_cast mass_mono hSub
    have hlogX : Real.log (X₁ : ℝ) ≤ 10 * Real.log L := by
      calc
        _ ≤ Real.log (L ^ (10 : ℕ)) := Real.log_le_log hX₁₀ (Nat.floor_le (by positivity))
        _ = _ := by rw [Real.log_pow]; norm_num
    have hslow : Real.log L ≤ (mean : ℝ) / 40 * L := by
      change ‖Real.log L‖ ≤ (mean : ℝ) / 40 * ‖L‖ at hSlowN
      simpa only [Real.norm_of_nonneg (Real.log_nonneg hL₁), Real.norm_of_nonneg hL₀.le] using hSlowN
    have hrm : (mass (interval d X₁) : ℝ) ≤ (mean : ℝ) * R := calc
      _ ≤ 1 + Real.log (X₁ : ℝ) := hMassR.trans (harmonic_le_one_add_log X₁)
      _ ≤ 1 + 10 * Real.log L := by linarith only [hlogX]
      _ ≤ (mean : ℝ) * (L / 2) := by linarith only [hslow, (div_le_iff₀ hMeanR).mp hLmean]
      _ ≤ _ := mul_le_mul_of_nonneg_left hRlow hMeanR.le
    apply (Rat.cast_le (K := ℝ)).mp
    push_cast
    simpa only [R, Rat.cast_sum] using hrm
  have hBaseLower : L / 3 - W - 1 ≤ (mass (interval d X₂) : ℝ) := by
    have hx : 0 < (X₂ : ℝ) := by exact_mod_cast (hX₁.trans_le hX₁₂)
    have hd : d - 1 ≤ X₂ :=
      Nat.sub_le_of_le_add ((Nat.le_nthRoot_iff (by decide : (3 : ℕ) ≠ 0)).mpr hDpow |>.trans (by omega))
    have hLogX : L / 3 - 1 ≤ Real.log (X₂ : ℝ) := calc
      _ ≤ Real.log ((N : ℝ) ^ (1 / 3 : ℝ) / 2) := by
        rw [Real.log_div (Real.rpow_pos_of_pos hN₀ _).ne' (by norm_num), Real.log_rpow hN₀]
        linarith only [Real.log_le_sub_one_of_pos (show 0 < (2 : ℝ) by norm_num)]
      _ ≤ _ := Real.log_le_log (by positivity) hX₂bounds.1
    rw [interval_mass_lower hd, Rat.cast_sub]
    have hh : Real.log (X₂ : ℝ) ≤ (harmonic X₂ : ℝ) := by
      simpa only [Nat.floor_natCast] using log_le_harmonic_floor (X₂ : ℝ) hx.le
    linarith only [hLogX,hh]
  have hCross : (1 / 8 + eta N) * (∑ i, r i) + (D : ℚ) * A <
      mass (interval d X₂) - mass E := by
    have hηR : (eta N : ℝ) ≤ (1 : ℝ) / 24 := by
      have hh : (eta N : ℝ) ≤ ((1 / 24 : ℚ) : ℝ) := Rat.cast_le.mpr hηbound.2
      simpa only [Rat.cast_div, Rat.cast_one, Rat.cast_ofNat] using hh
    have hLeft : (1 / 8 + (eta N : ℝ)) * R + K ≤ (1 / 6 : ℝ) * (L + 1) + K := by
      exact add_le_add_left
        (mul_le_mul (by linarith only [hηR]) hRupper hR₀.le (by norm_num : (0 : ℝ) ≤ 1 / 6)) K
    have hE₁ : (mass E : ℝ) ≤ 1 := by exact_mod_cast hE
    have hRight : (1 / 6 : ℝ) * (L + 1) + K <
        (mass (interval d X₂) : ℝ) - (mass E : ℝ) := by
      linarith only [hLW,hBaseLower,hE₁,le_abs_self W,abs_nonneg W,hK]
    apply (Rat.cast_lt (K := ℝ)).mp
    push_cast
    simpa only [R, K, Rat.cast_sum] using hLeft.trans_lt hRight
  have hEarlyLoad : mean + 1 / (a * (max 1 d : ℕ)) ≤ 1 - delta N := by
    linarith only [hδbound.1]
  have hRside : (D : ℚ) * A < ∑ i, r i := by
    apply (Rat.cast_lt (K := ℝ)).mp
    push_cast
    simpa only [R, K, Rat.cast_sum] using sub_pos.mp hRK
  obtain ⟨Base,hDis,hBase⟩ := allocate_of_prefix_bounds hm F E r ha hA.le hr
    hParams.1 hParams.2.1.le hMean.le (fun T hT => by
      obtain ⟨h₁,h₂,h₃,hShape⟩ := hF T hT
      exact ⟨h₁,h₂,h₃,hShape.imp_right (fun hp => ⟨hp.1,hp.2.trans hBlockWeight⟩)⟩)
    hPair hMass hX₁ hX₁₂ hX₂max hD hEtaInv hSurv hEarlyMass hEarlyLoad hRegular hRside hCross
  refine ⟨Base,hDis,fun i => ⟨(hBase i).1,(hBase i).2.1,(hBase i).2.2.1,(hBase i).2.2.2.1,
    (hBase i).2.2.2.2.1, ?_⟩⟩
  have hri : 0 ≤ (r i : ℝ) := by exact_mod_cast (ha.le.trans (hr i).1)
  have hir : (r i : ℝ) ≤ A := by exact_mod_cast (hr i).2.1
  have hCount : ((Base i).card : ℝ) ≤ (r i : ℝ) * (X₂ : ℝ) +
      ((r i : ℝ) / (R - K)) * N + 2 * (r i : ℝ) * (eta N : ℝ) * N := by
    have hh : (((Base i).card : ℚ) : ℝ) ≤
        ((r i * (X₂ : ℚ) + (r i / ((∑ j, r j) - (D : ℚ) * A)) * N +
          2 * r i * eta N * N : ℚ) : ℝ) := Rat.cast_le.mpr (hBase i).2.2.2.2.2
    simpa only [Rat.cast_add, Rat.cast_mul, Rat.cast_natCast, Rat.cast_div, Rat.cast_sub,
      Rat.cast_ofNat] using hh
  have hXlength : (X₂ : ℝ) ≤ (N : ℝ) / L ^ 2 := by
    apply (le_div_iff₀ (pow_pos hL₀ 2)).mpr
    exact (mul_le_mul hX₂bounds.2 hLength (pow_nonneg hL₀.le 2) (Real.rpow_nonneg hN₀.le _)).trans_eq
      (by rw [← Real.rpow_add hN₀]; norm_num)
  have hEtaLength : (eta N : ℝ) ≤ 2 / L ^ (2 : ℕ) :=
    hParams.2.2.2.2.2.2.trans (div_le_div_of_nonneg_left (by norm_num) (pow_pos hL₀ 2)
      (pow_le_pow_right₀ hL₁ (by decide : (2 : ℕ) ≤ 9)))
  have hDen : L ^ 2 / 8 ≤ (R - K) * R := by
    have h := mul_le_mul hRlower hRlow (by positivity : 0 ≤ L / 2) hRK.le
    nlinarith only [h]
  have hRatio :
      ((r i : ℝ) / (R - K)) * N ≤ (N : ℝ) * (r i : ℝ) / R + (8 * (A : ℝ) * K) * ((N : ℝ) / L ^ 2) := by
    calc
      _ = (N : ℝ) * (r i : ℝ) / R + ((r i : ℝ) * K * N) / ((R - K) * R) := by
        field_simp [hR₀.ne',hRK.ne']
        ring
      _ ≤ _ := by
        apply add_le_add_right
        calc
          _ ≤ ((A : ℝ) * K * N) / ((R - K) * R) := div_le_div_of_nonneg_right
            (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hir hK) hN₀.le) (by positivity)
          _ ≤ ((A : ℝ) * K * N) / (L ^ 2 / 8) :=
            div_le_div_of_nonneg_left (by positivity) (by positivity) hDen
          _ = _ := by ring
  have hPrefix : (r i : ℝ) * (X₂ : ℝ) ≤ (A : ℝ) * ((N : ℝ) / L ^ 2) :=
    mul_le_mul hir hXlength (Nat.cast_nonneg _) hAR.le
  have hLater : 2 * (r i : ℝ) * (eta N : ℝ) * N ≤ 4 * (A : ℝ) * ((N : ℝ) / L ^ 2) := calc
    _ ≤ 2 * (A : ℝ) * (2 / L ^ 2) * N := by
      exact mul_le_mul_of_nonneg_right (mul_le_mul (by linarith only [hir]) hEtaLength
        (by exact_mod_cast hParams.2.1.le) (by positivity)) hN₀.le
    _ = _ := by ring
  calc
    _ ≤ _ := hCount
    _ ≤ (A : ℝ) * ((N : ℝ) / L ^ 2) +
        ((N : ℝ) * (r i : ℝ) / R + (8 * (A : ℝ) * K) * ((N : ℝ) / L ^ 2)) +
        4 * (A : ℝ) * ((N : ℝ) / L ^ 2) := add_le_add (add_le_add hPrefix hRatio) hLater
    _ = _ := by dsimp only [K]; ring

end LeanAB.PaperB.Baseline
