module

public import PaperB.Obstruction.PrimeMass
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
meta import Mathlib.Tactic

/-! Large-prime exclusions for reciprocal representations. -/

@[expose] public section

open Filter
open scoped BigOperators Topology

namespace LeanAB.PaperB

/-- The smoothness cutoff in the packing theorem. -/
noncomputable def smoothCutoff (N : ℕ) : ℝ := (N : ℝ) ^ (1 / 20 : ℝ)

/-- The permitted target denominator D_N from the packing theorem. -/
noncomputable def permittedDenominator (N : ℕ) : ℕ :=
  Nat.lcmUpto ⌊smoothCutoff N⌋₊ *
    ∏ p ∈ (Nat.primesLE (Nat.sqrt N)).filter (⌊smoothCutoff N⌋₊ < ·), p

/-- The high-prime cutoff in the arithmetic obstruction. -/
noncomputable def obstructionCutoff (N : ℕ) : ℝ := 10 * N / Real.log N

private theorem smoothCutoff_floor_le_sqrt {N : ℕ} (hN : 1 ≤ N) :
    ⌊smoothCutoff N⌋₊ ≤ Nat.sqrt N := by
  have hN' : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hs : smoothCutoff N ≤ Real.sqrt N := by
    rw [smoothCutoff, Real.sqrt_eq_rpow]
    exact Real.rpow_le_rpow_of_exponent_le hN' (by norm_num)
  have hf : (⌊smoothCutoff N⌋₊ : ℝ) ≤ Real.sqrt N :=
    (Nat.floor_le (by unfold smoothCutoff; positivity)).trans hs
  apply Nat.le_sqrt.mpr
  have hsq := pow_le_pow_left₀ (show (0 : ℝ) ≤ ↑⌊smoothCutoff N⌋₊ by positivity) hf 2
  rw [Real.sq_sqrt (by positivity), pow_two] at hsq
  exact_mod_cast hsq

/-- A prime above the square-root boundary cannot divide D_N. -/
theorem not_dvd_permittedDenominator_of_sqrt_lt {N p : ℕ} (hN : 1 ≤ N) (hp : p.Prime)
    (hlarge : Nat.sqrt N < p) : ¬p ∣ permittedDenominator N := by
  intro hdvd
  rw [permittedDenominator, hp.dvd_mul] at hdvd
  rcases hdvd with hsmall | hmid
  · have hmem : p ∈ (Nat.lcmUpto ⌊smoothCutoff N⌋₊).primeFactors :=
      hp.mem_primeFactors hsmall (Nat.lcmUpto_ne_zero _)
    rw [Nat.primeFactors_lcmUpto, Nat.mem_primesLE] at hmem
    exact (not_le_of_gt hlarge) (hmem.1.trans (smoothCutoff_floor_le_sqrt hN))
  · obtain ⟨q, hq, hpq⟩ := (hp.prime.dvd_finsetProd_iff _).mp hmid
    have hq' := Nat.mem_primesLE.mp (Finset.mem_filter.mp hq).1
    have heq := (Nat.prime_dvd_prime_iff_eq hp hq'.2).mp hpq
    exact (not_le_of_gt hlarge) (heq ▸ hq'.1)

private theorem mass_denominators_le (N : ℕ) : mass (denominators N) ≤ N := by
  have h := Finset.sum_le_sum (s := denominators N)
    (g := fun _ => (1 : ℚ)) (fun a ha =>
      inv_le_one_of_one_le₀ (by exact_mod_cast (Finset.mem_Icc.mp ha).1 : (1 : ℚ) ≤ a))
  simpa [mass, denominators, interval] using h

private theorem log_lcmUpto_le_six (q : ℕ) : Real.log (Nat.lcmUpto q : ℝ) ≤ 6 * q := by
  rw [← Chebyshev.psi_eq_log_lcmUpto]
  have hlog : Real.log 4 ≤ 2 := by
    rw [show (4 : ℝ) = 2 * 2 by norm_num, Real.log_mul (by norm_num) (by norm_num)]
    linarith [Real.log_lt_sub_one_of_pos (show (0 : ℝ) < 2 by norm_num) (by norm_num)]
  exact (Chebyshev.psi_le_const_mul_self (show (0 : ℝ) ≤ q by positivity)).trans
    (by gcongr; linarith)

/-- For all sufficiently large N, the high-prime cutoff forces both
the square-root condition and the no-wrap bound D_q H_q < p. -/
theorem eventually_obstructionBlockBounds :
    ∀ᶠ N : ℕ in atTop, ∀ p : ℕ, obstructionCutoff N < p →
      Nat.sqrt N < p ∧ (Nat.lcmUpto (N / p) : ℚ) * mass (cofactorBlock N p) < p := by
  have hlog := (isLittleO_log_rpow_atTop (show (0 : ℝ) < 1 / 8 by norm_num)).bound
    (show (0 : ℝ) < 1 by norm_num)
  have hcast : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  filter_upwards [hcast.eventually hlog, eventually_ge_atTop (2 : ℕ)] with N hlog hN p hp
  have hN₁ : (1 : ℝ) < N := by exact_mod_cast (by omega : 1 < N)
  have hN₀ : (0 : ℝ) < N := zero_lt_one.trans hN₁
  have hlogpos : 0 < Real.log (N : ℝ) := Real.log_pos hN₁
  have hrpow : (0 : ℝ) < (N : ℝ) ^ (1 / 8 : ℝ) := Real.rpow_pos_of_pos hN₀ _
  have hL : Real.log (N : ℝ) ≤ (N : ℝ) ^ (1 / 8 : ℝ) := by
    simpa only [Real.norm_eq_abs, abs_of_nonneg hlogpos.le, abs_of_nonneg hrpow.le, one_mul] using hlog
  have hp₀ : (0 : ℝ) < p := (by unfold obstructionCutoff; positivity : 0 < obstructionCutoff N).trans hp
  have hNp : 10 * (N : ℝ) < p * Real.log N := (div_lt_iff₀ hlogpos).mp hp
  have hq : (↑(N / p) : ℝ) ≤ Real.log N / 10 :=
    Nat.cast_div_le.trans ((div_le_iff₀ hp₀).mpr (by linarith only [hNp.le]))
  have hsqrt : Real.sqrt (N : ℝ) < (p : ℝ) := by
    refine ((lt_div_iff₀ hlogpos).mpr ?_).trans hp
    calc
      Real.sqrt (N : ℝ) * Real.log N ≤ Real.sqrt (N : ℝ) * ((N : ℝ) ^ (1 / 8 : ℝ)) :=
        mul_le_mul_of_nonneg_left hL (Real.sqrt_nonneg _)
      _ = (N : ℝ) ^ (5 / 8 : ℝ) := by
        rw [Real.sqrt_eq_rpow, ← Real.rpow_add hN₀]
        norm_num
      _ < (N : ℝ) := by
        simpa using Real.rpow_lt_rpow_of_exponent_lt hN₁ (show (5 / 8 : ℝ) < 1 by norm_num)
      _ ≤ 10 * N := by linarith only [hN₀.le]
  have hsquare : (N : ℝ) < (p : ℝ) * p := by
    rw [← pow_two]
    exact (Real.sqrt_lt (by positivity) hp₀.le).mp hsqrt
  refine ⟨Nat.sqrt_lt.mpr (by exact_mod_cast hsquare), ?_⟩
  have hD : (Nat.lcmUpto (N / p) : ℝ) ≤ (N : ℝ) ^ (3 / 5 : ℝ) := by
    have hD₀ : (0 : ℝ) < Nat.lcmUpto (N / p) := by exact_mod_cast Nat.lcmUpto_pos (N / p)
    rw [Real.rpow_def_of_pos hN₀, ← Real.exp_log hD₀, Real.exp_le_exp]
    exact (log_lcmUpto_le_six (N / p)).trans (by linarith only [hq])
  have hqL : (↑(N / p) : ℝ) ≤ (N : ℝ) ^ (1 / 8 : ℝ) :=
    (hq.trans (by linarith only [hlogpos.le])).trans hL
  have hproduct : (Nat.lcmUpto (N / p) : ℝ) * (N / p : ℕ) * Real.log N < N := calc
    _ ≤ (N : ℝ) ^ (3 / 5 : ℝ) * (N : ℝ) ^ (1 / 8 : ℝ) * (N : ℝ) ^ (1 / 8 : ℝ) :=
      mul_le_mul (mul_le_mul hD hqL (by positivity) (by positivity)) hL
        hlogpos.le (by positivity)
    _ = (N : ℝ) ^ (17 / 20 : ℝ) := by rw [← Real.rpow_add hN₀, ← Real.rpow_add hN₀]; norm_num
    _ < N := by
      simpa using Real.rpow_lt_rpow_of_exponent_lt hN₁ (show (17 / 20 : ℝ) < 1 by norm_num)
  have hqBounds : (Nat.lcmUpto (N / p) : ℝ) * (N / p : ℕ) < p :=
    ((lt_div_iff₀ hlogpos).mpr (hproduct.trans_le (by linarith only [hN₀.le]))).trans hp
  exact (mul_le_mul_of_nonneg_left (mass_denominators_le (N / p)) (by positivity)).trans_lt
    (by exact_mod_cast hqBounds)

/-- No high-prime multiple can appear in a representation whose reduced denominator
divides the packing denominator. The result is uniform in the target and the subset. -/
theorem eventually_primePart_empty_above_obstructionCutoff :
    ∀ᶠ N : ℕ in atTop, ∀ (p : ℕ) (S : Finset ℕ), p.Prime → p ≤ N →
      obstructionCutoff N < p → S ⊆ denominators N → (mass S).den ∣ permittedDenominator N →
      primePart p S = ∅ := by
  filter_upwards [eventually_obstructionBlockBounds, eventually_ge_atTop (1 : ℕ)] with N hN hN₀
    p S hp hpN hpCut hS hden
  obtain ⟨hsqrt, hsmall⟩ := hN p hpCut
  exact primePart_eq_empty_of_lcm_mul_mass_lt
    (mem_largePrimes.mpr ⟨hp, hpN, hsqrt⟩) hS
    (fun h => not_dvd_permittedDenominator_of_sqrt_lt hN₀ hp hsqrt (h.trans hden)) hsmall


/-- The primes whose multiples are excluded by the obstruction. -/
noncomputable def excludedPrimes (N : ℕ) : Finset ℕ := by
  classical
  exact (largePrimes N).filter (fun p => obstructionCutoff N < p)

/-- The set of all excluded denominators, counted once each. -/
noncomputable def excludedDenominators (N : ℕ) : Finset ℕ :=
  (excludedPrimes N).biUnion (fun p => primePart p (denominators N))

theorem excludedDenominators_subset_interval {N d : ℕ} (hd : d ≤ Nat.sqrt N) :
    excludedDenominators N ⊆ interval d N := by
  intro a ha
  obtain ⟨p, hp, hpa⟩ := Finset.mem_biUnion.mp ha
  have hpsqrt := (mem_largePrimes.mp (Finset.mem_filter.mp hp).1).2.2
  obtain ⟨ha, hpdvd⟩ := Finset.mem_filter.mp hpa
  have ⟨hapos, haN⟩ := Finset.mem_Icc.mp ha
  exact Finset.mem_Icc.mpr ⟨max_le hapos ((hd.trans hpsqrt.le).trans
    (Nat.le_of_dvd hapos hpdvd)), haN⟩

/-- The removed mass is the sum of the individual prime-block masses. -/
theorem excludedDenominators_mass (N : ℕ) :
    mass (excludedDenominators N) =
      ∑ p ∈ excludedPrimes N, mass (cofactorBlock N p) / p := by
  have hdis : ((excludedPrimes N : Finset ℕ) : Set ℕ).PairwiseDisjoint
      (fun p => primePart p (denominators N)) := by
    intro p hp q hq hpq
    exact primePart_disjoint (Finset.mem_filter.mp hp).1 (Finset.mem_filter.mp hq).1 hpq
  calc
    _ = ∑ p ∈ excludedPrimes N, mass (primePart p (denominators N)) :=
      Finset.sum_biUnion hdis
    _ = _ := Finset.sum_congr rfl fun p hp =>
      mass_primePart (mem_largePrimes.mp (Finset.mem_filter.mp hp).1).1.pos

private theorem eventually_excludedDenominators_disjoint :
    ∀ᶠ N : ℕ in atTop, ∀ (S : Finset ℕ), S ⊆ denominators N →
      (mass S).den ∣ permittedDenominator N → Disjoint S (excludedDenominators N) := by
  filter_upwards [eventually_primePart_empty_above_obstructionCutoff] with N hN S hS hden
  refine Finset.disjoint_left.mpr fun a ha hExcluded => ?_
  obtain ⟨p, hp, hpa⟩ := Finset.mem_biUnion.mp hExcluded
  obtain ⟨hplarge, hcut⟩ := Finset.mem_filter.mp hp
  obtain ⟨hprime, hpN, _⟩ := mem_largePrimes.mp hplarge
  have hnmem : a ∈ primePart p S := Finset.mem_filter.mpr ⟨ha, (Finset.mem_filter.mp hpa).2⟩
  rw [hN p S hprime hpN hcut hS hden] at hnmem
  exact Finset.notMem_empty a hnmem

/-- Uniform in the number of groups and all permitted reduced denominators, the
total mass is bounded by the interval mass less the exact excluded-block sum. -/
theorem eventually_packing_mass_le_sub_excluded (d : ℕ) :
    ∀ᶠ N : ℕ in atTop, ∀ {m : ℕ} (r : Fin m → ℚ) (S : Fin m → Finset ℕ),
      Pairwise (fun i j => Disjoint (S i) (S j)) →
      (∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧ (r i).den ∣ permittedDenominator N) →
      (∑ i, r i) ≤ mass (interval d N) -
        ∑ p ∈ excludedPrimes N, mass (cofactorBlock N p) / p := by
  filter_upwards [eventually_excludedDenominators_disjoint, eventually_ge_atTop (d * d)]
    with N hN hdslow m r S hdis hall
  have hd : d ≤ Nat.sqrt N := Nat.le_sqrt.mpr hdslow
  let E := excludedDenominators N
  let T := interval d N
  have hET : E ⊆ T := excludedDenominators_subset_interval hd
  have hgroups (i : Fin m) : S i ⊆ T \ E := by
    obtain ⟨hST, hm, hden⟩ := hall i
    have hS : S i ⊆ denominators N := by
      intro a ha
      obtain ⟨hal, har⟩ := Finset.mem_Icc.mp (hST ha)
      exact Finset.mem_Icc.mpr ⟨(le_max_left 1 d).trans hal, har⟩
    have hi := hN (S i) hS (hm ▸ hden)
    exact fun a ha => Finset.mem_sdiff.mpr ⟨hST ha, fun he => Finset.disjoint_left.mp hi ha he⟩
  have hsum : mass (T \ E) + mass E = mass T := Finset.sum_sdiff hET
  rw [← excludedDenominators_mass, ← hsum, add_sub_cancel_right]
  calc
    _ = ∑ i, mass (S i) := Finset.sum_congr rfl (fun i _ => (hall i).2.1.symm)
    _ = mass (Finset.univ.biUnion S) := (Finset.sum_biUnion (fun i _ j _ hij => hdis hij)).symm
    _ ≤ _ := mass_mono (Finset.biUnion_subset.mpr (fun i _ => hgroups i))


private theorem eventually_obstructionWindow_bounds :
    ∀ᶠ N : ℕ in atTop, let L := Real.log (N : ℝ); let U := Real.log L
      1 ≤ U - Real.log 10 ∧ 2 * (U - Real.log 10) ≤ L ∧
        (U - Real.log 10)^2 ≤ L := by
  have hL : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hU := Real.tendsto_log_atTop.comp hL
  have hSmall := (isLittleO_log_rpow_atTop (r := (1 / 2 : ℝ)) (by norm_num)).bound
    (show (0 : ℝ) < 1 by norm_num)
  filter_upwards [hL.eventually_ge_atTop 4, hU.eventually_ge_atTop (1 + Real.log 10),
    hL.eventually hSmall] with N hl hu hs
  dsimp
  let L := Real.log (N : ℝ)
  let U := Real.log L
  change 4 ≤ L at hl
  change 1 + Real.log 10 ≤ U at hu
  change ‖U‖ ≤ 1 * ‖L ^ (1 / 2 : ℝ)‖ at hs
  have h10 : 0 ≤ Real.log 10 := Real.log_nonneg (by norm_num)
  have hw : 1 ≤ U - Real.log 10 := by linarith only [hu]
  have hl₀ : (0 : ℝ) ≤ L := by linarith only [hl]
  have hu₀ : (0 : ℝ) ≤ U := by linarith only [hu, h10]
  have hR : U ≤ Real.sqrt L := by
    simpa only [Real.norm_eq_abs, ← Real.sqrt_eq_rpow, one_mul, abs_of_nonneg hu₀,
      abs_of_nonneg (Real.sqrt_nonneg L)] using hs
  have hs₂ : 2 ≤ Real.sqrt L := by
    have h := Real.sqrt_le_sqrt hl
    simpa [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (show (0 : ℝ) ≤ 2 by norm_num)]
      using h
  have hw₀ : 0 ≤ U - Real.log 10 := zero_le_one.trans hw
  refine ⟨hw, ?_, ?_⟩
  · linarith only [hR, h10,
      show 2 * Real.sqrt L ≤ L by
        have := mul_le_mul_of_nonneg_right hs₂ (Real.sqrt_nonneg L)
        rwa [Real.mul_self_sqrt hl₀] at this]
  · exact (pow_le_pow_left₀ hw₀ (by linarith only [h10, hR]) _).trans_eq (Real.sq_sqrt hl₀)

private theorem obstructionCutoff_eq_windowLeft {N : ℕ} (hN : 1 < N) :
    obstructionCutoff N = (N : ℝ) * Real.exp (-(Real.log (Real.log N) - Real.log 10)) := by
  have hL : 0 < Real.log (N : ℝ) := Real.log_pos (by exact_mod_cast hN)
  rw [show -(Real.log (Real.log (N : ℝ)) - Real.log 10) =
    Real.log 10 - Real.log (Real.log N) by ring, Real.exp_sub, Real.exp_log (by norm_num : (0 : ℝ) < 10),
    Real.exp_log hL, obstructionCutoff]
  ring

/-- The exact excluded-prime mass agrees with the analytic window at w = U − log 10. -/
theorem eventually_excludedPrimeMass_eq_window :
    ∀ᶠ N : ℕ in atTop, (mass (excludedDenominators N) : ℝ) =
      windowPrimeMass N (Real.log (Real.log N) - Real.log 10) := by
  filter_upwards [eventually_obstructionBlockBounds, eventually_ge_atTop (2 : ℕ)] with N hN hN₀
  have hCut : 0 ≤ obstructionCutoff N := by
    unfold obstructionCutoff
    exact div_nonneg (by positivity) (Real.log_nonneg (by exact_mod_cast (by omega : 1 ≤ N)))
  have hE : excludedPrimes N = primesBetween (obstructionCutoff N) N := by
    ext p
    rw [excludedPrimes, Finset.mem_filter, mem_largePrimes, mem_primesBetween hCut (by positivity)]
    constructor
    · rintro ⟨⟨hprime, hle, _⟩, hc⟩
      exact ⟨hc, by exact_mod_cast hle, hprime⟩
    · rintro ⟨hc, hle, hprime⟩
      exact ⟨⟨hprime, by exact_mod_cast hle, (hN p hc).1⟩, hc⟩
  rw [excludedDenominators_mass, windowPrimeMass, ← obstructionCutoff_eq_windowLeft (by omega)]
  rw [hE, Rat.cast_sum]
  refine Finset.sum_congr rfl (fun p _ => ?_)
  rw [Rat.cast_div, Rat.cast_natCast]

/-- The necessary mass estimate in F2, with the quantitative θ input exposed.
Its choice of constants is uniform over all target lists and reduced denominators. -/
theorem eventually_packing_necessary_of_theta (hθ : ThetaLogSquaredError) (d : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      ∀ {m : ℕ} (r : Fin m → ℚ) (S : Fin m → Finset ℕ),
      Pairwise (fun i j => Disjoint (S i) (S j)) →
      (∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧ (r i).den ∣ permittedDenominator N) →
      ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) -
        (Real.log (Real.log N)) ^ 2 / (2 * Real.log N) +
          C * Real.log (Real.log N) / Real.log N := by
  obtain ⟨C₁, hC₁, hmass⟩ := eventually_windowPrimeMass_error_of_theta hθ
  have h10 : 0 ≤ Real.log 10 := Real.log_nonneg (by norm_num)
  refine ⟨C₁ + Real.log 10, by linarith, ?_⟩
  filter_upwards [eventually_packing_mass_le_sub_excluded d, eventually_excludedPrimeMass_eq_window,
    hmass, eventually_obstructionWindow_bounds] with N hPack hExact hM hb
    m r S hDis hAll
  dsimp only at hb
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let w := U - Real.log 10
  have hL : 0 < L := by linarith only [hb.1, hb.2.1]
  have hUm : w ≤ U := by dsimp [w]; linarith only [h10]
  have hB := hM w hb.1 hb.2.1 hb.2.2
  have hLw :
      w ^ 2 / (2 * L) - C₁ * w / L ≤ windowPrimeMass N w := by
    linarith only [(abs_le.mp hB).1]
  have hshift : U ^ 2 / (2 * L) - Real.log 10 * U / L ≤ w ^ 2 / (2 * L) := by
    suffices U ^ 2 - 2 * Real.log 10 * U ≤ w ^ 2 by
      have := div_le_div_of_nonneg_right this (show 0 ≤ 2 * L by positivity)
      convert this using 1
      ring
    dsimp [w]
    nlinarith only [sq_nonneg (Real.log 10)]
  have hCw : C₁ * w / L ≤ C₁ * U / L :=
    div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hUm hC₁.le) hL.le
  have hQ :
      (∑ i, r i) ≤ mass (interval d N) - mass (excludedDenominators N) := by
    rw [excludedDenominators_mass]
    exact hPack r S hDis hAll
  have hR : ((∑ i, r i : ℚ) : ℝ) ≤
      (mass (interval d N) : ℝ) - (mass (excludedDenominators N) : ℝ) := by
    exact_mod_cast hQ
  calc
    _ ≤ (mass (interval d N) : ℝ) - windowPrimeMass N w := by rw [← hExact]; exact hR
    _ ≤ (mass (interval d N) : ℝ) - U ^ 2 / (2 * L) +
        Real.log 10 * U / L + C₁ * U / L := by
          linarith only [hLw, hshift, hCw]
    _ = _ := by ring

end LeanAB.PaperB
