module

public import PaperB.CapacityApproximation
public import PaperB.FixedTargets
public import Mathlib.NumberTheory.Harmonic.Bounds
meta import Mathlib.Tactic

/-! The size of the near-capacity target list and restoring the reserved unit group. -/

@[expose] public section

namespace LeanAB.PaperB

open Filter Finset FixedTargets
open scoped Topology

/-- The number of further unit groups needed after reserving the singleton at denominator 1. -/
noncomputable def nearCapacityGroupCount (A : ℝ) (N : ℕ) : ℕ :=
  (⌊(capacity N : ℝ) - A / (N : ℝ) ^ (1 / 12 : ℝ)⌋ : ℤ).toNat - 1

/-- Exact floor identity, positive group count, and uniform logarithmic bounds
for the unit groups of the near-capacity construction. -/
theorem eventually_nearCapacityGroupCount (A : ℝ) (hA : 0 ≤ A) :
    ∀ᶠ N : ℕ in atTop,
      let m := nearCapacityGroupCount A N
      0 < m ∧ |(m : ℝ) - Real.log (N : ℝ)| ≤ 4 ∧
        (m : ℝ) ≤ 2 * Real.log (N : ℝ) ∧
        (m : ℝ) ≤ (capacity N : ℝ) - 1 - A / (N : ℝ) ^ (1 / 12 : ℝ) ∧
        ((m + 1 : ℕ) : ℤ) = ⌊(capacity N : ℝ) - A / (N : ℝ) ^ (1 / 12 : ℝ)⌋ := by
  have hNat : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hL := Real.tendsto_log_atTop.comp hNat
  have hPow := (tendsto_rpow_atTop (by norm_num : (0 : ℝ) < 1 / 12)).comp hNat
  filter_upwards [capacityNearHarmonic, hL.eventually_ge_atTop 6,
    hPow.eventually_ge_atTop A, eventually_ge_atTop (1 : ℕ)] with N hNear hLarge hDen hN
  let L := Real.log (N : ℝ)
  let P := A / (N : ℝ) ^ (1 / 12 : ℝ)
  let x := (capacity N : ℝ) - P
  let j : ℤ := ⌊x⌋
  let m := nearCapacityGroupCount A N
  change 6 ≤ L at hLarge
  change A ≤ (N : ℝ) ^ (1 / 12 : ℝ) at hDen
  have hNpos : (0 : ℝ) < N := by exact_mod_cast (show 0 < N by omega)
  have hPden := Real.rpow_pos_of_pos hNpos (1 / 12 : ℝ)
  have hPlo : 0 ≤ P := div_nonneg hA hPden.le
  have hPup : P ≤ 1 := (div_le_iff₀ hPden).mpr (by rwa [one_mul])
  have hHlo : L ≤ (harmonic N : ℝ) := by
    simpa only [L, Nat.floor_natCast] using log_le_harmonic_floor (N : ℝ) hNpos.le
  have hHup : (harmonic N : ℝ) ≤ 1 + L := harmonic_le_one_add_log N
  have hNear' : |(capacity N : ℝ) - (harmonic N : ℝ)| ≤ 1 := hNear
  obtain ⟨hClo, hCup⟩ := abs_le.mp hNear'
  have hxlo : L - 2 ≤ x := by dsimp [x]; linarith only [hHlo, hClo, hPup]
  have hxup : x ≤ L + 2 := by dsimp [x]; linarith only [hHup, hCup, hPlo]
  have hjlo : x < (j : ℝ) + 1 := Int.lt_floor_add_one x
  have hjup : (j : ℝ) ≤ x := Int.floor_le x
  have hj₂R : (2 : ℝ) ≤ (j : ℝ) := by linarith only [hLarge, hxlo, hjlo]
  have hj₂ : (2 : ℤ) ≤ j := by exact_mod_cast hj₂R
  have htoNat : (j.toNat : ℤ) = j := Int.toNat_of_nonneg (by omega)
  have hmSucc : m + 1 = j.toNat := by
    change j.toNat - 1 + 1 = j.toNat
    omega
  have hmExact : ((m + 1 : ℕ) : ℤ) = j := by rw [hmSucc, htoNat]
  have hmR : (m : ℝ) + 1 = (j : ℝ) := by exact_mod_cast hmExact
  have hmPos : 0 < m := by omega
  refine ⟨hmPos, abs_le.mpr ⟨?_, ?_⟩, ?_, ?_, hmExact⟩
  · linarith only [hxlo, hjlo, hmR]
  · linarith only [hxup, hjup, hmR]
  · linarith only [hxup, hjup, hmR, hLarge]
  · change (m : ℝ) ≤ (capacity N : ℝ) - 1 - P
    dsimp only [x] at hjup
    linarith only [hjup, hmR]

/-- Restoring the reserved unit denominator preserves disjointness and adds one group. -/
theorem unitPacking_insert_one_of_ordered {N m : ℕ} (hN : 1 ≤ N)
    (S : Fin m → Finset ℕ) (hPair : Pairwise fun i j => Disjoint (S i) (S j))
    (hS : ∀ i, S i ⊆ interval 2 N ∧ mass (S i) = 1) :
    UnitPacking N (insert {1} (univ.image S)) ∧ (insert {1} (univ.image S)).card = m + 1 := by
  have hNonempty (i : Fin m) : (S i).Nonempty := by
    apply nonempty_iff_ne_empty.mpr
    intro hEmpty
    have hmass := (hS i).2
    rw [hEmpty] at hmass
    norm_num [mass] at hmass
  have hMem (i : Fin m) : S i ∈ edges 2 N 1 := mem_edges.mpr (hS i)
  obtain ⟨hMatch, hCard⟩ := ordered_image_matching S hPair hNonempty hMem
  obtain ⟨hFull, hFullCard⟩ :=
    insert_singleton_matching (by decide : 0 < (1 : ℕ)) hN (by norm_num : (1 : ℚ)⁻¹ = 1) hMatch
  refine ⟨⟨?_, hFull.2⟩, hFullCard.trans (by rw [hCard])⟩
  intro F hF
  exact mem_edges.mp (hFull.1 hF)

theorem unitPacking_insert_one_length_le {m : ℕ} (S : Fin m → Finset ℕ) {B : ℝ}
    (hB : 1 ≤ B) (hLength : ∀ i, ((S i).card : ℝ) ≤ B) :
    ∀ F ∈ insert {1} (univ.image S), (F.card : ℝ) ≤ B := by
  intro F hF
  rcases mem_insert.mp hF with rfl | hF
  · simpa using hB
  · obtain ⟨i, _, rfl⟩ := mem_image.mp hF
    exact hLength i

/-- A near-capacity construction of the further groups proves the desired
packing lower bound after restoring denominator 1. -/
theorem capacityAttainment_of_nearCapacity_ordered {A : ℝ} (hA : 0 ≤ A)
    (hPacking : ∀ᶠ N : ℕ in atTop, ∃ S : Fin (nearCapacityGroupCount A N) → Finset ℕ,
      Pairwise (fun i j => Disjoint (S i) (S j)) ∧
        ∀ i, S i ⊆ interval 2 N ∧ mass (S i) = 1) :
    CapacityAttainment A := by
  filter_upwards [hPacking, eventually_nearCapacityGroupCount A hA, eventually_ge_atTop (1 : ℕ)]
    with N hPack hCount hN
  obtain ⟨S, hPair, hS⟩ := hPack
  obtain ⟨hFull, hCard⟩ := unitPacking_insert_one_of_ordered hN S hPair hS
  have hk : nearCapacityGroupCount A N + 1 ≤ k N :=
    (k_isGreatest N).2 ⟨_, hFull, hCard⟩
  rw [← hCount.2.2.2.2]
  exact_mod_cast hk


/-- The actual packing attains the same length bound after restoring the reserved singleton. -/
theorem eventually_nearCapacity_unitPacking_of_ordered {A B : ℝ} (hA : 0 ≤ A) (hB : 0 ≤ B)
    (hPacking : ∀ᶠ N : ℕ in atTop, ∃ S : Fin (nearCapacityGroupCount A N) → Finset ℕ,
      Pairwise (fun i j => Disjoint (S i) (S j)) ∧
        ∀ i, S i ⊆ interval 2 N ∧ mass (S i) = 1 ∧
          ((S i).card : ℝ) ≤ (N : ℝ) / Real.log (N : ℝ) + B * (N : ℝ) / (Real.log (N : ℝ)) ^ 2) :
    ∀ᶠ N : ℕ in atTop, ∃ F : Finset (Finset ℕ), UnitPacking N F ∧
      (F.card : ℤ) = ⌊(capacity N : ℝ) - A / (N : ℝ) ^ (1 / 12 : ℝ)⌋ ∧
      ∀ S ∈ F, (S.card : ℝ) ≤ (N : ℝ) / Real.log (N : ℝ) + B * (N : ℝ) / (Real.log (N : ℝ)) ^ 2 := by
  filter_upwards [hPacking, eventually_nearCapacityGroupCount A hA, eventually_ge_atTop (2 : ℕ)]
    with N hPack hCount hN
  obtain ⟨S, hPair, hS⟩ := hPack
  obtain ⟨hFull, hCard⟩ := unitPacking_insert_one_of_ordered (by omega : 1 ≤ N) S hPair
    (fun i => ⟨(hS i).1, (hS i).2.1⟩)
  refine ⟨insert {1} (univ.image S), hFull, ?_, ?_⟩
  · rw [hCard]
    exact hCount.2.2.2.2
  · apply unitPacking_insert_one_length_le S _ (fun i => (hS i).2.2)
    have hNpos : (0 : ℝ) < N := by exact_mod_cast (show 0 < N by omega)
    have hOne : (1 : ℝ) < N := by exact_mod_cast (show 1 < N by omega)
    have hL := Real.log_pos hOne
    have hBase : (1 : ℝ) ≤ (N : ℝ) / Real.log (N : ℝ) := by
      apply (le_div_iff₀ hL).mpr
      linarith only [Real.log_le_sub_one_of_pos hNpos]
    refine hBase.trans (le_add_of_nonneg_right ?_)
    exact div_nonneg (mul_nonneg hB hNpos.le) (sq_nonneg _)

end LeanAB.PaperB

