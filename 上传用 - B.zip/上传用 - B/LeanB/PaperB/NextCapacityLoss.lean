module

public import PaperB.TargetPadding

meta import Mathlib.Tactic

@[expose] public section

namespace LeanAB.PaperB

open Filter FixedTargets

/-- The improved loss fits within the earlier sufficient bound for a fixed
choice of its secondary coefficient. -/
theorem eventually_nextSufficientLoss_le_sufficientLoss (C : ℝ) (hC : 0 ≤ C) :
    ∀ᶠ N : ℕ in atTop, nextSufficientLoss N C ≤ sufficientLoss N (5 + C) := by
  have hL : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hU := Real.tendsto_log_atTop.comp hL
  have hV := Real.tendsto_log_atTop.comp hU
  filter_upwards [hL.eventually_ge_atTop 1, hU.eventually_ge_atTop 1,
    hV.eventually_ge_atTop 1] with N hLn hUn hVn
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let V := Real.log U
  have hL₁ : 1 ≤ L := hLn
  have hU₁ : 1 ≤ U := hUn
  have hV₁ : 1 ≤ V := hVn
  have hV₀ : 0 < V := zero_lt_one.trans_le hV₁
  have hLogV : Real.log V ≤ V :=
    (Real.log_le_sub_one_of_pos hV₀).trans (sub_le_self _ zero_le_one)
  have hCV : C ≤ C * V := le_mul_of_one_le_right hC hV₁
  have hInner : V + 4 * Real.log V + C ≤ (5 + C) * V :=
    by linarith only [hLogV, hCV]
  have hRatio : 0 ≤ U / L := div_nonneg (zero_le_one.trans hU₁) (zero_le_one.trans hL₁)
  change U ^ 2 / (2 * L) + U * V / L + U / L * (4 * Real.log V + C) ≤
    U ^ 2 / (2 * L) + (5 + C) * U * V / L
  calc
    _ = U ^ 2 / (2 * L) + (U / L) * (V + 4 * Real.log V + C) := by ring
    _ ≤ U ^ 2 / (2 * L) + (U / L) * ((5 + C) * V) := by
      linarith only [mul_le_mul_of_nonneg_left hInner hRatio]
    _ = _ := by ring

theorem eventually_nextSufficientLoss_monotone :
    ∀ᶠ N : ℕ in atTop, Monotone (nextSufficientLoss N) := by
  have hL : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hU := Real.tendsto_log_atTop.comp hL
  filter_upwards [hL.eventually_ge_atTop 1, hU.eventually_ge_atTop 1] with N hLn hUn
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let V := Real.log U
  have hL₁ : 1 ≤ L := hLn
  have hU₁ : 1 ≤ U := hUn
  have hRatio : 0 ≤ U / L := div_nonneg (zero_le_one.trans hU₁) (zero_le_one.trans hL₁)
  intro C D hCD
  have hCoeff : 4 * Real.log V + C ≤ 4 * Real.log V + D := by linarith only [hCD]
  change U ^ 2 / (2 * L) + U * V / L + (U / L) * (4 * Real.log V + C) ≤
    U ^ 2 / (2 * L) + U * V / L + (U / L) * (4 * Real.log V + D)
  linarith only [mul_le_mul_of_nonneg_left hCoeff hRatio]

theorem eventually_nextSufficientLoss_nonneg_lt_one (C : ℝ) (hC : 0 ≤ C) :
    ∀ᶠ N : ℕ in atTop, 0 ≤ nextSufficientLoss N C ∧ nextSufficientLoss N C < 1 := by
  have hL : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hU := Real.tendsto_log_atTop.comp hL
  have hV := Real.tendsto_log_atTop.comp hU
  have hB : 0 ≤ 5 + C := by linarith only [hC]
  filter_upwards [hL.eventually_ge_atTop 1, hU.eventually_ge_atTop 1,
    hV.eventually_ge_atTop 1, eventually_nextSufficientLoss_le_sufficientLoss C hC,
    eventually_losses_between_zero_one 0 (5 + C) le_rfl hB] with N hLn hUn hVn hCompar hOld
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let V := Real.log U
  have hL₀ : 0 ≤ L := zero_le_one.trans (show 1 ≤ L from hLn)
  have hU₀ : 0 ≤ U := zero_le_one.trans (show 1 ≤ U from hUn)
  have hV₁ : 1 ≤ V := hVn
  have hV₀ : 0 ≤ V := zero_le_one.trans hV₁
  have hLogV : 0 ≤ Real.log V := Real.log_nonneg hV₁
  refine ⟨?_, hCompar.trans_lt hOld.2.2⟩
  change 0 ≤ U ^ 2 / (2 * L) + U * V / L + (U / L) * (4 * Real.log V + C)
  positivity

end LeanAB.PaperB
