module

public import Common.StrongPNT
public import PaperB.Obstruction.PrimeMass
public import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
meta import Mathlib.Tactic

/-! Prime windows for the powersmooth sets used in the repair construction. -/

@[expose] public section

open Filter Finset Set Asymptotics
open scoped Topology

namespace LeanAB.PaperB

/-- A fixed power window contains a positive reciprocal mass of primes. -/
theorem eventually_prime_power_window_mass {a b : ℝ} (ha : 0 < a) (hab : a < b) :
    ∀ᶠ x : ℝ in atTop,
      (b - a) / (2 * b) ≤ ∑ p ∈ primesBetween (x ^ a) (x ^ b), (p : ℝ)⁻¹ := by
  obtain ⟨C, hC, hθ⟩ := thetaLogSquaredError_pntPlus
  obtain ⟨T, hT⟩ := eventually_atTop.mp hθ
  have hb := ha.trans hab
  have hpow : Tendsto (fun x : ℝ => x ^ a) atTop atTop := tendsto_rpow_atTop ha
  have hlog : Tendsto Real.log atTop atTop := Real.tendsto_log_atTop
  filter_upwards [eventually_gt_atTop (1 : ℝ), hpow.eventually_ge_atTop (max T (Real.exp 1)),
    hlog.eventually_ge_atTop (max (2 / (b - a)) ((4 * C + 1) / a))] with x hx hxT hxlog
  let A := x ^ a
  let B := x ^ b
  let δ := C / (Real.log A) ^ 2
  have hx₀ : 0 < x := zero_lt_one.trans hx
  have hlogx : 0 < Real.log x := Real.log_pos hx
  have hA₁ : 1 < A := Real.one_lt_rpow hx ha
  have hAB : A ≤ B := Real.rpow_le_rpow_of_exponent_le hx.le hab.le
  have hB₁ := hA₁.trans_le hAB
  have hlogA : 0 < Real.log A := Real.log_pos hA₁
  have hlogB : 0 < Real.log B := Real.log_pos hB₁
  have hlogA' : Real.log A = a * Real.log x := Real.log_rpow hx₀ _
  have hlogB' : Real.log B = b * Real.log x := Real.log_rpow hx₀ _
  have hlogAone : 1 ≤ Real.log A := by
    rw [← Real.log_exp 1]
    exact Real.log_le_log (Real.exp_pos _) ((le_max_right T (Real.exp 1)).trans hxT)
  have hlogA3 : 4 * C + 1 ≤ Real.log A := by
    rw [hlogA']
    rw [mul_comm a]
    exact (div_le_iff₀ ha).mp ((le_max_right (2 / (b - a)) _).trans hxlog)
  have hErr (t : ℝ) (ht : t ∈ Set.Icc A B) :
      |Chebyshev.theta t - t| ≤ δ * t := by
    have htpos := hA₁.trans_le ht.1
    have htlog := Real.log_le_log (zero_lt_one.trans hA₁) ht.1
    have hδt : C / (Real.log t) ^ 2 ≤ δ := by
      exact div_le_div_of_nonneg_left hC (sq_pos_of_pos hlogA)
        (pow_le_pow_left₀ hlogA.le htlog 2)
    calc
      _ ≤ C * t / (Real.log t) ^ 2 := hT _ ((le_max_left T (Real.exp 1)).trans (hxT.trans ht.1))
      _ = (C / (Real.log t) ^ 2) * t := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_right hδt (zero_lt_one.trans htpos).le
  have hCont : ContinuousOn (fun t : ℝ => -(t ^ 2)⁻¹) (Set.Icc A B) := by
    apply ContinuousOn.neg
    apply (continuous_id.pow 2).continuousOn.inv₀
    intro t ht
    exact pow_ne_zero _ (zero_lt_one.trans (hA₁.trans_le ht.1)).ne'
  have hAbel := abs_weighted_prime_sum_sub_integral_le (f := fun t => t⁻¹)
    (f' := fun t => -(t ^ 2)⁻¹) (zero_lt_one.trans hA₁).le hAB
    (fun t ht => hasDerivAt_inv ((zero_lt_one.trans (hA₁.trans_le ht.1)).ne')) hCont
    (fun t ht => inv_nonneg.mpr (zero_lt_one.trans (hA₁.trans_le ht.1)).le)
    (fun _ _ => neg_nonpos.mpr (inv_nonneg.mpr (sq_nonneg _))) hErr
  have hInt : (∫ t in A..B, t⁻¹) = (b - a) * Real.log x := by
    rw [integral_inv_of_pos (zero_lt_one.trans hA₁) (zero_lt_one.trans hB₁),
      Real.log_div (zero_lt_one.trans hB₁).ne' (zero_lt_one.trans hA₁).ne', hlogA', hlogB']
    ring
  have hI : 2 ≤ (b - a) * Real.log x := by
    rw [mul_comm]
    exact (div_le_iff₀ (sub_pos.mpr hab)).mp ((le_max_left (2 / (b - a)) _).trans hxlog)
  have hAbs := (abs_le.mp hAbel).1
  rw [hInt] at hAbs
  have hAinv : 2 * A * A⁻¹ = 2 := by field_simp
  rw [hAinv] at hAbs
  have hUpper : (∑ p ∈ primesBetween A B, (p : ℝ)⁻¹ * Real.log p) ≤
      (∑ p ∈ primesBetween A B, (p : ℝ)⁻¹) * Real.log B := by
    rw [sum_mul]
    apply sum_le_sum
    intro p hp
    obtain ⟨_, hpB, hpPrime⟩ := (mem_primesBetween (zero_lt_one.trans hA₁).le
      (zero_lt_one.trans hB₁).le).mp hp
    exact mul_le_mul_of_nonneg_left
      (Real.log_le_log (by exact_mod_cast hpPrime.pos) hpB) (by positivity)
  change (b - a) / (2 * b) ≤ ∑ p ∈ primesBetween A B, (p : ℝ)⁻¹
  have hδsmall : δ ≤ 1 / 4 := by
    change C / Real.log A ^ 2 ≤ 1 / 4
    apply (div_le_iff₀ (sq_pos_of_pos hlogA)).mpr
    have hsq : Real.log A ≤ Real.log A ^ 2 := by nlinarith only [hlogAone]
    linarith only [hsq, hlogA3]
  have hHalf : (b - a) * Real.log x / 2 ≤
      ∑ p ∈ primesBetween A B, (p : ℝ)⁻¹ * Real.log p := by
    have hδI := mul_le_mul_of_nonneg_right hδsmall (show 0 ≤ (b - a) * Real.log x + 2 by linarith)
    linarith
  have hgoal := hHalf.trans hUpper
  rw [hlogB', ← mul_assoc] at hgoal
  apply (div_le_iff₀ (by positivity : 0 < 2 * b)).mpr
  have hcancel := (mul_le_mul_iff_left₀ hlogx).mp
    (show ((b - a) / 2) * Real.log x ≤
      ((∑ p ∈ primesBetween A B, (p : ℝ)⁻¹) * b) * Real.log x by linarith)
  linarith

/-- The prime count is uniform for a window of relative width at least 1/(K log x)
whose left endpoint lies in a fixed power range of x. -/
theorem eventually_short_prime_window_count {a K : ℝ} (ha : 0 < a) (hK : 0 < K) :
    ∀ᶠ x : ℝ in atTop, ∀ z w : ℝ, x ^ a ≤ z → z ≤ x →
      z / (K * Real.log x) ≤ w → w ≤ z →
      z / (4 * K * (Real.log x) ^ 2) ≤ (primesBetween z (z + w)).card := by
  obtain ⟨C, hC, hθ⟩ := thetaLogSquaredError_pntPlus
  obtain ⟨T, hT⟩ := eventually_atTop.mp hθ
  have hpow : Tendsto (fun x : ℝ => x ^ a) atTop atTop := tendsto_rpow_atTop ha
  filter_upwards [eventually_gt_atTop (2 : ℝ), hpow.eventually_ge_atTop T,
    Real.tendsto_log_atTop.eventually_ge_atTop (6 * K * C / a ^ 2)] with x hx hxT hxLog
  intro z w hz hzx hw hww
  have hx' : 1 < x := by linarith
  have hlogx : 0 < Real.log x := Real.log_pos hx'
  have hlogxK : 0 < K * Real.log x := mul_pos hK hlogx
  have hz' : 1 < z := (Real.one_lt_rpow hx' ha).trans_le hz
  have hz₀ : 0 < z := zero_lt_one.trans hz'
  have hw₀ : 0 < w := (div_pos hz₀ hlogxK).trans_le hw
  have hzb : z ≤ z + w := by linarith
  let δ : ℝ := C / (a * Real.log x) ^ 2
  have hden : 0 < a * Real.log x := mul_pos ha hlogx
  have hδ₀ : 0 ≤ δ := div_nonneg hC (sq_nonneg _)
  have hδ : δ ≤ (6 * K * Real.log x)⁻¹ := by
    apply (div_le_iff₀ (sq_pos_of_pos hden)).mpr
    apply (le_inv_mul_iff₀ (by positivity : 0 < 6 * K * Real.log x)).mpr
    have h0 := (div_le_iff₀ (sq_pos_of_pos ha)).mp hxLog
    have h1 := mul_le_mul_of_nonneg_right h0 hlogx.le
    simpa only [mul_pow] using (show 6 * K * Real.log x * C ≤
      a ^ 2 * Real.log x ^ 2 by nlinarith only [h1])
  have hErr (t : ℝ) (ht : t ∈ Set.Icc z (z + w)) :
      |Chebyshev.theta t - t| ≤ δ * t := by
    have hlogt : a * Real.log x ≤ Real.log t := by
      rw [← Real.log_rpow (by linarith : 0 < x)]
      exact Real.log_le_log (by positivity) (hz.trans ht.1)
    have hδt : C / (Real.log t) ^ 2 ≤ δ :=
      div_le_div_of_nonneg_left hC (sq_pos_of_pos hden) (pow_le_pow_left₀ hden.le hlogt 2)
    calc
      _ ≤ C * t / (Real.log t) ^ 2 := hT t (hxT.trans (hz.trans ht.1))
      _ = (C / (Real.log t) ^ 2) * t := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_right hδt (hz₀.le.trans ht.1)
  have hAbel := abs_weighted_prime_sum_sub_integral_le (f := fun _ => 1)
    (f' := fun _ => 0) hz₀.le hzb (fun t _ => hasDerivAt_const t 1) continuousOn_const
    (fun _ _ => zero_le_one) (fun _ _ => le_rfl) hErr
  simp only [one_mul, mul_one, intervalIntegral.integral_const, smul_eq_mul, add_sub_cancel_left] at hAbel
  have hAbs := (abs_le.mp hAbel).1
  have hδw : δ * (w + 2 * z) ≤ w / 2 := calc
    _ ≤ (6 * K * Real.log x)⁻¹ * (3 * z) :=
      mul_le_mul hδ (by linarith) (by positivity) (by positivity)
    _ = z / (K * Real.log x) / 2 := by field_simp; ring
    _ ≤ _ := div_le_div_of_nonneg_right hw (by norm_num)
  have hPrimeLogs : w / 2 ≤ ∑ p ∈ primesBetween z (z + w), Real.log p := by linarith
  have hlog2 : Real.log 2 ≤ Real.log x :=
    Real.log_le_log (by norm_num) hx.le
  have hMain : (∑ p ∈ primesBetween z (z + w), Real.log p) ≤
      ((primesBetween z (z + w)).card : ℝ) * (2 * Real.log x) := by
    calc
      _ ≤ ∑ _p ∈ primesBetween z (z + w), 2 * Real.log x := ?_
      _ = _ := by rw [Finset.sum_const, nsmul_eq_mul]
    apply sum_le_sum
    intro p hp
    obtain ⟨_, hpz, hPrime⟩ := (mem_primesBetween hz₀.le (hz₀.le.trans hzb)).mp hp
    calc
      _ ≤ Real.log (2 * x) := Real.log_le_log (by exact_mod_cast hPrime.pos) (by linarith)
      _ = Real.log 2 + Real.log x := Real.log_mul (by norm_num) (by linarith)
      _ ≤ _ := by linarith
  apply (div_le_iff₀ (by positivity : 0 < 4 * K * Real.log x ^ 2)).mpr
  have hFinal := (div_le_iff₀ hlogxK).mp hw
  have hstep : w ≤ ((primesBetween z (z + w)).card : ℝ) * (4 * Real.log x) := by
    linarith only [hPrimeLogs.trans hMain]
  nlinarith only [hFinal, mul_le_mul_of_nonneg_right hstep hlogxK.le]

end LeanAB.PaperB
