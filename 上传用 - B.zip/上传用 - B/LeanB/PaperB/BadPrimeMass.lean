module

public import PaperB.AverageLift
public import PaperB.RepairBudget
meta import Mathlib.Tactic

/-! The reciprocal mass discarded for exceptional primes in the F2 cover. -/

@[expose] public section

namespace LeanAB.PaperB.Closure

open Filter Finset Asymptotics
open scoped Topology

/-- The large primes with no reciprocal cover at the common cofactor height. -/
noncomputable def badCoverPrimes (N Q : ℕ) : Finset ℕ := by
  classical
  exact (largePrimes N).filter fun p => ¬ CoversResidues p (interval 1 Q)

/-- All the original denominator blocks of the large primes without a cover. -/
noncomputable def badCoverPart (N Q : ℕ) : Finset ℕ :=
  (badCoverPrimes N Q).biUnion fun p => primePart p (denominators N)

theorem mem_badCoverPrimes {N Q p : ℕ} :
    p ∈ badCoverPrimes N Q ↔ p ∈ largePrimes N ∧ ¬ CoversResidues p (interval 1 Q) := by
  classical
  exact mem_filter

private theorem primeWindow_split {x y z : ℝ} (hx : 0 ≤ x) (hxy : x ≤ y) (hyz : y ≤ z) :
    primesBetween x z = primesBetween x y ∪ primesBetween y z := by
  ext p
  simp only [mem_union, mem_primesBetween hx (hx.trans (hxy.trans hyz)),
    mem_primesBetween hx (hx.trans hxy),
    mem_primesBetween (hx.trans hxy) (hx.trans (hxy.trans hyz))]
  constructor
  · rintro ⟨hxP,hzP,hp⟩
    exact (le_or_gt (p : ℝ) y).elim
      (fun hyP => Or.inl ⟨hxP,hyP,hp⟩) (fun hyP => Or.inr ⟨hyP,hzP,hp⟩)
  · rintro (⟨hxP,hyP,hp⟩ | ⟨hyP,hzP,hp⟩)
    · exact ⟨hxP,hyP.trans hyz,hp⟩
    · exact ⟨hxy.trans_lt hyP,hzP,hp⟩

private theorem dyadic_prime_sum_le {x A : ℝ} (hx : 0 ≤ x) (M : ℕ)
    (bad : ℕ → Prop) [DecidablePred bad] (w : ℕ → ℝ)
    (hBins : ∀ i < M, (∑ p ∈ (primesBetween ((2 : ℝ) ^ i * x) (2 * (2 ^ i * x))).filter bad,
        w p) ≤ A) :
    (∑ p ∈ (primesBetween x ((2 : ℝ) ^ M * x)).filter bad, w p) ≤ (M : ℝ) * A := by
  induction M with
  | zero => simp [primesBetween]
  | succ i ih =>
    let P : ℝ := 2 ^ i * x
    have hP : x ≤ P := by
      simpa only [one_mul] using mul_le_mul_of_nonneg_right
        (show 1 ≤ (2 : ℝ) ^ i from one_le_pow₀ (by norm_num)) hx
    have hP₀ := hx.trans hP
    have hEnd : (2 : ℝ) ^ (i + 1) * x = 2 * P := by dsimp only [P]; rw [pow_succ]; ring
    rw [hEnd, primeWindow_split hx hP (by linarith)]
    have hDisj : Disjoint (primesBetween x P) (primesBetween P (2 * P)) := by
      refine disjoint_left.mpr fun p hp hp' => ?_
      exact ((mem_primesBetween hP₀ (by positivity)).mp hp').1.not_ge
        ((mem_primesBetween hx hP₀).mp hp).2.1
    rw [filter_union, sum_union (hDisj.mono (filter_subset _ _) (filter_subset _ _))]
    calc
      _ ≤ (i : ℝ) * A + A :=
        add_le_add (ih fun j hj => hBins j (Nat.lt_succ_of_lt hj)) (hBins i (Nat.lt_succ_self i))
      _ = _ := by push_cast; ring

private theorem log_window_bound_mono {P N : ℝ} (hP₁ : 1 ≤ P)
    (hU₁ : 1 ≤ Real.log (Real.log P)) (hPN : P ≤ N) :
    Real.log P * Real.log (Real.log P) * Real.log (Real.log (Real.log P)) ^ 4 ≤
      Real.log N * Real.log (Real.log N) * Real.log (Real.log (Real.log N)) ^ 4 := by
  have hL : Real.log P ≤ Real.log N := Real.log_le_log (zero_lt_one.trans_le hP₁) hPN
  have hL₀ : 0 < Real.log P := Real.log_pos (by
    by_contra! h
    have heq := le_antisymm h hP₁
    rw [heq, Real.log_one, Real.log_zero] at hU₁
    norm_num at hU₁)
  have hU := Real.log_le_log hL₀ hL
  have hU₀ := zero_lt_one.trans_le hU₁
  have hV := Real.log_le_log hU₀ hU
  exact mul_le_mul
    (mul_le_mul hL hU hU₀.le (hL₀.le.trans hL))
    (pow_le_pow_left₀ (Real.log_nonneg hU₁) hV 4)
    (pow_nonneg (Real.log_nonneg hU₁) _) (mul_nonneg (hL₀.le.trans hL) (hU₀.le.trans hU))

/-- At the common F2 cofactor height, all discarded large-prime blocks
together cost at most N^(-1/4+ε), with the width constant independent of ε. -/
theorem eventually_badCoverPart_mass_le_rpow :
    ∃ K : ℝ, 0 < K ∧ ∀ ε : ℝ, 0 < ε → ∀ᶠ N : ℕ in atTop, ∀ Q : ℕ,
      K * Real.log (N : ℝ) * Real.log (Real.log (N : ℝ)) *
          Real.log (Real.log (Real.log (N : ℝ))) ^ 4 ≤ (Q : ℝ) →
      (mass (badCoverPart N Q) : ℝ) ≤ (N : ℝ) ^ (-1 / 4 + ε) := by
  obtain ⟨K,hK,hAverage⟩ := eventually_average_reciprocal_cover
  refine ⟨K,hK,?_⟩
  intro ε hε
  let δ := min ε (1 / 8 : ℝ)
  have hδ : 0 < δ := lt_min hε (by norm_num)
  have hδ₈ : δ ≤ 1 / 8 := min_le_right _ _
  have hδ_ε : δ ≤ ε := min_le_left _ _
  let s : ℝ := ε - δ / 2
  have hs : 0 < s := by dsimp only [s]; linarith
  let c : ℝ := 1 / Real.log 2 + 1
  have hLog2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hc : 0 < c := by dsimp only [c]; positivity
  have hPow := (isLittleO_log_rpow_rpow_atTop (s := s) 2 hs).bound
    (show 0 < 1 / (2 * c) by positivity)
  obtain ⟨T, hT⟩ := eventually_atTop.mp (hAverage δ hδ)
  obtain ⟨T', hT'⟩ := eventually_atTop.mp
    ((Real.tendsto_log_atTop.comp Real.tendsto_log_atTop).eventually_ge_atTop (1 : ℝ))
  have hCast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hRoot := Real.tendsto_sqrt_atTop.comp hCast
  filter_upwards [hRoot.eventually_ge_atTop (max 1 (max T T')),
    (Real.tendsto_log_atTop.comp hCast).eventually_ge_atTop 1, hCast.eventually hPow,
    eventually_ge_atTop (1 : ℕ)] with N hRootN hLogN hPowN hN
  intro Q hQ
  classical
  let x := Real.sqrt (N : ℝ)
  let L := Real.log (N : ℝ)
  let M : ℕ := ⌈L / Real.log 2⌉₊
  let A : ℝ := (1 + L) * x ^ (-1 / 2 + δ)
  let B := badCoverPrimes N Q
  let w (p : ℕ) : ℝ := mass (primePart p (denominators N))
  have hN₀ : 0 < (N : ℝ) := by exact_mod_cast (zero_lt_one.trans_le hN)
  have hx₁ : 1 ≤ x := (le_max_left _ _).trans hRootN
  have hx₀ := zero_lt_one.trans_le hx₁
  have hL₁ : 1 ≤ L := hLogN
  have hL₀ := zero_lt_one.trans_le hL₁
  have hNUpper : (N : ℝ) ≤ (2 : ℝ) ^ M * x := by
    have hPower : (N : ℝ) ≤ (2 : ℝ) ^ M := by
      rw [← Real.rpow_natCast]
      apply (Real.le_rpow_iff_log_le hN₀ (by norm_num)).mpr
      exact (div_le_iff₀ hLog2).mp (Nat.le_ceil (L / Real.log 2))
    simpa only [mul_one] using mul_le_mul hPower hx₁ zero_le_one (by positivity : 0 ≤ (2 : ℝ) ^ M)
  have hB : (primesBetween x ((2 : ℝ) ^ M * x)).filter (fun p => p ∈ B) = B := by
    ext p
    simp only [mem_filter, and_iff_right_iff_imp]
    intro hp
    obtain ⟨hPrime,hpN,hpSq⟩ := mem_largePrimes.mp (mem_badCoverPrimes.mp hp).1
    have hplt : x < (p : ℝ) := by
      apply (Real.sqrt_lt hN₀.le (Nat.cast_nonneg _)).mpr
      rw [pow_two]
      exact_mod_cast Nat.sqrt_lt.mp hpSq
    exact (mem_primesBetween hx₀.le (by positivity)).mpr ⟨hplt,
      (Nat.cast_le.mpr hpN).trans hNUpper,hPrime⟩
  have hEach (i : ℕ) :
      (∑ p ∈ (primesBetween ((2 : ℝ) ^ i * x) (2 * (2 ^ i * x))).filter (fun p => p ∈ B), w p)
        ≤ A := by
    let P : ℝ := 2 ^ i * x
    let J := (primesBetween P (2 * P)).filter (fun p => p ∈ B)
    change (∑ p ∈ J, w p) ≤ A
    have hP : x ≤ P := by
      simpa only [one_mul] using mul_le_mul_of_nonneg_right
        (show 1 ≤ (2 : ℝ) ^ i from one_le_pow₀ (by norm_num)) hx₀.le
    have hP₀ := hx₀.trans_le hP
    have hLocal (p : ℕ) (hp : p ∈ J) := (mem_primesBetween hP₀.le (by positivity)).mp
      (mem_filter.mp hp).1
    by_cases hPN : P ≤ (N : ℝ)
    · have hU₁ : 1 ≤ Real.log (Real.log P) := hT' P
        ((le_max_right T T').trans ((le_max_right 1 (max T T')).trans (hRootN.trans hP)))
      obtain ⟨E,hE,hCover⟩ := hT P
        ((le_max_left T T').trans ((le_max_right 1 (max T T')).trans (hRootN.trans hP)))
      have hJ : J ⊆ E := by
        intro p hp
        obtain ⟨hpLo,hpHi,hpPrime⟩ := hLocal p hp
        by_contra he
        obtain ⟨q,_,hq,hqCover⟩ := hCover p hpPrime hpLo.le hpHi he
        have hqQ : (q : ℝ) ≤ Q := hq.trans (le_trans (by
          have hh := mul_le_mul_of_nonneg_left
            (log_window_bound_mono (hx₁.trans hP) hU₁ hPN) hK.le
          convert hh using 1 <;> ring) hQ)
        apply (mem_badCoverPrimes.mp (mem_filter.mp hp).2).2
        intro v
        obtain ⟨S,hS,hv⟩ := hqCover v
        exact ⟨S,hS.trans (Icc_subset_Icc_right (Nat.cast_le.mp hqQ)),hv⟩
      have hCard : (J.card : ℝ) ≤ P ^ (1 / 2 + δ) :=
        (show (J.card : ℝ) ≤ E.card by exact_mod_cast card_le_card hJ).trans hE
      have hWeight (p : ℕ) (hp : p ∈ J) : w p ≤ (1 + L) / P := by
        obtain ⟨hpLo,_,hpPrime⟩ := hLocal p hp
        have hpN := (mem_largePrimes.mp (mem_badCoverPrimes.mp (mem_filter.mp hp).2).1).2.1
        have hQ₀ : 0 < N / p := Nat.div_pos hpN hpPrime.pos
        have hLog : Real.log ((N / p : ℕ) : ℝ) ≤ L :=
          Real.log_le_log (by exact_mod_cast hQ₀) (by exact_mod_cast Nat.div_le_self N p)
        have hMass : (mass (cofactorBlock N p) : ℝ) ≤ 1 + L := by
          have hh := harmonic_le_one_add_log (N / p)
          rw [← mass_denominators_eq_harmonic] at hh
          change (mass (denominators (N / p)) : ℝ) ≤ 1 + L
          linarith only [hh,hLog]
        dsimp only [w]
        rw [mass_primePart hpPrime.pos, Rat.cast_div, Rat.cast_natCast]
        exact (div_le_div_of_nonneg_right hMass (Nat.cast_nonneg _)).trans
          (div_le_div_of_nonneg_left (by positivity) hP₀ hpLo.le)
      calc
        _ ≤ ∑ _p ∈ J, (1 + L) / P := sum_le_sum hWeight
        _ = (J.card : ℝ) * ((1 + L) / P) := by rw [sum_const,nsmul_eq_mul]
        _ ≤ P ^ (1 / 2 + δ) * ((1 + L) / P) :=
          mul_le_mul_of_nonneg_right hCard (by positivity)
        _ = (1 + L) * P ^ (-1 / 2 + δ) := by
          have hpPow : P ^ (1 / 2 + δ) / P = P ^ (-1 / 2 + δ) := calc
            _ = P ^ (1 / 2 + δ) / P ^ (1 : ℝ) := by rw [Real.rpow_one]
            _ = _ := by
              rw [← Real.rpow_sub hP₀, show (1 / 2 + δ - 1 : ℝ) = -1 / 2 + δ by ring]
          calc
            _ = (1 + L) * (P ^ (1 / 2 + δ) / P) := by ring
            _ = _ := by rw [hpPow]
        _ ≤ _ := mul_le_mul_of_nonneg_left (Real.rpow_le_rpow_of_nonpos hx₀ hP (by linarith)) (by positivity)
    · have hEmpty : J = ∅ := eq_empty_iff_forall_notMem.mpr fun p hp => by
        have hpN := (mem_largePrimes.mp (mem_badCoverPrimes.mp (mem_filter.mp hp).2).1).2.1
        exact hPN ((hLocal p hp).1.le.trans (Nat.cast_le.mpr hpN))
      rw [hEmpty,sum_empty]
      exact mul_nonneg (by positivity) (Real.rpow_nonneg hx₀.le _)
  have hSum : ∑ p ∈ B, w p ≤ (M : ℝ) * A := by
    simpa only [hB] using dyadic_prime_sum_le hx₀.le M (fun p => p ∈ B) w (fun i _ => hEach i)
  have hMass : (mass (badCoverPart N Q) : ℝ) = ∑ p ∈ B, w p := by
    have hD : ((B : Finset ℕ) : Set ℕ).PairwiseDisjoint
        (fun p => primePart p (denominators N)) := by
      intro p hp q hq hpq
      exact primePart_disjoint (mem_badCoverPrimes.mp hp).1 (mem_badCoverPrimes.mp hq).1 hpq
    rw [badCoverPart, show mass _ = ∑ p ∈ B, mass (primePart p (denominators N))
      from sum_biUnion hD, Rat.cast_sum]
  have hM : (M : ℝ) ≤ c * L := by
    have hh := Nat.ceil_lt_add_one (show 0 ≤ L / Real.log 2 by positivity)
    change (M : ℝ) < L / Real.log 2 + 1 at hh
    calc
      _ ≤ L / Real.log 2 + 1 := hh.le
      _ ≤ c * L := by dsimp only [c]; rw [add_mul, one_mul, one_div_mul_eq_div]; linarith
  have hSmall : 2 * c * L ^ (2 : ℕ) ≤ (N : ℝ) ^ s := by
    change ‖L ^ (2 : ℝ)‖ ≤ (1 / (2 * c)) * ‖(N : ℝ) ^ s‖ at hPowN
    have hh : L ^ (2 : ℕ) ≤ (1 / (2 * c)) * (N : ℝ) ^ s := by
      simpa only [show (2 : ℝ) = ((2 : ℕ) : ℝ) by norm_num, Real.rpow_natCast,
        Real.norm_eq_abs, abs_of_nonneg (sq_nonneg L), abs_of_nonneg (Real.rpow_nonneg hN₀.le _)] using hPowN
    rw [one_div_mul_eq_div, le_div_iff₀ (by positivity : 0 < 2 * c), mul_comm] at hh
    exact hh
  rw [hMass]
  calc
    _ ≤ (M : ℝ) * A := hSum
    _ ≤ (c * L) * ((2 * L) * x ^ (-1 / 2 + δ)) := mul_le_mul hM
      (mul_le_mul_of_nonneg_right (by linarith) (Real.rpow_nonneg hx₀.le _)) (by positivity) (by positivity)
    _ = (2 * c * L ^ (2 : ℕ)) * (N : ℝ) ^ (-1 / 4 + δ / 2) := by
      have hr : x ^ (-1 / 2 + δ) = (N : ℝ) ^ (-1 / 4 + δ / 2) := by
        change (Real.sqrt (N : ℝ)) ^ (-1 / 2 + δ) = _
        rw [Real.sqrt_eq_rpow, ← Real.rpow_mul hN₀.le,
          show (1 / 2 * (-1 / 2 + δ) : ℝ) = -1 / 4 + δ / 2 by ring]
      rw [hr]
      ring
    _ ≤ (N : ℝ) ^ s * (N : ℝ) ^ (-1 / 4 + δ / 2) :=
      mul_le_mul_of_nonneg_right hSmall (Real.rpow_nonneg hN₀.le _)
    _ = _ := by
      rw [← Real.rpow_add hN₀, show s + (-1 / 4 + δ / 2) = -1 / 4 + ε by dsimp only [s]; ring]

/-- The bad blocks fit within the F2 next-order reciprocal-mass budget. -/
theorem eventually_badCoverPart_mass_le :
    ∃ K : ℝ, 0 < K ∧ ∀ᶠ N : ℕ in atTop, ∀ Q : ℕ,
      K * Real.log (N : ℝ) * Real.log (Real.log (N : ℝ)) *
          Real.log (Real.log (Real.log (N : ℝ))) ^ 4 ≤ (Q : ℝ) →
      (mass (badCoverPart N Q) : ℝ) ≤ Real.log (Real.log (N : ℝ)) / Real.log (N : ℝ) := by
  obtain ⟨K,hK,hLoss⟩ := eventually_badCoverPart_mass_le_rpow
  refine ⟨K,hK,?_⟩
  have hCast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hL := Real.tendsto_log_atTop.comp hCast
  have hU := Real.tendsto_log_atTop.comp hL
  filter_upwards [hLoss (1 / 8) (by norm_num),
    eventually_log_pow_le_rpow 1 (show 0 < (1 / 8 : ℝ) by norm_num),
    hL.eventually_ge_atTop 1, hU.eventually_ge_atTop 1, eventually_ge_atTop (1 : ℕ)]
    with N hLossN hLog hL₁ hU₁ hN₁
  intro Q hQ
  have hN₀ : 0 < (N : ℝ) := by exact_mod_cast zero_lt_one.trans_le hN₁
  have hLp : 0 < Real.log (N : ℝ) := zero_lt_one.trans_le hL₁
  calc
    _ ≤ (N : ℝ) ^ (-1 / 4 + 1 / 8 : ℝ) := hLossN Q hQ
    _ = 1 / (N : ℝ) ^ (1 / 8 : ℝ) := by
      rw [show (-1 / 4 + 1 / 8 : ℝ) = -(1 / 8) by norm_num, Real.rpow_neg hN₀.le]
      exact (one_div _).symm
    _ ≤ 1 / Real.log (N : ℝ) := div_le_div_of_nonneg_left zero_le_one hLp (by simpa only [pow_one] using hLog)
    _ ≤ _ := div_le_div_of_nonneg_right hU₁ hLp.le

end LeanAB.PaperB.Closure
