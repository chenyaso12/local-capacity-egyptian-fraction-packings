module

public import PaperB.Baseline
meta import Mathlib.Tactic

/-! The exact lower and upper floors at the sufficient length threshold in F2. -/

@[expose] public section

namespace LeanAB.PaperB.FixedTargets

open Filter
open scoped Topology

/-- One constant gives both unrounded loss bounds and the sufficient length
threshold for the restricted matching number. -/
theorem eventually_boundedPacking_floors_of_sufficiency (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ K : ℕ,
      (r : ℝ) * (N : ℝ) / Real.log N + C * (N : ℝ) / (Real.log N) ^ 2 ≤ K →
      ⌊((targetStock r N : ℝ) - sufficientLoss N C) / (r : ℝ)⌋ ≤
        (boundedPackingNumber r K N : ℤ) ∧
      (boundedPackingNumber r K N : ℤ) ≤
        ⌊((targetStock r N : ℝ) - necessaryLoss N C) / (r : ℝ)⌋ := by
  obtain ⟨Cminus,hMinus,hUp⟩ := eventually_boundedPacking_upper hr
  obtain ⟨Cplus,D,hPlus,hD,hLow⟩ := eventually_boundedPacking_lower_with_length_of_sufficiency hSuff hr
  let C := max (max Cminus Cplus) D
  have hCminus : Cminus ≤ C := (le_max_left _ _).trans (le_max_left _ _)
  have hCplus : Cplus ≤ C := (le_max_right _ _).trans (le_max_left _ _)
  have hCD : D ≤ C := le_max_right _ _
  refine ⟨C,hD.trans_le hCD,?_⟩
  have hL : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hU := Real.tendsto_log_atTop.comp hL
  filter_upwards [hUp,hLow,hL.eventually_ge_atTop 1,hU.eventually_ge_atTop 1] with N hUpper hLower hN hU
  intro K hK
  let L := Real.log (N : ℝ)
  let U := Real.log L
  change 1 ≤ L at hN
  change 1 ≤ U at hU
  have hL₀ : 0 < L := zero_lt_one.trans_le hN
  have hU₀ : 0 ≤ U := zero_le_one.trans hU
  have hLogU₀ : 0 ≤ Real.log U := Real.log_nonneg hU
  have hr₀ : (0 : ℝ) ≤ r := by exact_mod_cast hr.le
  have hLength : (r : ℝ) * (N : ℝ) / L + D * (N : ℝ) / L ^ 2 ≤ K := by
    apply le_trans (add_le_add le_rfl ?_) hK
    exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right hCD (Nat.cast_nonneg _))
      (sq_nonneg L)
  have hPlus' : sufficientLoss N Cplus ≤ sufficientLoss N C := by
    change U ^ 2 / (2 * L) + Cplus * U * Real.log U / L ≤
      U ^ 2 / (2 * L) + C * U * Real.log U / L
    exact add_le_add le_rfl (div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hCplus hU₀) hLogU₀) hL₀.le)
  have hMinus' : necessaryLoss N C ≤ necessaryLoss N Cminus := by
    change U ^ 2 / (2 * L) - C * U / L ≤ U ^ 2 / (2 * L) - Cminus * U / L
    exact sub_le_sub_left (div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_right hCminus hU₀) hL₀.le) _
  exact ⟨(Int.floor_mono (div_le_div_of_nonneg_right (sub_le_sub_left hPlus' _) hr₀)).trans
      (hLower K hLength),
    (hUpper K).trans (Int.floor_mono (div_le_div_of_nonneg_right (sub_le_sub_left hMinus' _) hr₀))⟩

/-- The exact F2 floors specialized to the explicit Liu--Sawhney height input. -/
theorem eventually_boundedPacking_floors_of_LiuSawhney
    (hHeight : ShortPointwise.LiuSawhneyPrimeHeight) {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ K : ℕ,
      (r : ℝ) * (N : ℝ) / Real.log N + C * (N : ℝ) / (Real.log N) ^ 2 ≤ K →
      ⌊((targetStock r N : ℝ) - sufficientLoss N C) / (r : ℝ)⌋ ≤
        (boundedPackingNumber r K N : ℤ) ∧
      (boundedPackingNumber r K N : ℤ) ≤
        ⌊((targetStock r N : ℝ) - necessaryLoss N C) / (r : ℝ)⌋ :=
  eventually_boundedPacking_floors_of_sufficiency (Baseline.packingSufficiency_of_LiuSawhney hHeight) hr

end LeanAB.PaperB.FixedTargets
