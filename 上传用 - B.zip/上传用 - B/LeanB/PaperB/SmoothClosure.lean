module

public import PaperB.SmoothFourier
public import PaperB.SmoothPoolMass
public import PaperB.SmoothSeparation
public import PaperB.PowersmoothDensity
import Mathlib.Tactic

public section

/-! Joining the smooth interval mass and separation estimates to the exact closure. -/

namespace LeanAB.PaperB.Closure

open Filter
open SmoothSeparation
open scoped Topology

/-- The full F2 uniform smooth closure follows from dyadic sixth-root
powersmooth density and the separation estimate for the canonical short interval. -/
theorem exists_uniformSmoothClosure_of_density_and_separation (c₆ cSep : ℝ)
    (hc₆ : 0 < c₆) (hcSep : 0 < cSep)
    (hDensity : ∀ᶠ X : ℕ in atTop,
      c₆ * (X : ℝ) ≤
        (((Finset.Ioc X (2 * X)).filter (fun b => b ∣ Nat.lcmUpto (Nat.nthRoot 6 X))).card : ℝ))
    (hSep : ∀ᶠ X : ℕ in atTop, ∀ j : ℤ, (X : ℝ) / 2 < |(j : ℝ)| →
      |(j : ℝ)| ≤ (Nat.lcmUpto (Nat.nthRoot 5 X) : ℝ) / 2 →
      ∃ W ⊆ closureShortDenominators X,
        cSep * (X : ℝ) ^ (3 / 4 : ℝ) ≤ (W.card : ℝ) ∧
        ∀ b ∈ W, ∀ a : ℤ, (X : ℝ) ^ (-1 / 4 : ℝ) / 2 ≤ |(j : ℝ) / b - a|) :
    ∃ C X₀ : ℕ, UniformSmoothClosure C X₀ := by
  obtain ⟨C, hC, hMass⟩ := exists_wide_smooth_closure_pool c₆ hc₆ hDensity
  refine ⟨C, uniformSmoothClosure_of_pools_and_separation C hC cSep hcSep ?_⟩
  have hLog := Real.tendsto_log_atTop.comp
    (tendsto_natCast_atTop_atTop : Tendsto (fun X : ℕ => (X : ℝ)) atTop atTop)
  filter_upwards [hMass, hSep, hLog.eventually_ge_atTop 2, eventually_ge_atTop (2 : ℕ)]
    with X hPool hSeparation hLogX hX
  let Y₀ := closureShortDenominators X
  let Pool := smoothClosurePool X C
  have hY₀ (b : ℕ) (hb : b ∈ Y₀) :
      (X ≤ b ∧ b ≤ 2 * X) ∧
        (b ∣ Nat.lcmUpto (Nat.nthRoot 5 X)) ∧
        (b : ℝ) ≤ (X : ℝ) * (1 + 1 / Real.log X) := by
    obtain ⟨hRange, hRest⟩ := Finset.mem_filter.mp hb
    exact ⟨Finset.mem_Icc.mp hRange, hRest⟩
  have hYsub : Y₀ ⊆ Pool := by
    intro b hb
    obtain ⟨⟨hLo, hHi⟩, hDiv, _⟩ := hY₀ b hb
    refine Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨max_le (by omega) hLo, ?_⟩, hDiv⟩
    exact hHi.trans (Nat.mul_le_mul_right _ (by omega))
  have hSmall := mass_le_one_of_short_interval hX hLogX Y₀
    (fun b hb => (hY₀ b hb).1.1) (fun b hb => (hY₀ b hb).2.2)
  exact ⟨Y₀, Pool, hYsub, fun b hb => (Finset.mem_filter.mp hb).1,
    fun b hb => (Finset.mem_filter.mp hb).2, hSmall, hPool, hSeparation⟩

/-- Uniform smooth closure with absolute constants, including all varying
targets in the interval [1/2, 3/4] with permitted reduced denominator. -/
theorem exists_uniformSmoothClosure :
    ∃ C X₀ : ℕ, UniformSmoothClosure C X₀ := by
  obtain ⟨c₆, hc₆, hDensity⟩ := eventually_powersmoothInterval_card_ge 6 (by decide)
  obtain ⟨cSep, hcSep, hSep⟩ := eventually_smooth_separation
  apply exists_uniformSmoothClosure_of_density_and_separation c₆ cSep hc₆ hcSep hDensity
  simpa only [show (-(1 / 4) : ℝ) = (-1 / 4 : ℝ) by norm_num] using hSep

end LeanAB.PaperB.Closure

