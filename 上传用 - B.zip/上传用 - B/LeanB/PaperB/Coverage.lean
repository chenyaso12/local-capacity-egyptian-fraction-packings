module

public import PaperB.Closure
public import PaperB.Capacity
public import Mathlib.Analysis.Fourier.ZMod
public import Mathlib.Data.ZMod.ValMinAbs
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Tactic

@[expose] public section

/-! Finite covering and Fourier arguments for the large-prime modular step. -/

namespace LeanAB.PaperB
namespace Closure

open AddChar
open scoped BigOperators

/-- Actual reciprocal subset-sum residues in one finite denominator pool. -/
def residueSupport (p : ℕ) (E : Finset ℕ) : Finset (ZMod p) :=
  E.powerset.image (cofactorResidue p)

theorem mem_residueSupport {p : ℕ} {E : Finset ℕ} {v : ZMod p} :
    v ∈ residueSupport p E ↔ ∃ J ⊆ E, cofactorResidue p J = v := by
  simp [residueSupport]

/-- Two disjoint pools whose images each exceed half of the field give a full cover. -/
theorem coversResidues_union_of_large_images {p : ℕ} [NeZero p] {E F : Finset ℕ}
    (hEF : Disjoint E F)
    (hE : p < 2 * (residueSupport p E).card) (hF : p < 2 * (residueSupport p F).card) :
    CoversResidues p (E ∪ F) := by
  classical
  intro v
  let A := residueSupport p E
  let B := (residueSupport p F).image (fun x => v - x)
  have hc : B.card = (residueSupport p F).card :=
    Finset.card_image_of_injective _ (fun _ _ h => sub_right_inj.mp h)
  have hAB : (A ∩ B).Nonempty := by
    by_contra! hh
    have hd : Disjoint A B := Finset.disjoint_iff_inter_eq_empty.mpr hh
    have hsum := (Finset.card_le_univ (A ∪ B))
    rw [Finset.card_union_of_disjoint hd, ZMod.card, hc] at hsum
    change p < 2 * A.card at hE
    omega
  obtain ⟨u, hu⟩ := hAB
  obtain ⟨w, hw, he⟩ := Finset.mem_image.mp (Finset.mem_inter.mp hu).2
  obtain ⟨J, hJ, hJu⟩ := mem_residueSupport.mp (Finset.mem_inter.mp hu).1
  obtain ⟨K, hK, hKw⟩ := mem_residueSupport.mp hw
  refine ⟨J ∪ K, Finset.union_subset_union hJ hK, ?_⟩
  change cofactorResidue p (J ∪ K) = v
  rw [cofactorResidue, Finset.sum_union (hEF.mono hJ hK)]
  change cofactorResidue p J + cofactorResidue p K = v
  rw [hJu, hKw, ← he, sub_add_cancel]

/-- The unnormalized Fourier product for independently including each denominator. -/
noncomputable def inverseSumFourier (p : ℕ) [NeZero p] (E : Finset ℕ) (h : ZMod p) : ℂ :=
  ∏ b ∈ E, (1 + ZMod.stdAddChar (h * (b : ZMod p)⁻¹))

theorem inverseSumFourier_eq_sum (p : ℕ) [NeZero p] (E : Finset ℕ) (h : ZMod p) :
    inverseSumFourier p E h = ∑ J ∈ E.powerset, ZMod.stdAddChar (h * cofactorResidue p J) := by
  rw [inverseSumFourier, Finset.prod_one_add]
  refine Finset.sum_congr rfl fun J hJ => ?_
  rw [cofactorResidue, Finset.mul_sum]
  clear hJ E
  classical
  induction J using Finset.induction_on with
  | empty => simp
  | insert j J hj ih => rw [Finset.prod_insert hj, Finset.sum_insert hj, map_add_eq_mul, ih]

private theorem sum_char_mul_eq_zero {p : ℕ} [NeZero p] {w : ZMod p} (h : w ≠ 0) :
    ∑ k : ZMod p, ZMod.stdAddChar (k * w) = 0 := by
  simpa only [mulShift_apply, mul_comm] using sum_eq_zero_of_ne_one (ZMod.isPrimitive_stdAddChar p h)

/-- A small nonzero-frequency Fourier product implies genuine existence at every residue. -/
theorem coversResidues_of_fourier_bound (p : ℕ) [NeZero p] (E : Finset ℕ)
    (hfourier : ∀ h : ZMod p, h ≠ 0 → ‖inverseSumFourier p E h‖ ≤ (2 : ℝ) ^ E.card / p) :
    CoversResidues p E := by
  classical
  intro v
  by_contra hd
  have hn (J : Finset ℕ) (hJ : J ∈ E.powerset) : cofactorResidue p J - v ≠ 0 :=
    fun h => hd ⟨J, Finset.mem_powerset.mp hJ, sub_eq_zero.mp h⟩
  let term (h : ZMod p) := ZMod.stdAddChar (-(h * v)) * inverseSumFourier p E h
  have hsum : ∑ h : ZMod p, term h = 0 := calc
    _ = ∑ h : ZMod p, ∑ J ∈ E.powerset,
        ZMod.stdAddChar (h * (cofactorResidue p J - v)) := by
      apply Finset.sum_congr rfl
      intro h _
      dsimp only [term]
      rw [inverseSumFourier_eq_sum, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro J _
      rw [← map_add_eq_mul]
      congr 1
      ring
    _ = ∑ J ∈ E.powerset, ∑ h : ZMod p,
        ZMod.stdAddChar (h * (cofactorResidue p J - v)) := Finset.sum_comm
    _ = _ := Finset.sum_eq_zero (fun J hJ => sum_char_mul_eq_zero (hn J hJ))
  have hz : term 0 = (2 : ℂ) ^ E.card := by
    simp [term, inverseSumFourier, one_add_one_eq_two]
  have hSplit := Finset.sum_erase_add (s := (Finset.univ : Finset (ZMod p))) term (Finset.mem_univ 0)
  rw [hsum, hz] at hSplit
  have hs := eq_neg_of_add_eq_zero_left hSplit
  have hpos : (0 : ℝ) < p := Nat.cast_pos.mpr (Nat.pos_of_ne_zero (NeZero.ne _))
  have hmass : (0 : ℝ) < (2 : ℝ) ^ E.card := by positivity
  have hsize : (((Finset.univ : Finset (ZMod p)).erase 0).card : ℝ) < p := by
    rw [Finset.card_erase_of_mem (Finset.mem_univ _), Finset.card_univ, ZMod.card]
    exact_mod_cast (Nat.sub_lt (Nat.pos_of_ne_zero (NeZero.ne p)) Nat.one_pos)
  have hnorm :
      ‖∑ h ∈ (Finset.univ : Finset (ZMod p)).erase 0, term h‖ < (2 : ℝ) ^ E.card := calc
    _ ≤ ∑ h ∈ (Finset.univ : Finset (ZMod p)).erase 0, ‖term h‖ := norm_sum_le _ _
    _ ≤ ∑ _h ∈ (Finset.univ : Finset (ZMod p)).erase 0, (2 : ℝ) ^ E.card / p := by
      apply Finset.sum_le_sum
      intro h hh
      dsimp only [term]
      rw [norm_mul, AddChar.norm_apply, one_mul]
      exact hfourier h (Finset.ne_of_mem_erase hh)
    _ = (((Finset.univ : Finset (ZMod p)).erase 0).card : ℝ) * ((2 : ℝ) ^ E.card / p) := by simp
    _ < _ := by
      calc
        _ < (p : ℝ) * ((2 : ℝ) ^ E.card / p) := mul_lt_mul_of_pos_right hsize (div_pos hmass hpos)
        _ = _ := by field_simp
  rw [hs, norm_neg, norm_pow] at hnorm
  norm_num at hnorm


/-- The distance to the nearest integer of a residue's phase j/p. -/
noncomputable def phaseDistance {p : ℕ} (x : ZMod p) : ℝ :=
  (x.valMinAbs.natAbs : ℝ) / p

private theorem norm_one_add_exp_I_two (x : ℝ) :
    ‖1 + Complex.exp (Complex.I * ((2 * x : ℝ) : ℂ))‖ = 2 * |Real.cos x| := by
  have hexp : Complex.exp (Complex.I * ((Real.pi + 2 * x : ℝ) : ℂ)) =
      -Complex.exp (Complex.I * ((2 * x : ℝ) : ℂ)) := by
    rw [show Complex.I * ((Real.pi + 2 * x : ℝ) : ℂ) =
      (Real.pi : ℂ) * Complex.I + Complex.I * ((2 * x : ℝ) : ℂ) by push_cast; ring,
      Complex.exp_add, Complex.exp_pi_mul_I, neg_one_mul]
  have hne : (1 : ℂ) + Complex.exp (Complex.I * ((2 * x : ℝ) : ℂ)) =
      -(Complex.exp (Complex.I * ((Real.pi + 2 * x : ℝ) : ℂ)) - 1) := by
    rw [hexp]
    ring
  rw [hne, norm_neg, Complex.norm_exp_I_mul_ofReal_sub_one,
    show (Real.pi + 2 * x) / 2 = x + Real.pi / 2 by ring, Real.sin_add_pi_div_two,
    Real.norm_eq_abs, abs_mul, abs_of_nonneg zero_le_two]

/-- Each factor has Gaussian decay in the nearest-integer distance. -/
theorem norm_one_add_stdAddChar_le {p : ℕ} [NeZero p] (x : ZMod p) :
    ‖1 + ZMod.stdAddChar x‖ ≤ 2 * Real.exp (-2 * phaseDistance x ^ 2) := by
  have hP : (0 : ℝ) < p := Nat.cast_pos.mpr (Nat.pos_of_ne_zero (NeZero.ne _))
  let u := (x.valMinAbs : ℝ) / p
  have habs : |u| = phaseDistance x := by
    rw [show |u| = |(x.valMinAbs : ℝ) / (p : ℝ)| by rfl, abs_div,
      abs_of_nonneg hP.le, ← Int.cast_abs, Int.abs_eq_natAbs, Int.cast_natCast, phaseDistance]
  have hhalf : |u| ≤ 1 / 2 := by
    rw [habs, phaseDistance]
    apply (div_le_iff₀ hP).mpr
    have h : (x.valMinAbs.natAbs : ℝ) ≤ ((p / 2 : ℕ) : ℝ) :=
      Nat.cast_le.mpr x.natAbs_valMinAbs_le
    exact h.trans (by
      have hdiv : ((p / 2 : ℕ) : ℝ) ≤ (p : ℝ) / ((2 : ℕ) : ℝ) := Nat.cast_div_le
      norm_num at hdiv
      simpa only [one_div, div_eq_mul_inv, one_mul, mul_comm] using hdiv)
  let ξ := Real.pi * u
  have hξabs : |ξ| ≤ Real.pi / 2 := by
    rw [show ξ = Real.pi * u by rfl, abs_mul, abs_of_pos Real.pi_pos, div_eq_mul_one_div]
    exact mul_le_mul_of_nonneg_left hhalf Real.pi_pos.le
  have hc₀ : 0 ≤ Real.cos ξ := by
    obtain ⟨hl, hu⟩ := abs_le.mp hξabs
    exact Real.cos_nonneg_of_mem_Icc ⟨hl, hu⟩
  have htrig := Real.cos_le_one_sub_mul_cos_sq (hξabs.trans (by linarith [Real.pi_pos.le]))
  have hsq : 2 / Real.pi ^ 2 * ξ ^ 2 = 2 * phaseDistance x ^ 2 := by
    rw [← habs, sq_abs]
    dsimp only [ξ]
    field_simp [Real.pi_ne_zero]
  rw [hsq] at htrig
  have hx : ZMod.stdAddChar x = Complex.exp (Complex.I * ((2 * ξ : ℝ) : ℂ)) := by
    rw [← ZMod.coe_valMinAbs x, ZMod.stdAddChar_coe]
    congr 1
    dsimp only [ξ, u]
    push_cast
    ring
  rw [hx, norm_one_add_exp_I_two, abs_of_nonneg hc₀]
  apply mul_le_mul_of_nonneg_left _ zero_le_two
  exact htrig.trans (by linarith [Real.add_one_le_exp (-2 * phaseDistance x ^ 2)])

/-- A uniform supply of separated phases is enough for a full residue cover. -/
theorem coversResidues_of_separated_phases {p : ℕ} [NeZero p] (E : Finset ℕ) (δ : ℝ)
    (hδ : 0 ≤ δ)
    (hsep : ∀ h : ZMod p, h ≠ 0 → Real.log p ≤
      2 * δ ^ 2 *
        ((E.filter (fun b : ℕ => δ ≤ phaseDistance (h * (b : ZMod p)⁻¹))).card : ℝ)) :
    CoversResidues p E := by
  classical
  refine coversResidues_of_fourier_bound p E (fun h hh => ?_)
  let phase (b : ℕ) := phaseDistance (h * (b : ZMod p)⁻¹)
  let good : Finset ℕ := E.filter fun b => δ ≤ phase b
  have hsum : δ ^ 2 * (good.card : ℝ) ≤ ∑ b ∈ E, phase b ^ 2 := calc
    _ = ∑ _b ∈ good, δ ^ 2 := by simp [mul_comm]
    _ ≤ ∑ b ∈ good, phase b ^ 2 := Finset.sum_le_sum fun b hb =>
      pow_le_pow_left₀ hδ (Finset.mem_filter.mp hb).2 _
    _ ≤ _ := Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) fun b _ _ => sq_nonneg _
  have hlog : Real.log (p : ℝ) ≤ 2 * ∑ b ∈ E, phase b ^ 2 :=
    (hsep h hh).trans (by
      have H := mul_le_mul_of_nonneg_left hsum zero_le_two
      simpa only [mul_assoc] using H)
  have hP : (0 : ℝ) < p := Nat.cast_pos.mpr (Nat.pos_of_ne_zero (NeZero.ne _))
  calc
    _ = ∏ b ∈ E, ‖1 + ZMod.stdAddChar (h * (b : ZMod p)⁻¹)‖ := by
      rw [inverseSumFourier, norm_prod]
    _ ≤ ∏ b ∈ E, 2 * Real.exp (-2 * phase b ^ 2) :=
      Finset.prod_le_prod₀ (fun _ _ => norm_nonneg _) (fun b _ => norm_one_add_stdAddChar_le _)
    _ = (2 : ℝ) ^ E.card * Real.exp (-2 * ∑ b ∈ E, phase b ^ 2) := by
      rw [Finset.prod_mul_distrib, Finset.prod_const, ← Real.exp_sum, Finset.mul_sum]
    _ ≤ (2 : ℝ) ^ E.card * Real.exp (-Real.log p) :=
      mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by linarith)) (by positivity)
    _ = _ := by rw [Real.exp_neg, Real.exp_log hP, div_eq_mul_inv]

end Closure
end LeanAB.PaperB
