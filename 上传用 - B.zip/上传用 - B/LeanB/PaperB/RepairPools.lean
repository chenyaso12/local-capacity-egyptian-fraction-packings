module

public import PaperB.PointwiseCover
public import PaperB.PrimeWindows
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Tactic

/-! Disjoint medium-prime repair pools and the shared smooth reserve of F2. -/

@[expose] public section

namespace LeanAB.PaperB.Closure

open Finset Filter Asymptotics
open scoped BigOperators Topology

/-- Split a finite supply into equally sized disjoint sets. Surplus elements
need not be used. -/
theorem exists_equal_disjoint_pools {α : Type*} (S : Finset α) (m w : ℕ)
    (hSize : m * w ≤ S.card) :
    ∃ L : Fin m → Finset α,
      (∀ i, L i ⊆ S ∧ (L i).card = w) ∧
        Pairwise (fun i j => Disjoint (L i) (L j)) := by
  classical
  obtain ⟨T, hT, hcard⟩ := exists_subset_card_eq hSize
  let e : Fin m × Fin w ≃ T := Fintype.equivOfCardEq (by simp [hcard])
  let f (i : Fin m) (j : Fin w) : α := (e (i, j)).val
  have hf {i k : Fin m} {j l : Fin w} (h : f i j = f k l) : (i, j) = (k, l) :=
    e.injective (Subtype.ext h)
  refine ⟨fun i => univ.image (f i), ?_, ?_⟩
  · intro i
    exact ⟨fun _ ha => by
      obtain ⟨j, _, rfl⟩ := mem_image.mp ha
      exact hT (e (i, j)).property, by
        rw [card_image_of_injective _ fun j k h => congrArg Prod.snd (hf h)]
        simp⟩
  · intro i k hik
    rw [disjoint_left]
    intro _ hi hk
    obtain ⟨j, _, hj⟩ := mem_image.mp hi
    obtain ⟨l, _, hl⟩ := mem_image.mp hk
    exact hik (congrArg Prod.fst (hf (hj.trans hl.symm)))

/-- Fixed-size reserve of powersmooth denominators in the upper half of the
height interval, with both bounds on its reciprocal mass. -/
theorem exists_smooth_reserve {d N y w : ℕ} (hN : 0 < N)
    (hSize : w ≤ ((interval d N).filter
      (fun a => N ≤ 2 * a ∧ a ∣ Nat.lcmUpto y)).card) :
    ∃ R : Finset ℕ, R ⊆ interval d N ∧ R.card = w ∧
      (∀ a ∈ R, N ≤ 2 * a ∧ a ∣ Nat.lcmUpto y) ∧
        (w : ℚ) / N ≤ mass R ∧ mass R ≤ 2 * (w : ℚ) / N := by
  obtain ⟨R, hR, hCard⟩ := exists_subset_card_eq hSize
  have hRN : R ⊆ interval d N := fun a ha => (mem_filter.mp (hR ha)).1
  have hRhalf (a : ℕ) (ha : a ∈ R) := (mem_filter.mp (hR ha)).2
  have hNq : (0 : ℚ) < N := by exact_mod_cast hN
  refine ⟨R, hRN, hCard, hRhalf, ?_, ?_⟩
  · have h := card_le_mul_mass hRN
    rw [hCard] at h
    exact (div_le_iff₀ hNq).mpr (by linarith)
  · have hWeight (a : ℕ) (ha : a ∈ R) : (a : ℚ)⁻¹ ≤ (2 : ℚ) / N := by
      have hapos : 0 < a := (Nat.succ_le_iff.mp
        ((le_max_left 1 d).trans (mem_Icc.mp (hRN ha)).1))
      have haq : (0 : ℚ) < a := by exact_mod_cast hapos
      have hhalf : (N : ℚ) ≤ 2 * (a : ℚ) := by exact_mod_cast (hRhalf a ha).1
      rw [← one_div]
      exact (div_le_div_iff₀ haq hNq).mpr (by simpa [mul_comm] using hhalf)
    calc
      mass R ≤ ∑ _a ∈ R, (2 : ℚ) / N := sum_le_sum hWeight
      _ = 2 * (w : ℚ) / N := by simp [hCard, nsmul_eq_mul]; ring

/-- Covers on arbitrary subsets of the upper half of a cofactor interval,
provided their cardinality beats the same uniform short-phase count. -/
theorem coversResidues_of_halfPrimes_subset {p T : ℕ} [Fact p.Prime]
    (hT : 4 ≤ T) (hTp : T + 2 ≤ p) (L : Finset ℕ) (hL : L ⊆ halfPrimes T)
    {δ : ℝ} (hδ : 0 ≤ δ) (hδ₁ : δ ≤ 1)
    (hCard : Real.log p ≤ 2 * δ ^ 2 *
      ((L.card : ℝ) - (2 * (T : ℝ) * δ + 3) * (4 * Real.log p / Real.log T))) :
    CoversResidues p L := by
  classical
  apply coversResidues_of_separated_phases L δ hδ
  intro h hh
  let phase (b : ℕ) := phaseDistance (h * (b : ZMod p)⁻¹)
  let bad := (halfPrimes T).filter (fun b => phase b ≤ δ)
  let good := L.filter (fun b => δ ≤ phase b)
  have hSub : L ⊆ bad ∪ good := by
    intro b hb
    refine mem_union.mpr ((le_total (phase b) δ).imp ?_ ?_)
    · exact fun hbδ => mem_filter.mpr ⟨hL hb, hbδ⟩
    · exact fun hδb => mem_filter.mpr ⟨hb, hδb⟩
  have hcount : (L.card : ℝ) ≤ (bad.card : ℝ) + (good.card : ℝ) :=
    by exact_mod_cast (card_le_card hSub).trans (card_union_le bad good)
  have hBad : (bad.card : ℝ) ≤ (2 * (T : ℝ) * δ + 3) *
      (4 * Real.log p / Real.log T) := small_phase_card_le p T hT hTp δ hδ hδ₁ h hh
  exact hCard.trans (mul_le_mul_of_nonneg_left (by linarith) (by positivity))

/-- Medium-prime repair pools obtained by dilating disjoint cofactor sets.
The same construction applies to either marker region in F2. -/
theorem exists_medium_repair_pools {ι : Type*} {d N y Q₀ B : ℕ}
    (hN : 0 < N) (hQ₀ : 0 < Q₀) (hB : 0 < B) (hd : 2 * B * d ≤ N)
    (Q : Finset ℕ) (hQ : ∀ p ∈ Q, p.Prime ∧ y < p)
    (M : Finset ℕ) (hM : ∀ P ∈ M, P.Prime ∧ y < P)
    (hMQ : Disjoint M Q) (L : ι → Finset ℕ)
    (hL : ∀ i, L i ⊆ halfPrimes (2 * Q₀))
    (hDisjoint : Pairwise (fun i j => Disjoint (L i) (L j)))
    (hCover : ∀ i p, p ∈ Q → CoversResidues p (L i))
    (hDilate : ∀ p ∈ Q, ∃ t : ℕ, 0 < t ∧
      (N : ℚ) / ((B : ℚ) * p * (2 * Q₀)) ≤ (t : ℚ) ∧
      (t : ℚ) ≤ (N : ℚ) / ((p : ℚ) * (2 * Q₀)) ∧
      ∀ b : ℕ, 0 < b → b ≤ 2 * Q₀ → t * b ∣ Nat.lcmUpto y) :
    ∃ C : ι → ℕ → Finset ℕ, ∃ S : Finset ℕ,
      (∀ i p, p ∈ Q → (C i p).card = (L i).card ∧
        (∀ b ∈ C i p, b ∣ Nat.lcmUpto y) ∧ CoversResidues p (C i p)) ∧
      (∀ p ∈ Q, Pairwise (fun i j => Disjoint (C i p) (C j p))) ∧
      Pairwise (fun i j => Disjoint (mediumPool Q (C i)) (mediumPool Q (C j))) ∧
      (∀ i, mediumPool Q (C i) ⊆ S) ∧ S ⊆ interval d N ∧
      (∀ a ∈ S, (∀ P ∈ M, ¬ P ∣ a) ∧ ¬ a ∣ Nat.lcmUpto y) ∧
      (∀ a ∈ S, ∃ p ∈ Q, ∃ b, b ∣ Nat.lcmUpto y ∧ a = p * b) ∧
      S.card ≤ Q.card * (2 * Q₀) ∧ mass S ≤ (Q.card : ℚ) * (4 * B * Q₀) / N := by
  classical
  have hSupply (p : ℕ) : ∃ t : ℕ, p ∈ Q → 0 < t ∧
      (N : ℚ) / ((B : ℚ) * p * (2 * Q₀)) ≤ (t : ℚ) ∧
      (t : ℚ) ≤ (N : ℚ) / ((p : ℚ) * (2 * Q₀)) ∧
      ∀ b : ℕ, 0 < b → b ≤ 2 * Q₀ → t * b ∣ Nat.lcmUpto y := by
    by_cases hp : p ∈ Q
    · obtain ⟨t, ht⟩ := hDilate p hp
      exact ⟨t, fun _ => ht⟩
    · exact ⟨1, fun h => (hp h).elim⟩
  choose t ht using hSupply
  let C (i : ι) (p : ℕ) := mark (t p) (L i)
  let Total (p : ℕ) := mark p (mark (t p) (halfPrimes (2 * Q₀)))
  let S := Q.biUnion Total
  have hPq (p : ℕ) (hp : p ∈ Q) : (0 : ℚ) < p := by exact_mod_cast (hQ p hp).1.pos
  have hQq : (0 : ℚ) < Q₀ := by exact_mod_cast hQ₀
  have hBq : (0 : ℚ) < B := by exact_mod_cast hB
  have hNq : (0 : ℚ) < N := by exact_mod_cast hN
  have hBounds (p : ℕ) (hp : p ∈ Q) (a : ℕ) (ha : a ∈ halfPrimes (2 * Q₀)) :
      0 < p * (t p * a) ∧ p * (t p * a) ≤ N ∧ N ≤ 2 * B * (p * (t p * a)) := by
    obtain ⟨hap, haL, haU⟩ := mem_halfPrimes.mp ha
    have haLower : Q₀ ≤ a := by
      have : (2 * Q₀) / 2 = Q₀ := by omega
      omega
    have haUq : (a : ℚ) ≤ 2 * Q₀ := by exact_mod_cast haU
    have haLq : (Q₀ : ℚ) ≤ a := by exact_mod_cast haLower
    have htq : (0 : ℚ) < t p := by exact_mod_cast (ht p hp).1
    have htU := (le_div_iff₀ (mul_pos (hPq p hp) (by positivity : 0 < (2 : ℚ) * Q₀))).mp
      (ht p hp).2.2.1
    have htL := (div_le_iff₀ (mul_pos (mul_pos hBq (hPq p hp)) (by positivity : 0 < (2 : ℚ) * Q₀))).mp
      (ht p hp).2.1
    have hU : (p : ℚ) * ((t p : ℚ) * a) ≤ N := by
      calc
        _ ≤ (p : ℚ) * ((t p : ℚ) * (2 * Q₀)) := by gcongr
        _ = (t p : ℚ) * ((p : ℚ) * (2 * Q₀)) := by ring
        _ ≤ N := htU
    have hD : (N : ℚ) ≤ 2 * (B : ℚ) * ((p : ℚ) * ((t p : ℚ) * a)) := by
      calc
        _ ≤ (t p : ℚ) * ((B : ℚ) * p * (2 * Q₀)) := htL
        _ = 2 * (B : ℚ) * ((p : ℚ) * ((t p : ℚ) * Q₀)) := by ring
        _ ≤ _ := by gcongr
    exact ⟨Nat.mul_pos (hQ p hp).1.pos (Nat.mul_pos (ht p hp).1 hap.pos), by exact_mod_cast hU, by exact_mod_cast hD⟩
  have hSmooth (i : ι) (p : ℕ) (hp : p ∈ Q) (b : ℕ) (hb : b ∈ C i p) :
      b ∣ Nat.lcmUpto y := by
    obtain ⟨a, ha, rfl⟩ := mem_image.mp hb
    have h := mem_halfPrimes.mp (hL i ha)
    exact (ht p hp).2.2.2 _ h.1.pos h.2.2
  have hPairs (p : ℕ) (hp : p ∈ Q) :
      Pairwise (fun i j => Disjoint (C i p) (C j p)) := by
    intro i j hij
    rw [disjoint_left]
    intro b hi hj
    obtain ⟨a, ha, hba⟩ := mem_image.mp hi
    obtain ⟨c, hc, hbc⟩ := mem_image.mp hj
    have h := Nat.eq_of_mul_eq_mul_left (ht p hp).1 (hba.trans hbc.symm)
    exact disjoint_left.mp (hDisjoint hij) ha (h ▸ hc)
  have hcard : S.card ≤ Q.card * (2 * Q₀) := by
    calc
      S.card ≤ ∑ p ∈ Q, (Total p).card := card_biUnion_le
      _ ≤ ∑ _p ∈ Q, 2 * Q₀ := by
        apply sum_le_sum
        intro p hp
        dsimp only [Total]
        rw [card_mark _ ((hQ p hp).1.pos), card_mark _ ((ht p hp).1)]
        have hSub : halfPrimes (2 * Q₀) ⊆ Icc 1 (2 * Q₀) := fun a ha =>
          mem_Icc.mpr ⟨(mem_halfPrimes.mp ha).1.one_le, (mem_halfPrimes.mp ha).2.2⟩
        simpa using card_le_card hSub
      _ = _ := by simp
  refine ⟨C, S, ?_, hPairs, medium_pool_pairwise_disjoint y Q C hQ hSmooth hPairs, ?_,
    ?_, ?_, ?_, ?_, ?_⟩
  · intro i p hp
    have htNot : ¬ p ∣ t p := by
      apply prime_not_dvd_smooth (hQ p hp).1 (hQ p hp).2
      simpa using (ht p hp).2.2.2 1 (by decide) (by omega)
    exact ⟨card_mark _ (ht p hp).1 _, hSmooth i p hp,
      coversResidues_mark (hQ p hp).1 (ht p hp).1 htNot _ (hCover i p hp)⟩
  · intro i a ha
    obtain ⟨p, hp, hmem⟩ := mem_biUnion.mp ha
    exact mem_biUnion.mpr ⟨p, hp, image_subset_image (image_subset_image (hL i)) hmem⟩
  · intro a ha
    obtain ⟨p, hp, hpa⟩ := mem_biUnion.mp ha
    obtain ⟨b, hb, rfl⟩ := mem_image.mp hpa
    obtain ⟨c, hc, rfl⟩ := mem_image.mp hb
    obtain ⟨hPos, hTop, hBot⟩ := hBounds p hp c hc
    have hD : d ≤ p * (t p * c) :=
      Nat.le_of_mul_le_mul_left ((hd.trans hBot).trans_eq rfl) (by positivity : 0 < 2 * B)
    exact mem_Icc.mpr ⟨max_le (by omega) hD, hTop⟩
  · intro a ha
    obtain ⟨p, hp, hpa⟩ := mem_biUnion.mp ha
    obtain ⟨b, hb, rfl⟩ := mem_image.mp hpa
    obtain ⟨c, hc, rfl⟩ := mem_image.mp hb
    have hC := mem_halfPrimes.mp hc
    have hDiv := (ht p hp).2.2.2 _ hC.1.pos hC.2.2
    refine ⟨?_, fun ha => prime_not_dvd_smooth (hQ p hp).1 (hQ p hp).2 ha (dvd_mul_right ..)⟩
    intro P hP hPa
    rcases (hM P hP).1.dvd_mul.mp hPa with hPp | hPc
    · have h := (Nat.prime_dvd_prime_iff_eq (hM P hP).1 (hQ p hp).1).mp hPp
      exact disjoint_left.mp hMQ hP (h ▸ hp)
    · exact prime_not_dvd_smooth (hM P hP).1 (hM P hP).2 hDiv hPc
  · intro a ha
    obtain ⟨p, hp, hpa⟩ := mem_biUnion.mp ha
    obtain ⟨b, hb, rfl⟩ := mem_image.mp hpa
    obtain ⟨c, hc, rfl⟩ := mem_image.mp hb
    have hc' := mem_halfPrimes.mp hc
    exact ⟨p, hp, t p * c, (ht p hp).2.2.2 _ hc'.1.pos hc'.2.2, rfl⟩
  · exact hcard
  · have hWeight (a : ℕ) (ha : a ∈ S) : (a : ℚ)⁻¹ ≤ (2 * B : ℚ) / N := by
      obtain ⟨p, hp, hpa⟩ := mem_biUnion.mp ha
      obtain ⟨b, hb, rfl⟩ := mem_image.mp hpa
      obtain ⟨c, hc, rfl⟩ := mem_image.mp hb
      obtain ⟨hPos, _, hBot⟩ := hBounds p hp c hc
      rw [← one_div]
      apply (div_le_div_iff₀ (by exact_mod_cast hPos) hNq).mpr
      simp only [one_mul]
      exact_mod_cast hBot
    calc
      mass S ≤ ∑ _a ∈ S, (2 * B : ℚ) / N := sum_le_sum hWeight
      _ = (S.card : ℚ) * ((2 * B : ℚ) / N) := by simp
      _ ≤ ((Q.card * (2 * Q₀) : ℕ) : ℚ) * ((2 * B : ℚ) / N) :=
        mul_le_mul_of_nonneg_right (by exact_mod_cast hcard) (by positivity)
      _ = _ := by push_cast; ring

/-- Eventually there are simultaneous, pairwise disjoint full cofactor covers
for every medium prime and for any number of groups at most K log N. -/
theorem eventually_medium_cofactor_covers (K : ℝ) (hK : 0 < K) :
    ∀ᶠ N : ℕ in atTop, ∀ m : ℕ, (m : ℝ) ≤ K * Real.log N →
      ∃ L : Fin m → Finset ℕ,
        (∀ i, L i ⊆ halfPrimes (2 * ⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊) ∧
          (L i).card = ⌊Real.log (N : ℝ) ^ (10 : ℕ)⌋₊) ∧
        Pairwise (fun i j => Disjoint (L i) (L j)) ∧
        ∀ i p, p.Prime → ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ < p → p ≤ N →
          CoversResidues p (L i) := by
  let z (N : ℕ) := Real.log (N : ℝ)
  let T (N : ℕ) := 2 * ⌈z N ^ (12 : ℕ)⌉₊
  have hz : Tendsto z atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hT : Tendsto T atTop atTop := by
    refine tendsto_atTop.mpr fun k => ?_
    filter_upwards [hz.eventually_ge_atTop (max 1 (k : ℝ))] with N hN
    have hz₁ := (le_max_left (1 : ℝ) (k : ℝ)).trans hN
    have hC : (k : ℝ) ≤ (⌈z N ^ (12 : ℕ)⌉₊ : ℕ) :=
      ((le_max_right (1 : ℝ) (k : ℝ)).trans hN).trans
        ((le_self_pow₀ hz₁ (by decide : (12 : ℕ) ≠ 0)).trans (Nat.le_ceil _))
    have h₁ : k ≤ ⌈z N ^ (12 : ℕ)⌉₊ := by exact_mod_cast hC
    dsimp [T]
    omega
  have hLogT : Tendsto (fun N => Real.log (T N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp (tendsto_natCast_atTop_atTop.comp hT)
  have hSmall := Real.isLittleO_log_id_atTop.bound
    (one_div_pos.mpr (show 0 < 42 * K by positivity))
  filter_upwards [hT.eventually_ge_atTop 4, hz.eventually_ge_atTop 2,
    hLogT.eventually_ge_atTop 256, hT.eventually eventually_halfPrimes_card_ge,
    hz.eventually hSmall, eventually_dilation_supply] with N hT₄ hz₂ hTLog hTcard hSmall hDil m hm
  let L := z N
  let W := ⌊L ^ (10 : ℕ)⌋₊
  let δ : ℝ := 1 / L ^ (3 : ℕ)
  have hL : 0 < L := by linarith only [hz₂]
  have hL₁ : 1 ≤ L := by linarith only [hz₂]
  have hδ : 0 ≤ δ := by dsimp [δ]; positivity
  have hδ₁ : δ ≤ 1 := (div_le_one (by positivity : 0 < L ^ (3 : ℕ))).mpr
    (one_le_pow₀ hL₁)
  have hTpos : 0 < T N := by omega
  have hTlog₀ : 0 < Real.log (T N : ℝ) := by linarith
  have hPow12 : 1 ≤ L ^ (12 : ℕ) := one_le_pow₀ hL₁
  have hWup : (W : ℝ) ≤ L ^ (10 : ℕ) := Nat.floor_le (by positivity)
  have hWlo : L ^ (10 : ℕ) / 2 ≤ (W : ℝ) := by
    have hp := Nat.lt_floor_add_one (L ^ (10 : ℕ))
    have h2 := pow_le_pow_left₀ (by norm_num : (0 : ℝ) ≤ 2) hz₂ (10 : ℕ)
    norm_num at h2
    linarith
  have hTup : (T N : ℝ) ≤ 4 * L ^ (12 : ℕ) := by
    have hh := Nat.ceil_lt_add_one (show (0 : ℝ) ≤ L ^ (12 : ℕ) by positivity)
    change (↑(2 * ⌈L ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) ≤ _
    push_cast
    linarith
  have hTlo : 2 * L ^ (12 : ℕ) ≤ (T N : ℝ) := by
    change _ ≤ (↑(2 * ⌈L ^ (12 : ℕ)⌉₊ : ℕ) : ℝ)
    push_cast
    exact mul_le_mul_of_nonneg_left (Nat.le_ceil _) (by norm_num)
  have hTtwo : T N + 2 ≤ ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ := by
    obtain ⟨h, _⟩ := hDil (T N) hTpos le_rfl
    have hh := (Nat.le_div_iff_mul_le hTpos).mp h
    omega
  have hLogFour : Real.log 4 = 2 * Real.log 2 := by
    rw [show (4 : ℝ) = 2 ^ (2 : ℕ) by norm_num, Real.log_pow]
    norm_num
  have hLogUp : Real.log (T N : ℝ) ≤ 14 * Real.log L := by
    have hh := Real.log_le_log (Nat.cast_pos.mpr hTpos) hTup
    rw [Real.log_mul (by norm_num) (by positivity), Real.log_pow, hLogFour] at hh
    norm_num at hh
    have hlog₂ : Real.log (2 : ℝ) ≤ Real.log L :=
      Real.log_le_log (by norm_num) hz₂
    linarith only [hh, hlog₂]
  have hKLog : 3 * K * Real.log (T N : ℝ) ≤ L := by
    change ‖Real.log L‖ ≤ (1 / (42 * K)) * ‖L‖ at hSmall
    rw [Real.norm_of_nonneg (Real.log_nonneg hL₁), Real.norm_of_nonneg hL.le] at hSmall
    have hMul : Real.log L * (42 * K) ≤ L :=
      (le_div_iff₀ (by positivity : 0 < 42 * K)).mp (by simpa [div_eq_mul_inv, mul_comm] using hSmall)
    calc
      _ ≤ (3 * K) * (14 * Real.log L) :=
        mul_le_mul_of_nonneg_left hLogUp (by positivity)
      _ = Real.log L * (42 * K) := by ring
      _ ≤ _ := hMul
  have hPartition : m * W ≤ (halfPrimes (T N)).card := by
    have h : (m : ℝ) * (W : ℝ) ≤ ((halfPrimes (T N)).card : ℝ) := by
      calc
        _ ≤ (K * L) * (L ^ (10 : ℕ)) :=
          mul_le_mul hm hWup (Nat.cast_nonneg _) (by positivity)
        _ = K * L ^ (11 : ℕ) := by ring
        _ ≤ (T N : ℝ) / (3 * Real.log (T N : ℝ)) := by
          apply (le_div_iff₀ (by positivity : 0 < 3 * Real.log (T N : ℝ))).mpr
          have hh := mul_le_mul_of_nonneg_right hKLog (by positivity : 0 ≤ L ^ (11 : ℕ))
          have h₁ : K * L ^ (11 : ℕ) * (3 * Real.log (T N : ℝ)) ≤ L ^ (12 : ℕ) := by
            calc
              _ = (3 * K * Real.log (T N : ℝ)) * L ^ (11 : ℕ) := by ring
              _ ≤ L * L ^ (11 : ℕ) := hh
              _ = _ := by ring
          linarith only [h₁, hTlo, hPow12]
        _ ≤ _ := hTcard
    exact_mod_cast h
  obtain ⟨E, hE, hPairs⟩ := exists_equal_disjoint_pools (halfPrimes (T N)) m W hPartition
  refine ⟨E, hE, hPairs, ?_⟩
  intro i p hp hpY hpN
  let _ : Fact p.Prime := ⟨hp⟩
  apply coversResidues_of_halfPrimes_subset hT₄ (hTtwo.trans hpY.le) (E i) (hE i).1 hδ hδ₁
  have hzP₀ : 0 ≤ Real.log (p : ℝ) := Real.log_nonneg (by exact_mod_cast hp.one_le)
  have hzP : Real.log (p : ℝ) ≤ L :=
    Real.log_le_log (by exact_mod_cast hp.pos) (by exact_mod_cast hpN)
  have hB₁ : 2 * (T N : ℝ) * δ + 3 ≤ 8 * L ^ (9 : ℕ) + 3 := by
    calc
      _ ≤ 2 * (4 * L ^ (12 : ℕ)) * δ + 3 := by gcongr
      _ = _ := by dsimp [δ]; field_simp; ring
  have hB₂ : 4 * Real.log (p : ℝ) / Real.log (T N : ℝ) ≤ L / 64 := by
    calc
      _ ≤ 4 * L / Real.log (T N : ℝ) := by gcongr
      _ ≤ 4 * L / 256 := by gcongr
      _ = _ := by ring
  have hB : (2 * (T N : ℝ) * δ + 3) *
      (4 * Real.log (p : ℝ) / Real.log (T N : ℝ)) ≤ L ^ (10 : ℕ) / 4 := by
    calc
      _ ≤ (8 * L ^ (9 : ℕ) + 3) * (L / 64) := by gcongr
      _ ≤ _ := by
        have h := mul_le_mul_of_nonneg_right (one_le_pow₀ hL₁ : 1 ≤ L ^ (9 : ℕ)) hL.le
        nlinarith only [h, hL.le]
  have hP : L ^ (10 : ℕ) / 4 ≤ ((E i).card : ℝ) -
      (2 * (T N : ℝ) * δ + 3) * (4 * Real.log (p : ℝ) / Real.log (T N : ℝ)) := by
    rw [(hE i).2]
    linarith only [hB, hWlo]
  calc
    Real.log (p : ℝ) ≤ L := hzP
    _ ≤ L ^ (4 : ℕ) / 2 := by
      have h := pow_le_pow_left₀ (by norm_num : (0 : ℝ) ≤ 2) hz₂ (3 : ℕ)
      have hh := mul_le_mul_of_nonneg_right h hL.le
      nlinarith only [hh, hL.le]
    _ = 2 * δ ^ 2 * (L ^ (10 : ℕ) / 4) := by dsimp [δ]; field_simp; ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hP (by positivity)

/-- After choosing any admissible medium and marker primes, the actual reserved
pools exist simultaneously with the F2 cardinality and reciprocal-mass bounds. -/
theorem eventually_medium_repair_pools (d : ℕ) (K : ℝ) (hK : 0 < K) :
    ∀ᶠ N : ℕ in atTop,
      ∀ m : ℕ, (m : ℝ) ≤ K * Real.log N →
      ∀ Q M : Finset ℕ,
        (∀ p ∈ Q, p.Prime ∧ ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ < p ∧ p ≤ Nat.sqrt N) →
        (∀ P ∈ M, P.Prime ∧ ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ < P) → Disjoint M Q →
      ∃ C : Fin m → ℕ → Finset ℕ, ∃ S : Finset ℕ,
        (∀ i p, p ∈ Q → (C i p).card = ⌊Real.log (N : ℝ) ^ (10 : ℕ)⌋₊ ∧
          (∀ b ∈ C i p, b ∣ Nat.lcmUpto ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊) ∧
          CoversResidues p (C i p)) ∧
        (∀ p ∈ Q, Pairwise (fun i j => Disjoint (C i p) (C j p))) ∧
        Pairwise (fun i j => Disjoint (mediumPool Q (C i)) (mediumPool Q (C j))) ∧
        (∀ i, mediumPool Q (C i) ⊆ S) ∧ S ⊆ interval d N ∧
        (∀ a ∈ S, (∀ P ∈ M, ¬ P ∣ a) ∧ ¬ a ∣ Nat.lcmUpto ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊) ∧
        (∀ a ∈ S, ∃ p ∈ Q, ∃ b, b ∣ Nat.lcmUpto ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ ∧ a = p * b) ∧
        S.card ≤ Nat.sqrt N * (2 * ⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊) ∧
        (mass S : ℝ) ≤ 692 * (⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ : ℕ) / Real.sqrt N := by
  have hNat : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  filter_upwards [eventually_medium_cofactor_covers K hK, eventually_powersmooth_dilation,
    eventually_dilation_supply, hLog.eventually_ge_atTop 1, eventually_ge_atTop (346 * d + 1)]
    with N hCover hDil hSupply hLog hN m hm Q M hQ hM hDisj
  obtain ⟨L, hL, hPair, hCover⟩ := hCover m hm
  let y := ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊
  let Q₀ := ⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊
  have hQ₀ : 0 < Q₀ := by
    have h := (one_le_pow₀ hLog : 1 ≤ Real.log (N : ℝ) ^ (12 : ℕ)).trans (Nat.le_ceil _)
    exact Nat.succ_le_iff.mp (by exact_mod_cast h : 1 ≤ Q₀)
  have hN₀ : 0 < N := by omega
  have hd : 2 * 173 * d ≤ N := by omega
  have hNext : 2 * Q₀ ≤ y := by
    have h := (hSupply (2 * Q₀) (by omega) le_rfl).1
    have h' := (Nat.le_div_iff_mul_le (show 0 < 2 * Q₀ by omega)).mp h
    omega
  have hQ' (p : ℕ) (hp : p ∈ Q) : p.Prime ∧ y < p := (hQ p hp).imp id And.left
  have hpN (p : ℕ) (hp : p ∈ Q) : p ≤ N := (hQ p hp).2.2.trans (Nat.sqrt_le_self _)
  have hD (p : ℕ) (hp : p ∈ Q) : ∃ t : ℕ, 0 < t ∧
      (N : ℚ) / ((173 : ℚ) * p * (2 * Q₀)) ≤ (t : ℚ) ∧
      (t : ℚ) ≤ (N : ℚ) / ((p : ℚ) * (2 * Q₀)) ∧
      ∀ b : ℕ, 0 < b → b ≤ 2 * Q₀ → t * b ∣ Nat.lcmUpto y := by
    have hpA : p * (2 * Q₀) ≤ N :=
      (Nat.mul_le_mul_left _ (hNext.trans (hQ' p hp).2.le)).trans
        (Nat.le_sqrt.mp (hQ p hp).2.2)
    obtain ⟨t, ht, hlo, hhi, hAll⟩ :=
      hDil (2 * Q₀) (by omega) le_rfl p (hQ' p hp).1 (hQ' p hp).2 hpA
    exact ⟨t, ht, by exact_mod_cast hlo, by exact_mod_cast hhi, fun b hb hB => (hAll b hb hB).1⟩
  obtain ⟨C, S, hC, hCPair, hPoolPair, hS, hAvail, hAvoid, hFactor, hCard, hMass⟩ :=
    exists_medium_repair_pools hN₀ hQ₀ (by decide : 0 < 173) hd Q hQ' M hM hDisj L
      (fun i => (hL i).1) hPair
      (fun i p hp => hCover i p (hQ' p hp).1 (hQ' p hp).2 (hpN p hp)) hD
  have hQcard : Q.card ≤ Nat.sqrt N := by
    have h : Q ⊆ Icc 1 (Nat.sqrt N) :=
      fun p hp => mem_Icc.mpr ⟨(hQ' p hp).1.one_le, (hQ p hp).2.2⟩
    simpa using card_le_card h
  refine ⟨C, S, ?_, hCPair, hPoolPair, hS, hAvail, hAvoid, hFactor,
    hCard.trans (Nat.mul_le_mul_right _ hQcard), ?_⟩
  · intro i p hp
    simpa only [(hL i).2] using hC i p hp
  · have hQsqrt : (Q.card : ℝ) ≤ Real.sqrt (N : ℝ) :=
      (Real.le_sqrt (by positivity) (by positivity)).mpr
        (by exact_mod_cast Nat.le_sqrt'.mp hQcard)
    have hMass' : (mass S : ℝ) ≤ (Q.card : ℝ) * (4 * 173 * Q₀) / N := by
      simpa only [Rat.cast_mul, Rat.cast_div, Rat.cast_natCast, Rat.cast_ofNat] using
        (Rat.cast_le.mpr hMass : (mass S : ℝ) ≤ ↑((Q.card : ℚ) * (4 * (173 : ℚ) * Q₀) / N))
    have hSqrt₀ : 0 < Real.sqrt (N : ℝ) := Real.sqrt_pos.2 (by exact_mod_cast hN₀)
    calc
      _ ≤ (Q.card : ℝ) * (4 * 173 * Q₀) / N := hMass'
      _ ≤ Real.sqrt (N : ℝ) * (4 * 173 * Q₀) / N := by gcongr
      _ = _ := by
        change Real.sqrt (N : ℝ) * (4 * 173 * (Q₀ : ℝ)) / N =
          692 * (Q₀ : ℝ) / Real.sqrt (N : ℝ)
        have hInv : Real.sqrt (N : ℝ) / N = (Real.sqrt (N : ℝ))⁻¹ := by
          apply (div_eq_iff (by positivity : (N : ℝ) ≠ 0)).2
          calc
            _ = (Real.sqrt (N : ℝ))⁻¹ * (Real.sqrt (N : ℝ) * Real.sqrt (N : ℝ)) := by
              rw [inv_mul_cancel_left₀ hSqrt₀.ne']
            _ = _ := by rw [Real.mul_self_sqrt (by positivity)]
        calc
          _ = (4 * 173 * (Q₀ : ℝ)) * (Real.sqrt (N : ℝ) / N) := by ring
          _ = _ := by rw [hInv]; ring

/-- There are enough distinct marker primes at either of the fixed power
scales used in F2, uniformly for all group counts \(m\le K\log N\). -/
theorem eventually_marker_primes {α K : ℝ} (hα : 0 < α) (hα₁ : α ≤ 1) (hK : 0 < K) :
    ∀ᶠ N : ℕ in atTop, ∀ m : ℕ, (m : ℝ) ≤ K * Real.log N →
      ∃ P : Fin m → ℕ, Function.Injective P ∧
        ∀ i, (P i).Prime ∧ (N : ℝ) ^ α < (P i : ℝ) ∧ (P i : ℝ) ≤ 2 * (N : ℝ) ^ α := by
  have hc : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hWin := eventually_short_prime_window_count (a := α) (K := 1) hα (by norm_num)
  have hSmall := (isLittleO_log_rpow_rpow_atTop 3 hα).bound
    (one_div_pos.mpr (show 0 < 4 * K by positivity))
  filter_upwards [hc.eventually hWin, hc.eventually hSmall,
    (Real.tendsto_log_atTop.comp hc).eventually_ge_atTop 1,
    eventually_ge_atTop (1 : ℕ)] with N hWin hSmall hLog hN m hm
  let x : ℝ := (N : ℝ) ^ α
  have hN₁ : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hx : 0 ≤ x := by dsimp [x]; positivity
  change (1 : ℝ) ≤ Real.log (N : ℝ) at hLog
  have hCount : x / (4 * Real.log (N : ℝ) ^ 2) ≤
      ((primesBetween x (x + x)).card : ℝ) := by
    simpa only [one_mul, mul_one] using
      hWin x x le_rfl (by simpa using Real.rpow_le_rpow_of_exponent_le hN₁ hα₁)
        (by rw [one_mul]; exact div_le_self hx hLog) le_rfl
  have hM : (m : ℝ) ≤ ((primesBetween x (x + x)).card : ℝ) := by
    apply hm.trans (_root_.le_trans ?_ hCount)
    apply (le_div_iff₀ (by positivity : 0 < 4 * Real.log (N : ℝ) ^ 2)).mpr
    have hI : ‖Real.log (N : ℝ) ^ (3 : ℝ)‖ ≤ (1 / (4 * K)) * ‖x‖ := hSmall
    rw [show (3 : ℝ) = (3 : ℕ) by norm_num, Real.rpow_natCast,
      Real.norm_of_nonneg (by positivity), Real.norm_of_nonneg hx] at hI
    have h := (le_div_iff₀ (by positivity : 0 < 4 * K)).mp (by
      simpa only [one_div, div_eq_mul_inv, mul_comm, one_mul] using hI :
      Real.log (N : ℝ) ^ (3 : ℕ) ≤ x / (4 * K))
    nlinarith only [h]
  obtain ⟨S, hS, hCard⟩ := exists_subset_card_eq (by exact_mod_cast hM)
  let e : Fin m ≃ S := Fintype.equivOfCardEq (by simp [hCard])
  refine ⟨fun i => (e i).val, fun i j hij => e.injective (Subtype.ext hij), ?_⟩
  intro i
  obtain ⟨hlo, hhi, hprime⟩ := (mem_primesBetween hx (by positivity : 0 ≤ x + x)).mp
    (hS (e i).property)
  exact ⟨hprime, hlo, by linarith only [hhi]⟩

/-- Summing reciprocal mass over the individual finite sets bounds the
reciprocal mass of their union. -/
theorem mass_biUnion_le {ι : Type*} (E : Finset ι) (B : ι → Finset ℕ) :
    mass (E.biUnion B) ≤ ∑ i ∈ E, mass (B i) := by
  classical
  induction E using Finset.induction_on with
  | empty => simp [mass]
  | insert i E hi ih =>
    rw [biUnion_insert, sum_insert hi]
    have h := sum_union_inter (s₁ := B i) (s₂ := E.biUnion B) (f := fun a : ℕ => (a : ℚ)⁻¹)
    change mass (B i ∪ E.biUnion B) + mass (B i ∩ E.biUnion B) =
      mass (B i) + mass (E.biUnion B) at h
    linarith [mass_nonneg (B i ∩ E.biUnion B)]
/-- Reciprocal mass of the multiples of an arbitrary finite set of excluded
factors. Overlap between the families can only decrease the deletion cost. -/
theorem mass_excluded_multiples_le {d N : ℕ} (Q : Finset ℕ)
    (hQ : ∀ q ∈ Q, 0 < q) :
    mass (Q.biUnion fun q => primePart q (interval d N)) ≤
      mass (interval 1 N) * mass Q := by
  classical
  have hSingle (q : ℕ) (hq : q ∈ Q) :
      mass (primePart q (interval d N)) ≤ mass (interval 1 N) / q := by
    have hSub : primePart q (interval d N) ⊆ mark q (interval 1 (N / q)) := by
      intro a ha
      obtain ⟨haI, haQ⟩ := mem_filter.mp ha
      have hapos : 0 < a :=
        (le_max_left 1 d).trans (mem_Icc.mp haI).1
      have hqpos := hQ q hq
      exact mem_image.mpr ⟨a / q, mem_Icc.mpr ⟨
        Nat.div_pos (Nat.le_of_dvd hapos haQ) hqpos,
        Nat.div_le_div_right (mem_Icc.mp haI).2⟩, by rw [Nat.mul_comm, Nat.div_mul_cancel haQ]⟩
    have hN : interval 1 (N / q) ⊆ interval 1 N :=
      fun _ ha => mem_Icc.mpr ⟨(mem_Icc.mp ha).1, (mem_Icc.mp ha).2.trans (Nat.div_le_self _ _)⟩
    exact (mass_mono hSub).trans (by
      rw [mass_mark q (hQ q hq)]
      exact div_le_div_of_nonneg_right (mass_mono hN) (by positivity))
  calc
    _ ≤ ∑ q ∈ Q, mass (primePart q (interval d N)) := mass_biUnion_le Q _
    _ ≤ ∑ q ∈ Q, mass (interval 1 N) / q := sum_le_sum hSingle
    _ = _ := by simp only [mass, div_eq_mul_inv, mul_sum]

/-- The tail of the sum of reciprocal prime squares, uniformly in the
upper endpoint. The logarithmic saving is needed at the near-capacity scale. -/
theorem eventually_sum_inv_prime_sq_le :
    ∀ᶠ a : ℝ in atTop, ∀ b : ℝ, a ≤ b →
      ∑ p ∈ primesBetween a b, ((p : ℝ) ^ (2 : ℕ))⁻¹ ≤ 4 / (a * Real.log a) := by
  have hθ := Chebyshev.tendsto_theta_div_atTop.eventually_lt_const
    (show (1 : ℝ) < 2 by norm_num)
  obtain ⟨A, hA⟩ := eventually_atTop.mp hθ
  filter_upwards [eventually_ge_atTop (max 2 A)] with a ha b hab
  have ha₁ : 1 < a := lt_of_lt_of_le (by norm_num) ((le_max_left 2 A).trans ha)
  have ha₀ : 0 < a := zero_lt_one.trans ha₁
  have hpos (t : ℝ) (ht : t ∈ Set.Icc a b) : 0 < t := ha₀.trans_le ht.1
  have hDeriv (t : ℝ) (ht : t ∈ Set.Icc a b) :
      HasDerivAt (fun t : ℝ => (t ^ (2 : ℕ))⁻¹) (-2 / t ^ (3 : ℕ)) t := by
    have ht₀ := (hpos t ht).ne'
    have h := ((hasDerivAt_id t).pow 2).inv (pow_ne_zero _ ht₀)
    change HasDerivAt (fun t : ℝ => (t ^ (2 : ℕ))⁻¹)
      (-(↑(2 : ℕ) * t ^ ((2 : ℕ) - 1) * 1) / (t ^ (2 : ℕ)) ^ (2 : ℕ)) t at h
    convert h using 1
    norm_num
    field_simp [ht₀]
  have hCont : ContinuousOn (fun t : ℝ => -2 / t ^ (3 : ℕ)) (Set.Icc a b) :=
    continuousOn_const.div (continuous_id.pow _).continuousOn
      (fun t ht => pow_ne_zero _ (hpos t ht).ne')
  have hBound : ∀ t ∈ Set.Icc a b, |Chebyshev.theta t - t| ≤ (1 : ℝ) * t := by
    intro t ht
    have h := hA t ((le_max_right 2 A).trans (ha.trans ht.1))
    have hUpper := (div_lt_iff₀ (hpos t ht)).mp h
    exact abs_le.mpr ⟨by linarith [Chebyshev.theta_nonneg t], by linarith⟩
  have hsum := abs_weighted_prime_sum_sub_integral_le (δ := 1) ha₀.le hab hDeriv hCont
    (fun _ _ => by positivity) (fun t ht => div_nonpos_of_nonpos_of_nonneg (by norm_num) (pow_nonneg (hpos t ht).le _))
    hBound
  have hInt : (∫ t in a..b, (t ^ (2 : ℕ))⁻¹) = a⁻¹ - b⁻¹ := by
    have hg (t : ℝ) (ht : t ∈ Set.uIcc a b) :
        HasDerivAt (fun t : ℝ => -t⁻¹) ((t ^ (2 : ℕ))⁻¹) t := by
      rw [Set.uIcc_of_le hab] at ht
      have h := (hasDerivAt_inv (hpos t ht).ne').neg
      change HasDerivAt (fun t : ℝ => -t⁻¹) (-(-(t ^ (2 : ℕ))⁻¹)) t at h
      simpa only [neg_neg] using h
    rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hg]
    · ring
    · apply ContinuousOn.intervalIntegrable
      apply (continuous_id.pow _).continuousOn.inv₀
      intro t ht
      rw [Set.uIcc_of_le hab] at ht
      exact pow_ne_zero _ (hpos t ht).ne'
  have hUpper : (∑ p ∈ primesBetween a b, ((p : ℝ) ^ (2 : ℕ))⁻¹ * Real.log p) ≤ 4 / a := by
    have hh := (abs_le.mp hsum).2
    rw [hInt] at hh
    have haEq : a * (a ^ (2 : ℕ))⁻¹ = a⁻¹ := by field_simp
    rw [mul_assoc, haEq] at hh
    have hbInv : 0 ≤ b⁻¹ := inv_nonneg.mpr (ha₀.le.trans hab)
    rw [div_eq_mul_inv]
    linarith only [hh, hbInv]
  have hLog : 0 < Real.log a := Real.log_pos ha₁
  apply (le_div_iff₀ (mul_pos ha₀ hLog)).mpr
  have hFinal := (le_div_iff₀ ha₀).mp hUpper
  calc
    _ = (∑ p ∈ primesBetween a b, ((p : ℝ) ^ (2 : ℕ))⁻¹ * Real.log a) * a := by
      rw [← sum_mul]
      ring
    _ ≤ (∑ p ∈ primesBetween a b, ((p : ℝ) ^ (2 : ℕ))⁻¹ * Real.log p) * a := by
      apply mul_le_mul_of_nonneg_right _ ha₀.le
      apply sum_le_sum
      intro p hp
      exact mul_le_mul_of_nonneg_left (Real.log_le_log ha₀
        ((mem_primesBetween ha₀.le (ha₀.le.trans hab)).mp hp).1.le) (by positivity)
    _ ≤ _ := hFinal

private theorem inv_pow_sum_le_geometric_tail {p k : ℕ} (hp : 2 ≤ p)
    (E : Finset ℕ) (hE : ∀ e ∈ E, k ≤ e) :
    ∑ e ∈ E, ((p : ℝ) ^ e)⁻¹ ≤ 2 * ((p : ℝ) ^ k)⁻¹ := by
  let r : ℝ := (p : ℝ)⁻¹
  have hpR : (2 : ℝ) ≤ p := by exact_mod_cast hp
  have hr : 0 ≤ r := by dsimp [r]; positivity
  have hr₁ : r ≤ 1 / 2 := by
    dsimp [r]
    rw [← one_div]
    exact one_div_le_one_div_of_le (by norm_num) hpR
  have hs := summable_geometric_of_lt_one hr (lt_of_le_of_lt hr₁ (by norm_num))
  let J := E.image (fun e => e - k)
  have hF : ∑ e ∈ E, ((p : ℝ) ^ e)⁻¹ = r ^ k * ∑ j ∈ J, r ^ j := by
    dsimp only [J]
    rw [mul_sum, sum_image]
    · apply sum_congr rfl
      intro e he
      dsimp only [r]
      rw [← inv_pow, ← pow_add, Nat.add_sub_of_le (hE e he)]
    · intro a ha b hb hab
      have h₁ := hE a ha
      have h₂ := hE b hb
      change a - k = b - k at hab
      omega
  have hSum : (∑ j ∈ J, r ^ j) ≤ 2 := by
    calc
      _ ≤ ∑' j : ℕ, r ^ j := hs.sum_le_tsum J (fun _ _ => by positivity)
      _ = (1 - r)⁻¹ := tsum_geometric_of_lt_one hr (lt_of_le_of_lt hr₁ (by norm_num))
      _ ≤ 2 := by
        rw [← one_div]
        apply (div_le_iff₀ (by linarith : 0 < 1 - r)).mpr
        linarith
  calc
    _ = r ^ k * ∑ j ∈ J, r ^ j := hF
    _ ≤ r ^ k * 2 := mul_le_mul_of_nonneg_left hSum (by positivity)
    _ = _ := by dsimp only [r]; rw [inv_pow, mul_comm]

/-- Exponents of high prime powers at a fixed prime. -/
noncomputable def highPrimeExponents (p N : ℕ) (z : ℝ) : Finset ℕ := by
  classical
  exact (range (N + 1)).filter fun e => 2 ≤ e ∧ z < (p : ℝ) ^ e

private theorem sum_high_exponents_le {p N : ℕ} {z : ℝ}
    (hp : 2 ≤ p) (hz : 0 < z) :
    (∑ e ∈ highPrimeExponents p N z, ((p : ℝ) ^ e)⁻¹) ≤ 2 / z ∧
      (∑ e ∈ highPrimeExponents p N z, ((p : ℝ) ^ e)⁻¹) ≤ 2 * ((p : ℝ) ^ (2 : ℕ))⁻¹ := by
  classical
  let k := max 2 (Nat.log p ⌊z⌋₊ + 1)
  have hp₁ : 1 < p := by omega
  have hpq : (1 : ℝ) ≤ p := by exact_mod_cast hp₁.le
  have hk (e : ℕ) (he : e ∈ highPrimeExponents p N z) : k ≤ e := by
    have h := (mem_filter.mp he).2
    have hh : ⌊z⌋₊ < p ^ e := (Nat.floor_lt hz.le).mpr (by exact_mod_cast h.2)
    have hlt : Nat.log p ⌊z⌋₊ < e := by
      by_cases h0 : ⌊z⌋₊ = 0
      · simp [h0]
        omega
      · exact (Nat.log_lt_iff_lt_pow hp₁ h0).mpr hh
    exact max_le h.1 (by omega)
  have hzK : z < (p : ℝ) ^ k := by
    have hNat : ⌊z⌋₊ < p ^ (Nat.log p ⌊z⌋₊ + 1) := Nat.lt_pow_succ_log_self hp₁ _
    have h := (Nat.floor_lt hz.le).mp hNat
    exact (by exact_mod_cast h : z < (p : ℝ) ^ (Nat.log p ⌊z⌋₊ + 1)).trans_le
      (pow_le_pow_right₀ hpq (le_max_right _ _))
  have h2K : (p : ℝ) ^ (2 : ℕ) ≤ (p : ℝ) ^ k :=
    pow_le_pow_right₀ hpq (le_max_left _ _)
  have hbound := inv_pow_sum_le_geometric_tail hp (highPrimeExponents p N z) hk
  constructor
  · refine hbound.trans ?_
    rw [div_eq_mul_inv]
    exact mul_le_mul_of_nonneg_left (inv_anti₀ hz hzK.le) (by norm_num)
  · exact hbound.trans (mul_le_mul_of_nonneg_left
      (inv_anti₀ (by positivity) h2K) (by norm_num))

private theorem eventually_real_primeCounting_le_twice :
    ∀ᶠ x : ℝ in atTop,
      (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤ 2 * (x / Real.log x) := by
  have h := (isEquivalent_iff_tendsto_one (by
    filter_upwards [eventually_gt_atTop (1 : ℝ)] with x hx
    exact div_ne_zero (zero_lt_one.trans hx).ne' (Real.log_pos hx).ne')).mp
      Nat.isEquivalent_primeCounting
  filter_upwards [h.eventually_lt_const (show (1 : ℝ) < 2 by norm_num),
    eventually_gt_atTop (1 : ℝ)] with x hRatio hx
  have hPos := div_pos (zero_lt_one.trans hx) (Real.log_pos hx)
  exact ((div_lt_iff₀ hPos).mp hRatio).le

/-- The union of the high prime powers needed for the deletion budget. We
include all powers with exponent at most N, hence every such factor of a
denominator in the height interval. -/
noncomputable def highPrimePowers (N : ℕ) (z : ℝ) : Finset ℕ := by
  classical
  exact (Nat.primesLE N).biUnion fun p => (highPrimeExponents p N z).image (fun e => p ^ e)

private theorem mass_highPrimePowers_le_sum (N : ℕ) (z : ℝ) :
    (mass (highPrimePowers N z) : ℝ) ≤ ∑ p ∈ Nat.primesLE N,
      ∑ e ∈ highPrimeExponents p N z, ((p : ℝ) ^ e)⁻¹ := by
  classical
  calc
    _ ≤ ((∑ p ∈ Nat.primesLE N, mass ((highPrimeExponents p N z).image (fun e => p ^ e)) : ℚ) : ℝ) :=
      Rat.cast_le.mpr (mass_biUnion_le _ _)
    _ = _ := by
      push_cast [Rat.cast_sum]
      apply sum_congr rfl
      intro p hp
      have hp₁ := (Nat.mem_primesLE.mp hp).2.two_le
      rw [mass, sum_image (fun i _ j _ h => (Nat.pow_right_injective hp₁ h))]
      push_cast
      rfl

/-- Uniform bound for all forbidden prime powers at cutoff \(x^2\).
This gives the saving \(1/(\sqrt z\log z)\) at cutoff \(z\). -/
theorem eventually_mass_highPrimePowers_le :
    ∀ᶠ x : ℝ in atTop, ∀ N : ℕ,
      (mass (highPrimePowers N (x ^ (2 : ℕ))) : ℝ) ≤ 12 / (x * Real.log x) := by
  classical
  filter_upwards [eventually_real_primeCounting_le_twice,
    eventually_sum_inv_prime_sq_le, eventually_gt_atTop (1 : ℝ)] with x hCount hTail hx N
  let z := x ^ (2 : ℕ)
  let P := Nat.primesLE N
  let S := P.filter (fun p : ℕ => (p : ℝ) ≤ x)
  let L := P.filter (fun p : ℕ => x < (p : ℝ))
  let w (p : ℕ) := ∑ e ∈ highPrimeExponents p N z, ((p : ℝ) ^ e)⁻¹
  have hx₀ := zero_lt_one.trans hx
  have hLog := Real.log_pos hx
  have hP : (∑ p ∈ P, w p) = (∑ p ∈ S, w p) + ∑ p ∈ L, w p := by
    rw [← sum_filter_add_sum_filter_not P (fun p : ℕ => (p : ℝ) ≤ x) w]
    simp only [S, L, not_le]
  have hsCount : (S.card : ℝ) ≤ 2 * (x / Real.log x) := by
    have hSub : S ⊆ Nat.primesLE ⌊x⌋₊ := by
      intro p hp
      obtain ⟨hpa, hlo⟩ := mem_filter.mp hp
      exact Nat.mem_primesLE.mpr ⟨Nat.le_floor hlo, (Nat.mem_primesLE.mp hpa).2⟩
    have hCard : (S.card : ℝ) ≤ (Nat.primeCounting ⌊x⌋₊ : ℝ) := by
      exact_mod_cast (card_le_card hSub).trans_eq (Nat.primesLE_card_eq_primeCounting _)
    exact hCard.trans hCount
  have hsMass : (∑ p ∈ S, w p) ≤ 4 / (x * Real.log x) := by
    calc
      _ ≤ ∑ _p ∈ S, 2 / z := sum_le_sum fun p hp => (sum_high_exponents_le
        ((Nat.mem_primesLE.mp (mem_filter.mp hp).1).2.two_le) (by dsimp [z]; positivity)).1
      _ = (S.card : ℝ) * (2 / z) := by simp
      _ ≤ (2 * (x / Real.log x)) * (2 / z) := mul_le_mul_of_nonneg_right hsCount
        (by dsimp [z]; positivity)
      _ = _ := by dsimp [z]; field_simp; ring
  have hlMass : (∑ p ∈ L, w p) ≤ 8 / (x * Real.log x) := by
    by_cases hN : x ≤ (N : ℝ)
    · have hEq : L = primesBetween x (N : ℝ) := by
        ext p
        dsimp only [L]
        rw [mem_filter, mem_primesBetween hx₀.le (by positivity)]
        simp only [P, Nat.mem_primesLE]
        exact ⟨fun h => ⟨h.2, by exact_mod_cast h.1.1, h.1.2⟩,
          fun h => ⟨⟨by exact_mod_cast h.2.1, h.2.2⟩, h.1⟩⟩
      calc
        _ ≤ ∑ p ∈ L, 2 * ((p : ℝ) ^ (2 : ℕ))⁻¹ := sum_le_sum fun p hp =>
          (sum_high_exponents_le ((Nat.mem_primesLE.mp (mem_filter.mp hp).1).2.two_le)
            (by positivity : 0 < z)).2
        _ = 2 * ∑ p ∈ primesBetween x (N : ℝ), ((p : ℝ) ^ (2 : ℕ))⁻¹ := by rw [hEq, mul_sum]
        _ ≤ 2 * (4 / (x * Real.log x)) := mul_le_mul_of_nonneg_left (hTail _ hN) (by norm_num)
        _ = _ := by ring
    · have hEmpty : L = ∅ := by
        refine eq_empty_iff_forall_notMem.mpr fun p hp => ?_
        have h := mem_filter.mp hp
        have h' : (p : ℝ) ≤ N := by exact_mod_cast (Nat.mem_primesLE.mp h.1).1
        exact hN (h.2.le.trans h')
      rw [hEmpty, sum_empty]
      positivity
  have h := mass_highPrimePowers_le_sum N z
  change (mass (highPrimePowers N z) : ℝ) ≤ ∑ p ∈ P, w p at h
  rw [hP] at h
  change (mass (highPrimePowers N z) : ℝ) ≤ _
  rw [div_eq_mul_inv] at hsMass hlMass ⊢
  linarith only [h, hsMass, hlMass]

/-- Every forbidden power dividing a denominator in the height interval
is included among the factors charged to the deletion budget. -/
theorem mem_highPrimePowers_of_dvd {N n p e : ℕ} {z : ℝ} (hn : 0 < n) (hN : n ≤ N)
    (hp : p.Prime) (he : 2 ≤ e) (hz : z < (p : ℝ) ^ e) (hDiv : p ^ e ∣ n) :
    p ^ e ∈ highPrimePowers N z := by
  classical
  have hpN : p ≤ N := (le_self_pow hp.one_le (by omega : e ≠ 0)).trans ((Nat.le_of_dvd hn hDiv).trans hN)
  have heN : e ≤ N := e.lt_two_pow_self.le.trans <|
    (Nat.pow_le_pow_left hp.two_le e).trans ((Nat.le_of_dvd hn hDiv).trans hN)
  exact mem_biUnion.mpr ⟨p, Nat.mem_primesLE.mpr ⟨hpN, hp⟩,
    mem_image.mpr ⟨e, mem_filter.mpr ⟨mem_range.mpr (by omega), he, hz⟩, rfl⟩⟩

/-- Every member of the high prime-power family is positive. -/
theorem highPrimePowers_pos {N q : ℕ} {z : ℝ} (hq : q ∈ highPrimePowers N z) : 0 < q := by
  classical
  obtain ⟨p, hp, hpq⟩ := mem_biUnion.mp hq
  obtain ⟨e, _, rfl⟩ := mem_image.mp hpq
  exact Nat.pow_pos (Nat.mem_primesLE.mp hp).2.pos

/-- The exact high-power deletion at a polynomial cutoff has mass
\(O(N^{-\alpha})\) when the cutoff is \((D N^\alpha)^2\), uniformly in d.
Taking \(\alpha=1/12\) gives the loss required by the near-capacity construction. -/
theorem eventually_mass_high_power_multiples {α D : ℝ} (hα : 0 < α) (hD : 0 < D) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ d : ℕ,
      (mass ((highPrimePowers N ((D * (N : ℝ) ^ α) ^ (2 : ℕ))).biUnion
        fun q => primePart q (interval d N)) : ℝ) ≤ C / (N : ℝ) ^ α := by
  have hNat : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hX : Tendsto (fun N : ℕ => D * (N : ℝ) ^ α) atTop atTop :=
    ((tendsto_rpow_atTop hα).comp hNat).const_mul_atTop hD
  refine ⟨48 / (D * α), by positivity, ?_⟩
  filter_upwards [hX.eventually eventually_mass_highPrimePowers_le,
    (Real.tendsto_log_atTop.comp hNat).eventually_ge_atTop (max 1 (-(2 * Real.log D) / α)),
    eventually_ge_atTop (1 : ℕ)] with N hTail hLog hN d
  let L := Real.log (N : ℝ)
  let x := D * (N : ℝ) ^ α
  let E := highPrimePowers N (x ^ (2 : ℕ))
  have hN₀ : (0 : ℝ) < N := by exact_mod_cast Nat.succ_le_iff.mp hN
  have hL₁ : 1 ≤ L := (le_max_left _ _).trans hLog
  have hL₀ := zero_lt_one.trans_le hL₁
  have hx : 0 < x := mul_pos hD (Real.rpow_pos_of_pos hN₀ _)
  have hLogX : α * L / 2 ≤ Real.log x := by
    have hShift := (div_le_iff₀ hα).mp ((le_max_right _ _).trans hLog)
    change -(2 * Real.log D) ≤ L * α at hShift
    dsimp only [x]
    rw [Real.log_mul hD.ne' (Real.rpow_pos_of_pos hN₀ _).ne', Real.log_rpow hN₀]
    linarith only [hShift]
  have hHx : (mass (interval 1 N) : ℝ) ≤ 2 * L := by
    rw [show interval 1 N = denominators N from rfl, mass_denominators_eq_harmonic]
    exact (harmonic_le_one_add_log _).trans (by linarith only [hL₁])
  have hSub := mass_excluded_multiples_le (d := d) (N := N) E (fun _ hq => highPrimePowers_pos hq)
  have hSubR : (mass (E.biUnion fun q => primePart q (interval d N)) : ℝ) ≤
      (mass (interval 1 N) : ℝ) * (mass E : ℝ) := by
    exact_mod_cast hSub
  change (mass (E.biUnion fun q => primePart q (interval d N)) : ℝ) ≤ _
  calc
    _ ≤ (mass (interval 1 N) : ℝ) * (mass E : ℝ) := hSubR
    _ ≤ (2 * L) * (12 / (x * Real.log x)) :=
      mul_le_mul hHx (hTail N) (Rat.cast_nonneg.mpr (mass_nonneg E)) (by positivity)
    _ ≤ (2 * L) * (12 / (x * (α * L / 2))) := by
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      apply div_le_div_of_nonneg_left (by norm_num) (by positivity)
      exact mul_le_mul_of_nonneg_left hLogX hx.le
    _ = _ := by
      dsimp only [x]
      field_simp [(Real.rpow_pos_of_pos hN₀ α).ne']
      ring

/-- Marker-multiple loss for any marker set above a common threshold. -/
theorem mass_excluded_multiples_le_of_lower {d N : ℕ} (M : Finset ℕ)
    {x : ℝ} (hx : 0 < x) (hM : ∀ p ∈ M, x ≤ (p : ℝ)) :
    (mass (M.biUnion fun p => primePart p (interval d N)) : ℝ) ≤
      (mass (interval 1 N) : ℝ) * ((M.card : ℝ) / x) := by
  have hPos (p : ℕ) (hp : p ∈ M) : 0 < p := by exact_mod_cast hx.trans_le (hM p hp)
  have hBound := mass_excluded_multiples_le M hPos (d := d) (N := N)
  have hMass : (mass M : ℝ) ≤ (M.card : ℝ) / x := by
    calc
      _ = ∑ p ∈ M, (p : ℝ)⁻¹ := by unfold mass; push_cast; rfl
      _ ≤ ∑ _p ∈ M, x⁻¹ := sum_le_sum fun p hp => inv_anti₀ hx (hM p hp)
      _ = _ := by simp [div_eq_mul_inv]
  exact (by exact_mod_cast hBound : _ ≤ (mass (interval 1 N) : ℝ) * (mass M : ℝ)).trans
    (mul_le_mul_of_nonneg_left hMass (Rat.cast_nonneg.mpr (mass_nonneg _)))

/-- The marker-multiple loss is at most \(2K N^{-\alpha}\) whenever the
marker scale is \(N^\beta\) with \(\beta>\alpha\) and there are at most
\(K\log N\) markers. Constants are uniform in the allowed set of markers. -/
theorem eventually_mass_marker_multiples {α β K : ℝ} (_hα : 0 < α)
    (hαβ : α < β) (hK : 0 < K) :
    ∀ᶠ N : ℕ in atTop, ∀ d : ℕ, ∀ M : Finset ℕ, (M.card : ℝ) ≤ K * Real.log N →
      (∀ p ∈ M, (N : ℝ) ^ β ≤ (p : ℝ)) →
      (mass (M.biUnion fun p => primePart p (interval d N)) : ℝ) ≤ (2 * K) / (N : ℝ) ^ α := by
  have hNat : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hPowSmall := (isLittleO_log_rpow_rpow_atTop 2 (sub_pos.mpr hαβ)).bound zero_lt_one
  filter_upwards [hNat.eventually hPowSmall,
    (Real.tendsto_log_atTop.comp hNat).eventually_ge_atTop 1, eventually_ge_atTop (1 : ℕ)]
    with N hSmall hL hN d M hSize hM
  let x : ℝ := (N : ℝ) ^ β
  let L := Real.log (N : ℝ)
  have hL₁ : 1 ≤ L := hL
  have hN₀ : (0 : ℝ) < N := by exact_mod_cast Nat.succ_le_iff.mp hN
  have hx : 0 < x := Real.rpow_pos_of_pos hN₀ _
  have hH : (mass (interval 1 N) : ℝ) ≤ 2 * L := by
    rw [show interval 1 N = denominators N from rfl, mass_denominators_eq_harmonic]
    exact (harmonic_le_one_add_log _).trans (by linarith only [hL₁])
  have hSmall' : L ^ (2 : ℕ) ≤ (N : ℝ) ^ (β - α) := by
    change ‖L ^ (2 : ℝ)‖ ≤ (1 : ℝ) * ‖(N : ℝ) ^ (β - α)‖ at hSmall
    rw [show (2 : ℝ) = (2 : ℕ) by norm_num, Real.rpow_natCast,
      Real.norm_of_nonneg (by positivity), Real.norm_of_nonneg (by positivity), one_mul] at hSmall
    exact hSmall
  calc
    _ ≤ (mass (interval 1 N) : ℝ) * ((M.card : ℝ) / x) :=
      mass_excluded_multiples_le_of_lower M hx hM
    _ ≤ (2 * L) * ((K * L) / x) := mul_le_mul hH
      (div_le_div_of_nonneg_right hSize hx.le) (by positivity) (by positivity)
    _ = 2 * K * L ^ (2 : ℕ) / x := by ring
    _ ≤ 2 * K * ((N : ℝ) ^ (β - α)) / x := by gcongr
    _ = _ := by
      rw [Real.rpow_sub hN₀]
      dsimp only [x]
      field_simp [(Real.rpow_pos_of_pos hN₀ α).ne', hx.ne']

end LeanAB.PaperB.Closure

