module

public import PaperB.BaselineCutoff

meta import Mathlib.Tactic

@[expose] public section

namespace LeanAB.PaperB.Closure

open Filter Finset
open scoped Topology

/-- Rounded cofactor bound at the next-capacity scale. -/
noncomputable def nextCoverBound (K : ℝ) (N : ℕ) : ℕ :=
  ⌈K * Real.log (N : ℝ) * Real.log (Real.log (N : ℝ)) *
    Real.log (Real.log (Real.log (N : ℝ))) ^ 4⌉₊

/-- The retained primes in the next-capacity construction are at most N/Q. -/
noncomputable def nextCutoff (K : ℝ) (N : ℕ) : ℝ :=
  (N : ℝ) / (nextCoverBound K N : ℝ)

theorem eventually_nextCoverBound_logs {K : ℝ} (hK : 0 < K) :
    ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      let U := Real.log L
      let V := Real.log U
      let Q := nextCoverBound K N
      let w := Real.log (Q : ℝ)
      0 < Q ∧ (Q : ℝ) ≤ L ^ 2 ∧ w ≤ 2 * U ∧ 2 * w ≤ L / 2 ∧
        |w - U| ≤ 6 * V ∧ w ≤ U + V + 4 * Real.log V + (|Real.log K| + 1) := by
  have hCast : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hCast
  have hLogLog := Real.tendsto_log_atTop.comp hLog
  have hLogLogLog := Real.tendsto_log_atTop.comp hLogLog
  have hSlowU := Real.isLittleO_log_id_atTop.bound (show (0 : ℝ) < 1 / 6 by norm_num)
  have hSlowL := Real.isLittleO_log_id_atTop.bound (show (0 : ℝ) < 1 / 8 by norm_num)
  filter_upwards [hLog.eventually_ge_atTop (max 1 (1 / K)), hLogLog.eventually_ge_atTop 1,
    hLogLogLog.eventually_ge_atTop (|Real.log K| + 1),
    hLogLog.eventually hSlowU, hLog.eventually hSlowL] with N hL hU hV hSlowU hSlowL
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let V := Real.log U
  let Q := nextCoverBound K N
  let w := Real.log (Q : ℝ)
  let A := K * L * U * V ^ 4
  change max 1 (1 / K) ≤ L at hL
  change 1 ≤ U at hU
  change |Real.log K| + 1 ≤ V at hV
  have hL₁ : 1 ≤ L := (le_max_left _ _).trans hL
  have hL₀ : 0 < L := zero_lt_one.trans_le hL₁
  have hU₀ : 0 < U := zero_lt_one.trans_le hU
  have hV₁ : 1 ≤ V := by linarith only [hV, abs_nonneg (Real.log K)]
  have hV₀ : 0 < V := zero_lt_one.trans_le hV₁
  have hKL : 1 ≤ K * L := by
    have hh := (div_le_iff₀ hK).mp ((le_max_right (1 : ℝ) (1 / K)).trans hL)
    rwa [mul_comm] at hh
  have hA₁ : 1 ≤ A := calc
    1 ≤ K * L := hKL
    _ ≤ K * L * U := le_mul_of_one_le_right (mul_nonneg hK.le hL₀.le) hU
    _ ≤ A := le_mul_of_one_le_right (mul_nonneg (mul_nonneg hK.le hL₀.le) hU₀.le)
      (one_le_pow₀ hV₁)
  have hA₀ := zero_lt_one.trans_le hA₁
  have hQ : 0 < Q := Nat.ceil_pos.mpr hA₀
  have hQ₀ : (0 : ℝ) < Q := Nat.cast_pos.mpr hQ
  have hQhi : (Q : ℝ) ≤ 2 * A := by
    have hCeil : (Q : ℝ) < A + 1 := Nat.ceil_lt_add_one hA₀.le
    linarith only [hCeil, hA₁]
  have hLogA : Real.log A = Real.log K + U + V + 4 * Real.log V := by
    dsimp only [A]
    rw [Real.log_mul (mul_ne_zero (mul_ne_zero hK.ne' hL₀.ne') hU₀.ne')
      (pow_ne_zero _ hV₀.ne'), Real.log_mul (mul_ne_zero hK.ne' hL₀.ne') hU₀.ne',
      Real.log_mul hK.ne' hL₀.ne', Real.log_pow]
    norm_num
    rfl
  have hLow := Real.log_le_log hA₀ (Nat.le_ceil A)
  change Real.log A ≤ w at hLow
  rw [hLogA] at hLow
  have hHi := Real.log_le_log hQ₀ hQhi
  change w ≤ Real.log (2 * A) at hHi
  rw [Real.log_mul (by norm_num) hA₀.ne', hLogA] at hHi
  have hUpper : w ≤ U + V + 4 * Real.log V + (|Real.log K| + 1) := by
    linarith only [hHi, le_abs_self (Real.log K),
      Real.log_le_sub_one_of_pos (show (0 : ℝ) < 2 by norm_num)]
  have hW : |w - U| ≤ 6 * V := by
    have hLower : U ≤ w := by
      linarith only [hLow, hV, neg_abs_le (Real.log K), Real.log_nonneg hV₁]
    rw [abs_of_nonneg (sub_nonneg.mpr hLower)]
    linarith only [hUpper, hV, Real.log_le_sub_one_of_pos hV₀]
  have hVsmall : V ≤ (1 / 6 : ℝ) * U := by
    change ‖V‖ ≤ (1 / 6 : ℝ) * ‖U‖ at hSlowU
    simpa only [Real.norm_eq_abs, abs_of_nonneg hV₀.le, abs_of_nonneg hU₀.le] using hSlowU
  have hUsmall : U ≤ (1 / 8 : ℝ) * L := by
    change ‖U‖ ≤ (1 / 8 : ℝ) * ‖L‖ at hSlowL
    simpa only [Real.norm_eq_abs, abs_of_nonneg hU₀.le, abs_of_nonneg hL₀.le] using hSlowL
  have hwU : w ≤ 2 * U := by linarith only [(le_abs_self _).trans hW, hVsmall]
  have hQsq : (Q : ℝ) ≤ L ^ 2 := by
    apply (Real.log_le_log_iff hQ₀ (pow_pos hL₀ 2)).mp
    rw [Real.log_pow]
    simpa only [Nat.cast_ofNat] using hwU
  exact ⟨hQ, hQsq, hwU, by linarith only [hwU, hUsmall], hW, hUpper⟩

/-- The rounded cofactor scale and the cutoff satisfy the geometric constraints
used to form the retained blocks. -/
theorem eventually_nextCutoff_geometry {K : ℝ} (hK : 0 < K) :
    ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      let U := Real.log L
      let Q := nextCoverBound K N
      let w := Real.log (Q : ℝ)
      0 < Q ∧ Q ≤ 2 * ⌈L ^ 12⌉₊ ∧ Real.sqrt (N : ℝ) < nextCutoff K N ∧
        L - w ≥ L / 2 ∧ w ≤ 2 * U := by
  have hCast : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hCast
  filter_upwards [eventually_nextCoverBound_logs hK, hLog.eventually_ge_atTop 1,
    eventually_ge_atTop (1 : ℕ)] with N hBounds hL hN
  let L := Real.log (N : ℝ)
  let Q := nextCoverBound K N
  let w := Real.log (Q : ℝ)
  obtain ⟨hQ, hQsq, hwU, hwL, _, _⟩ := hBounds
  have hL₁ : 1 ≤ L := hL
  have hL₀ := zero_lt_one.trans_le hL₁
  have hQlarge : Q ≤ 2 * ⌈L ^ 12⌉₊ := by
    have h : (Q : ℝ) ≤ (⌈L ^ 12⌉₊ : ℝ) := hQsq.trans
      ((pow_le_pow_right₀ hL₁ (by norm_num : (2 : ℕ) ≤ 12)).trans (Nat.le_ceil _))
    have hh : Q ≤ ⌈L ^ 12⌉₊ := by exact_mod_cast h
    omega
  have hN₀ : (0 : ℝ) < N := Nat.cast_pos.mpr (zero_lt_one.trans_le hN)
  have hQ₀ : (0 : ℝ) < Q := Nat.cast_pos.mpr hQ
  have hSqrtQ : (Q : ℝ) < Real.sqrt (N : ℝ) := by
    rw [← Real.exp_log hQ₀, Real.sqrt_eq_rpow, Real.rpow_def_of_pos hN₀, Real.exp_lt_exp]
    change w < L * (1 / 2)
    linarith only [show 2 * w ≤ L / 2 from hwL, hL₀]
  have hSqrtCut : Real.sqrt (N : ℝ) < nextCutoff K N := by
    apply (lt_div_iff₀ hQ₀).mpr
    exact (mul_lt_mul_of_pos_left hSqrtQ (Real.sqrt_pos.mpr hN₀)).trans_eq
      (Real.mul_self_sqrt hN₀.le)
  exact ⟨hQ, hQlarge, hSqrtCut, by linarith only [show 2 * w ≤ L / 2 from hwL, hL₀], hwU⟩

/-- The mass removed above the next-capacity cutoff, with the second term
and the coefficient of the fourth iterated logarithm retained. -/
theorem eventually_nextCutoffPart_mass {K : ℝ} (hK : 0 < K) (d : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      let U := Real.log L
      (mass (cutoffPart d N (nextCutoff K N)) : ℝ) ≤
        U ^ 2 / (2 * L) + U * Real.log U / L +
          (U / L) * (4 * Real.log (Real.log U) + C) := by
  obtain ⟨B, hB, hWindow⟩ := eventually_windowPrimeMass_error_loglog 6 (by norm_num)
  let C := B + (|Real.log K| + 1) + 18
  refine ⟨C, by dsimp only [C]; positivity, ?_⟩
  have hCast : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hCast
  have hLogLog := Real.tendsto_log_atTop.comp hLog
  have hSmall := (isLittleO_log_rpow_rpow_atTop (2 : ℝ) (s := 1) one_pos).bound
    (show (0 : ℝ) < 1 by norm_num)
  filter_upwards [eventually_nextCoverBound_logs hK, hWindow, hLog.eventually_ge_atTop 1,
    hLogLog.eventually_ge_atTop 1, hLogLog.eventually hSmall,
    eventually_ge_atTop (1 : ℕ)] with N hLogs hWindow hL hU hSmall hN
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let V := Real.log U
  let Q := nextCoverBound K N
  let w := Real.log (Q : ℝ)
  obtain ⟨hQ, _, _, hHalf, hWidth, hUpper⟩ := hLogs
  have hNr : 0 < N := zero_lt_one.trans_le hN
  have hL₀ : 0 < L := zero_lt_one.trans_le hL
  have hU₀ : 0 ≤ U := zero_le_one.trans hU
  have hHalf' : 2 * w ≤ L := by linarith only [show 2 * w ≤ L / 2 from hHalf, hL₀]
  have hCut : (N : ℝ) * Real.exp (-w) = nextCutoff K N := by
    change (N : ℝ) * Real.exp (-Real.log (Q : ℝ)) = (N : ℝ) / (Q : ℝ)
    rw [Real.exp_neg, Real.exp_log (Nat.cast_pos.mpr hQ), div_eq_mul_inv]
  have hSub : cutoffPart d N (nextCutoff K N) ⊆ cutoffPart 1 N (nextCutoff K N) := by
    have hNonneg : 0 ≤ nextCutoff K N := div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _)
    intro n hn
    obtain ⟨hInt, hp⟩ := (mem_cutoffPart hNonneg).mp hn
    obtain ⟨hnlo, hnhi⟩ := mem_Icc.mp hInt
    exact (mem_cutoffPart hNonneg).mpr
      ⟨mem_Icc.mpr ⟨(le_max_left 1 d).trans hnlo, hnhi⟩, hp⟩
  have hMass : (mass (cutoffPart d N (nextCutoff K N)) : ℝ) ≤ windowPrimeMass N w := calc
    _ ≤ (mass (cutoffPart 1 N (nextCutoff K N)) : ℝ) := Rat.cast_le.mpr (mass_mono hSub)
    _ = _ := by rw [windowPrimeMass_eq_union_mass hNr hHalf', hCut]; rfl
  have hError := hWindow w hWidth
  have hWindowUpper : windowPrimeMass N w ≤ w ^ 2 / (2 * L) + B * U / L := by
    linarith only [(le_abs_self _).trans hError]
  have hVSq : V ^ 2 ≤ U := by
    change ‖V ^ (2 : ℝ)‖ ≤ 1 * ‖U ^ (1 : ℝ)‖ at hSmall
    simpa only [show (2 : ℝ) = ((2 : ℕ) : ℝ) by norm_num, Real.rpow_natCast, Real.rpow_one,
      Real.norm_eq_abs, abs_of_nonneg (sq_nonneg V), abs_of_nonneg hU₀, one_mul] using hSmall
  have hSquare : (w - U) ^ 2 / (2 * L) ≤ 18 * U / L := calc
    _ ≤ (36 * U) / (2 * L) := by
      apply div_le_div_of_nonneg_right _ (by positivity)
      calc
        _ = |w - U| ^ 2 := (sq_abs _).symm
        _ ≤ (6 * V) ^ 2 := pow_le_pow_left₀ (abs_nonneg _) hWidth 2
        _ = 36 * V ^ 2 := by ring
        _ ≤ 36 * U := mul_le_mul_of_nonneg_left hVSq (by norm_num)
    _ = _ := by ring
  have hLinear : U * (w - U) / L ≤ U * (V + 4 * Real.log V + (|Real.log K| + 1)) / L := by
    apply div_le_div_of_nonneg_right _ hL₀.le
    exact mul_le_mul_of_nonneg_left (by linarith only [hUpper]) hU₀
  calc
    _ ≤ windowPrimeMass N w := hMass
    _ ≤ w ^ 2 / (2 * L) + B * U / L := hWindowUpper
    _ = U ^ 2 / (2 * L) + U * (w - U) / L + (w - U) ^ 2 / (2 * L) + B * U / L := by
      ring
    _ ≤ U ^ 2 / (2 * L) + U * (V + 4 * Real.log V + (|Real.log K| + 1)) / L +
        18 * U / L + B * U / L := by linarith only [hLinear, hSquare]
    _ = _ := by
      change _ = U ^ 2 / (2 * L) + U * V / L + (U / L) * (4 * Real.log V + C)
      dsimp only [C]
      ring

end LeanAB.PaperB.Closure
