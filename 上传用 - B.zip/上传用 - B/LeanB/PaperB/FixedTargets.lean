module

public import PaperB.Obstruction.Published
public import Mathlib.Data.Fintype.EquivFin
public import Mathlib.Data.Rat.Floor
public import Mathlib.NumberTheory.Harmonic.EulerMascheroni
meta import Mathlib.Tactic

/-! Fixed targets, bounded matching numbers, and their least-height definitions. -/

@[expose] public section

namespace LeanAB.PaperB.FixedTargets

open Filter Finset
open scoped BigOperators Topology

/-- The finite family of sets representing exactly r on the permitted stock. -/
def edges (d N : ℕ) (r : ℚ) : Finset (Finset ℕ) :=
  (interval d N).powerset.filter (fun S => mass S = r)

@[simp] theorem mem_edges {d N : ℕ} {r : ℚ} {S : Finset ℕ} :
    S ∈ edges d N r ↔ S ⊆ interval d N ∧ mass S = r := by
  simp [edges]

def boundedEdges (d N : ℕ) (r : ℚ) (K : ℕ) : Finset (Finset ℕ) :=
  (edges d N r).filter (fun S => S.card ≤ K)

@[simp] theorem mem_boundedEdges {d N K : ℕ} {r : ℚ} {S : Finset ℕ} :
    S ∈ boundedEdges d N r K ↔ S ⊆ interval d N ∧ mass S = r ∧ S.card ≤ K := by
  simp [boundedEdges, and_assoc]

/-- A finite matching is an actual family of pairwise disjoint eligible sets. -/
def IsMatching (E F : Finset (Finset ℕ)) : Prop :=
  F ⊆ E ∧ (↑F : Set (Finset ℕ)).PairwiseDisjoint id

noncomputable def sizes (E : Finset (Finset ℕ)) : Finset ℕ := by
  classical
  exact (E.powerset.filter (fun F : Finset (Finset ℕ) => (↑F : Set (Finset ℕ)).PairwiseDisjoint id)).image card

theorem mem_sizes {E : Finset (Finset ℕ)} {j : ℕ} :
    j ∈ sizes E ↔ ∃ F, IsMatching E F ∧ F.card = j := by
  classical
  simp [sizes, IsMatching]

theorem sizes_nonempty (E : Finset (Finset ℕ)) : (sizes E).Nonempty := by
  refine ⟨0, mem_sizes.mpr ⟨∅, ?_, rfl⟩⟩
  simp [IsMatching]

noncomputable def matchingNumber (E : Finset (Finset ℕ)) : ℕ :=
  (sizes E).max' (sizes_nonempty E)

theorem matchingNumber_spec (E : Finset (Finset ℕ)) :
    IsGreatest {j | ∃ F, IsMatching E F ∧ F.card = j} (matchingNumber E) := by
  exact ⟨mem_sizes.mp (max'_mem _ _), fun j hj => le_max' _ _ (mem_sizes.mpr hj)⟩

theorem matchingNumber_mono : Monotone matchingNumber := by
  intro E F hEF
  obtain ⟨G, hG, hCard⟩ := (matchingNumber_spec E).1
  exact (matchingNumber_spec F).2 ⟨G, ⟨hG.1.trans hEF, hG.2⟩, hCard⟩

theorem exists_ordered_matching (E : Finset (Finset ℕ)) :
    ∃ S : Fin (matchingNumber E) → Finset ℕ,
      Pairwise (fun i j => Disjoint (S i) (S j)) ∧ ∀ i, S i ∈ E := by
  classical
  obtain ⟨F, hF, hc⟩ := (matchingNumber_spec E).1
  let e : F ≃ Fin (matchingNumber E) := Fintype.equivFinOfCardEq (by simpa using hc)
  let S (i : Fin (matchingNumber E)) : Finset ℕ := (e.symm i).val
  have hS : Function.Injective S := Subtype.val_injective.comp e.symm.injective
  exact ⟨S, fun i j hij => hF.2 (e.symm i).property (e.symm j).property (fun h => hij (hS h)),
    fun i => hF.1 (e.symm i).property⟩

theorem ordered_image_matching {E : Finset (Finset ℕ)} {m : ℕ}
    (S : Fin m → Finset ℕ) (hDis : Pairwise (fun i j => Disjoint (S i) (S j)))
    (hNonempty : ∀ i, (S i).Nonempty) (hS : ∀ i, S i ∈ E) :
    IsMatching E (univ.image S) ∧ (univ.image S).card = m := by
  have hInj : Function.Injective S := by
    intro i j heq
    by_contra hij
    obtain ⟨a, ha⟩ := hNonempty i
    exact disjoint_left.mp (hDis hij) ha (heq ▸ ha)
  refine ⟨⟨?_, ?_⟩, ?_⟩
  · intro V hV
    obtain ⟨i, _, rfl⟩ := mem_image.mp hV
    exact hS i
  · intro V hV W hW hVW
    obtain ⟨i, _, rfl⟩ := mem_image.mp hV
    obtain ⟨j, _, rfl⟩ := mem_image.mp hW
    exact hDis (ne_of_apply_ne S hVW)
  · rw [card_image_of_injective _ hInj, card_univ, Fintype.card_fin]

theorem le_matchingNumber_of_ordered {E : Finset (Finset ℕ)} {m : ℕ}
    (S : Fin m → Finset ℕ) (hDis : Pairwise (fun i j => Disjoint (S i) (S j)))
    (hNonempty : ∀ i, (S i).Nonempty) (hS : ∀ i, S i ∈ E) :
    m ≤ matchingNumber E :=
  (matchingNumber_spec E).2 ⟨univ.image S, ordered_image_matching S hDis hNonempty hS⟩

/-- The fixed-target maximum k_r(N) in F2, using denominators in [2,N]. -/
noncomputable def fixedPackingNumber (r : ℚ) (N : ℕ) : ℕ :=
  matchingNumber (edges 2 N r)

/-- The length-restricted matching number ν_K(r;N). -/
noncomputable def boundedPackingNumber (r : ℚ) (K N : ℕ) : ℕ :=
  matchingNumber (boundedEdges 2 N r K)

theorem boundedPackingNumber_le (r : ℚ) (K N : ℕ) :
    boundedPackingNumber r K N ≤ fixedPackingNumber r N :=
  matchingNumber_mono (filter_subset _ _)

theorem fixedPackingNumber_mono (r : ℚ) : Monotone (fixedPackingNumber r) := by
  intro N M hNM
  apply matchingNumber_mono
  intro S hS
  obtain ⟨hIn, hMass⟩ := mem_edges.mp hS
  exact mem_edges.mpr ⟨fun a ha => mem_Icc.mpr
    ⟨(mem_Icc.mp (hIn ha)).1, (mem_Icc.mp (hIn ha)).2.trans hNM⟩, hMass⟩

/-- Least denominator a positive target can use in a [2,N] representation. -/
def targetCutoff (r : ℚ) : ℕ :=
  max 2 ⌈r⁻¹⌉₊

theorem targetCutoff_ge_two (r : ℚ) : 2 ≤ targetCutoff r :=
  le_max_left _ _

theorem cutoff_reciprocal_le {r : ℚ} (hr : 0 < r) :
    ((targetCutoff r : ℕ) : ℚ)⁻¹ ≤ r := by
  have hbase : r⁻¹ ≤ (targetCutoff r : ℚ) :=
    Nat.le_ceil _ |>.trans (Nat.cast_le.mpr (le_max_right _ _))
  simpa only [inv_inv] using inv_anti₀ (inv_pos.mpr hr) hbase

theorem subset_target_interval {r : ℚ} {N : ℕ} {S : Finset ℕ}
    (hS : S ⊆ interval 2 N) (hMass : mass S = r) : S ⊆ interval (targetCutoff r) N := by
  intro b hb
  have hbRange := mem_Icc.mp (hS hb)
  have hB : (0 : ℚ) < b := Nat.cast_pos.mpr (by omega)
  have hAtom : (b : ℚ)⁻¹ ≤ r := by
    rw [← hMass]
    simpa only [mass, sum_singleton] using mass_mono (singleton_subset_iff.mpr hb)
  have hB' : r⁻¹ ≤ (b : ℚ) := by
    simpa only [inv_inv] using inv_anti₀ (inv_pos.mpr hB) hAtom
  exact mem_Icc.mpr ⟨max_le (by omega : 1 ≤ b) (max_le (by omega : 2 ≤ b) (Nat.ceil_le.mpr hB')),
    hbRange.2⟩

theorem edges_eq_target_interval (r : ℚ) (N : ℕ) :
    edges 2 N r = edges (targetCutoff r) N r := by
  ext S
  simp only [mem_edges]
  constructor
  · exact fun h => ⟨subset_target_interval h.1 h.2, h.2⟩
  · refine fun h => ⟨?_, h.2⟩
    intro a ha
    have hR := mem_Icc.mp (h.1 ha)
    exact mem_Icc.mpr ⟨max_le (by omega) ((targetCutoff_ge_two r).trans ((le_max_right _ _).trans hR.1)), hR.2⟩

/-- The exact reciprocal mass available to a fixed positive target. -/
def targetStock (r : ℚ) (N : ℕ) : ℚ :=
  mass (interval (targetCutoff r) N)

theorem interval_insert_lower {d N : ℕ} (hd : 0 < d) (hN : d ≤ N) :
    interval d N = insert d (interval (d + 1) N) := by
  ext a
  simp only [interval, mem_Icc, mem_insert]
  omega

theorem interval_insert_upper {d N : ℕ} (hd : 0 < d) (hN : d ≤ N) :
    interval d N = insert N (interval d (N - 1)) := by
  ext a
  simp only [interval, mem_Icc, mem_insert]
  omega

theorem mass_interval_step_lower {d N : ℕ} (hd : 0 < d) (hN : d ≤ N) :
    mass (interval d N) = (d : ℚ)⁻¹ + mass (interval (d + 1) N) := by
  rw [interval_insert_lower hd hN, mass, sum_insert (by simp [interval])]
  rfl

theorem mass_interval_step_upper {d N : ℕ} (hd : 0 < d) (hN : d ≤ N) :
    mass (interval d N) = (N : ℚ)⁻¹ + mass (interval d (N - 1)) := by
  rw [interval_insert_upper hd hN, mass, sum_insert (by
    have hN₀ : 0 < N := hd.trans_le hN
    simp [interval, show ¬ N ≤ N - 1 by omega])]
  rfl

theorem targetStock_eq_harmonic_sub (r : ℚ) {N : ℕ} (hN : targetCutoff r - 1 ≤ N) :
    targetStock r N = mass (interval 1 N) - mass (interval 1 (targetCutoff r - 1)) := by
  let d := targetCutoff r
  have hd : 2 ≤ d := targetCutoff_ge_two r
  have hDis : Disjoint (interval d N) (interval 1 (d - 1)) := by
    apply disjoint_left.mpr
    intro b hb hb'
    simp only [interval, mem_Icc] at hb hb'
    omega
  have hUnion : interval d N ∪ interval 1 (d - 1) = interval 1 N := by
    ext b
    simp only [interval, mem_union, mem_Icc]
    omega
  have h : mass (interval d N) + mass (interval 1 (d - 1)) = mass (interval 1 N) := by
    rw [← hUnion]
    exact (sum_union hDis).symm
  change mass (interval d N) = _
  change mass (interval d N) = mass (interval 1 N) - mass (interval 1 (d - 1))
  linarith


/-- A denominator that already pays the full target cannot share a group. -/
theorem eq_singleton_of_atom_eq_target {r : ℚ} {d N : ℕ} {S : Finset ℕ}
    (hS : S ⊆ interval d N) (hMass : mass S = r) {a : ℕ} (ha : a ∈ S)
    (hatom : (a : ℚ)⁻¹ = r) : S = {a} := by
  apply Subset.antisymm
  · intro b hb
    apply mem_singleton.mpr
    by_contra hn
    have ht : insert b {a} ⊆ S := insert_subset hb (singleton_subset_iff.mpr ha)
    have hle := mass_mono ht
    have hb₀ : (0 : ℚ) < b := Nat.cast_pos.mpr (by have := (mem_Icc.mp (hS hb)).1; omega)
    rw [mass, sum_insert (by simpa using hn), sum_singleton, hatom] at hle
    linarith [inv_pos.mpr hb₀]
  · exact singleton_subset_iff.mpr ha

theorem insert_singleton_matching {r : ℚ} {d N : ℕ} {F : Finset (Finset ℕ)}
    (hd : 0 < d) (hN : d ≤ N) (hr : (d : ℚ)⁻¹ = r)
    (hF : IsMatching (edges (d + 1) N r) F) :
    IsMatching (edges d N r) (insert {d} F) ∧ (insert {d} F).card = F.card + 1 := by
  have hAvoid (S : Finset ℕ) (hS : S ∈ F) : d ∉ S := by
    intro h
    have hh := (mem_Icc.mp ((mem_edges.mp (hF.1 hS)).1 h)).1
    omega
  have hdNot : ({d} : Finset ℕ) ∉ F := fun h => hAvoid {d} h (mem_singleton_self _)
  refine ⟨⟨?_, ?_⟩, card_insert_of_notMem hdNot⟩
  · intro S hS
    rcases mem_insert.mp hS with h | h
    · subst S
      exact mem_edges.mpr ⟨singleton_subset_iff.mpr (mem_Icc.mpr ⟨by omega, hN⟩),
        by simp [mass, hr]⟩
    · obtain ⟨hSub, hMass⟩ := mem_edges.mp (hF.1 h)
      exact mem_edges.mpr ⟨fun a ha => mem_Icc.mpr
        ⟨max_le (le_max_left _ _ |>.trans (mem_Icc.mp (hSub ha)).1)
          (by have := (mem_Icc.mp (hSub ha)).1; omega), (mem_Icc.mp (hSub ha)).2⟩, hMass⟩
  · intro S hS T hT hne
    change Disjoint S T
    rcases mem_insert.mp hS with h | h
    · subst S
      have hTF := (mem_insert.mp hT).resolve_left hne.symm
      exact disjoint_left.mpr fun a ha ht => hAvoid T hTF ((mem_singleton.mp ha) ▸ ht)
    · rcases mem_insert.mp hT with hh | hh
      · subst T
        exact disjoint_left.mpr fun a ha ht => hAvoid S h ((mem_singleton.mp ht) ▸ ha)
      · exact hF.2 h hh hne

/-- Removing the boundary denominator loses exactly one possible group at the
unit-fraction boundary. -/
theorem matchingNumber_boundary {r : ℚ} {d N : ℕ} (hd : 0 < d) (hN : d ≤ N)
    (hr : (d : ℚ)⁻¹ = r) :
    matchingNumber (edges d N r) = matchingNumber (edges (d + 1) N r) + 1 := by
  apply le_antisymm
  · obtain ⟨F, hF, hCard⟩ := (matchingNumber_spec (edges d N r)).1
    let G := F.erase {d}
    have hGF : G ⊆ F := erase_subset _ _
    have hG : IsMatching (edges (d + 1) N r) G := by
      refine ⟨?_, hF.2.subset hGF⟩
      intro S hS
      obtain ⟨hSub, hMass⟩ := mem_edges.mp (hF.1 (hGF hS))
      have hdS : d ∉ S := fun hdS =>
        (mem_erase.mp hS).1 (eq_singleton_of_atom_eq_target hSub hMass hdS hr)
      refine mem_edges.mpr ⟨?_, hMass⟩
      intro a ha
      have hR := mem_Icc.mp (hSub ha)
      have hne : a ≠ d := fun h => hdS (h ▸ ha)
      exact mem_Icc.mpr ⟨by omega, hR.2⟩
    have hGnum := (matchingNumber_spec (edges (d + 1) N r)).2 ⟨G, hG, rfl⟩
    have hFG : F.card ≤ G.card + 1 := by
      by_cases h : ({d} : Finset ℕ) ∈ F
      · simp [G, card_erase_add_one h]
      · simp [G, erase_eq_of_notMem h]
    rw [← hCard]
    exact hFG.trans (Nat.add_le_add_right hGnum _)
  · obtain ⟨F, hF, hCard⟩ := (matchingNumber_spec (edges (d + 1) N r)).1
    obtain ⟨hF', hCard'⟩ := insert_singleton_matching hd hN hr hF
    exact (matchingNumber_spec (edges d N r)).2 ⟨insert {d} F, hF', hCard'.trans (by rw [hCard])⟩

theorem k_eq_unit_matchingNumber (N : ℕ) : k N = matchingNumber (edges 1 N 1) := by
  have hEq (F : Finset (Finset ℕ)) : UnitPacking N F ↔ IsMatching (edges 1 N 1) F := by
    simp only [UnitPacking, IsMatching, denominators, Finset.subset_iff, mem_edges]
  have hm : IsGreatest {j | ∃ F, UnitPacking N F ∧ F.card = j}
      (matchingNumber (edges 1 N 1)) := by
    simpa only [hEq] using matchingNumber_spec (edges 1 N 1)
  exact (k_isGreatest N).unique hm

theorem k_eq_one_add_fixedPackingNumber_one {N : ℕ} (hN : 1 ≤ N) :
    k N = fixedPackingNumber 1 N + 1 := by
  rw [k_eq_unit_matchingNumber, matchingNumber_boundary (by decide : 0 < 1) hN (by norm_num)]
  rfl

theorem integer_represented_of_le_k {N j : ℕ} (hj : j ≤ k N) : j ∈ representedIntegers N := by
  obtain ⟨F, hF, hc⟩ := (k_isGreatest N).1
  obtain ⟨G, hG, hg⟩ := exists_subset_card_eq (by simpa only [hc] using hj : j ≤ F.card)
  refine mem_representedIntegers.mpr ⟨G.biUnion id, ?_, ?_⟩
  · intro a ha
    obtain ⟨S, hS, ha⟩ := mem_biUnion.mp ha
    exact (hF.1 S (hG hS)).1 ha
  · calc
      _ = ∑ S ∈ G, mass S := sum_biUnion (hF.2.subset hG)
      _ = ∑ _S ∈ G, (1 : ℚ) := sum_congr rfl fun S hS => (hF.1 S (hG hS)).2
      _ = _ := by simp [hg]

/-- A gap of at most one between the packing and representing maxima forces
every integer up to the representing maximum to occur. -/
theorem represented_initial_segment_if_close {N : ℕ} (hClose : h N ≤ k N + 1) :
    representedIntegers N = range (h N + 1) := by
  ext j
  simp only [mem_range]
  constructor
  · intro hj
    exact Nat.lt_succ_of_le ((h_isGreatest N).2 (mem_representedIntegers.mp hj))
  · intro hj
    by_cases hClosej : j ≤ k N
    · exact integer_represented_of_le_k hClosej
    · have hEq : j = h N := by omega
      rw [hEq]
      exact mem_representedIntegers.mpr (h_isGreatest N).1


/-- The necessary loss B₋ appearing in the lower bound on excluded mass. -/
noncomputable def necessaryLoss (N : ℕ) (C : ℝ) : ℝ :=
  let L := Real.log (N : ℝ)
  let U := Real.log L
  U ^ 2 / (2 * L) - C * U / L

/-- The sufficient loss B₊ in the packing construction. -/
noncomputable def sufficientLoss (N : ℕ) (C : ℝ) : ℝ :=
  let L := Real.log (N : ℝ)
  let U := Real.log L
  U ^ 2 / (2 * L) + C * U * Real.log U / L

theorem eventually_fixed_denominator_dvd (q : ℕ) (hq : 0 < q) :
    ∀ᶠ N : ℕ in atTop, q ∣ permittedDenominator N := by
  have hGrowth : Tendsto (fun N : ℕ => smoothCutoff N) atTop atTop :=
    (tendsto_rpow_atTop (show (0 : ℝ) < 1 / 20 by norm_num)).comp tendsto_natCast_atTop_atTop
  filter_upwards [hGrowth.eventually_ge_atTop (q : ℝ)] with N hN
  have hIn : q ∈ Icc 1 ⌊smoothCutoff N⌋₊ := mem_Icc.mpr ⟨hq, Nat.le_floor hN⟩
  have hlcm : q ∣ Nat.lcmUpto ⌊smoothCutoff N⌋₊ := dvd_lcm (f := id) hIn
  exact hlcm.trans (dvd_mul_right _ _)

/-- The sharp necessary floor for a fixed positive rational, unconditionally. -/
theorem eventually_fixedPacking_upper {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      (fixedPackingNumber r N : ℤ) ≤ ⌊((targetStock r N : ℝ) - necessaryLoss N C) / (r : ℝ)⌋ := by
  obtain ⟨C, hC, hNecessary⟩ := eventually_packing_necessary (targetCutoff r)
  refine ⟨C, hC, ?_⟩
  filter_upwards [hNecessary, eventually_fixed_denominator_dvd r.den r.den_pos] with N hn hd
  obtain ⟨S, hPair, hS⟩ := exists_ordered_matching (edges 2 N r)
  have hAll (i : Fin (fixedPackingNumber r N)) :
      S i ⊆ interval (targetCutoff r) N ∧ mass (S i) = r ∧ r.den ∣ permittedDenominator N := by
    obtain ⟨hIn, hMass⟩ := mem_edges.mp (hS i)
    exact ⟨subset_target_interval hIn hMass, hMass, hd⟩
  have hBound := hn (fun _ : Fin (fixedPackingNumber r N) => r) S hPair hAll
  have hMass : (fixedPackingNumber r N : ℝ) * (r : ℝ) ≤
      (targetStock r N : ℝ) - necessaryLoss N C := by
    simp only [sum_const, card_univ, Fintype.card_fin, nsmul_eq_mul, Rat.cast_mul, Rat.cast_natCast] at hBound
    unfold targetStock necessaryLoss
    linarith only [hBound]
  apply Int.le_floor.mpr
  rw [Int.cast_natCast]
  apply (le_div_iff₀ (by exact_mod_cast hr : (0 : ℝ) < r)).mpr
  exact hMass

theorem eventually_boundedPacking_upper {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ K : ℕ,
      (boundedPackingNumber r K N : ℤ) ≤ ⌊((targetStock r N : ℝ) - necessaryLoss N C) / (r : ℝ)⌋ := by
  obtain ⟨C, hC, hBound⟩ := eventually_fixedPacking_upper hr
  refine ⟨C, hC, ?_⟩
  filter_upwards [hBound] with N hN K
  exact le_trans (by exact_mod_cast boundedPackingNumber_le r K N) hN

/-- The upper floor for integer reciprocal sums and disjoint unit packings. -/
theorem eventually_unit_and_integer_upper :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      (k N : ℤ) ≤ ⌊(mass (interval 1 N) : ℝ) - necessaryLoss N C⌋ ∧
      (h N : ℤ) ≤ ⌊(mass (interval 1 N) : ℝ) - necessaryLoss N C⌋ := by
  obtain ⟨C, hC, hNecessary⟩ := eventually_packing_necessary 1
  refine ⟨C, hC, ?_⟩
  filter_upwards [hNecessary] with N hn
  obtain ⟨S, hSub, hMass⟩ := (h_isGreatest N).1
  have hAll (i : Fin 1) :
      S ⊆ interval 1 N ∧ mass S = (h N : ℚ) ∧
        ((h N : ℕ) : ℚ).den ∣ permittedDenominator N := ⟨hSub, hMass, by simp⟩
  have hBound := hn (fun _ : Fin 1 => (h N : ℚ)) (fun _ => S)
    (fun _ _ hij => (hij (Subsingleton.elim _ _)).elim) hAll
  have hUpper : (h N : ℤ) ≤ ⌊(mass (interval 1 N) : ℝ) - necessaryLoss N C⌋ := by
    apply Int.le_floor.mpr
    rw [Int.cast_natCast]
    simp only [Fin.sum_univ_one, Rat.cast_natCast] at hBound
    unfold necessaryLoss
    linarith only [hBound]
  exact ⟨le_trans (by exact_mod_cast k_le_h N) hUpper, hUpper⟩

/-- Least height admitting j disjoint sets of exactly the fixed target. -/
noncomputable def fixedHeight (r : ℚ) (j : ℕ) (hExists : ∃ N, j ≤ fixedPackingNumber r N) : ℕ :=
  Nat.find hExists

/-- Least height admitting the exact integer j as a single reciprocal sum. -/
noncomputable def integerHeight (j : ℕ) (hExists : ∃ N, j ∈ representedIntegers N) : ℕ :=
  Nat.find hExists

theorem fixedHeight_spec (r : ℚ) (j : ℕ) (hExists : ∃ N, j ≤ fixedPackingNumber r N) :
    j ≤ fixedPackingNumber r (fixedHeight r j hExists) ∧
      ∀ M < fixedHeight r j hExists, fixedPackingNumber r M < j := by
  exact ⟨Nat.find_spec hExists, fun M hM => lt_of_not_ge (Nat.find_min hExists hM)⟩

theorem integerHeight_spec (j : ℕ) (hExists : ∃ N, j ∈ representedIntegers N) :
    j ∈ representedIntegers (integerHeight j hExists) ∧
      ∀ M < integerHeight j hExists, j ∉ representedIntegers M :=
  ⟨Nat.find_spec hExists, fun _ hM => Nat.find_min hExists hM⟩

/-- Exact adjacent-height comparison underlying the fixed-target inverse height
expansion. The upper packing bound is used at N and the lower bound at N−1. -/
theorem fixedHeight_adjacent {r : ℚ} (hr : 0 < r) {j : ℕ}
    (hExists : ∃ N, j ≤ fixedPackingNumber r N) (N : ℕ)
    (hN : N = fixedHeight r j hExists) (hCut : targetCutoff r ≤ N)
    (Cupper Clower : ℝ)
    (hUpper : (fixedPackingNumber r N : ℤ) ≤
      ⌊((targetStock r N : ℝ) - necessaryLoss N Cupper) / (r : ℝ)⌋)
    (hLower : ⌊((targetStock r (N - 1) : ℝ) - sufficientLoss (N - 1) Clower) / (r : ℝ)⌋ ≤
      (fixedPackingNumber r (N - 1) : ℤ)) :
    necessaryLoss N Cupper ≤ (targetStock r N : ℝ) - (r : ℝ) * j ∧
      (targetStock r N : ℝ) - (r : ℝ) * j < sufficientLoss (N - 1) Clower + 1 / (N : ℝ) := by
  have hr₀ : (0 : ℝ) < r := by exact_mod_cast hr
  have hj : (j : ℤ) ≤ (fixedPackingNumber r N : ℤ) := by
    rw [hN]
    exact_mod_cast (fixedHeight_spec r j hExists).1
  have hLeft := (Int.le_floor.mp (hj.trans hUpper))
  rw [Int.cast_natCast] at hLeft
  have hMass := (le_div_iff₀ hr₀).1 hLeft
  have hPrev : (fixedPackingNumber r (N - 1) : ℤ) < j := by
    exact_mod_cast (fixedHeight_spec r j hExists).2 (N - 1) (by
      rw [← hN]
      have hTwo := targetCutoff_ge_two r
      omega)
  have hRight := Int.floor_lt.mp (hLower.trans_lt hPrev)
  rw [Int.cast_natCast] at hRight
  have hMassPrev := (div_lt_iff₀ hr₀).1 hRight
  have hStep : (targetStock r N : ℝ) = 1 / (N : ℝ) + (targetStock r (N - 1) : ℝ) := by
    unfold targetStock
    rw [mass_interval_step_upper (by have := targetCutoff_ge_two r; omega) hCut,
      Rat.cast_add, Rat.cast_inv, Rat.cast_natCast, one_div]
  constructor
  · linarith only [hMass]
  · rw [hStep]
    linarith only [hMassPrev]


/-- The literal finite length expression of F2(i), in real arithmetic. -/
noncomputable def packingLength (N : ℕ) (C r R : ℝ) : ℝ :=
  (N : ℝ) * r / max R (Real.log (N : ℝ) / 2) + C * (N : ℝ) / (Real.log (N : ℝ)) ^ 2

/-- The sufficient side of F2 as an explicit premise. Its constants are
uniform over the finite nonempty list and over all permitted reduced denominators. -/
def PackingSufficiency : Prop :=
  ∀ (a A : ℝ) (d : ℕ), 0 < a → a ≤ A → 0 < d → 1 / (d : ℝ) < a →
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ {m : ℕ}, 0 < m → ∀ r : Fin m → ℚ,
      (∀ i, a ≤ (r i : ℝ) ∧ (r i : ℝ) ≤ A ∧ (r i).den ∣ permittedDenominator N) →
      ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) - sufficientLoss N C →
      ∃ S : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (S i) (S j)) ∧
        ∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧
          ((S i).card : ℝ) ≤ packingLength N C (r i : ℝ) ((∑ i, r i : ℚ) : ℝ)

/-- A finite equal-target instance of the sufficient packing conclusion. -/
def EqualTargetsAt (r : ℚ) (d N : ℕ) (C : ℝ) : Prop :=
  ∀ m : ℕ, 0 < m →
    (m : ℝ) * (r : ℝ) ≤ (mass (interval d N) : ℝ) - sufficientLoss N C →
    ∃ S : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (S i) (S j)) ∧
      ∀ i, S i ⊆ interval d N ∧ mass (S i) = r ∧
        ((S i).card : ℝ) ≤ packingLength N C (r : ℝ) ((m : ℝ) * (r : ℝ))

theorem eventually_equalTargetsAt_of_sufficiency (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) {d : ℕ} (hd : 0 < d) (hStrict : (d : ℚ)⁻¹ < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, EqualTargetsAt r d N C := by
  have hr' : (0 : ℝ) < r := by exact_mod_cast hr
  have hD : (1 : ℝ) / (d : ℝ) < r := by
    rw [one_div]
    simpa only [Rat.cast_inv, Rat.cast_natCast] using
      (show (((d : ℚ)⁻¹ : ℚ) : ℝ) < (r : ℝ) from Rat.cast_lt.mpr hStrict)
  obtain ⟨C, hC, hS⟩ := hSuff (r : ℝ) (r : ℝ) d hr' le_rfl hd hD
  refine ⟨C, hC, ?_⟩
  filter_upwards [hS, eventually_fixed_denominator_dvd r.den r.den_pos] with N hN hden
  intro m hm hMass
  have hsum : ((∑ _i : Fin m, r : ℚ) : ℝ) = (m : ℝ) * (r : ℝ) := by
    simp [nsmul_eq_mul]
  have h := hN hm (fun _ => r) (fun _ => ⟨le_rfl, le_rfl, hden⟩) (hsum ▸ hMass)
  simpa only [hsum] using h

private theorem eventually_boundary_or_strict_equalTargetsAt (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      (((targetCutoff r : ℕ) : ℚ)⁻¹ < r → EqualTargetsAt r (targetCutoff r) N C) ∧
      (((targetCutoff r : ℕ) : ℚ)⁻¹ = r → EqualTargetsAt r (targetCutoff r + 1) N C) := by
  have hd : 0 < targetCutoff r := (by decide : 0 < 2).trans_le (targetCutoff_ge_two r)
  rcases lt_or_eq_of_le (cutoff_reciprocal_le hr) with hStrict | hEq
  · obtain ⟨C, hC, hN⟩ := eventually_equalTargetsAt_of_sufficiency hSuff hr hd hStrict
    exact ⟨C, hC, hN.mono fun _ hN => ⟨fun _ => hN, fun h => (hStrict.ne h).elim⟩⟩
  · have hStrict : (((targetCutoff r + 1 : ℕ) : ℚ)⁻¹) < r := by
      calc
        _ < ((targetCutoff r : ℕ) : ℚ)⁻¹ :=
          inv_strictAnti₀ (Nat.cast_pos.mpr hd) (by exact_mod_cast Nat.lt_succ_self (targetCutoff r))
        _ = _ := hEq
    obtain ⟨C, hC, hN⟩ := eventually_equalTargetsAt_of_sufficiency hSuff hr (by omega) hStrict
    exact ⟨C, hC, hN.mono fun _ hN => ⟨fun h => (h.ne hEq).elim, fun _ => hN⟩⟩

private theorem exists_equal_matching_of_mass_fit {r : ℚ} (hr : 0 < r)
    {d N m : ℕ} {C : ℝ} (hSuff : EqualTargetsAt r d N C)
    (hMass : (m : ℝ) * (r : ℝ) ≤ (mass (interval d N) : ℝ) - sufficientLoss N C) :
    ∃ F, IsMatching (edges d N r) F ∧ F.card = m ∧
      ∀ S ∈ F, (S.card : ℝ) ≤ packingLength N C (r : ℝ) ((m : ℝ) * (r : ℝ)) := by
  by_cases hm : m = 0
  · exact ⟨∅, by simp [IsMatching], by simp [hm], by simp⟩
  · obtain ⟨S, hP, hS⟩ := hSuff m (Nat.pos_of_ne_zero hm) hMass
    have hn (i) : (S i).Nonempty :=
      nonempty_iff_ne_empty.mpr (fun h => hr.ne' (by simpa [h, mass] using (hS i).2.1.symm))
    obtain ⟨hF, hCard⟩ := ordered_image_matching S hP hn fun i => mem_edges.mpr
      ⟨(hS i).1, (hS i).2.1⟩
    exact ⟨_, hF, hCard, fun T hT => by
      obtain ⟨i, _, rfl⟩ := mem_image.mp hT
      exact (hS i).2.2⟩

/-- Actual finite families attaining a mass-feasible number of fixed targets,
including insertion of the boundary singleton. The length denominator uses m−1
so that it bounds the length in both branches. -/
theorem exists_fixed_matching_of_mass_fit {r : ℚ} (hr : 0 < r) {N m : ℕ}
    (hN : targetCutoff r ≤ N) {C : ℝ}
    (hStrict : (((targetCutoff r : ℕ) : ℚ)⁻¹ < r) → EqualTargetsAt r (targetCutoff r) N C)
    (hBoundary : (((targetCutoff r : ℕ) : ℚ)⁻¹ = r) → EqualTargetsAt r (targetCutoff r + 1) N C)
    (hMass : (m : ℝ) * (r : ℝ) ≤ (targetStock r N : ℝ) - sufficientLoss N C) :
    ∃ F, IsMatching (edges 2 N r) F ∧ F.card = m ∧ ∀ S ∈ F, (S.card : ℝ) ≤
      max 1 (packingLength N C (r : ℝ) (((m - 1 : ℕ) : ℝ) * (r : ℝ))) := by
  let d := targetCutoff r
  have hd : 0 < d := (by decide : 0 < 2).trans_le (targetCutoff_ge_two r)
  have hr' : (0 : ℝ) < r := by exact_mod_cast hr
  have hLog : 0 < Real.log (N : ℝ) := Real.log_pos (by
    have htwo := targetCutoff_ge_two r
    exact_mod_cast (by omega : 1 < N))
  rcases lt_or_eq_of_le (cutoff_reciprocal_le hr) with hlt | heq
  · obtain ⟨F, hF, hc, hLen⟩ := exists_equal_matching_of_mass_fit hr (hStrict hlt) hMass
    refine ⟨F, by simpa only [edges_eq_target_interval r N] using hF, hc, fun U hU => ?_⟩
    apply (hLen U hU).trans
    refine le_max_of_le_right ?_
    unfold packingLength
    apply add_le_add _ le_rfl
    apply div_le_div_of_nonneg_left (mul_nonneg (Nat.cast_nonneg N) hr'.le)
      ((show 0 < Real.log (N : ℝ) / 2 by linarith).trans_le (le_max_right _ _))
    exact max_le_max (mul_le_mul_of_nonneg_right (by exact_mod_cast Nat.sub_le m 1) hr'.le) le_rfl
  · by_cases hm : m = 0
    · exact ⟨∅, by simp [IsMatching], by simp [hm], by simp⟩
    have hStep : (targetStock r N : ℝ) = (r : ℝ) + (mass (interval (d + 1) N) : ℝ) := by
      have h := mass_interval_step_lower hd hN
      rw [heq] at h
      exact_mod_cast h
    have hmSplit : (m : ℝ) = ((m - 1 : ℕ) : ℝ) + 1 := by
      exact_mod_cast (by omega : m = (m - 1) + 1)
    have hMass' : ((m - 1 : ℕ) : ℝ) * (r : ℝ) ≤
        (mass (interval (d + 1) N) : ℝ) - sufficientLoss N C := by
      rw [hStep, hmSplit, add_mul, one_mul] at hMass
      linarith
    obtain ⟨F, hF, hc, hLen⟩ := exists_equal_matching_of_mass_fit hr (hBoundary heq) hMass'
    obtain ⟨hF', hc'⟩ := insert_singleton_matching hd hN heq hF
    refine ⟨insert {d} F, by simpa only [edges_eq_target_interval r N] using hF',
      hc'.trans (by omega), fun U hU => ?_⟩
    rcases mem_insert.mp hU with rfl | hU
    · simp
    · exact (hLen U hU).trans (le_max_right _ _)


/-- Conditional on F2(i), the lower floor is attained by an actual family
satisfying its exact finite length budget. -/
theorem eventually_fixed_matching_floor_of_sufficiency (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      let m := ⌊((targetStock r N : ℝ) - sufficientLoss N C) / (r : ℝ)⌋₊
      ∃ F, IsMatching (edges 2 N r) F ∧ F.card = m ∧
        ∀ S ∈ F, (S.card : ℝ) ≤
          max 1 (packingLength N C (r : ℝ) (((m - 1 : ℕ) : ℝ) * (r : ℝ))) := by
  obtain ⟨C, hC, hApp⟩ := eventually_boundary_or_strict_equalTargetsAt hSuff hr
  refine ⟨C, hC, ?_⟩
  filter_upwards [hApp, eventually_ge_atTop (targetCutoff r)] with N hCases hN
  let x := ((targetStock r N : ℝ) - sufficientLoss N C) / (r : ℝ)
  let m := ⌊x⌋₊
  change ∃ F, IsMatching (edges 2 N r) F ∧ F.card = m ∧
    ∀ S ∈ F, (S.card : ℝ) ≤ max 1 (packingLength N C (r : ℝ) (((m - 1 : ℕ) : ℝ) * (r : ℝ)))
  by_cases hm : m = 0
  · exact ⟨∅, by simp [IsMatching], by simp [hm], by simp⟩
  · have hx : 0 ≤ x := (Nat.pos_of_floor_pos (Nat.pos_of_ne_zero hm)).le
    have hFit := (le_div_iff₀ (by exact_mod_cast hr : (0 : ℝ) < r)).mp (Nat.floor_le hx)
    exact exists_fixed_matching_of_mass_fit hr hN hCases.1 hCases.2 hFit

theorem eventually_fixed_and_bounded_lower_of_sufficiency (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      let x := ((targetStock r N : ℝ) - sufficientLoss N C) / (r : ℝ)
      let m := ⌊x⌋₊
      ⌊x⌋ ≤ (fixedPackingNumber r N : ℤ) ∧
        ∀ K : ℕ, max 1 (packingLength N C (r : ℝ) (((m - 1 : ℕ) : ℝ) * (r : ℝ))) ≤ K →
          ⌊x⌋ ≤ (boundedPackingNumber r K N : ℤ) := by
  obtain ⟨C, hC, hLower⟩ := eventually_fixed_matching_floor_of_sufficiency hSuff hr
  refine ⟨C, hC, ?_⟩
  filter_upwards [hLower] with N hN
  obtain ⟨F, hF, hc, hLen⟩ := hN
  refine ⟨Int.toNat_le.mp ?_, fun K hK => Int.toNat_le.mp ?_⟩
  · rw [Int.floor_toNat, ← hc]
    exact (matchingNumber_spec (edges 2 N r)).2 ⟨F, hF, rfl⟩
  · rw [Int.floor_toNat, ← hc]
    refine (matchingNumber_spec (boundedEdges 2 N r K)).2 ⟨F, ⟨?_, hF.2⟩, rfl⟩
    intro S hS
    obtain ⟨hIn, hMass⟩ := mem_edges.mp (hF.1 hS)
    exact mem_boundedEdges.mpr ⟨hIn, hMass, by exact_mod_cast (hLen S hS).trans hK⟩

theorem eventually_unit_lower_of_sufficiency (hSuff : PackingSufficiency) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      ⌊(mass (interval 1 N) : ℝ) - sufficientLoss N C⌋ ≤ (k N : ℤ) := by
  obtain ⟨C, hC, hLower⟩ := eventually_fixed_and_bounded_lower_of_sufficiency hSuff (by norm_num : (0 : ℚ) < 1)
  have hTwo : targetCutoff 1 = 2 := by norm_num [targetCutoff]
  refine ⟨C, hC, ?_⟩
  filter_upwards [hLower, eventually_ge_atTop (1 : ℕ)] with N hN hN₁
  have hStock : (targetStock 1 N : ℝ) = (mass (interval 1 N) : ℝ) - 1 := by
    rw [targetStock_eq_harmonic_sub 1 (by simpa [hTwo] using hN₁),
      hTwo, Rat.cast_sub]
    norm_num [interval, mass]
  have hShift : (mass (interval 1 N) : ℝ) - sufficientLoss N C =
      (((targetStock 1 N : ℝ) - sufficientLoss N C) / (1 : ℚ)) + 1 := by
    rw [hStock]
    norm_num
    ring
  rw [hShift, Int.floor_add_one, k_eq_one_add_fixedPackingNumber_one hN₁, Nat.cast_add, Nat.cast_one]
  exact add_le_add hN.1 le_rfl

/-- The exact constraints needed to resolve a one-integer floor gap hold
eventually for any positive constants from the necessary and sufficient sides. -/
theorem eventually_losses_between_zero_one (Cminus Cplus : ℝ)
    (hMinus : 0 ≤ Cminus) (hPlus : 0 ≤ Cplus) :
    ∀ᶠ N : ℕ in atTop,
      0 < necessaryLoss N Cminus ∧ necessaryLoss N Cminus ≤ sufficientLoss N Cplus ∧
        sufficientLoss N Cplus < 1 := by
  have hL : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hU := Real.tendsto_log_atTop.comp hL
  let b : ℝ := 1 / (2 * (Cplus + 1))
  have hb : 0 < b := one_div_pos.mpr (by linarith)
  have hSmall := (isLittleO_log_rpow_rpow_atTop 2 (by norm_num : (0 : ℝ) < 1)).bound hb
  filter_upwards [hL.eventually_ge_atTop 1, hU.eventually_ge_atTop (2 * Cminus + 1),
    hL.eventually hSmall] with N hLN hUN hBound
  let L := Real.log (N : ℝ)
  let U := Real.log L
  have hLp : 0 < L := zero_lt_one.trans_le hLN
  change 2 * Cminus + 1 ≤ U at hUN
  have hU₁ : 1 ≤ U := by linarith only [hUN, hMinus]
  have hUp : 0 < U := zero_lt_one.trans_le hU₁
  have hLog : 0 ≤ Real.log U := Real.log_nonneg hU₁
  have hULog : Real.log U ≤ U := (Real.log_le_sub_one_of_pos hUp).trans (by linarith)
  have hRatio : U ^ (2 : ℕ) / L ≤ b := by
    apply (div_le_iff₀ hLp).mpr
    change ‖U ^ (2 : ℝ)‖ ≤ b * ‖L ^ (1 : ℝ)‖ at hBound
    rw [show U ^ (2 : ℝ) = U ^ (2 : ℕ) by exact Real.rpow_two U, Real.rpow_one,
      Real.norm_of_nonneg (sq_nonneg U), Real.norm_of_nonneg hLp.le] at hBound
    exact hBound
  change 0 < U ^ 2 / (2 * L) - Cminus * U / L ∧
    U ^ 2 / (2 * L) - Cminus * U / L ≤ U ^ 2 / (2 * L) + Cplus * U * Real.log U / L ∧
    U ^ 2 / (2 * L) + Cplus * U * Real.log U / L < 1
  constructor
  · rw [show U ^ 2 / (2 * L) - Cminus * U / L = U * (U - 2 * Cminus) / (2 * L) by
      field_simp]
    exact div_pos (mul_pos hUp (by linarith only [hUN])) (by positivity)
  · constructor
    · exact (sub_le_self _ (by positivity)).trans (le_add_of_nonneg_right (by positivity))
    · have hTerm := div_le_div_of_nonneg_right
        (mul_le_mul_of_nonneg_left hULog (mul_nonneg hPlus hUp.le)) hLp.le
      calc
        _ ≤ U ^ 2 / (2 * L) + Cplus * U * U / L := add_le_add le_rfl hTerm
        _ = (1 / 2 + Cplus) * (U ^ 2 / L) := by ring
        _ ≤ (1 / 2 + Cplus) * b := mul_le_mul_of_nonneg_left hRatio (by linarith)
        _ < 1 := by
          dsimp [b]
          rw [← mul_div_assoc, mul_one, div_lt_iff₀ (by linarith only [hPlus])]
          linarith only [hPlus]

/-- Conditional on F2(i), the one-integer floor gap yields exactly the F2
initial segment, and the unit maximum is one of the two adjacent integers. -/
theorem eventually_unit_and_integer_initial_segment_of_sufficiency (hSuff : PackingSufficiency) :
    ∃ Cminus Cplus : ℝ, 0 < Cminus ∧ 0 < Cplus ∧ ∀ᶠ N : ℕ in atTop,
      ⌊(mass (interval 1 N) : ℝ) - sufficientLoss N Cplus⌋ ≤ (k N : ℤ) ∧
      (h N : ℤ) ≤ ⌊(mass (interval 1 N) : ℝ) - necessaryLoss N Cminus⌋ ∧
      ((k N : ℤ) = ⌊(mass (interval 1 N) : ℝ)⌋ - 1 ∨
        (k N : ℤ) = ⌊(mass (interval 1 N) : ℝ)⌋) ∧
      representedIntegers N = range (h N + 1) := by
  obtain ⟨Cminus, hm, hUpper⟩ := eventually_unit_and_integer_upper
  obtain ⟨Cplus, hp, hLower⟩ := eventually_unit_lower_of_sufficiency hSuff
  refine ⟨Cminus, Cplus, hm, hp, ?_⟩
  filter_upwards [hUpper, hLower, eventually_losses_between_zero_one Cminus Cplus hm.le hp.le]
    with N hUp hLo hLoss
  let H := (mass (interval 1 N) : ℝ)
  have hLem : ⌊H⌋ - 1 ≤ (k N : ℤ) := by
    have hf : ⌊H⌋ - 1 = ⌊H - 1⌋ := by simp
    rw [hf]
    exact (Int.floor_mono (by dsimp [H]; linarith [hLoss.2.2] :
      H - 1 ≤ H - sufficientLoss N Cplus)).trans hLo
  have hUem : (k N : ℤ) ≤ ⌊H⌋ :=
    hUp.1.trans (Int.floor_mono (sub_le_self _ hLoss.1.le))
  have hUpperH : (h N : ℤ) ≤ ⌊H⌋ :=
    hUp.2.trans (Int.floor_mono (sub_le_self _ hLoss.1.le))
  have hCloseInt : (h N : ℤ) ≤ (k N : ℤ) + 1 := hUpperH.trans (by omega)
  have hClose : h N ≤ k N + 1 := by exact_mod_cast hCloseInt
  refine ⟨hLo, hUp.2, ?_, represented_initial_segment_if_close hClose⟩
  change (k N : ℤ) = ⌊H⌋ - 1 ∨ (k N : ℤ) = ⌊H⌋
  omega


theorem mass_interval_one_eq_harmonic (N : ℕ) : mass (interval 1 N) = harmonic N := by
  induction N with
  | zero => simp [interval, mass, harmonic]
  | succ N ih =>
    rw [mass_interval_step_upper (by decide : 0 < 1) (Nat.succ_pos N),
      Nat.succ_sub_one, ih, harmonic_succ]
    ring

/-- The exact centering constant for the available stock of a fixed target. -/
theorem tendsto_targetStock_sub_log (r : ℚ) :
    Tendsto (fun N : ℕ => (targetStock r N : ℝ) - Real.log (N : ℝ)) atTop
      (𝓝 (Real.eulerMascheroniConstant - (mass (interval 1 (targetCutoff r - 1)) : ℝ))) := by
  refine (Real.tendsto_harmonic_sub_log.sub_const
    (mass (interval 1 (targetCutoff r - 1)) : ℝ)).congr' ?_
  filter_upwards [eventually_ge_atTop (targetCutoff r - 1)] with N hN
  rw [targetStock_eq_harmonic_sub r hN, Rat.cast_sub, mass_interval_one_eq_harmonic N]
  ring

theorem eventually_abs_targetStock_sub_log_le (r : ℚ) :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ N : ℕ in atTop,
      |(targetStock r N : ℝ) - Real.log (N : ℝ)| ≤ D := by
  let c := Real.eulerMascheroniConstant - (mass (interval 1 (targetCutoff r - 1)) : ℝ)
  have h := tendsto_targetStock_sub_log r
  refine ⟨|c| + 1, by linarith [abs_nonneg c], ?_⟩
  filter_upwards [h.eventually (Ioi_mem_nhds (show c - 1 < c by linarith)),
    h.eventually_lt_const (show c < c + 1 by linarith)] with N hlo hhi
  change c - 1 < (targetStock r N : ℝ) - Real.log (N : ℝ) at hlo
  exact abs_le.mpr ⟨by linarith [neg_abs_le c], by linarith [le_abs_self c]⟩

theorem tendsto_fixedPackingNumber_of_sufficiency (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) :
    Tendsto (fixedPackingNumber r) atTop atTop := by
  have hr' : (0 : ℝ) < r := by exact_mod_cast hr
  obtain ⟨C, hc, hFloors⟩ := eventually_fixed_and_bounded_lower_of_sufficiency hSuff hr
  obtain ⟨D, _, hStock⟩ := eventually_abs_targetStock_sub_log_le r
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  refine tendsto_atTop.2 fun j => ?_
  filter_upwards [hFloors, hStock, eventually_losses_between_zero_one 0 C le_rfl hc.le,
    hLog.eventually_ge_atTop ((j : ℝ) * (r : ℝ) + D + 1)] with N hFloor hSt hLoss hLogN
  have hfit : (j : ℝ) * (r : ℝ) ≤ (targetStock r N : ℝ) - sufficientLoss N C := by
    linarith only [(abs_le.mp hSt).1, hLoss.2.2, hLogN]
  have hj : (j : ℤ) ≤ ⌊((targetStock r N : ℝ) - sufficientLoss N C) / (r : ℝ)⌋ :=
    Int.le_floor.mpr (by rw [Int.cast_natCast]; exact (le_div_iff₀ hr').mpr hfit)
  exact_mod_cast hj.trans hFloor.1

theorem exists_fixed_height_of_sufficiency (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) (j : ℕ) : ∃ N, j ≤ fixedPackingNumber r N :=
  ((tendsto_fixedPackingNumber_of_sufficiency hSuff hr).eventually_ge_atTop j).exists

theorem tendsto_fixedHeight (r : ℚ) (hExists : ∀ j : ℕ, ∃ N, j ≤ fixedPackingNumber r N) :
    Tendsto (fun j => fixedHeight r j (hExists j)) atTop atTop := by
  refine tendsto_atTop.2 fun x => ?_
  filter_upwards [eventually_ge_atTop (fixedPackingNumber r x + 1)] with j hj
  by_contra! hlt
  have hMax := (fixedHeight_spec r j (hExists j)).1.trans
    (fixedPackingNumber_mono r hlt.le)
  omega

/-- The least height of j disjoint unit-sum groups. -/
noncomputable def unitHeight (j : ℕ) (hExists : ∃ N, j ≤ k N) : ℕ :=
  Nat.find hExists

theorem unitHeight_spec (j : ℕ) (hExists : ∃ N, j ≤ k N) :
    j ≤ k (unitHeight j hExists) ∧ ∀ M < unitHeight j hExists, k M < j :=
  ⟨Nat.find_spec hExists, fun _ hM => lt_of_not_ge (Nat.find_min hExists hM)⟩

theorem exists_unit_height_of_sufficiency (hSuff : PackingSufficiency) (j : ℕ) :
    ∃ N, j ≤ k N := by
  have h := tendsto_fixedPackingNumber_of_sufficiency hSuff (by norm_num : (0 : ℚ) < 1)
  have H : ∀ᶠ N : ℕ in atTop, j ≤ k N := by
    filter_upwards [h.eventually_ge_atTop j, eventually_ge_atTop (1 : ℕ)] with N hj hN
    rw [k_eq_one_add_fixedPackingNumber_one hN]
    omega
  exact H.exists

theorem exists_integer_height_of_sufficiency (hSuff : PackingSufficiency) (j : ℕ) :
    ∃ N, j ∈ representedIntegers N := by
  obtain ⟨N, hN⟩ := exists_unit_height_of_sufficiency hSuff j
  exact ⟨N, integer_represented_of_le_k hN⟩

theorem integerHeight_le_unitHeight (j : ℕ)
    (hInteger : ∃ N, j ∈ representedIntegers N) (hUnit : ∃ N, j ≤ k N) :
    integerHeight j hInteger ≤ unitHeight j hUnit :=
  Nat.find_min' hInteger (integer_represented_of_le_k (unitHeight_spec j hUnit).1)


/-- For the exact number of groups from the lower floor, the finite length
budget is eventually bounded by rN/log N plus a uniform N/(log N)^2 term. -/
theorem eventually_fixed_length_scale {r : ℚ} (hr : 0 < r) (C : ℝ) (hC : 0 ≤ C) :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ N : ℕ in atTop,
      let m := ⌊((targetStock r N : ℝ) - sufficientLoss N C) / (r : ℝ)⌋₊
      max 1 (packingLength N C (r : ℝ) (((m - 1 : ℕ) : ℝ) * (r : ℝ))) ≤
        (r : ℝ) * (N : ℝ) / Real.log N + D * (N : ℝ) / (Real.log N) ^ 2 := by
  obtain ⟨D, hD, hSt⟩ := eventually_abs_targetStock_sub_log_le r
  have hr' : (0 : ℝ) < r := by exact_mod_cast hr
  let B : ℝ := D + 1 + 2 * (r : ℝ)
  have hB : 0 < B := by unfold B; linarith
  have hNat : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp hNat
  have hSmall := Real.isLittleO_log_id_atTop.bound hr'
  refine ⟨C + 2 * (r : ℝ) * B, by positivity, ?_⟩
  filter_upwards [hSt, eventually_losses_between_zero_one 0 C le_rfl hC,
    hLog.eventually_ge_atTop (2 * B), hNat.eventually hSmall] with N hStock hLoss hLogN hSmallN
  let L := Real.log (N : ℝ)
  let x := ((targetStock r N : ℝ) - sufficientLoss N C) / (r : ℝ)
  let m := ⌊x⌋₊
  change max 1 (packingLength N C (r : ℝ) (((m - 1 : ℕ) : ℝ) * (r : ℝ))) ≤
    (r : ℝ) * (N : ℝ) / L + (C + 2 * (r : ℝ) * B) * (N : ℝ) / L ^ 2
  change 2 * B ≤ L at hLogN
  have hLp : 0 < L := by linarith only [hLogN, hB]
  have hLB : 0 < L - B := by linarith only [hLogN, hB]
  have hFloor := Nat.lt_floor_add_one x
  change x < (m : ℝ) + 1 at hFloor
  have hPrev : (m : ℝ) ≤ ((m - 1 : ℕ) : ℝ) + 1 := by exact_mod_cast (show m ≤ m - 1 + 1 by omega)
  have hMassFlow := mul_lt_mul_of_pos_right
    (show x < ((m - 1 : ℕ) : ℝ) + 2 by linarith only [hFloor, hPrev]) hr'
  dsimp [x] at hMassFlow
  rw [div_mul_cancel₀ _ hr'.ne', add_mul] at hMassFlow
  have hMass : L - B ≤ ((m - 1 : ℕ) : ℝ) * (r : ℝ) := by
    dsimp only [B, L]
    linarith only [hMassFlow, (abs_le.mp hStock).1, hLoss.2.2]
  have hMain : (N : ℝ) * (r : ℝ) / max (((m - 1 : ℕ) : ℝ) * (r : ℝ)) (L / 2) ≤
      (r : ℝ) * (N : ℝ) / L + (2 * (r : ℝ) * B) * (N : ℝ) / L ^ 2 := calc
    _ ≤ (N : ℝ) * (r : ℝ) / (L - B) := div_le_div_of_nonneg_left
      (mul_nonneg (Nat.cast_nonneg N) hr'.le) hLB (hMass.trans (le_max_left _ _))
    _ = (r : ℝ) * (N : ℝ) / L + (r : ℝ) * (N : ℝ) * B / (L * (L - B)) := by
      field_simp [hLp.ne', hLB.ne']
      ring
    _ ≤ _ := by
      apply add_le_add le_rfl
      have hDen : L ^ 2 / 2 ≤ L * (L - B) := by
        have h := mul_le_mul_of_nonneg_left (show L / 2 ≤ L - B by linarith only [hLogN]) hLp.le
        nlinarith only [h]
      calc
        _ ≤ (r : ℝ) * (N : ℝ) * B / (L ^ 2 / 2) := div_le_div_of_nonneg_left
          (by positivity) (by positivity) hDen
        _ = _ := by rw [div_div_eq_mul_div]; ring
  apply max_le
  · have hLogSmall : L ≤ (r : ℝ) * (N : ℝ) := by
      change ‖L‖ ≤ (r : ℝ) * ‖(N : ℝ)‖ at hSmallN
      rw [Real.norm_of_nonneg hLp.le, Real.norm_of_nonneg (Nat.cast_nonneg N)] at hSmallN
      exact hSmallN
    have hOne : (1 : ℝ) ≤ (r : ℝ) * (N : ℝ) / L :=
      (le_div_iff₀ hLp).2 (by simpa only [one_mul] using hLogSmall)
    exact hOne.trans (le_add_of_nonneg_right (by positivity))
  · unfold packingLength
    change (N : ℝ) * (r : ℝ) / max (((m - 1 : ℕ) : ℝ) * (r : ℝ)) (L / 2) +
      C * (N : ℝ) / L ^ 2 ≤ _
    calc
      _ ≤ (r : ℝ) * (N : ℝ) / L + (2 * (r : ℝ) * B) * (N : ℝ) / L ^ 2 +
          C * (N : ℝ) / L ^ 2 := add_le_add hMain le_rfl
      _ = _ := by ring

/-- Conditional F2 lower floor for length-restricted matchings with the paper's
eventual rN/log N + O(N/(log N)^2) length threshold. -/
theorem eventually_boundedPacking_lower_with_length_of_sufficiency (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) :
    ∃ C D : ℝ, 0 < C ∧ 0 < D ∧ ∀ᶠ N : ℕ in atTop, ∀ K : ℕ,
      (r : ℝ) * (N : ℝ) / Real.log N + D * (N : ℝ) / (Real.log N) ^ 2 ≤ K →
        ⌊((targetStock r N : ℝ) - sufficientLoss N C) / (r : ℝ)⌋ ≤ (boundedPackingNumber r K N : ℤ) := by
  obtain ⟨C, hC, hBound⟩ := eventually_fixed_and_bounded_lower_of_sufficiency hSuff hr
  obtain ⟨D, hD, hLength⟩ := eventually_fixed_length_scale hr C hC.le
  refine ⟨C, D, hC, hD, ?_⟩
  filter_upwards [hBound, hLength] with N hN hL K hK
  exact hN.2 K (hL.trans hK)


/-- Both adjacent floors are available eventually at the actual least
fixed-target heights, conditional on F2(i). -/
theorem eventually_fixedHeight_adjacent_of_sufficiency (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) (hExists : ∀ j : ℕ, ∃ N, j ≤ fixedPackingNumber r N) :
    ∃ Cupper Clower : ℝ, 0 < Cupper ∧ 0 < Clower ∧ ∀ᶠ j : ℕ in atTop,
      let N := fixedHeight r j (hExists j)
      necessaryLoss N Cupper ≤ (targetStock r N : ℝ) - (r : ℝ) * j ∧
      (targetStock r N : ℝ) - (r : ℝ) * j < sufficientLoss (N - 1) Clower + 1 / (N : ℝ) := by
  obtain ⟨Cupper, hu, hUp⟩ := eventually_fixedPacking_upper hr
  obtain ⟨Clower, hl, hLo⟩ := eventually_fixed_and_bounded_lower_of_sufficiency hSuff hr
  have hH := tendsto_fixedHeight r hExists
  have hPrev : Tendsto (fun j => fixedHeight r j (hExists j) - 1) atTop atTop := by
    refine tendsto_atTop.2 fun x => ?_
    filter_upwards [hH.eventually_ge_atTop (x + 1)] with j hj
    change x + 1 ≤ fixedHeight r j (hExists j) at hj
    omega
  refine ⟨Cupper, Clower, hu, hl, ?_⟩
  filter_upwards [hH.eventually hUp, hPrev.eventually hLo,
    hH.eventually_ge_atTop (targetCutoff r)] with j hu' hl' hCut
  exact fixedHeight_adjacent hr (hExists j) (fixedHeight r j (hExists j)) rfl hCut Cupper Clower hu' hl'.1

theorem targetStock_log_error {r : ℚ} {N : ℕ} (hN : 0 < N) (hCut : targetCutoff r - 1 ≤ N) :
    let center := Real.eulerMascheroniConstant - (mass (interval 1 (targetCutoff r - 1)) : ℝ)
    0 ≤ (targetStock r N : ℝ) - Real.log (N : ℝ) - center ∧
      (targetStock r N : ℝ) - Real.log (N : ℝ) - center ≤ 1 / (N : ℝ) := by
  have hn' : (0 : ℝ) < N := Nat.cast_pos.mpr hN
  have hp : (0 : ℝ) < (N : ℝ) + 1 := by positivity
  have hLower : Real.eulerMascheroniConstant < (harmonic N : ℝ) - Real.log (N : ℝ) := by
    simpa only [Real.eulerMascheroniSeq', ite_eq_right hN.ne'] using
      Real.eulerMascheroniConstant_lt_eulerMascheroniSeq' N
  have hUpper : (harmonic N : ℝ) - Real.log ((N : ℝ) + 1) < Real.eulerMascheroniConstant := by
    simpa only [Real.eulerMascheroniSeq, Nat.cast_add, Nat.cast_one] using
      Real.eulerMascheroniSeq_lt_eulerMascheroniConstant N
  have hDiff : Real.log ((N : ℝ) + 1) - Real.log (N : ℝ) ≤ 1 / (N : ℝ) := calc
    _ = Real.log (((N : ℝ) + 1) / (N : ℝ)) := (Real.log_div hp.ne' hn'.ne').symm
    _ ≤ ((N : ℝ) + 1) / (N : ℝ) - 1 := Real.log_le_sub_one_of_pos (div_pos hp hn')
    _ = _ := by field_simp; ring
  change 0 ≤ (targetStock r N : ℝ) - Real.log N -
      (Real.eulerMascheroniConstant - (mass (interval 1 (targetCutoff r - 1)) : ℝ)) ∧ _
  rw [targetStock_eq_harmonic_sub r hCut, Rat.cast_sub, mass_interval_one_eq_harmonic N]
  constructor <;> linarith only [hLower, hUpper, hDiff]

noncomputable def heightMainCorrection (N : ℕ) : ℝ :=
  Real.log (Real.log (N : ℝ)) ^ 2 / (2 * Real.log (N : ℝ))

noncomputable def heightErrorScale (N : ℕ) : ℝ :=
  let L := Real.log (N : ℝ)
  let U := Real.log L
  U * Real.log U / L

private theorem log_predecessor_difference_le_one {N : ℕ} (hN : 2 ≤ N) :
    Real.log (N : ℝ) - Real.log ((N - 1 : ℕ) : ℝ) ≤ 1 := by
  have hNp : (0 : ℝ) < N := by exact_mod_cast (show 0 < N by omega)
  have hNprev : (0 : ℝ) < ((N - 1 : ℕ) : ℝ) := by exact_mod_cast (show 0 < N - 1 by omega)
  rw [← Real.log_div hNp.ne' hNprev.ne']
  refine (Real.log_le_sub_one_of_pos (div_pos hNp hNprev)).trans ?_
  have hh : (N : ℝ) / ((N - 1 : ℕ) : ℝ) ≤ 2 :=
    (div_le_iff₀ hNprev).2 (by exact_mod_cast (show N ≤ 2 * (N - 1) by omega))
  linarith

private theorem sufficientLoss_predecessor_le {N : ℕ} {C : ℝ}
    (hN : 2 ≤ N) (hL : 2 ≤ Real.log (N : ℝ))
    (hUPrev : 1 ≤ Real.log (Real.log ((N - 1 : ℕ) : ℝ)))
    (hLogU : 1 ≤ Real.log (Real.log (Real.log (N : ℝ)))) (hC : 0 ≤ C) :
    sufficientLoss (N - 1) C ≤ heightMainCorrection N + (1 + 2 * C) * heightErrorScale N := by
  let L := Real.log (N : ℝ)
  let V := Real.log ((N - 1 : ℕ) : ℝ)
  let U := Real.log L
  let W := Real.log V
  change 2 ≤ L at hL
  change 1 ≤ W at hUPrev
  change 1 ≤ Real.log U at hLogU
  have hL0 : 0 < L := by linarith only [hL]
  have hJump : L - V ≤ 1 := log_predecessor_difference_le_one hN
  have hHalf : L / 2 ≤ V := by linarith only [hL, hJump]
  have hV0 : 0 < V := (by positivity : 0 < L / 2).trans_le hHalf
  have hVL : V ≤ L := Real.log_le_log (by exact_mod_cast (show 0 < N - 1 by omega))
    (by exact_mod_cast Nat.sub_le N 1)
  have hWU : W ≤ U := Real.log_le_log hV0 hVL
  have hW0 : 0 ≤ W := zero_le_one.trans hUPrev
  have hU0 : 0 ≤ U := hW0.trans hWU
  have hUp : 0 < U := (zero_lt_one.trans_le hUPrev).trans_le hWU
  have hUL : U ≤ L := (Real.log_le_sub_one_of_pos hL0).trans (by linarith)
  have hLogW : Real.log W ≤ Real.log U :=
    Real.log_le_log (zero_lt_one.trans_le hUPrev) hWU
  have hLogW0 : 0 ≤ Real.log W := Real.log_nonneg hUPrev
  have hLogU0 : 0 ≤ Real.log U := zero_le_one.trans hLogU
  have hMain : W ^ 2 / (2 * V) ≤ U ^ 2 / (2 * L) + U * Real.log U / L := calc
    _ ≤ U ^ 2 / (2 * V) := div_le_div_of_nonneg_right (pow_le_pow_left₀ hW0 hWU _) (by positivity)
    _ = U ^ 2 / (2 * L) + U ^ 2 * (L - V) / (2 * V * L) := by
      field_simp [hV0.ne', hL0.ne']; ring
    _ ≤ _ := by
      apply add_le_add le_rfl
      have hD : L ^ 2 ≤ 2 * V * L := by
        have h := mul_le_mul_of_nonneg_right hHalf hL0.le
        nlinarith only [h]
      have hLogU' : U / L ≤ Real.log U :=
        (div_le_iff₀ hL0).2
          (hUL.trans (by simpa only [one_mul] using mul_le_mul_of_nonneg_right hLogU hL0.le))
      calc
        _ ≤ U ^ 2 / (2 * V * L) := div_le_div_of_nonneg_right
          (by simpa only [mul_one] using mul_le_mul_of_nonneg_left hJump (sq_nonneg U)) (by positivity)
        _ ≤ U ^ 2 / L ^ 2 := div_le_div_of_nonneg_left (sq_nonneg U) (by positivity) hD
        _ = (U / L) * (U / L) := by ring
        _ ≤ (U / L) * Real.log U := mul_le_mul_of_nonneg_left hLogU' (by positivity)
        _ = _ := by ring
  have hExtra : C * W * Real.log W / V ≤ 2 * C * (U * Real.log U / L) := calc
    _ ≤ C * U * Real.log U / V := div_le_div_of_nonneg_right
      (mul_le_mul (mul_le_mul_of_nonneg_left hWU hC) hLogW hLogW0 (by positivity)) hV0.le
    _ ≤ C * U * Real.log U / (L / 2) :=
      div_le_div_of_nonneg_left (by positivity) (by positivity) hHalf
    _ = _ := by rw [div_div_eq_mul_div]; ring
  change W ^ 2 / (2 * V) + C * W * Real.log W / V ≤
    U ^ 2 / (2 * L) + (1 + 2 * C) * (U * Real.log U / L)
  calc
    _ ≤ _ := add_le_add hMain hExtra
    _ = _ := by ring

/-- The leading inverse-height coefficient computed at the actual height.
Only the final change of scale from log N_j to rj remains. -/
theorem eventually_fixedHeight_height_scale_of_sufficiency (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) (hExists : ∀ j : ℕ, ∃ N, j ≤ fixedPackingNumber r N) :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ j : ℕ in atTop,
      let N := fixedHeight r j (hExists j)
      |Real.log (N : ℝ) - ((r : ℝ) * j +
        (mass (interval 1 (targetCutoff r - 1)) : ℝ) - Real.eulerMascheroniConstant +
        heightMainCorrection N)| ≤ D * heightErrorScale N := by
  obtain ⟨Cupper, Clower, hu, hl, hAdj⟩ := eventually_fixedHeight_adjacent_of_sufficiency hSuff hr hExists
  let S (j : ℕ) : ℕ := fixedHeight r j (hExists j)
  have hS := tendsto_fixedHeight r hExists
  have hPrev : Tendsto (fun j => S j - 1) atTop atTop := by
    refine tendsto_atTop.2 fun x => ?_
    filter_upwards [hS.eventually_ge_atTop (x + 1)] with j hj
    change x + 1 ≤ S j at hj
    omega
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hLog₂ : Tendsto (fun N : ℕ => Real.log (Real.log (N : ℝ))) atTop atTop :=
    Real.tendsto_log_atTop.comp hLog
  have hLog₃ : Tendsto (fun N : ℕ => Real.log (Real.log (Real.log (N : ℝ)))) atTop atTop :=
    Real.tendsto_log_atTop.comp hLog₂
  refine ⟨Cupper + 2 * Clower + 3, by positivity, ?_⟩
  filter_upwards [hAdj, hS.eventually_ge_atTop (max 2 (targetCutoff r)),
    (hLog.comp hS).eventually_ge_atTop 2, (hLog₂.comp hPrev).eventually_ge_atTop 1,
    (hLog₂.comp hS).eventually_ge_atTop 1, (hLog₃.comp hS).eventually_ge_atTop 1] with
    j hAdj hj hL hUPrev hU hLogU
  let N := S j
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let E := heightErrorScale N
  let A := heightMainCorrection N
  let H := (mass (interval 1 (targetCutoff r - 1)) : ℝ)
  change 2 ≤ L at hL
  change 1 ≤ U at hU
  change 1 ≤ Real.log U at hLogU
  change max 2 (targetCutoff r) ≤ N at hj
  have hN : 2 ≤ N := (le_max_left _ _).trans hj
  have hCut : targetCutoff r ≤ N := (le_max_right _ _).trans hj
  have hn : (0 : ℝ) < N := by exact_mod_cast (show 0 < N by omega)
  have hL0 : 0 < L := by linarith only [hL]
  have hU0 : 0 ≤ U := zero_le_one.trans hU
  have hErr0 : 0 ≤ E := div_nonneg (mul_nonneg hU0 (zero_le_one.trans hLogU)) hL0.le
  have hErrLarge : 1 / (N : ℝ) ≤ E := calc
    _ ≤ 1 / L := one_div_le_one_div_of_le hL0
      ((Real.log_le_sub_one_of_pos hn).trans (by linarith))
    _ ≤ _ := div_le_div_of_nonneg_right
      (by simpa only [one_mul] using mul_le_mul hU hLogU zero_le_one hU0) hL0.le
  have hNec : A - Cupper * E ≤ necessaryLoss N Cupper := by
    change A - Cupper * (U * Real.log U / L) ≤ A - Cupper * U / L
    have hTmp : Cupper * U ≤ Cupper * (U * Real.log U) := mul_le_mul_of_nonneg_left
      (by simpa only [mul_one] using mul_le_mul_of_nonneg_left hLogU hU0) hu.le
    have hDiv : Cupper * U / L ≤ Cupper * (U * Real.log U / L) := by
      rw [← mul_div_assoc]
      exact div_le_div_of_nonneg_right hTmp hL0.le
    linarith only [hDiv]
  have hSuffUp := sufficientLoss_predecessor_le hN hL hUPrev hLogU hl.le
  have hStock := targetStock_log_error (r := r) (N := N) (by omega) (by omega)
  change A - Cupper * E ≤ necessaryLoss N Cupper at hNec
  change _ ≤ A + (1 + 2 * Clower) * E at hSuffUp
  change necessaryLoss N Cupper ≤ (targetStock r N : ℝ) - (r : ℝ) * j ∧
    (targetStock r N : ℝ) - (r : ℝ) * j < sufficientLoss (N - 1) Clower + 1 / (N : ℝ) at hAdj
  change 0 ≤ (targetStock r N : ℝ) - L - (Real.eulerMascheroniConstant - H) ∧
    (targetStock r N : ℝ) - L - (Real.eulerMascheroniConstant - H) ≤ 1 / (N : ℝ) at hStock
  have hD₁ := mul_nonneg (by linarith only [hl] : 0 ≤ 2 * Clower + 2) hErr0
  have hD₂ := mul_nonneg (by linarith only [hu] : 0 ≤ Cupper + 1) hErr0
  change |L - ((r : ℝ) * j + H - Real.eulerMascheroniConstant + A)| ≤ _
  exact abs_le.mpr ⟨by nlinarith only [hNec, hAdj.1, hStock.2, hErrLarge, hD₁],
    by nlinarith only [hSuffUp, hAdj.2, hStock.1, hErrLarge, hD₂]⟩

private theorem inverse_correction_transfer {r x L D : ℝ} (hr : 0 < r) (hx : 0 < x)
    (hD : 0 ≤ D) (hClose : |L - r * x| ≤ D) (hSize : 2 * D ≤ r * x)
    (hV : 1 ≤ Real.log x) (hLogV : 1 ≤ Real.log (Real.log x))
    (hU : 1 ≤ Real.log L) :
    let K := |Real.log (r / 2)| + |Real.log (2 * r)|
    let J := Real.log x * Real.log (Real.log x) / x
    |Real.log L ^ 2 / (2 * L) - Real.log x ^ 2 / (2 * r * x)| ≤
      (K * (K + 2) / r + D / r ^ 2) * J ∧
    Real.log L * Real.log (Real.log L) / L ≤
      (2 / r * (K + 1) * (Real.log (K + 1) + 1)) * J := by
  let K := |Real.log (r / 2)| + |Real.log (2 * r)|
  let U := Real.log L
  let V := Real.log x
  let J := V * Real.log V / x
  change 1 ≤ U at hU
  change 1 ≤ V at hV
  change 1 ≤ Real.log V at hLogV
  change |U ^ 2 / (2 * L) - V ^ 2 / (2 * r * x)| ≤ (K * (K + 2) / r + D / r ^ 2) * J ∧
    U * Real.log U / L ≤ (2 / r * (K + 1) * (Real.log (K + 1) + 1)) * J
  have hU0 : 0 ≤ U := zero_le_one.trans hU
  have hV0 : 0 ≤ V := zero_le_one.trans hV
  have hLogU0 : 0 ≤ Real.log U := Real.log_nonneg hU
  have hLogV0 : 0 ≤ Real.log V := zero_le_one.trans hLogV
  have hK0 : 0 ≤ K := add_nonneg (abs_nonneg _) (abs_nonneg _)
  have hrx : 0 < r * x := mul_pos hr hx
  have hLo : r * x / 2 ≤ L := by linarith only [(abs_le.mp hClose).1, hSize]
  have hHi : L ≤ 2 * r * x := by linarith only [(abs_le.mp hClose).2, hSize, hrx]
  have hL : 0 < L := (by positivity : 0 < r * x / 2).trans_le hLo
  have hLoQ : r / 2 ≤ L / x :=
    (le_div_iff₀ hx).mpr (by rw [div_mul_eq_mul_div]; exact hLo)
  have hHiQ : L / x ≤ 2 * r := (div_le_iff₀ hx).mpr hHi
  have hAbs : |U - V| ≤ K := by
    change |Real.log L - Real.log x| ≤ K
    rw [← Real.log_div hL.ne' hx.ne']
    exact abs_le.mpr ⟨by
      have H := Real.log_le_log (show 0 < r / 2 by positivity) hLoQ
      unfold K
      linarith only [H, neg_abs_le (Real.log (r / 2)), abs_nonneg (Real.log (2 * r))],
      by
        have H := Real.log_le_log (div_pos hL hx) hHiQ
        unfold K
        linarith only [H, le_abs_self (Real.log (2 * r)), abs_nonneg (Real.log (r / 2))]⟩
  have hUV : U ≤ (K + 1) * V := by
    have hmul : K ≤ K * V := by
      simpa only [mul_one] using mul_le_mul_of_nonneg_left hV hK0
    nlinarith only [(abs_le.mp hAbs).2, hmul]
  have hJV : V / x ≤ J := by
    apply div_le_div_of_nonneg_right _ hx.le
    simpa only [mul_one] using mul_le_mul_of_nonneg_left hLogV hV0
  have hVx : V ≤ x := (Real.log_le_sub_one_of_pos hx).trans (sub_le_self _ zero_le_one)
  have hU2 : |U ^ 2 - V ^ 2| ≤ K * (K + 2) * V := by
    rw [show U ^ 2 - V ^ 2 = (U - V) * (U + V) by ring,
      abs_mul, abs_of_nonneg (add_nonneg hU0 hV0)]
    have hS : U + V ≤ (K + 2) * V := by nlinarith only [hUV]
    calc
      _ ≤ K * ((K + 2) * V) := mul_le_mul hAbs hS (add_nonneg hU0 hV0) hK0
      _ = _ := by ring
  have hTerm₁ : |(U ^ 2 - V ^ 2) / (2 * L)| ≤ K * (K + 2) / r * J := calc
    _ = |U ^ 2 - V ^ 2| / (2 * L) := by rw [abs_div, abs_of_pos (by positivity : 0 < 2 * L)]
    _ ≤ K * (K + 2) * V / (2 * L) := div_le_div_of_nonneg_right hU2 (by positivity)
    _ ≤ K * (K + 2) * V / (r * x) :=
      div_le_div_of_nonneg_left (by positivity) hrx (by linarith only [hLo])
    _ = K * (K + 2) / r * (V / x) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hJV (by positivity)
  have hTerm₂ : |V ^ 2 * (r * x - L) / (2 * L * r * x)| ≤ D / r ^ 2 * J := calc
    _ = V ^ 2 * |L - r * x| / (2 * L * r * x) := by
      rw [abs_div, abs_mul, abs_sub_comm (r * x), abs_of_nonneg (sq_nonneg V),
        abs_of_pos (by positivity : 0 < 2 * L * r * x)]
    _ ≤ V ^ 2 * D / (2 * L * r * x) :=
      div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hClose (sq_nonneg V)) (by positivity)
    _ ≤ V ^ 2 * D / (r * x) ^ 2 := by
      apply div_le_div_of_nonneg_left (by positivity) (by positivity)
      have h := mul_le_mul_of_nonneg_right (show r * x ≤ 2 * L by linarith only [hLo]) hrx.le
      nlinarith only [h]
    _ = D / r ^ 2 * ((V / x) * (V / x)) := by ring
    _ ≤ D / r ^ 2 * (V / x) := by
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      have h := mul_le_mul_of_nonneg_left ((div_le_one₀ hx).mpr hVx)
        (div_nonneg hV0 hx.le)
      simpa only [mul_one] using h
    _ ≤ _ := mul_le_mul_of_nonneg_left hJV (by positivity)
  constructor
  · rw [show U ^ 2 / (2 * L) - V ^ 2 / (2 * r * x) =
      (U ^ 2 - V ^ 2) / (2 * L) + V ^ 2 * (r * x - L) / (2 * L * r * x) by
        field_simp [hr.ne', hx.ne', hL.ne']; ring]
    calc
      _ ≤ _ := abs_add_le _ _
      _ ≤ _ := (add_le_add hTerm₁ hTerm₂).trans_eq (by ring)
  · have hK1 : 1 ≤ K + 1 := by linarith only [hK0]
    have hKlog := Real.log_nonneg hK1
    have hLBound : Real.log U ≤ (Real.log (K + 1) + 1) * Real.log V := calc
      _ ≤ Real.log ((K + 1) * V) := Real.log_le_log (zero_lt_one.trans_le hU) hUV
      _ = Real.log (K + 1) + Real.log V := by
        rw [Real.log_mul (by positivity : K + 1 ≠ 0) (zero_lt_one.trans_le hV).ne']
      _ ≤ _ := by
        have q := mul_le_mul_of_nonneg_left hLogV hKlog
        nlinarith only [q]
    calc
      _ ≤ ((K + 1) * V) * ((Real.log (K + 1) + 1) * Real.log V) / L :=
        div_le_div_of_nonneg_right (mul_le_mul hUV hLBound hLogU0 (by positivity)) hL.le
      _ ≤ ((K + 1) * V) * ((Real.log (K + 1) + 1) * Real.log V) / (r * x / 2) :=
        div_le_div_of_nonneg_left (by positivity) (by positivity) hLo
      _ = _ := by rw [div_div_eq_mul_div]; ring

/-- The full fixed-target inverse-height estimate of F2, conditional only on
its sufficient packing theorem. The main correction is written at j. -/
theorem eventually_fixedHeight_log_of_sufficiency (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) (hExists : ∀ j : ℕ, ∃ N, j ≤ fixedPackingNumber r N) :
    ∃ F : ℝ, 0 < F ∧ ∀ᶠ j : ℕ in atTop,
      let N := fixedHeight r j (hExists j)
      |Real.log (N : ℝ) - ((r : ℝ) * j +
        (mass (interval 1 (targetCutoff r - 1)) : ℝ) - Real.eulerMascheroniConstant +
        Real.log (j : ℝ) ^ 2 / (2 * (r : ℝ) * j))| ≤
        F * (Real.log (j : ℝ) * Real.log (Real.log (j : ℝ)) / (j : ℝ)) := by
  obtain ⟨B, hB, hHeight⟩ := eventually_fixedHeight_height_scale_of_sufficiency hSuff hr hExists
  have hr' : (0 : ℝ) < r := by exact_mod_cast hr
  let S (j : ℕ) := fixedHeight r j (hExists j)
  let c := (mass (interval 1 (targetCutoff r - 1)) : ℝ) - Real.eulerMascheroniConstant
  let D := B + |c| + 1
  let K := |Real.log ((r : ℝ) / 2)| + |Real.log (2 * (r : ℝ))|
  let Dmain := K * (K + 2) / (r : ℝ) + D / (r : ℝ) ^ 2
  let Derr := 2 / (r : ℝ) * (K + 1) * (Real.log (K + 1) + 1)
  have hD : 0 < D := by dsimp [D]; positivity
  have hK : 0 ≤ K := add_nonneg (abs_nonneg _) (abs_nonneg _)
  have hKlog : 0 ≤ Real.log (K + 1) := Real.log_nonneg (by linarith only [hK])
  have hS := tendsto_fixedHeight r hExists
  have hNat : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog : Tendsto (fun n : ℕ => Real.log (n : ℝ)) atTop atTop := Real.tendsto_log_atTop.comp hNat
  have hLog₂ : Tendsto (fun n : ℕ => Real.log (Real.log (n : ℝ))) atTop atTop :=
    Real.tendsto_log_atTop.comp hLog
  refine ⟨B * Derr + Dmain + 1, by dsimp [Derr, Dmain]; positivity, ?_⟩
  filter_upwards [hHeight, hS.eventually (eventually_losses_between_zero_one 0 1 le_rfl zero_le_one),
    hNat.eventually_ge_atTop (2 * D / (r : ℝ)), hLog.eventually_ge_atTop 1,
    hLog₂.eventually_ge_atTop 1, (hLog₂.comp hS).eventually_ge_atTop 1,
    eventually_ge_atTop (1 : ℕ)] with j hHeight hLoss hSize hV hLogV hU hj
  let N := S j
  let L := Real.log (N : ℝ)
  let A := heightMainCorrection N
  let E := heightErrorScale N
  let Y := L - ((r : ℝ) * j + (mass (interval 1 (targetCutoff r - 1)) : ℝ) -
    Real.eulerMascheroniConstant + A)
  let J := Real.log (j : ℝ) * Real.log (Real.log (j : ℝ)) / (j : ℝ)
  have hj' : (0 : ℝ) < j := by exact_mod_cast (show 0 < j by omega)
  have hJ : 0 ≤ J := div_nonneg (mul_nonneg (zero_le_one.trans hV) (zero_le_one.trans hLogV)) hj'.le
  change |Y| ≤ B * E at hHeight
  change 0 < necessaryLoss N 0 ∧ necessaryLoss N 0 ≤ sufficientLoss N 1 ∧
    sufficientLoss N 1 < 1 at hLoss
  have hAeq : necessaryLoss N 0 = A := by simp [necessaryLoss, A, heightMainCorrection]
  have hEeq : sufficientLoss N 1 = A + E := by simp [sufficientLoss, A, E, heightMainCorrection, heightErrorScale]
  rw [hAeq, hEeq] at hLoss
  have hBHeight : |Y| ≤ B := hHeight.trans (by
    simpa only [mul_one] using mul_le_mul_of_nonneg_left (show E ≤ 1 by linarith [hLoss.1, hLoss.2.2]) hB.le)
  have hClose : |L - (r : ℝ) * (j : ℝ)| ≤ D := by
    rw [show L - (r : ℝ) * (j : ℝ) = Y + c + A by dsimp [Y, c]; ring]
    calc
      _ ≤ (|Y| + |c|) + |A| := (abs_add_le _ _).trans (add_le_add (abs_add_le _ _) le_rfl)
      _ ≤ _ := add_le_add (add_le_add hBHeight le_rfl)
        (by rw [abs_of_nonneg hLoss.1.le]; linarith [hLoss.2.1, hLoss.2.2])
  have hjSize : 2 * D ≤ (r : ℝ) * (j : ℝ) := by
    simpa only [mul_comm (r : ℝ)] using (div_le_iff₀ hr').mp hSize
  have hTransfer := inverse_correction_transfer hr' hj' hD.le hClose hjSize hV hLogV hU
  let Bmain := Real.log (j : ℝ) ^ 2 / (2 * (r : ℝ) * (j : ℝ))
  have hMain : |A - Bmain| ≤ Dmain * J := hTransfer.1
  have hErr : E ≤ Derr * J := hTransfer.2
  change |L - ((r : ℝ) * j + (mass (interval 1 (targetCutoff r - 1)) : ℝ) -
    Real.eulerMascheroniConstant + Bmain)| ≤ (B * Derr + Dmain + 1) * J
  rw [show L - ((r : ℝ) * j + (mass (interval 1 (targetCutoff r - 1)) : ℝ) -
      Real.eulerMascheroniConstant + Bmain) = Y + (A - Bmain) by dsimp [Y, c]; ring]
  calc
    _ ≤ |Y| + |A - Bmain| := abs_add_le _ _
    _ ≤ B * (Derr * J) + Dmain * J := add_le_add (hHeight.trans (mul_le_mul_of_nonneg_left hErr hB.le)) hMain
    _ = (B * Derr + Dmain) * J := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_right (by linarith) hJ

end LeanAB.PaperB.FixedTargets
