module

public import PaperB.FixedTargets
public import Mathlib.Algebra.BigOperators.Fin
public import Mathlib.Data.Fin.Tuple.Basic
public import Mathlib.NumberTheory.Harmonic.Bounds
meta import Mathlib.Tactic

/-! Padding a finite target list by integer targets to reduce F2(i) to the high-total case. -/

@[expose] public section

namespace LeanAB.PaperB.FixedTargets

open Filter Finset
open scoped BigOperators Topology

/-- The least number of copies of a positive target that reaches the threshold. -/
theorem exists_padding_count {R T b : ℝ} (hR : R < T) (hb : 0 < b) :
    ∃ k : ℕ, 0 < k ∧ T ≤ R + (k : ℝ) * b ∧ R + (k : ℝ) * b < T + b ∧
      ∀ j : ℕ, j < k → R + (j : ℝ) * b < T := by
  let x := (T - R) / b
  have hx : 0 < x := div_pos (sub_pos.mpr hR) hb
  let k := ⌈x⌉₊
  have hLow : x ≤ (k : ℝ) := Nat.le_ceil x
  have hHigh : (k : ℝ) < x + 1 := Nat.ceil_lt_add_one hx.le
  have hxmul : x * b = T - R := div_mul_cancel₀ _ hb.ne'
  refine ⟨k, Nat.ceil_pos.mpr hx, ?_, ?_, ?_⟩
  · have h := mul_le_mul_of_nonneg_right hLow hb.le
    rw [hxmul] at h
    linarith only [h]
  · have h := mul_lt_mul_of_pos_right hHigh hb
    rw [add_mul, hxmul, one_mul] at h
    linarith only [h]
  · intro j hj
    have hjx : (j : ℝ) < x := by
      by_contra! h
      exact (not_le_of_gt hj) (Nat.ceil_le.mpr h)
    have h := mul_lt_mul_of_pos_right hjx hb
    rw [hxmul] at h
    linarith only [h]

/-- Append exactly k copies of the integer b after the original target indices. -/
def padTargets {m : ℕ} (r : Fin m → ℚ) (b k : ℕ) : Fin (m + k) → ℚ :=
  Fin.append r (fun _ : Fin k => (b : ℚ))

@[simp] theorem padTargets_left {m : ℕ} (r : Fin m → ℚ) (b k : ℕ) (i : Fin m) :
    padTargets r b k (Fin.castAdd k i) = r i :=
  Fin.append_left _ _ _

@[simp] theorem padTargets_right {m : ℕ} (r : Fin m → ℚ) (b k : ℕ) (i : Fin k) :
    padTargets r b k (Fin.natAdd m i) = (b : ℚ) :=
  Fin.append_right _ _ _

theorem padTargets_total {m : ℕ} (r : Fin m → ℚ) (b k : ℕ) :
    ((∑ i, padTargets r b k i : ℚ) : ℝ) = ((∑ i, r i : ℚ) : ℝ) + (k : ℝ) * b := by
  rw [Fin.sum_univ_add]
  simp [nsmul_eq_mul]

theorem padTargets_admissible {m N : ℕ} {a A : ℝ} {r : Fin m → ℚ} {b k : ℕ}
    (hr : ∀ i, a ≤ (r i : ℝ) ∧ (r i : ℝ) ≤ A ∧ (r i).den ∣ permittedDenominator N)
    (hb : a ≤ (b : ℝ)) :
    ∀ i, a ≤ (padTargets r b k i : ℝ) ∧
      (padTargets r b k i : ℝ) ≤ max A (b : ℝ) ∧
        (padTargets r b k i).den ∣ permittedDenominator N := by
  intro i
  refine Fin.addCases (fun j => ?_) (fun j => ?_) i
  · simpa only [padTargets_left] using
      ⟨(hr j).1, (hr j).2.1.trans (le_max_left A (b : ℝ)), (hr j).2.2⟩
  · simp only [padTargets_right, Rat.cast_natCast, Rat.den_natCast, one_dvd, and_true]
    exact ⟨hb, le_max_right A (b : ℝ)⟩

/-- The small padding overshoot is admissible for all sufficiently large heights. -/
theorem eventually_padding_room_of_lt_one (d b : ℕ) {loss : ℕ → ℝ}
    (hLoss : ∀ᶠ N : ℕ in atTop, loss N < 1) :
    ∀ᶠ N : ℕ in atTop,
      Real.log (N : ℝ) / 2 + (b : ℝ) ≤
        (mass (interval d N) : ℝ) - loss N := by
  let H : ℝ := mass (interval 1 (d - 1))
  have hL : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [eventually_ge_atTop (d - 1), hLoss,
    hL.eventually_ge_atTop (2 * ((b : ℝ) + H + 1))] with N hN hLoss hLarge
  have hUnion : interval d N ∪ interval 1 (d - 1) = interval 1 N := by
    ext a
    simp only [interval, mem_union, mem_Icc]
    omega
  have hDis : Disjoint (interval d N) (interval 1 (d - 1)) := by
    apply disjoint_left.mpr
    intro a ha hb
    simp only [interval, mem_Icc] at ha hb
    omega
  have hMass : mass (interval d N) + mass (interval 1 (d - 1)) = mass (interval 1 N) := by
    rw [← hUnion]
    exact (sum_union hDis).symm
  have hSplit : (mass (interval d N) : ℝ) + H = (mass (interval 1 N) : ℝ) := by
    dsimp only [H]
    exact_mod_cast hMass
  have hFull : Real.log (N : ℝ) ≤ (mass (interval 1 N) : ℝ) := by
    simpa only [Nat.floor_natCast, mass_interval_one_eq_harmonic] using
      log_le_harmonic_floor (N : ℝ) (by positivity)
  linarith only [hSplit, hFull, hLarge, hLoss]

theorem eventually_padding_room (d : ℕ) (_hd : 0 < d) (b : ℕ) (C : ℝ) (hC : 0 ≤ C) :
    ∀ᶠ N : ℕ in atTop,
      Real.log (N : ℝ) / 2 + (b : ℝ) ≤
        (mass (interval d N) : ℝ) - sufficientLoss N C :=
  eventually_padding_room_of_lt_one d b
    ((eventually_losses_between_zero_one 0 C le_rfl hC).mono fun _ h => h.2.2)


/-- Restricted sufficient side, with the original output and only the extra high-total premise. -/
def HighTotalPackingAtLoss (loss : ℕ → ℝ → ℝ) : Prop :=
  ∀ (a A : ℝ) (d : ℕ), 0 < a → a ≤ A → 0 < d → 1 / (d : ℝ) < a →
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ {m : ℕ}, 0 < m → ∀ r : Fin m → ℚ,
      (∀ i, a ≤ (r i : ℝ) ∧ (r i : ℝ) ≤ A ∧ (r i).den ∣ permittedDenominator N) →
      Real.log (N : ℝ) / 2 ≤ ((∑ i, r i : ℚ) : ℝ) →
      ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) - loss N C →
      ∃ S : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (S i) (S j)) ∧
        ∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧
          ((S i).card : ℝ) ≤ packingLength N C (r i : ℝ) ((∑ i, r i : ℚ) : ℝ)

/-- Simultaneous packing at a prescribed sufficient loss. -/
def PackingAtLoss (loss : ℕ → ℝ → ℝ) : Prop :=
  ∀ (a A : ℝ) (d : ℕ), 0 < a → a ≤ A → 0 < d → 1 / (d : ℝ) < a →
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ {m : ℕ}, 0 < m → ∀ r : Fin m → ℚ,
      (∀ i, a ≤ (r i : ℝ) ∧ (r i : ℝ) ≤ A ∧ (r i).den ∣ permittedDenominator N) →
      ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) - loss N C →
      ∃ S : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (S i) (S j)) ∧
        ∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧
          ((S i).card : ℝ) ≤ packingLength N C (r i : ℝ) ((∑ i, r i : ℚ) : ℝ)

def HighTotalPackingSufficiency : Prop := HighTotalPackingAtLoss sufficientLoss

theorem packingLength_antitone_total {N : ℕ} {C r R T : ℝ}
    (hL : 0 < Real.log (N : ℝ)) (hr : 0 ≤ r) (hRT : R ≤ T) :
    packingLength N C r T ≤ packingLength N C r R := by
  unfold packingLength
  apply add_le_add _ le_rfl
  exact div_le_div_of_nonneg_left (by positivity)
    ((half_pos hL).trans_le (le_max_right _ _)) (max_le_max hRT le_rfl)

/-- F2(i) follows from its high-total case with the same mass and length expressions. -/
theorem packingAtLoss_of_highTotal {loss : ℕ → ℝ → ℝ}
    (hLoss : ∀ C : ℝ, 0 ≤ C → ∀ᶠ N : ℕ in atTop, loss N C < 1)
    (hHigh : HighTotalPackingAtLoss loss) : PackingAtLoss loss := by
  intro a A d ha hA hd hda
  let b := ⌈a⌉₊
  have hb : a ≤ (b : ℝ) := Nat.le_ceil a
  have hbpos : 0 < (b : ℝ) := ha.trans_le hb
  obtain ⟨C, hC, h⟩ := hHigh a (max A (b : ℝ)) d ha
    (hA.trans (le_max_left _ _)) hd hda
  refine ⟨C, hC, ?_⟩
  have hL : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [h, eventually_padding_room_of_lt_one d b (hLoss C hC.le), hL.eventually_gt_atTop 0]
    with N hN hRoom hLog
  intro m hm r hr hMass
  let R : ℝ := ((∑ i, r i : ℚ) : ℝ)
  by_cases hlo : R < Real.log (N : ℝ) / 2
  · obtain ⟨k, _, hTop, hOvershoot, _⟩ := exists_padding_count hlo hbpos
    let t : Fin (m + k) → ℚ := padTargets r b k
    have hTotal : ((∑ i, t i : ℚ) : ℝ) = R + (k : ℝ) * b := padTargets_total r b k
    obtain ⟨S, hPair, hS⟩ := hN (by omega : 0 < m + k) t
      (padTargets_admissible hr hb) (hTotal ▸ hTop)
      (hTotal ▸ hOvershoot.le.trans hRoom)
    refine ⟨fun i => S (Fin.castAdd k i),
      fun i j hij => hPair (fun heq => hij (Fin.castAdd_injective m k heq)), fun i => ?_⟩
    obtain ⟨hSub, hEq, hCard⟩ := hS (Fin.castAdd k i)
    have hAt : t (Fin.castAdd k i) = r i := padTargets_left r b k i
    rw [hAt] at hEq hCard
    refine ⟨hSub, hEq, hCard.trans ?_⟩
    apply packingLength_antitone_total hLog (ha.le.trans (hr i).1)
    rw [hTotal]
    exact le_add_of_nonneg_right (by positivity)
  · exact hN hm r (fun i => ⟨(hr i).1, (hr i).2.1.trans (le_max_left _ _), (hr i).2.2⟩)
      (le_of_not_gt hlo) hMass

theorem packingSufficiency_of_highTotal (hHigh : HighTotalPackingSufficiency) :
    PackingSufficiency :=
  packingAtLoss_of_highTotal
    (fun C hC => (eventually_losses_between_zero_one 0 C le_rfl hC).mono fun _ h => h.2.2)
    hHigh


/-- Reducing to high-total lists is logically equivalent to the original sufficient side. -/
theorem packingSufficiency_iff_highTotal : PackingSufficiency ↔ HighTotalPackingSufficiency := by
  refine ⟨?_, packingSufficiency_of_highTotal⟩
  intro h a A d ha hA hd hda
  obtain ⟨C, hC, h⟩ := h a A d ha hA hd hda
  refine ⟨C, hC, h.mono ?_⟩
  intro N hN m hm r hr _ hMass
  exact hN hm r hr hMass

/-- The stock constraint also gives the uniform \(O_a(\log N)\) bound on group count. -/
theorem eventually_target_total_and_count_bound_of_mass_le (a : ℝ) (d : ℕ) (ha : 0 < a) :
    ∀ᶠ N : ℕ in atTop, ∀ {m : ℕ} (r : Fin m → ℚ),
      (∀ i, a ≤ (r i : ℝ)) →
      ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) →
      ((∑ i, r i : ℚ) : ℝ) ≤ Real.log (N : ℝ) + 1 ∧
        (m : ℝ) ≤ (2 / a) * Real.log (N : ℝ) := by
  have hL : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [hL.eventually_ge_atTop 1] with N hLog
  intro m r hr hMass
  have hSub : interval d N ⊆ interval 1 N := by
    intro n hn
    simp only [interval, mem_Icc] at hn ⊢
    omega
  have hMono : (mass (interval d N) : ℝ) ≤ (mass (interval 1 N) : ℝ) :=
    Rat.cast_le.mpr (mass_mono hSub)
  have hFull : (mass (interval 1 N) : ℝ) ≤ 1 + Real.log (N : ℝ) := by
    simpa only [mass_interval_one_eq_harmonic] using harmonic_le_one_add_log N
  have hTotal : ((∑ i, r i : ℚ) : ℝ) ≤ Real.log (N : ℝ) + 1 :=
    by linarith only [hMass, hMono, hFull]
  have hLower : (m : ℝ) * a ≤ ((∑ i, r i : ℚ) : ℝ) := by
    rw [Rat.cast_sum]
    simpa [nsmul_eq_mul] using
      (Finset.sum_le_sum (s := (univ : Finset (Fin m))) (fun i _ => hr i))
  refine ⟨hTotal, ?_⟩
  change 1 ≤ Real.log (N : ℝ) at hLog
  calc
    (m : ℝ) ≤ (2 * Real.log (N : ℝ)) / a := (le_div_iff₀ ha).mpr (by linarith only [hLog, hLower, hTotal])
    _ = (2 / a) * Real.log (N : ℝ) := by ring

theorem eventually_target_total_and_count_bound (a C : ℝ) (d : ℕ) (ha : 0 < a) (hC : 0 ≤ C) :
    ∀ᶠ N : ℕ in atTop, ∀ {m : ℕ} (r : Fin m → ℚ),
      (∀ i, a ≤ (r i : ℝ)) →
      ((∑ i, r i : ℚ) : ℝ) ≤ (mass (interval d N) : ℝ) - sufficientLoss N C →
      ((∑ i, r i : ℚ) : ℝ) ≤ Real.log (N : ℝ) + 1 ∧
        (m : ℝ) ≤ (2 / a) * Real.log (N : ℝ) := by
  filter_upwards [eventually_target_total_and_count_bound_of_mass_le a d ha,
    eventually_losses_between_zero_one 0 C le_rfl hC] with N h hLoss m r hr hm
  exact h r hr (hm.trans (sub_le_self _ (hLoss.1.le.trans hLoss.2.1)))

end LeanAB.PaperB.FixedTargets


namespace LeanAB.PaperB

/-- The sufficient loss in the next coefficient theorem of the frozen F2 draft. -/
noncomputable def nextSufficientLoss (N : ℕ) (C : ℝ) : ℝ :=
  let L := Real.log (N : ℝ)
  let U := Real.log L
  U ^ 2 / (2 * L) + U * Real.log U / L +
    U / L * (4 * Real.log (Real.log U) + C)

end LeanAB.PaperB
