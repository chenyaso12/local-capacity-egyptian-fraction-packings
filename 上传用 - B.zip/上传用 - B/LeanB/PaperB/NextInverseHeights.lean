module

public import PaperB.InverseHeights
public import PaperB.NextCapacityNecessary
public import PaperB.TargetPadding
meta import Mathlib.Tactic

/-! The next correction to the two inverse denominator heights. -/

@[expose] public section

open Filter
open scoped Topology

namespace LeanAB.PaperB

private noncomputable def correctionNumerator (u : ℝ) : ℝ :=
  u ^ 2 / 2 + u * Real.log u

private noncomputable def indexCorrection (x : ℝ) : ℝ :=
  correctionNumerator (Real.log x) / x

private noncomputable def indexError (x : ℝ) : ℝ :=
  Real.log x * Real.log (Real.log (Real.log x)) / x

private theorem abs_log_sub_le_abs_sub_of_one_le {x y : ℝ} (hx : 1 ≤ x) (hy : 1 ≤ y) :
    |Real.log x - Real.log y| ≤ |x - y| := by
  have hmain {a b : ℝ} (hb : 1 ≤ b) (hab : b ≤ a) :
      |Real.log a - Real.log b| ≤ |a - b| := by
    have hb₀ : 0 < b := zero_lt_one.trans_le hb
    have ha₀ : 0 < a := hb₀.trans_le hab
    have hlog := Real.log_le_log hb₀ hab
    rw [abs_of_nonneg (sub_nonneg.mpr hlog), abs_of_nonneg (sub_nonneg.mpr hab),
      ← Real.log_div ha₀.ne' hb₀.ne']
    calc
      _ ≤ a / b - 1 := Real.log_le_sub_one_of_pos (div_pos ha₀ hb₀)
      _ = (a - b) / b := by field_simp
      _ ≤ a - b := (div_le_iff₀ hb₀).mpr (le_mul_of_one_le_right (sub_nonneg.mpr hab) hb)
  rcases le_total y x with h | h
  · exact hmain hy h
  · rw [abs_sub_comm (Real.log x), abs_sub_comm x]
    exact hmain hx h

private theorem next_index_comparison {x L : ℝ} (hx : 8 ≤ x) (hClose : |L - x| ≤ 4)
    (hU : 1 ≤ Real.log L) (hV : 1 ≤ Real.log x)
    (hDeepU : 1 ≤ Real.log (Real.log (Real.log L)))
    (hDeepV : 1 ≤ Real.log (Real.log (Real.log x))) :
    |indexCorrection L - indexCorrection x| ≤ 26 * indexError x ∧
    indexError L ≤ 8 * indexError x := by
  let U := Real.log L
  let V := Real.log x
  change 1 ≤ U at hU
  change 1 ≤ V at hV
  change 1 ≤ Real.log (Real.log U) at hDeepU
  change 1 ≤ Real.log (Real.log V) at hDeepV
  have hx₀ : 0 < x := by linarith
  have hL₁ : x / 2 ≤ L := by linarith only [(abs_le.mp hClose).1, hx]
  have hL₂ : L ≤ 2 * x := by linarith only [(abs_le.mp hClose).2, hx]
  have hL₀ : 0 < L := (by positivity : 0 < x / 2).trans_le hL₁
  have hU₀ : 0 ≤ U := zero_le_one.trans hU
  have hV₀ : 0 ≤ V := zero_le_one.trans hV
  have hlog2 : Real.log 2 ≤ 1 := by
    linarith only [Real.log_le_sub_one_of_pos (show (0 : ℝ) < 2 by norm_num)]
  have hUV : |U - V| ≤ 1 := by
    dsimp only [U, V]
    rw [← Real.log_div hL₀.ne' hx₀.ne']
    have hmin : 1 / 2 ≤ L / x := (le_div_iff₀ hx₀).mpr (by convert hL₁ using 1; ring)
    have hmax : L / x ≤ 2 := (div_le_iff₀ hx₀).mpr hL₂
    have hlo := Real.log_le_log (show 0 < (1 / 2 : ℝ) by norm_num) hmin
    have hhi := Real.log_le_log (div_pos hL₀ hx₀) hmax
    rw [one_div, Real.log_inv] at hlo
    exact abs_le.mpr ⟨by linarith only [hlo, hlog2], hhi.trans hlog2⟩
  have huv := (abs_log_sub_le_abs_sub_of_one_le hU hV).trans hUV
  have hUle : U ≤ 2 * V := by linarith only [(abs_le.mp hUV).2,hV]
  have hLogU : 0 ≤ Real.log U := Real.log_nonneg hU
  have hLogV : 0 ≤ Real.log V := Real.log_nonneg hV
  have hVx : V ≤ x := (Real.log_le_sub_one_of_pos hx₀).trans (by linarith)
  have hLogUle : Real.log U ≤ 2 * V :=
    (Real.log_le_sub_one_of_pos (zero_lt_one.trans_le hU)).trans (by linarith)
  have hLogVle : Real.log V ≤ x :=
    (Real.log_le_sub_one_of_pos (zero_lt_one.trans_le hV)).trans (by linarith)
  have hHalf : |(U ^ 2 - V ^ 2) / 2| ≤ 3 * V / 2 := by
    rw [abs_div, abs_of_nonneg (by norm_num : (0 : ℝ) ≤ 2),
      show U ^ 2 - V ^ 2 = (U - V) * (U + V) by ring,
      abs_mul, abs_of_nonneg (add_nonneg hU₀ hV₀)]
    apply div_le_div_of_nonneg_right _ (by norm_num)
    have hSum : U + V ≤ 3 * V := by linarith only [hUle]
    simpa only [one_mul] using mul_le_mul hUV hSum (add_nonneg hU₀ hV₀) zero_le_one
  have hProd : |U * Real.log U - V * Real.log V| ≤ 3 * V := by
    rw [show U * Real.log U - V * Real.log V =
      (U - V) * Real.log U + V * (Real.log U - Real.log V) by ring]
    refine (abs_add_le _ _).trans ?_
    rw [abs_mul, abs_mul, abs_of_nonneg hLogU, abs_of_nonneg hV₀]
    have h₁ : |U - V| * Real.log U ≤ 2 * V := by
      simpa only [one_mul] using mul_le_mul hUV hLogUle hLogU zero_le_one
    have h₂ : V * |Real.log U - Real.log V| ≤ V := by
      simpa only [mul_one] using mul_le_mul_of_nonneg_left huv hV₀
    linarith only [h₁,h₂]
  have hNum : |correctionNumerator U - correctionNumerator V| ≤ 5 * V := by
    rw [show correctionNumerator U - correctionNumerator V =
      (U ^ 2 - V ^ 2) / 2 + (U * Real.log U - V * Real.log V) by
        unfold correctionNumerator; ring]
    exact (abs_add_le _ _).trans (by linarith only [hHalf,hProd,hV₀])
  have hFV₀ : 0 ≤ correctionNumerator V := by dsimp [correctionNumerator]; positivity
  have hFV : correctionNumerator V ≤ 2 * V * x := by
    unfold correctionNumerator
    nlinarith only [mul_le_mul_of_nonneg_left hVx hV₀,
      mul_le_mul_of_nonneg_left hLogVle hV₀, mul_nonneg hV₀ hx₀.le]
  have hTerm₁ : |(correctionNumerator U - correctionNumerator V) / L| ≤ 10 * (V / x) := calc
    _ = |correctionNumerator U - correctionNumerator V| / L :=
      by rw [abs_div, abs_of_pos hL₀]
    _ ≤ 5 * V / L := div_le_div_of_nonneg_right hNum hL₀.le
    _ ≤ 5 * V / (x / 2) := div_le_div_of_nonneg_left (by positivity) (by positivity) hL₁
    _ = _ := by ring
  have hTerm₂ : |correctionNumerator V * (x - L) / (L * x)| ≤ 16 * (V / x) := calc
    _ = correctionNumerator V * |L - x| / (L * x) := by
      rw [abs_div, abs_mul, abs_sub_comm x, abs_of_nonneg hFV₀, abs_of_pos (mul_pos hL₀ hx₀)]
    _ ≤ (2 * V * x) * 4 / (L * x) := div_le_div_of_nonneg_right
      (mul_le_mul hFV hClose (abs_nonneg _) (by positivity)) (by positivity)
    _ ≤ (2 * V * x) * 4 / ((x / 2) * x) :=
      div_le_div_of_nonneg_left (by positivity) (by positivity)
        (mul_le_mul_of_nonneg_right hL₁ hx₀.le)
    _ = _ := by field_simp; ring
  have hNarrow : V / x ≤ indexError x := by
    apply div_le_div_of_nonneg_right _ hx₀.le
    exact le_mul_of_one_le_right hV₀ hDeepV
  refine ⟨?_, ?_⟩
  · change |correctionNumerator U / L - correctionNumerator V / x| ≤ _
    rw [show correctionNumerator U / L - correctionNumerator V / x =
      (correctionNumerator U - correctionNumerator V) / L +
      correctionNumerator V * (x - L) / (L * x) by
        field_simp [hx₀.ne', hL₀.ne']; ring]
    apply (abs_add_le _ _).trans
    linarith only [hTerm₁, hTerm₂, hNarrow]
  · change U * Real.log (Real.log U) / L ≤ 8 * (V * Real.log (Real.log V) / x)
    have hBaseU : 1 ≤ Real.log U := by
      exact ((Real.log_pos_iff hLogU).mp (zero_lt_one.trans_le hDeepU)).le
    have hBaseV : 1 ≤ Real.log V := by
      exact ((Real.log_pos_iff hLogV).mp (zero_lt_one.trans_le hDeepV)).le
    have hDeep := (abs_log_sub_le_abs_sub_of_one_le hBaseU hBaseV).trans huv
    have hDeepLe : Real.log (Real.log U) ≤ 2 * Real.log (Real.log V) := by
      linarith only [(abs_le.mp hDeep).2, hDeepV]
    calc
      _ ≤ (2 * V) * (2 * Real.log (Real.log V)) / L :=
        div_le_div_of_nonneg_right
          (mul_le_mul hUle hDeepLe (zero_le_one.trans hDeepU) (by positivity)) hL₀.le
      _ ≤ (2 * V) * (2 * Real.log (Real.log V)) / (x / 2) :=
        div_le_div_of_nonneg_left (by positivity) (by positivity) hL₁
      _ = _ := by ring


private theorem log4_tendsto_nat :
    Tendsto (fun j : ℕ => Real.log (Real.log (Real.log (Real.log (j : ℝ))))) atTop atTop :=
  Real.tendsto_log_atTop.comp (Real.tendsto_log_atTop.comp
    (Real.tendsto_log_atTop.comp (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop)))

private theorem log3_tendsto_nat :
    Tendsto (fun j : ℕ => Real.log (Real.log (Real.log (j : ℝ)))) atTop atTop :=
  Real.tendsto_log_atTop.comp (Real.tendsto_log_atTop.comp
    (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop))

private theorem log2_tendsto_nat :
    Tendsto (fun j : ℕ => Real.log (Real.log (j : ℝ))) atTop atTop :=
  Real.tendsto_log_atTop.comp (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop)

private theorem next_index_at_height {f : ℕ → ℕ} (hf : Tendsto f atTop atTop)
    (hClose : ∀ᶠ j : ℕ in atTop, |Real.log (f j : ℝ) - j| ≤ 4) :
    ∀ᶠ j : ℕ in atTop,
      let L := Real.log (f j : ℝ)
      |indexCorrection L - indexCorrection j| ≤ 26 * indexError j ∧
        indexError L ≤ 8 * indexError j := by
  have hLog : Tendsto (fun j : ℕ => Real.log (j : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [hClose, eventually_ge_atTop (8 : ℕ), (log2_tendsto_nat.comp hf).eventually_ge_atTop 1,
    hLog.eventually_ge_atTop 1, (log4_tendsto_nat.comp hf).eventually_ge_atTop 1,
    log3_tendsto_nat.eventually_ge_atTop 1] with j hClose hj hU hV hDeepU hDeepV
  exact next_index_comparison (by exact_mod_cast hj) hClose hU hV hDeepU hDeepV

private theorem eventually_one_div_le_indexError :
    ∀ᶠ j : ℕ in atTop, 1 / (j : ℝ) ≤ indexError j := by
  have hLog : Tendsto (fun j : ℕ => Real.log (j : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [hLog.eventually_ge_atTop 1, log3_tendsto_nat.eventually_ge_atTop 1]
    with j hV hDeepV
  apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg _)
  simpa only [one_mul] using mul_le_mul hV hDeepV zero_le_one (zero_le_one.trans hV)

private theorem next_center_expansion {x : ℝ} (hx : x ≠ 0) :
    indexCorrection x = Real.log x ^ 2 / (2 * x) + Real.log x * Real.log (Real.log x) / x := by
  unfold indexCorrection correctionNumerator
  field_simp [hx]

private theorem next_inverse_lower {f : ℕ → ℕ} (hf : Tendsto f atTop atTop)
    (hIdx : ∀ j, j ≤ h (f j))
    (hClose : ∀ᶠ j : ℕ in atTop, |Real.log (f j : ℝ) - j| ≤ 4)
    {C : ℝ} (hC : 0 < C)
    (hNecessary : ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      let U := Real.log L
      U ^ 2 / (2 * L) + U * Real.log U / L - (U / L) *
        (2 * Real.log (Real.log (Real.log U)) + C) ≤
      (harmonic N : ℝ) - (capacity N : ℝ)) :
    ∀ᶠ j : ℕ in atTop,
      (j : ℝ) - Real.eulerMascheroniConstant + indexCorrection j -
        (43 + 8 * C) * indexError j ≤ Real.log (f j : ℝ) := by
  have hLog : Tendsto (fun j : ℕ => Real.log (j : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [hf.eventually hNecessary, next_index_at_height hf hClose,
    hf.eventually_ge_atTop (1 : ℕ), eventually_ge_atTop (1 : ℕ),
    (hLog.comp hf).eventually_ge_atTop 1, (log2_tendsto_nat.comp hf).eventually_ge_atTop 1,
    (log4_tendsto_nat.comp hf).eventually_ge_atTop 1, eventually_one_div_le_indexError]
    with j hNec hCmp hN hj hL hU hDeepU hOne
  let N := f j
  let L := Real.log (N : ℝ)
  let U := Real.log L
  have hL₀ : 0 < L := zero_lt_one.trans_le hL
  have hj₀ : 0 < j := Nat.succ_le_iff.mp hj
  have hN₀ : 0 < N := Nat.succ_le_iff.mp hN
  have hCapZ : (h N : ℤ) ≤ ⌊(capacity N : ℝ)⌋ := by exact_mod_cast h_le_floor_capacity N
  have hJZ : (j : ℤ) ≤ (h N : ℤ) := by exact_mod_cast hIdx j
  have hCap : (j : ℝ) ≤ (capacity N : ℝ) := by
    simpa only [Int.cast_natCast] using Int.le_floor.mp (hJZ.trans hCapZ)
  have hDeep : 1 ≤ Real.log (Real.log U) := hDeepU
  have hLogLe : Real.log (Real.log (Real.log U)) ≤ Real.log (Real.log U) :=
    (Real.log_le_sub_one_of_pos (zero_lt_one.trans_le hDeep)).trans (by linarith)
  have hVScale : 0 ≤ U / L := div_nonneg (zero_le_one.trans hU) hL₀.le
  have hPenalty : U / L * (2 * Real.log (Real.log (Real.log U)) + C) ≤
      (16 + 8 * C) * indexError j := calc
    _ ≤ U / L * ((2 + C) * Real.log (Real.log U)) := by
      apply mul_le_mul_of_nonneg_left _ hVScale
      nlinarith only [hLogLe, mul_le_mul_of_nonneg_left hDeep hC.le]
    _ = (2 + C) * indexError L := by dsimp [indexError, U]; ring
    _ ≤ (2 + C) * (8 * indexError j) :=
      mul_le_mul_of_nonneg_left hCmp.2 (by positivity)
    _ = _ := by ring
  have hMain := (abs_le.mp hCmp.1).1
  have hCenter := (harmonic_log_center hN₀).2
  have hRec := (reciprocal_height_le_inverse_index hj₀ (hIdx j)).trans hOne
  change U ^ 2 / (2 * L) + U * Real.log U / L - U / L *
    (2 * Real.log (Real.log (Real.log U)) + C) ≤
      (harmonic N : ℝ) - (capacity N : ℝ) at hNec
  rw [← next_center_expansion hL₀.ne'] at hNec
  change -(26 * indexError j) ≤ indexCorrection L - indexCorrection j at hMain
  change (j : ℝ) - Real.eulerMascheroniConstant + indexCorrection j -
    (43 + 8 * C) * indexError j ≤ L
  nlinarith only [hCap,hNec,hPenalty,hMain,hCenter,hRec]

private theorem unit_predecessor_log_close :
    ∀ᶠ j : ℕ in atTop, |Real.log ((unitInverseHeight j - 1 : ℕ) : ℝ) - (j : ℝ)| ≤ 4 := by
  filter_upwards [log_inverse_within_three,
    tendsto_unitInverseHeight.eventually_ge_atTop (2 : ℕ)] with j hC hN
  let N := unitInverseHeight j
  have hNp : (0 : ℝ) < ((N - 1 : ℕ) : ℝ) := by
    have hN' : 2 ≤ N := hN
    exact_mod_cast (show 0 < N - 1 by omega)
  have hGap := log_predecessor_gap_le_one hN
  have hMon := Real.log_le_log hNp (show ((N - 1 : ℕ) : ℝ) ≤ N by exact_mod_cast Nat.sub_le N 1)
  have hAbs := abs_le.mp hC.1
  exact abs_le.mpr ⟨by linarith only [hGap,hAbs.1], by linarith only [hMon,hAbs.2]⟩


/-- The next inverse-height coefficient on the necessary side holds for
both the least unit-packing height and the least integer height. -/
theorem eventually_next_inverse_heights_lower :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ j : ℕ in atTop,
      let V := Real.log (j : ℝ)
      let E := V * Real.log (Real.log V) / (j : ℝ)
      let A := (j : ℝ) - Real.eulerMascheroniConstant +
        V ^ 2 / (2 * (j : ℝ)) + V * Real.log V / (j : ℝ)
      A - C * E ≤ Real.log (unitInverseHeight j : ℝ) ∧
      A - C * E ≤ Real.log (integerInverseHeight j : ℝ) := by
  obtain ⟨C,hC,hNec⟩ := eventually_nextCapacity_deficit_lower
  have hUnit : ∀ᶠ j : ℕ in atTop, |Real.log (unitInverseHeight j : ℝ) - j| ≤ 4 :=
    log_inverse_within_three.mono fun _ h => h.1.trans (by norm_num)
  have hInt : ∀ᶠ j : ℕ in atTop, |Real.log (integerInverseHeight j : ℝ) - j| ≤ 4 :=
    log_inverse_within_three.mono fun _ h => h.2.trans (by norm_num)
  refine ⟨43 + 8 * C, by positivity, ?_⟩
  filter_upwards [next_inverse_lower tendsto_unitInverseHeight index_le_h_at_unit hUnit hC hNec,
    next_inverse_lower tendsto_integerInverseHeight index_le_h_at_integer hInt hC hNec,
    eventually_ge_atTop (1 : ℕ)] with j hN hT hj
  have hjR : (0 : ℝ) < j := by exact_mod_cast Nat.succ_le_iff.mp hj
  rw [next_center_expansion hjR.ne'] at hN hT
  dsimp only [indexError] at hN hT
  exact ⟨by linarith only [hN], by linarith only [hT]⟩

private theorem next_inverse_unit_upper {C : ℝ} (hC : 0 < C)
    (hCount : ∀ᶠ N : ℕ in atTop, ⌊(harmonic N : ℝ) - nextSufficientLoss N C⌋ ≤ (k N : ℤ)) :
    ∀ᶠ j : ℕ in atTop,
      Real.log (unitInverseHeight j : ℝ) ≤
        (j : ℝ) - Real.eulerMascheroniConstant + indexCorrection j + (59 + 8 * C) * indexError j := by
  have hLog : Tendsto (fun j : ℕ => Real.log (j : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [unitInverse_adjacent_upper hCount,
    next_index_at_height tendsto_unitInversePredecessor unit_predecessor_log_close,
    tendsto_unitInverseHeight.eventually_ge_atTop (1 : ℕ), eventually_ge_atTop (1 : ℕ),
    (hLog.comp tendsto_unitInversePredecessor).eventually_ge_atTop 1,
    (log2_tendsto_nat.comp tendsto_unitInversePredecessor).eventually_ge_atTop 1,
    (log4_tendsto_nat.comp tendsto_unitInversePredecessor).eventually_ge_atTop 1,
    eventually_one_div_le_indexError] with j hAdj hCmp hN hj hL hU hDeepU hOne
  let N := unitInverseHeight j
  let L := Real.log ((N - 1 : ℕ) : ℝ)
  let U := Real.log L
  have hL₀ : 0 < L := zero_lt_one.trans_le hL
  have hj₀ : 0 < j := Nat.succ_le_iff.mp hj
  have hN₀ : 0 < N := Nat.succ_le_iff.mp hN
  have hDeep : 1 ≤ Real.log (Real.log U) := hDeepU
  have hVScale : 0 ≤ U / L := div_nonneg (zero_le_one.trans hU) hL₀.le
  have hPenalty : U / L * (4 * Real.log (Real.log U) + C) ≤
      (32 + 8 * C) * indexError j := calc
    _ ≤ U / L * ((4 + C) * Real.log (Real.log U)) := by
      apply mul_le_mul_of_nonneg_left _ hVScale
      nlinarith only [mul_le_mul_of_nonneg_left hDeep hC.le]
    _ = (4 + C) * indexError L := by dsimp [indexError, U]; ring
    _ ≤ (4 + C) * (8 * indexError j) :=
      mul_le_mul_of_nonneg_left hCmp.2 (by positivity)
    _ = _ := by ring
  have hMain := (abs_le.mp hCmp.1).2
  have hCenter := (harmonic_log_center hN₀).1
  have hRec := (reciprocal_height_le_inverse_index hj₀ (index_le_h_at_unit j)).trans hOne
  change (harmonic N : ℝ) - j < nextSufficientLoss (N - 1) C + 1 / (N : ℝ) at hAdj
  change (harmonic N : ℝ) - j < U ^ 2 / (2 * L) + U * Real.log U / L +
    U / L * (4 * Real.log (Real.log U) + C) + 1 / (N : ℝ) at hAdj
  rw [← next_center_expansion hL₀.ne'] at hAdj
  change indexCorrection L - indexCorrection j ≤ 26 * indexError j at hMain
  nlinarith only [hAdj,hPenalty,hMain,hCenter,hRec]

/-- The sharp F2 count bound gives the full next logarithmic inverse-height
expansion simultaneously for unit packings and integer representations. -/
theorem eventually_next_inverse_heights_of_count
    (hCount : ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      ⌊(harmonic N : ℝ) - nextSufficientLoss N C⌋ ≤ (k N : ℤ)) :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ j : ℕ in atTop,
      let V := Real.log (j : ℝ)
      let E := V * Real.log (Real.log V) / (j : ℝ)
      let A := (j : ℝ) - Real.eulerMascheroniConstant +
        V ^ 2 / (2 * (j : ℝ)) + V * Real.log V / (j : ℝ)
      |Real.log (unitInverseHeight j : ℝ) - A| ≤ D * E ∧
      |Real.log (integerInverseHeight j : ℝ) - A| ≤ D * E := by
  obtain ⟨C,hC,hCount⟩ := hCount
  obtain ⟨B,hB,hLower⟩ := eventually_next_inverse_heights_lower
  let D := B + 59 + 8 * C
  refine ⟨D, by dsimp [D]; positivity, ?_⟩
  filter_upwards [next_inverse_unit_upper hC hCount, hLower, eventually_one_div_le_indexError,
    tendsto_integerInverseHeight.eventually_ge_atTop (1 : ℕ),
    eventually_ge_atTop (1 : ℕ)] with j hUnit hLow hOne hT hj
  let N := unitInverseHeight j
  let T := integerInverseHeight j
  let V := Real.log (j : ℝ)
  let E := indexError j
  let A := (j : ℝ) - Real.eulerMascheroniConstant +
    V ^ 2 / (2 * (j : ℝ)) + V * Real.log V / (j : ℝ)
  have hjR : (0 : ℝ) < j := by exact_mod_cast Nat.succ_le_iff.mp hj
  have hT₀ : 0 < T := Nat.succ_le_iff.mp hT
  have hE : 0 ≤ E := (by positivity : 0 ≤ 1 / (j : ℝ)).trans hOne
  have hTN : Real.log (T : ℝ) ≤ Real.log (N : ℝ) :=
    Real.log_le_log (Nat.cast_pos.mpr hT₀) (by exact_mod_cast integerInverseHeight_le_unitInverseHeight j)
  have hUpper : Real.log (N : ℝ) ≤ A + (59 + 8 * C) * E := by
    rw [next_center_expansion hjR.ne'] at hUnit
    dsimp only [A, V, E, N]
    linarith only [hUnit]
  have hB₁ : B * E ≤ D * E :=
    mul_le_mul_of_nonneg_right (by dsimp [D]; linarith only [hC]) hE
  have hC₁ : (59 + 8 * C) * E ≤ D * E :=
    mul_le_mul_of_nonneg_right (by dsimp [D]; linarith only [hB]) hE
  change A - B * E ≤ Real.log (N : ℝ) ∧ A - B * E ≤ Real.log (T : ℝ) at hLow
  change |Real.log (N : ℝ) - A| ≤ D * E ∧ |Real.log (T : ℝ) - A| ≤ D * E
  exact ⟨abs_le.mpr ⟨by linarith only [hLow.1,hB₁], by linarith only [hUpper,hC₁]⟩,
    abs_le.mpr ⟨by linarith only [hLow.2,hB₁], by linarith only [hUpper,hC₁,hTN]⟩⟩


/-- The next-loss packing theorem, applied to unit targets above \(1\), gives
the sharp unit count after reinstating the singleton at \(1\). -/
theorem eventually_unit_lower_of_nextPacking (hSuff : FixedTargets.PackingAtLoss nextSufficientLoss) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      ⌊(harmonic N : ℝ) - nextSufficientLoss N C⌋ ≤ (k N : ℤ) := by
  obtain ⟨C,hC,hPacking⟩ := hSuff 1 1 2 (by norm_num) le_rfl (by norm_num) (by norm_num)
  refine ⟨C,hC,?_⟩
  filter_upwards [hPacking, eventually_ge_atTop (1 : ℕ)] with N hP hN
  let A := (mass (interval 2 N) : ℝ) - nextSufficientLoss N C
  let m := ⌊A⌋
  have hTwo : FixedTargets.targetCutoff 1 = 2 := by norm_num [FixedTargets.targetCutoff]
  have hStock : (mass (interval 2 N) : ℝ) = (harmonic N : ℝ) - 1 := by
    have h := FixedTargets.targetStock_eq_harmonic_sub 1 (by simpa [hTwo] using hN)
    rw [FixedTargets.targetStock, hTwo] at h
    rw [h, Rat.cast_sub, FixedTargets.mass_interval_one_eq_harmonic N]
    norm_num [interval, mass]
  have hShift : (harmonic N : ℝ) - nextSufficientLoss N C = A + 1 := by
    dsimp [A]
    linarith only [hStock]
  rw [hShift, Int.floor_add_one, FixedTargets.k_eq_one_add_fixedPackingNumber_one hN,
    Nat.cast_add, Nat.cast_one]
  apply add_le_add_left _ 1
  change m ≤ (FixedTargets.fixedPackingNumber 1 N : ℤ)
  by_cases hm : 0 < m
  · let j := m.toNat
    have hj' : (j : ℤ) = m := Int.toNat_of_nonneg hm.le
    have hj : 0 < j := by omega
    have hMass : ((∑ _ : Fin j, (1 : ℚ) : ℚ) : ℝ) ≤ A := calc
      _ = (j : ℝ) := by simp
      _ = (m : ℝ) := by exact_mod_cast hj'
      _ ≤ A := Int.floor_le A
    obtain ⟨S,hPair,hS⟩ := hP hj (fun _ => 1) (by intro i; norm_num) hMass
    have hJ : j ≤ FixedTargets.fixedPackingNumber 1 N := by
      apply FixedTargets.le_matchingNumber_of_ordered (E := FixedTargets.edges 2 N 1) S hPair
      · intro i
        by_contra hi
        have h := (hS i).2.1
        rw [Finset.not_nonempty_iff_eq_empty.mp hi] at h
        norm_num [mass] at h
      · intro i
        exact FixedTargets.mem_edges.mpr ⟨(hS i).1,(hS i).2.1⟩
    rw [← hj']
    exact_mod_cast hJ
  · exact (le_of_not_gt hm).trans (Int.natCast_nonneg _)

/-- The complete F2 next inverse-height expansion follows directly from the
next-loss packing theorem. -/
theorem eventually_next_inverse_heights_of_nextPacking
    (hSuff : FixedTargets.PackingAtLoss nextSufficientLoss) :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ j : ℕ in atTop,
      let V := Real.log (j : ℝ)
      let E := V * Real.log (Real.log V) / (j : ℝ)
      let A := (j : ℝ) - Real.eulerMascheroniConstant +
        V ^ 2 / (2 * (j : ℝ)) + V * Real.log V / (j : ℝ)
      |Real.log (unitInverseHeight j : ℝ) - A| ≤ D * E ∧
      |Real.log (integerInverseHeight j : ℝ) - A| ≤ D * E :=
  eventually_next_inverse_heights_of_count (eventually_unit_lower_of_nextPacking hSuff)

end LeanAB.PaperB
