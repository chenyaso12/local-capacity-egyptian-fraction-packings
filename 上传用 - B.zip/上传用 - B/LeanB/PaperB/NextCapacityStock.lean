module

public import PaperB.BaselineStock
public import PaperB.BadPrimeMass
public import PaperB.NextCapacityCutoff
public import PaperB.NextCapacityLoss
meta import Mathlib.Tactic

/-! The corrected stock at the F2 next-capacity cutoff. -/

public section

namespace LeanAB.PaperB.Baseline

open Filter Finset Closure NearCapacity
open scoped Topology

private theorem repairExclusions_union_bad_subset (d N Q : ℕ) (M S R : Finset ℕ) :
    repairExclusions d N (smoothCutoff N) (M ∪ badCoverPrimes N Q) S R ⊆
      repairExclusions d N (smoothCutoff N) M S R ∪ badCoverPart N Q := by
  classical
  intro n hn
  simp only [repairExclusions, mem_union, mem_biUnion, primePart, mem_filter] at hn
  simp only [repairExclusions, badCoverPart, mem_union, mem_biUnion, primePart, mem_filter]
  rcases hn with ((⟨p,hp,hn,hd⟩ | ⟨p,hp,hn,hd⟩) | hs) | hr
  · exact Or.inl (Or.inl (Or.inl (Or.inl ⟨p,hp,hn,hd⟩)))
  · rcases hp with hp | hp
    · exact Or.inl (Or.inl (Or.inl (Or.inr ⟨p,hp,hn,hd⟩)))
    · obtain ⟨hnLo,hnHi⟩ := mem_Icc.mp hn
      exact Or.inr ⟨p,hp,mem_Icc.mpr ⟨(le_max_left _ _).trans hnLo,hnHi⟩,hd⟩
  · exact Or.inl (Or.inl (Or.inr hs))
  · exact Or.inl (Or.inr hr)

private theorem mediumPrimes_union_bad_eq (N Q z : ℕ) (M : Finset ℕ) :
    mediumPrimes N z (M ∪ badCoverPrimes N Q) = mediumPrimes N z M := by
  ext p
  rw [mem_mediumPrimes, mem_mediumPrimes]
  constructor
  · rintro ⟨hp,hSq,hz,hM⟩
    exact ⟨hp,hSq,hz,fun h => hM (mem_union_left _ h)⟩
  · rintro ⟨hp,hSq,hz,hM⟩
    refine ⟨hp,hSq,hz,fun h => (mem_union.mp h).elim hM ?_⟩
    intro h
    exact (mem_largePrimes.mp (mem_badCoverPrimes.mp h).1).2.2.not_ge hSq

/-- Average reciprocal covers give the manuscript's next-order stock loss
for every fixed lower endpoint and repair-pool budget. -/
theorem hasRetainedBlockMass_of_averageCover :
    ∃ K : ℝ, 0 < K ∧ HasRetainedBlockMass (nextCoverBound K)
      (fun N => badCoverPrimes N (nextCoverBound K N)) nextSufficientLoss := by
  obtain ⟨K,hK,hBadMass⟩ := eventually_badCoverPart_mass_le
  refine ⟨K,hK,?_⟩
  intro d E hE
  obtain ⟨T,hT,hTail⟩ := eventually_nextCutoffPart_mass hK d
  let C : ℝ := T + E + 1 + 2076
  have hC : 0 < C := by dsimp only [C]; positivity
  refine ⟨C,hC,?_⟩
  have hGeo := eventually_nextCutoff_geometry hK
  have hWidth : ∀ᶠ N : ℕ in atTop, 0 < nextCoverBound K N ∧
      Real.sqrt N < (N : ℝ) / nextCoverBound K N ∧ nextCoverBound K N ≤
        2 * ⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ := by
    filter_upwards [hGeo] with N hN
    obtain ⟨hQ,hMax,hZ,_,_⟩ := hN
    exact ⟨hQ,hZ,hMax⟩
  have hCover : ∀ᶠ N : ℕ in atTop, ∀ p ∈ largePrimes N,
      (p : ℝ) ≤ (N : ℝ) / nextCoverBound K N → p ∉ badCoverPrimes N (nextCoverBound K N) →
      CoversResidues p (interval 1 (nextCoverBound K N)) := by
    exact Eventually.of_forall fun N p hp _ he => Classical.byContradiction fun h =>
      he (mem_badCoverPrimes.mpr ⟨hp,h⟩)
  have hChargeWidth : ∀ᶠ N : ℕ in atTop, 0 < nextCoverBound K N ∧
      Real.sqrt N < (N : ℝ) / nextCoverBound K N ∧
      Real.log (nextCoverBound K N : ℝ) ≤ 2 * Real.log (Real.log (N : ℝ)) ∧
      2 * Real.log (nextCoverBound K N : ℝ) ≤ Real.log (N : ℝ) := by
    filter_upwards [hGeo] with N hN
    obtain ⟨hQ,_,hZ,hL,hU⟩ := hN
    refine ⟨hQ,hZ,hU,?_⟩
    change Real.log (N : ℝ) - Real.log (nextCoverBound K N : ℝ) ≥ Real.log (N : ℝ) / 2 at hL
    linarith only [hL]
  have hCast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hL := Real.tendsto_log_atTop.comp hCast
  have hU := Real.tendsto_log_atTop.comp hL
  filter_upwards [eventually_retainedBlocks_at_width d (nextCoverBound K)
      (fun N => badCoverPrimes N (nextCoverBound K N)) hWidth hCover,
    eventually_correctionCharge_le_at_width (nextCoverBound K) hChargeWidth,
    hTail, hBadMass, eventually_nextSufficientLoss_nonneg_lt_one C hC.le,
    hL.eventually_ge_atTop 1, hU.eventually_ge_atTop 1]
    with N hRetained hCharge hTailN hBadMassN hLossN hL1 hU1
  intro M S R hM hS hR hBudget
  classical
  let Q := nextCoverBound K N
  let D := badCoverPrimes N Q
  let M' := M ∪ D
  let Z := nextCutoff K N
  let L := Real.log (N : ℝ)
  let U := Real.log L
  change 1 ≤ L at hL1
  change 1 ≤ U at hU1
  have hLp : 0 < L := zero_lt_one.trans_le hL1
  have hRatio : 0 ≤ U / L := div_nonneg (zero_le_one.trans hU1) hLp.le
  have hZ : 0 ≤ Z := div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg Q)
  have hM' : ∀ p ∈ M', p.Prime ∧ Nat.sqrt N < p := by
    intro p hp
    rcases mem_union.mp hp with hOld | hBad
    · exact hM p hOld
    · obtain ⟨hp,_,hSq⟩ := mem_largePrimes.mp (mem_badCoverPrimes.mp hBad).1
      exact ⟨hp,hSq⟩
  have hS' : ∀ n ∈ S, ∃ q ∈ mediumPrimes N ⌊smoothCutoff N⌋₊ M', q ∣ n := by
    dsimp only [M', D]
    rw [mediumPrimes_union_bad_eq]
    exact hS
  obtain ⟨B⟩ := hRetained M' S R (subset_union_right : D ⊆ M') hM' hS' hR
  have hRepair : (mass (repairExclusions d N (smoothCutoff N) M' S R) : ℝ) ≤ E / L ^ 4 + U / L := by
    have hExtra : (mass (badCoverPart N Q) : ℝ) ≤ U / L :=
      hBadMassN Q (Nat.le_ceil _)
    have hUnion : mass (repairExclusions d N (smoothCutoff N) M S R ∪ badCoverPart N Q) ≤
        mass (repairExclusions d N (smoothCutoff N) M S R) + mass (badCoverPart N Q) := by
      let A := repairExclusions d N (smoothCutoff N) M S R
      let F := badCoverPart N Q
      have hh := sum_union_inter (s₁ := A) (s₂ := F) (f := fun a : ℕ => (a : ℚ)⁻¹)
      change mass (A ∪ F) + mass (A ∩ F) = mass A + mass F at hh
      change mass (A ∪ F) ≤ mass A + mass F
      linarith only [hh, mass_nonneg (A ∩ F)]
    have hRplus : (mass (repairExclusions d N (smoothCutoff N) M' S R) : ℝ) ≤
        (mass (repairExclusions d N (smoothCutoff N) M S R) : ℝ) + mass (badCoverPart N Q) := by
      exact_mod_cast (mass_mono (repairExclusions_union_bad_subset d N Q M S R)).trans
        hUnion
    exact hRplus.trans (add_le_add hBudget hExtra)
  have hE' : E / L ^ 4 ≤ E * U / L := by
    calc
      _ ≤ E / L := div_le_div_of_nonneg_left hE hLp
        (by simpa only [pow_one] using pow_le_pow_right₀ hL1 (show (1 : ℕ) ≤ 4 by decide))
      _ ≤ _ := div_le_div_of_nonneg_right (le_mul_of_one_le_right hE hU1) hLp.le
  have hTailN' : (mass (cutoffPart d N Z) : ℝ) ≤ nextSufficientLoss N T := hTailN
  have hChargeN : (correctionChargeAt N M' Q : ℝ) ≤ 2076 * U / L := hCharge M'
  have hStock : (mass (interval d N) : ℝ) -
        (mass (repairExclusions d N (smoothCutoff N) M' S R) : ℝ) -
        (mass (cutoffPart d N Z) : ℝ) ≤ (mass (stock d N M' S R (Z := Z)) : ℝ) := by
    exact_mod_cast mass_stock_ge_of_nonneg d N M' S R hZ
  have hW : (mass (stock d N M' S R (Z := Z)) : ℝ) - (correctionChargeAt N M' Q : ℝ) ≤
      ∑ T ∈ B.family, (mass T : ℝ) := by exact_mod_cast B.weight
  have hLossEq : nextSufficientLoss N C = nextSufficientLoss N T + E * U / L +
      U / L + 2076 * U / L := by
    simp only [nextSufficientLoss, C, U, L]
    ring
  refine ⟨B, ?_, ?_⟩
  · rw [hLossEq]
    linarith only [hStock,hW,hRepair,hE',hTailN',hChargeN]
  · have hSubset : stock d N M' S R (Z := Z) ⊆ interval d N :=
      fun n hn => (mem_stock.mp hn).1
    have hSum : (mass (interval d N \ stock d N M' S R (Z := Z)) : ℝ) +
        (mass (stock d N M' S R (Z := Z)) : ℝ) = (mass (interval d N) : ℝ) := by
      exact_mod_cast (sum_sdiff hSubset : mass (interval d N \ stock d N M' S R (Z := Z)) +
        mass (stock d N M' S R (Z := Z)) = mass (interval d N))
    have hMissing : (mass (interval d N \ stock d N M' S R (Z := Z)) : ℝ) ≤
        nextSufficientLoss N C := by
      rw [hLossEq]
      have hC₀ : 0 ≤ (2076 : ℝ) * U / L := by positivity
      linarith only [hStock,hSum,hRepair,hE',hTailN',hC₀]
    have hFinal : (mass (interval d N \ stock d N M' S R (Z := Z)) : ℝ) ≤ 1 :=
      hMissing.trans hLossN.2.le
    exact_mod_cast hFinal

end LeanAB.PaperB.Baseline

namespace LeanAB.PaperB

open Filter Finset Closure Baseline
open scoped Topology

/-- The local capacity deficit is at most the next-order sufficient loss. -/
theorem eventually_nextCapacity_deficit_upper :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      (_root_.harmonic N : ℝ) - (capacity N : ℝ) ≤ nextSufficientLoss N C := by
  obtain ⟨K,_,hProvider⟩ := hasRetainedBlockMass_of_averageCover
  obtain ⟨E,hE,hBudget⟩ := eventually_baseline_repair_budget 1 one_pos
  obtain ⟨C,hC,hStock⟩ := hProvider 1 E hE.le
  refine ⟨C,hC,?_⟩
  have hCast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  filter_upwards [hBudget, hStock, eventually_ge_atTop (1 : ℕ),
    (Real.tendsto_log_atTop.comp hCast).eventually_ge_atTop 1] with N hBudgetN hStockN hN hL
  change 1 ≤ Real.log (N : ℝ) at hL
  classical
  have hEmpty : (mass (repairExclusions 1 N (smoothCutoff N) ∅ ∅ ∅) : ℝ) ≤
      E / Real.log (N : ℝ) ^ 4 := by
    apply hBudgetN 1 ∅ ∅ ∅
    · simpa only [card_empty, Nat.cast_zero, one_mul] using zero_le_one.trans hL
    · simp
    · have h : (mass (∅ : Finset ℕ) : ℝ) = 0 := by simp [mass]
      rw [h]
      positivity
    · have h : (mass (∅ : Finset ℕ) : ℝ) = 0 := by simp [mass]
      rw [h]
      positivity
  obtain ⟨B,hWeight,_⟩ := hStockN ∅ ∅ ∅ (by simp) (by simp) (by simp) hEmpty
  let A := B.family.biUnion id
  have hA : A ⊆ denominators N := by
    intro n hn
    obtain ⟨T,hT,hnT⟩ := mem_biUnion.mp hn
    exact (mem_stock.mp ((B.good T hT).2.1 hnT)).1
  have hMass : mass A = ∑ T ∈ B.family, mass T := sum_biUnion B.disjoint
  have hDen : (mass A).den ∣ permittedDenominator N := by
    rw [hMass]
    exact (Rat.den_sum_dvd_lcm_den _ _).trans (lcm_dvd fun T hT => (B.good T hT).2.2.1)
  have hFeas : LocalFeasible N A := by
    refine ⟨hA,fun p hp => localResidue_zero_of_den_ndvd hp hA ?_⟩
    obtain ⟨hPrime,_,hLarge⟩ := mem_largePrimes.mp hp
    exact fun hpD => not_dvd_permittedDenominator_of_sqrt_lt hN hPrime hLarge (hpD.trans hDen)
  have hCap : mass A ≤ capacity N := (capacity_isGreatest N).2 ⟨A,hFeas,rfl⟩
  have hCapR : (mass A : ℝ) ≤ (capacity N : ℝ) := by exact_mod_cast hCap
  have hMassR : (mass A : ℝ) = ∑ T ∈ B.family, (mass T : ℝ) := by rw [hMass, Rat.cast_sum]
  have hFull : (mass (interval 1 N) : ℝ) = (_root_.harmonic N : ℝ) := by
    exact_mod_cast mass_denominators_eq_harmonic N
  linarith only [hWeight,hCapR,hMassR,hFull]

end LeanAB.PaperB
