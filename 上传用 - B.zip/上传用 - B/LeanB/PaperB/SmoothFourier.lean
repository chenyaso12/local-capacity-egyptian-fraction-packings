module

public import PaperB.Coverage
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Tactic

public section

/-! Fourier inversion for the smooth closure step, including composite moduli. -/

namespace LeanAB.PaperB.Closure

open Filter AddChar
open scoped BigOperators Topology

private noncomputable def cyclicTerm {P : ℕ} [NeZero P]
    (E : Finset ℕ) (w : ℕ → ZMod P) (v h : ZMod P) : ℂ :=
  ZMod.stdAddChar (-(h * v)) * ∏ b ∈ E, (1 + ZMod.stdAddChar (h * w b))

private theorem cyclicTerm_expand {P : ℕ} [NeZero P]
    (E : Finset ℕ) (w : ℕ → ZMod P) (v h : ZMod P) :
    cyclicTerm E w v h = ∑ J ∈ E.powerset, ZMod.stdAddChar (h * (∑ b ∈ J, w b) - h * v) := by
  rw [cyclicTerm, Finset.prod_one_add, Finset.mul_sum]
  refine Finset.sum_congr rfl fun J hJ => ?_
  rw [Finset.mul_sum, sub_eq_add_neg, add_comm, map_add_eq_mul]
  congr 1
  clear hJ E
  induction J using Finset.induction_on with
  | empty => simp
  | insert j J hj ih => rw [Finset.prod_insert hj, Finset.sum_insert hj, map_add_eq_mul, ih]

/-- Fourier inversion with separate zero, nonnegative, and small frequencies.
Works for any positive modulus, including the least common multiple of a denominator pool. -/
private theorem exists_subset_cyclic_sum {P : ℕ} [NeZero P]
    (E : Finset ℕ) (w : ℕ → ZMod P) (v : ZMod P)
    (hbound : ∀ h : ZMod P, h ≠ 0 →
      -((2 : ℝ) ^ E.card / P) ≤ (cyclicTerm E w v h).re) :
    ∃ J ⊆ E, ∑ b ∈ J, w b = v := by
  classical
  by_contra hn
  have hsum : ∑ h : ZMod P, cyclicTerm E w v h = 0 := calc
    _ = ∑ h : ZMod P, ∑ J ∈ E.powerset, ZMod.stdAddChar (h * (∑ b ∈ J, w b - v)) := by
      apply Finset.sum_congr rfl
      intro h _
      simp only [cyclicTerm_expand, mul_sub]
    _ = ∑ J ∈ E.powerset, ∑ h : ZMod P, ZMod.stdAddChar (h * (∑ b ∈ J, w b - v)) :=
      Finset.sum_comm
    _ = _ := by
      refine Finset.sum_eq_zero fun J hJ => ?_
      have hne : (∑ b ∈ J, w b) - v ≠ 0 :=
        fun h => hn ⟨J, Finset.mem_powerset.mp hJ, sub_eq_zero.mp h⟩
      simpa only [AddChar.mulShift_apply, mul_comm] using
        AddChar.sum_eq_zero_of_ne_one (ZMod.isPrimitive_stdAddChar P hne)
  have hRe : ∑ h : ZMod P, (cyclicTerm E w v h).re = 0 := by
    have hh := congrArg Complex.re hsum
    simpa only [Complex.re_sum, Complex.zero_re] using hh
  have hzero : (cyclicTerm E w v 0).re = (2 : ℝ) ^ E.card := by
    simp only [cyclicTerm, zero_mul, neg_zero, map_zero_eq_one, one_add_one_eq_two,
      Finset.prod_const, one_mul]
    rw [← Complex.ofReal_ofNat, ← Complex.ofReal_pow, Complex.ofReal_re]
  let nonzero := (Finset.univ : Finset (ZMod P)).erase 0
  have hsplit := Finset.sum_erase_add (s := (Finset.univ : Finset (ZMod P)))
    (fun h => (cyclicTerm E w v h).re) (Finset.mem_univ 0)
  change (∑ h ∈ nonzero, (cyclicTerm E w v h).re) + _ = _ at hsplit
  rw [hRe, hzero] at hsplit
  have hP : (0 : ℝ) < P := Nat.cast_pos.mpr (Nat.pos_of_ne_zero (NeZero.ne _))
  have hcard : (nonzero.card : ℝ) < P := by
    dsimp only [nonzero]
    rw [Finset.card_erase_of_mem (Finset.mem_univ _), Finset.card_univ, ZMod.card]
    exact_mod_cast Nat.sub_lt (Nat.pos_of_ne_zero (NeZero.ne P)) Nat.one_pos
  have hsumlb : -((2 : ℝ) ^ E.card) < ∑ h ∈ nonzero, (cyclicTerm E w v h).re := calc
    _ < (nonzero.card : ℝ) * (-((2 : ℝ) ^ E.card / P)) := by
      rw [mul_neg]
      apply neg_lt_neg_iff.mpr
      calc
        _ < (P : ℝ) * ((2 : ℝ) ^ E.card / P) :=
          mul_lt_mul_of_pos_right hcard (div_pos (by positivity) hP)
        _ = _ := by field_simp
    _ = ∑ _h ∈ nonzero, -((2 : ℝ) ^ E.card / P) := by simp
    _ ≤ _ := Finset.sum_le_sum fun h hh => hbound h (Finset.ne_of_mem_erase hh)
  linarith

private theorem cast_cofactor {P b : ℕ} (hb : 0 < b) (hdiv : b ∣ P) :
    ((P / b : ℕ) : ℝ) = P / (b : ℝ) := by
  apply (eq_div_iff (by positivity : (b : ℝ) ≠ 0)).mpr
  exact_mod_cast Nat.div_mul_cancel hdiv

private theorem cast_cofactor_rat {P b : ℕ} (hb : 0 < b) (hdiv : b ∣ P) :
    ((P / b : ℕ) : ℚ) = P / (b : ℚ) := by
  apply (eq_div_iff (by positivity : (b : ℚ) ≠ 0)).mpr
  exact_mod_cast Nat.div_mul_cancel hdiv

private theorem scaled_mass {P : ℕ} (E : Finset ℕ)
    (hE : ∀ b ∈ E, 0 < b ∧ b ∣ P) :
    (((∑ b ∈ E, ((P / b : ℕ) : ℤ)) : ℤ) : ℚ) = (P : ℚ) * mass E := by
  rw [mass, Finset.mul_sum, Int.cast_sum]
  refine Finset.sum_congr rfl fun b hb => ?_
  rw [Int.cast_natCast, cast_cofactor_rat (hE b hb).1 (hE b hb).2, div_eq_mul_inv]

private theorem scaled_target {P : ℕ} {s : ℚ} (hden : s.den ∣ P) :
    ((s.num * ((P / s.den : ℕ) : ℤ) : ℤ) : ℚ) = (P : ℚ) * s := by
  rw [Int.cast_mul, Int.cast_natCast, cast_cofactor_rat s.den_pos hden]
  calc
    _ = (P : ℚ) * ((s.num : ℚ) / (s.den : ℚ)) := by ring
    _ = _ := by rw [Rat.num_div_den]

private theorem high_frequency_norm {P : ℕ} [NeZero P] (E : Finset ℕ) (h v : ZMod P)
    (W : Finset ℕ) (hWE : W ⊆ E) {δ : ℝ} (hδ : 0 ≤ δ)
    (hsep : ∀ b ∈ W, δ ≤ phaseDistance (h * ((P / b : ℕ) : ZMod P)))
    (hcount : Real.log P ≤ 2 * δ ^ 2 * (W.card : ℝ)) :
    ‖cyclicTerm E (fun b => ((P / b : ℕ) : ZMod P)) v h‖ ≤ (2 : ℝ) ^ E.card / P := by
  let phase (b : ℕ) := phaseDistance (h * ((P / b : ℕ) : ZMod P))
  have hsum : δ ^ 2 * (W.card : ℝ) ≤ ∑ b ∈ E, phase b ^ 2 := calc
    _ = ∑ _b ∈ W, δ ^ 2 := by simp [mul_comm]
    _ ≤ ∑ b ∈ W, phase b ^ 2 := Finset.sum_le_sum fun b hb =>
      pow_le_pow_left₀ hδ (hsep b hb) _
    _ ≤ _ := Finset.sum_le_sum_of_subset_of_nonneg hWE fun b _ _ => sq_nonneg _
  have hlog : Real.log (P : ℝ) ≤ 2 * ∑ b ∈ E, phase b ^ 2 :=
    hcount.trans (by simpa only [mul_assoc] using mul_le_mul_of_nonneg_left hsum zero_le_two)
  have hP : (0 : ℝ) < P := Nat.cast_pos.mpr (Nat.pos_of_ne_zero (NeZero.ne _))
  calc
    _ = ∏ b ∈ E, ‖1 + ZMod.stdAddChar (h * ((P / b : ℕ) : ZMod P))‖ := by
      rw [cyclicTerm, norm_mul, AddChar.norm_apply, one_mul, norm_prod]
    _ ≤ ∏ b ∈ E, 2 * Real.exp (-2 * phase b ^ 2) :=
      Finset.prod_le_prod₀ (fun _ _ => norm_nonneg _) (fun b _ => norm_one_add_stdAddChar_le _)
    _ = (2 : ℝ) ^ E.card * Real.exp (-2 * ∑ b ∈ E, phase b ^ 2) := by
      rw [Finset.prod_mul_distrib, Finset.prod_const, ← Real.exp_sum, Finset.mul_sum]
    _ ≤ (2 : ℝ) ^ E.card * Real.exp (-Real.log P) :=
      mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by linarith)) (by positivity)
    _ = _ := by rw [Real.exp_neg, Real.exp_log hP, div_eq_mul_inv]

private theorem phaseDistance_ge_of_separation {P b : ℕ} [NeZero P] {h : ZMod P}
    (hb : 0 < b) (hdiv : b ∣ P) {δ : ℝ}
    (hsep : ∀ z : ℤ, δ ≤ |(h.valMinAbs : ℝ) / b - z|) :
    δ ≤ phaseDistance (h * ((P / b : ℕ) : ZMod P)) := by
  let F : ZMod P := h * ((P / b : ℕ) : ZMod P)
  have heq : ((F.valMinAbs : ℤ) : ZMod P) =
      ((h.valMinAbs * ((P / b : ℕ) : ℤ) : ℤ) : ZMod P) := by
    rw [ZMod.coe_valMinAbs, Int.cast_mul, Int.cast_natCast, ZMod.coe_valMinAbs]
  obtain ⟨z, hz⟩ := (ZMod.intCast_eq_intCast_iff_dvd_sub _ _ P).mp heq
  have hzR : (h.valMinAbs : ℝ) * ((P / b : ℕ) : ℝ) - (F.valMinAbs : ℝ) =
      (P : ℝ) * (z : ℝ) := by
    have hcast := congrArg (fun j : ℤ => (j : ℝ)) hz
    simpa only [Int.cast_sub, Int.cast_mul, Int.cast_natCast] using hcast
  rw [cast_cofactor hb hdiv] at hzR
  have hP : (0 : ℝ) < P := Nat.cast_pos.mpr (Nat.pos_of_ne_zero (NeZero.ne _))
  have hid : (h.valMinAbs : ℝ) / (b : ℝ) - z = (F.valMinAbs : ℝ) / P := by
    apply (eq_div_iff hP.ne').mpr
    rw [← sub_eq_zero]
    calc
      _ = (h.valMinAbs : ℝ) * ((P : ℝ) / b) - (F.valMinAbs : ℝ) - (P : ℝ) * z := by ring
      _ = 0 := sub_eq_zero.mpr hzR
  specialize hsep z
  rw [hid, abs_div, abs_of_pos hP, ← Int.cast_abs, Int.abs_eq_natAbs, Int.cast_natCast] at hsep
  exact hsep

private theorem centered_factor (x : ℝ) :
    1 + Complex.exp ((↑(2 * x) : ℂ) * Complex.I) =
      (↑(2 * Real.cos x) : ℂ) * Complex.exp ((x : ℂ) * Complex.I) := by
  have h₁ : Complex.exp (-(x : ℂ) * Complex.I) *
      Complex.exp ((x : ℂ) * Complex.I) = 1 := by
    rw [← Complex.exp_add, show -(x : ℂ) * Complex.I + (x : ℂ) * Complex.I = 0 by ring,
      Complex.exp_zero]
  have h₂ : Complex.exp ((x : ℂ) * Complex.I) * Complex.exp ((x : ℂ) * Complex.I) =
      Complex.exp ((↑(2 * x) : ℂ) * Complex.I) := by
    rw [← Complex.exp_add]
    push_cast
    congr 1
    ring
  rw [show (↑(2 * Real.cos x) : ℂ) = 2 * Complex.cos (x : ℂ) by
    rw [Complex.ofReal_mul, Complex.ofReal_ofNat, Complex.ofReal_cos], Complex.cos]
  calc
    _ = Complex.exp (-(x : ℂ) * Complex.I) * Complex.exp ((x : ℂ) * Complex.I) +
        Complex.exp ((x : ℂ) * Complex.I) * Complex.exp ((x : ℂ) * Complex.I) := by
      rw [h₁, h₂]
    _ = _ := by ring

private theorem real_mass_sum (E : Finset ℕ) :
    (mass E : ℝ) = ∑ b ∈ E, (b : ℝ)⁻¹ := by
  simp only [mass, Rat.cast_sum, Rat.cast_inv, Rat.cast_natCast]

private theorem small_frequency_nonneg {P X : ℕ} [NeZero P] (hX : 0 < X)
    (E : Finset ℕ) (hE : ∀ b ∈ E, X ≤ b ∧ b ∣ P)
    (s : ℚ) (hs : s.den ∣ P)
    (hL : 2 * (s : ℝ) ≤ (mass E : ℝ)) (hU : (mass E : ℝ) ≤ 2 * (s : ℝ) + 1 / X)
    (h : ZMod P) (hsmall : |(h.valMinAbs : ℝ)| ≤ X / 2) :
    0 ≤ (cyclicTerm E (fun b => ((P / b : ℕ) : ZMod P))
      ((s.num * ((P / s.den : ℕ) : ℤ) : ℤ) : ZMod P) h).re := by
  let j : ℝ := h.valMinAbs
  let v : ℤ := s.num * ((P / s.den : ℕ) : ℤ)
  have hj : |j| ≤ (X : ℝ) / 2 := hsmall
  have hXr : (0 : ℝ) < X := Nat.cast_pos.mpr hX
  have hv : (v : ℝ) = (P : ℝ) * (s : ℝ) := by
    exact_mod_cast scaled_target hs
  have hTarget : ZMod.stdAddChar (-(h * (v : ZMod P))) =
      Complex.exp ((↑(-2 * Real.pi * j * (s : ℝ)) : ℂ) * Complex.I) := by
    rw [show (-(h * (v : ZMod P))) = ((-(h.valMinAbs * v) : ℤ) : ZMod P) by
          simp only [Int.cast_neg, Int.cast_mul, ZMod.coe_valMinAbs],
      ZMod.stdAddChar_coe]
    congr 1
    push_cast
    change _ = -2 * (Real.pi : ℂ) * (j : ℂ) * (s : ℂ) * Complex.I
    have hv' : (v : ℂ) = (P : ℂ) * (s : ℂ) := by exact_mod_cast hv
    rw [hv']
    have hPc : (P : ℂ) ≠ 0 := by exact_mod_cast (NeZero.ne P)
    dsimp only [j]
    push_cast
    field_simp
  have hTerms (b : ℕ) (hb : b ∈ E) :
      ZMod.stdAddChar (h * ((P / b : ℕ) : ZMod P)) =
        Complex.exp ((↑(2 * (Real.pi * j / (b : ℝ))) : ℂ) * Complex.I) := by
    rw [show h * ((P / b : ℕ) : ZMod P) =
        ((h.valMinAbs * ((P / b : ℕ) : ℤ) : ℤ) : ZMod P) by
          rw [Int.cast_mul, Int.cast_natCast, ZMod.coe_valMinAbs],
      ZMod.stdAddChar_coe]
    congr 1
    have hcR := cast_cofactor (hX.trans_le (hE b hb).1) (hE b hb).2
    have hcC : ((P / b : ℕ) : ℂ) = (P : ℂ) / (b : ℂ) := by
      simpa only [Complex.ofReal_natCast, Complex.ofReal_div] using
        congrArg Complex.ofReal hcR
    simp only [Int.cast_mul, Int.cast_natCast, Complex.ofReal_mul, Complex.ofReal_ofNat,
      Complex.ofReal_div, Complex.ofReal_natCast]
    rw [hcC]
    have hPc : (P : ℂ) ≠ 0 := by exact_mod_cast (NeZero.ne P)
    have hbC : (b : ℂ) ≠ 0 := by exact_mod_cast (hX.trans_le (hE b hb).1).ne'
    dsimp only [j]
    rw [Complex.ofReal_intCast]
    field_simp
  let x (b : ℕ) : ℝ := Real.pi * j / (b : ℝ)
  have hsplit : ∏ b ∈ E, (1 + ZMod.stdAddChar (h * ((P / b : ℕ) : ZMod P))) =
      (∏ b ∈ E, (↑(2 * Real.cos (x b)) : ℂ)) *
      Complex.exp (∑ b ∈ E, (x b : ℂ) * Complex.I) := calc
    _ = ∏ b ∈ E, (↑(2 * Real.cos (x b)) : ℂ) * Complex.exp ((x b : ℂ) * Complex.I) := by
      refine Finset.prod_congr rfl fun b hb => ?_
      rw [hTerms b hb, centered_factor]
    _ = _ := by rw [Finset.prod_mul_distrib, ← Complex.exp_sum]
  have hxsum : (∑ b ∈ E, (x b : ℂ) * Complex.I) =
      (↑(Real.pi * j * (mass E : ℝ)) : ℂ) * Complex.I := by
    rw [← Finset.sum_mul, ← Complex.ofReal_sum]
    congr 2
    simp only [x, real_mass_sum, div_eq_mul_inv, Finset.mul_sum]
  have hfactor (b : ℕ) (hb : b ∈ E) : 0 ≤ 2 * Real.cos (x b) := by
    have hbX : (X : ℝ) ≤ b := Nat.cast_le.mpr (hE b hb).1
    have hb₀ : (0 : ℝ) < b := hXr.trans_le hbX
    have hh : |j| / (b : ℝ) ≤ 1 / 2 :=
      (div_le_iff₀ hb₀).mpr (by linarith)
    have habs : |x b| ≤ Real.pi / 2 := by
      rw [show x b = Real.pi * (j / (b : ℝ)) by dsimp [x]; ring,
        abs_mul, abs_of_pos Real.pi_pos, abs_div, abs_of_pos hb₀, show Real.pi / 2 = Real.pi * (1 / 2) by ring]
      exact mul_le_mul_of_nonneg_left hh Real.pi_pos.le
    exact mul_nonneg zero_le_two (Real.cos_nonneg_of_mem_Icc (abs_le.mp habs))
  let α : ℝ := Real.pi * j * ((mass E : ℝ) - 2 * (s : ℝ))
  have hα : |α| ≤ Real.pi / 2 := by
    have hgap : 0 ≤ (mass E : ℝ) - 2 * (s : ℝ) := by linarith
    have hgap' : (mass E : ℝ) - 2 * (s : ℝ) ≤ 1 / X := by linarith
    calc
      _ = Real.pi * (|j| * ((mass E : ℝ) - 2 * (s : ℝ))) := by
        simp [α, abs_mul, abs_of_pos Real.pi_pos, abs_of_nonneg hgap, mul_assoc]
      _ ≤ Real.pi * ((X / 2 : ℝ) * (1 / X)) :=
        mul_le_mul_of_nonneg_left (mul_le_mul hj hgap' hgap (by positivity)) Real.pi_pos.le
      _ = _ := by field_simp
  rw [cyclicTerm, hTarget, hsplit, hxsum, mul_left_comm, ← Complex.exp_add]
  rw [show (↑(-2 * Real.pi * j * (s : ℝ)) : ℂ) * Complex.I +
      (↑(Real.pi * j * (mass E : ℝ)) : ℂ) * Complex.I = (α : ℂ) * Complex.I by
        dsimp only [α]
        push_cast
        ring]
  have hc : (∏ b ∈ E, (↑(2 * Real.cos (x b)) : ℂ)) =
      (↑(∏ b ∈ E, 2 * Real.cos (x b)) : ℂ) := by
    exact (map_prod Complex.ofRealHom _ _).symm
  rw [hc, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im, zero_mul, sub_zero,
    Complex.exp_ofReal_mul_I_re]
  exact mul_nonneg (Finset.prod_nonneg hfactor) (Real.cos_nonneg_of_mem_Icc (abs_le.mp hα))

/-- F2's Fourier closure, given the denominator pool and separated phases
for the frequencies outside the low-frequency interval. -/
theorem exists_smooth_closure_of_separation {X P : ℕ} (hX : 5 ≤ X) (hP : 0 < P)
    (E : Finset ℕ) (hE : ∀ b ∈ E, X ≤ b ∧ b ∣ P)
    (s : ℚ) (_hs₁ : (1 / 2 : ℚ) ≤ s) (hs₂ : s ≤ 3 / 4) (hs : s.den ∣ P)
    (hL : 2 * (s : ℝ) ≤ (mass E : ℝ)) (hU : (mass E : ℝ) ≤ 2 * (s : ℝ) + 1 / X)
    {δ : ℝ} (hδ : 0 ≤ δ)
    (hsep : ∀ j : ℤ, (X : ℝ) / 2 < |(j : ℝ)| → |(j : ℝ)| ≤ (P : ℝ) / 2 →
      ∃ W ⊆ E, (∀ b ∈ W, ∀ a : ℤ, δ ≤ |(j : ℝ) / b - a|) ∧
        Real.log P ≤ 2 * δ ^ 2 * (W.card : ℝ)) :
    ∃ T ⊆ E, mass T = s := by
  let _ : NeZero P := ⟨hP.ne'⟩
  let w (b : ℕ) : ZMod P := ((P / b : ℕ) : ZMod P)
  let v : ℤ := s.num * ((P / s.den : ℕ) : ℤ)
  have hX₀ : 0 < X := by omega
  have hfreq (h : ZMod P) (_ : h ≠ 0) :
      -((2 : ℝ) ^ E.card / P) ≤ (cyclicTerm E w (v : ZMod P) h).re := by
    by_cases hlo : |(h.valMinAbs : ℝ)| ≤ X / 2
    · exact le_trans (neg_nonpos.mpr (by positivity))
        (small_frequency_nonneg hX₀ E hE s hs hL hU h hlo)
    · have hhi : |(h.valMinAbs : ℝ)| ≤ P / 2 := by
        rw [← Int.cast_abs, Int.abs_eq_natAbs, Int.cast_natCast]
        have hcard := (Nat.cast_le (α := ℝ)).mpr (ZMod.natAbs_valMinAbs_le h)
        exact hcard.trans (by norm_num at *; exact Nat.cast_div_le)
      obtain ⟨W, hWE, hW, hWcard⟩ := hsep h.valMinAbs (lt_of_not_ge hlo) hhi
      have hHigh := high_frequency_norm E h (v : ZMod P) W hWE hδ
        (fun b hb => phaseDistance_ge_of_separation (hX₀.trans_le (hE b (hWE hb)).1)
          (hE b (hWE hb)).2 (hW b hb)) hWcard
      have hRe : -(cyclicTerm E w (v : ZMod P) h).re ≤
          ‖cyclicTerm E w (v : ZMod P) h‖ := calc
        _ ≤ |-(cyclicTerm E w (v : ZMod P) h).re| := le_abs_self _
        _ = |(cyclicTerm E w (v : ZMod P) h).re| := abs_neg _
        _ ≤ _ := Complex.abs_re_le_norm _
      change ‖cyclicTerm E w (v : ZMod P) h‖ ≤ _ at hHigh
      linarith
  obtain ⟨T, hTE, hT⟩ := exists_subset_cyclic_sum E w (v : ZMod P) hfreq
  let t : ℤ := ∑ b ∈ T, ((P / b : ℕ) : ℤ)
  have hcast : (t : ZMod P) = (v : ZMod P) := by
    simpa only [t, Int.cast_sum, Int.cast_natCast, w] using hT
  obtain ⟨q, hq⟩ := (ZMod.intCast_eq_intCast_iff_dvd_sub t v P).mp hcast
  have htr : (t : ℚ) = (P : ℚ) * mass T :=
    scaled_mass T fun b hb => ⟨hX₀.trans_le (hE b (hTE hb)).1, (hE b (hTE hb)).2⟩
  have hvr : (v : ℚ) = (P : ℚ) * s := scaled_target hs
  have hqQ : s - mass T = (q : ℚ) := by
    have hh := congrArg (fun z : ℤ => (z : ℚ)) hq
    simp only [Int.cast_sub, Int.cast_mul, Int.cast_natCast, htr, hvr] at hh
    exact mul_left_cancel₀ (show (P : ℚ) ≠ 0 by positivity) (by linarith)
  have hqR : (s : ℝ) - (mass T : ℝ) = (q : ℝ) := by exact_mod_cast hqQ
  have h5 : (5 : ℝ) ≤ X := by exact_mod_cast hX
  have hXinv : (1 : ℝ) / X ≤ 1 / 5 :=
    one_div_le_one_div_of_le (by norm_num) h5
  have hmass : (mass T : ℝ) ≤ (mass E : ℝ) := Rat.cast_le.mpr (mass_mono hTE)
  have hmass₀ : (0 : ℝ) ≤ (mass T : ℝ) := Rat.cast_nonneg.mpr (mass_nonneg T)
  have hsR : (s : ℝ) ≤ 3 / 4 := by
    simpa only [Rat.cast_div, Rat.cast_ofNat] using (Rat.cast_le (K := ℝ)).mpr hs₂
  have hql : (-1 : ℝ) < q := by linarith
  have hqu : (q : ℝ) < 1 := by linarith
  have hq0 : q = 0 := by
    have hl : (-1 : ℤ) < q := by exact_mod_cast hql
    have hu : q < (1 : ℤ) := by exact_mod_cast hqu
    omega
  exact ⟨T, hTE, by simp [hq0, sub_eq_zero] at hqQ; exact hqQ.symm⟩

/-- The short initial interval can be kept in the pool while still allowing
the total mass to be adjusted to any target in the doubling window. -/
theorem mass_le_one_of_short_interval {X : ℕ} (hX : 2 ≤ X)
    (hLog : 2 ≤ Real.log X) (Y : Finset ℕ) (hLower : ∀ b ∈ Y, X ≤ b)
    (hUpper : ∀ b ∈ Y, (b : ℝ) ≤ (X : ℝ) * (1 + 1 / Real.log X)) :
    mass Y ≤ 1 := by
  have hSmall : (1 : ℝ) / Real.log X ≤ 1 / 2 :=
    one_div_le_one_div_of_le (by norm_num) hLog
  have hSubset : Y ⊆ Finset.Icc X (X + X / 2) := by
    intro b hb
    refine Finset.mem_Icc.mpr ⟨hLower b hb, ?_⟩
    have hr : 2 * (b : ℝ) ≤ 3 * (X : ℝ) := by
      linarith only [hUpper b hb, mul_le_mul_of_nonneg_left hSmall (Nat.cast_nonneg X)]
    have hn : 2 * b ≤ 3 * X := by exact_mod_cast hr
    omega
  have hcard := Finset.card_le_card hSubset
  rw [Nat.card_Icc] at hcard
  have hcard' : Y.card ≤ X := by omega
  have hX₀ : (0 : ℚ) < X := by exact_mod_cast (show 0 < X by omega)
  calc
    mass Y ≤ ∑ _b ∈ Y, (X : ℚ)⁻¹ :=
      Finset.sum_le_sum fun b hb => inv_anti₀ hX₀ (by exact_mod_cast hLower b hb)
    _ = (Y.card : ℚ) * (X : ℚ)⁻¹ := by simp
    _ ≤ (X : ℚ) * (X : ℚ)⁻¹ :=
      mul_le_mul_of_nonneg_right (by exact_mod_cast hcard') (by positivity)
    _ = 1 := mul_inv_cancel₀ hX₀.ne'

/-- A pool can be shortened to within one atom of any feasible target mass
while keeping every element of the required subset. -/
theorem exists_intermediate_smooth_mass {X : ℕ} (hX : 0 < X) {Y₀ Pool : Finset ℕ}
    (hSubset : Y₀ ⊆ Pool) (hLower : ∀ b ∈ Pool, X ≤ b)
    {u : ℚ} (hlo : mass Y₀ ≤ u) (hhi : u ≤ mass Pool) :
    ∃ E, Y₀ ⊆ E ∧ E ⊆ Pool ∧ u ≤ mass E ∧ mass E ≤ u + (X : ℚ)⁻¹ := by
  classical
  have hsdiff : mass (Pool \ Y₀) = mass Pool - mass Y₀ := Finset.sum_sdiff_eq_sub hSubset
  have hdem : 0 ≤ mass Pool - u := sub_nonneg.mpr hhi
  have hroom : mass Pool - u ≤ mass (Pool \ Y₀) := by rw [hsdiff]; linarith
  obtain ⟨D, hD, hDlo, hDhi⟩ := exists_subset_weight_between (Pool \ Y₀)
    (fun b => (b : ℚ)⁻¹) (η := (X : ℚ)⁻¹) hdem (by positivity)
    (fun b hb => inv_anti₀ (by exact_mod_cast hX)
      (by exact_mod_cast hLower b (Finset.mem_sdiff.mp hb).1)) hroom
  have hDsub := hD.trans (Finset.sdiff_subset : Pool \ Y₀ ⊆ Pool)
  refine ⟨Pool \ D, ?_, Finset.sdiff_subset, ?_, ?_⟩
  · intro b hb
    exact Finset.mem_sdiff.mpr ⟨hSubset hb, fun h => (Finset.mem_sdiff.mp (hD h)).2 hb⟩
  · change mass D ≤ _ at hDhi
    rw [show mass (Pool \ D) = mass Pool - mass D from Finset.sum_sdiff_eq_sub hDsub]
    linarith
  · change _ ≤ mass D at hDlo
    rw [show mass (Pool \ D) = mass Pool - mass D from Finset.sum_sdiff_eq_sub hDsub]
    linarith

private theorem log_smooth_modulus_le (X : ℕ) :
    Real.log (Nat.lcmUpto (Nat.nthRoot 5 X) : ℝ) ≤ 6 * (X : ℝ) ^ (1 / 5 : ℝ) := by
  have hpow : ((Nat.nthRoot 5 X : ℕ) : ℝ) ^ (5 : ℕ) ≤ (X : ℝ) := by
    exact_mod_cast Nat.pow_nthRoot_le (n := 5) (a := X) (Or.inl (by decide))
  have hroot := Real.rpow_le_rpow (by positivity) hpow (by norm_num : (0 : ℝ) ≤ 1 / 5)
  rw [← Real.rpow_natCast_mul (by positivity), show ((5 : ℕ) : ℝ) * (1 / 5) = 1 by norm_num,
    Real.rpow_one] at hroot
  rw [← Chebyshev.psi_eq_log_lcmUpto]
  have h4 : Real.log 4 ≤ 2 := by
    rw [show (4 : ℝ) = 2 * 2 by norm_num, Real.log_mul (by norm_num) (by norm_num)]
    linarith [Real.log_lt_sub_one_of_pos (show (0 : ℝ) < 2 by norm_num) (by norm_num)]
  exact (Chebyshev.psi_le_const_mul_self (show (0 : ℝ) ≤ Nat.nthRoot 5 X by positivity)).trans
    ((by gcongr; linarith : _ ≤ 6 * (Nat.nthRoot 5 X : ℝ)).trans (by gcongr))

/-- The power-scale gap in F2 suffices for every large frequency, uniformly
in the target fraction. -/
theorem eventually_power_separation_controls_fourier (c : ℝ) (hc : 0 < c) :
    ∀ᶠ X : ℕ in atTop, ∀ W : Finset ℕ, c * (X : ℝ) ^ (3 / 4 : ℝ) ≤ (W.card : ℝ) →
      Real.log (Nat.lcmUpto (Nat.nthRoot 5 X) : ℝ) ≤
        2 * ((X : ℝ) ^ (-1 / 4 : ℝ) / 2) ^ 2 * (W.card : ℝ) := by
  have hcast : Tendsto (fun X : ℕ => (X : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hpower := (tendsto_rpow_atTop (show (0 : ℝ) < 1 / 20 by norm_num)).comp hcast
  filter_upwards [hpower.eventually_ge_atTop (12 / c), eventually_ge_atTop (1 : ℕ)]
    with X hX hX₁ W hW
  have hX₀ : (0 : ℝ) < X := Nat.cast_pos.mpr hX₁
  have hX' : 12 ≤ (X : ℝ) ^ (1 / 20 : ℝ) * c := (div_le_iff₀ hc).mp hX
  have hsq (z : ℝ) : 2 * (z / 2) ^ 2 = z ^ 2 / 2 := by ring
  calc
    _ ≤ 6 * (X : ℝ) ^ (1 / 5 : ℝ) := log_smooth_modulus_le X
    _ ≤ (c / 2) * (X : ℝ) ^ (1 / 4 : ℝ) := by
      rw [show (1 / 4 : ℝ) = 1 / 20 + 1 / 5 by norm_num, Real.rpow_add hX₀]
      nlinarith [mul_le_mul_of_nonneg_right hX' (Real.rpow_nonneg hX₀.le (1 / 5 : ℝ))]
    _ = 2 * ((X : ℝ) ^ (-1 / 4 : ℝ) / 2) ^ 2 * (c * (X : ℝ) ^ (3 / 4 : ℝ)) := by
      rw [hsq, ← Real.rpow_mul_natCast hX₀.le]
      rw [show (-1 / 4 : ℝ) * ((2 : ℕ) : ℝ) = -1 / 2 by norm_num]
      calc
        _ = c / 2 * ((X : ℝ) ^ (-1 / 2 : ℝ) * (X : ℝ) ^ (3 / 4 : ℝ)) := by
          rw [← Real.rpow_add hX₀]
          congr 1
          norm_num
        _ = _ := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hW (by positivity)

/-- Uniform smooth closure follows from one eventual pool supply and the
uniform high-frequency separation estimate. The mass and witness hypotheses are
independent of the rational target, so the closing constants are uniform. -/
theorem uniformSmoothClosure_of_pools_and_separation
    (C₀ : ℕ) (hC₀ : 1 < C₀) (c : ℝ) (hc : 0 < c)
    (hPools : ∀ᶠ X : ℕ in atTop, ∃ Y₀ Pool : Finset ℕ,
      Y₀ ⊆ Pool ∧ Pool ⊆ interval X (C₀ * X) ∧
      (∀ b ∈ Pool, b ∣ Nat.lcmUpto (Nat.nthRoot 5 X)) ∧
      mass Y₀ ≤ 1 ∧ (3 / 2 : ℚ) ≤ mass Pool ∧
      ∀ j : ℤ, (X : ℝ) / 2 < |(j : ℝ)| →
        |(j : ℝ)| ≤ (Nat.lcmUpto (Nat.nthRoot 5 X) : ℝ) / 2 →
        ∃ W ⊆ Y₀, c * (X : ℝ) ^ (3 / 4 : ℝ) ≤ (W.card : ℝ) ∧
          ∀ b ∈ W, ∀ a : ℤ, (X : ℝ) ^ (-1 / 4 : ℝ) / 2 ≤ |(j : ℝ) / b - a|) :
    ∃ X₀, UniformSmoothClosure C₀ X₀ := by
  have hEventually : ∀ᶠ X : ℕ in atTop, 0 < X →
      ∀ s : ℚ, (1 / 2 : ℚ) ≤ s → s ≤ 3 / 4 →
        s.den ∣ Nat.lcmUpto (Nat.nthRoot 5 X) →
        ∃ T : Finset ℕ, T ⊆ interval X (C₀ * X) ∧
          (∀ b ∈ T, b ∣ Nat.lcmUpto (Nat.nthRoot 5 X)) ∧ mass T = s := by
    filter_upwards [hPools, eventually_power_separation_controls_fourier c hc,
      eventually_ge_atTop (5 : ℕ)] with X hPool hFour hX _ s hs₁ hs₂ hden
    obtain ⟨Y₀, Pool, hSub, hInterval, hDiv, hSmall, hMass, hSep⟩ := hPool
    have hPoolLower (b : ℕ) (hb : b ∈ Pool) : X ≤ b :=
      (le_max_right 1 X).trans (Finset.mem_Icc.mp (hInterval hb)).1
    obtain ⟨E, hY₀, hE, hElo, hEhi⟩ := exists_intermediate_smooth_mass
      (by omega : 0 < X) hSub hPoolLower (show mass Y₀ ≤ 2 * s by linarith)
      (show 2 * s ≤ mass Pool by linarith)
    have hEL : 2 * (s : ℝ) ≤ (mass E : ℝ) := by exact_mod_cast hElo
    have hEU : (mass E : ℝ) ≤ 2 * (s : ℝ) + 1 / X := by
      have hh : (mass E : ℝ) ≤ ((2 * s + (X : ℚ)⁻¹ : ℚ) : ℝ) := Rat.cast_le.mpr hEhi
      simpa only [Rat.cast_add, Rat.cast_mul, Rat.cast_ofNat, Rat.cast_inv, Rat.cast_natCast,
        one_div] using hh
    obtain ⟨T, hTE, hT⟩ := exists_smooth_closure_of_separation hX (Nat.lcmUpto_pos _) E
      (fun b hb => ⟨hPoolLower b (hE hb), hDiv b (hE hb)⟩) s hs₁ hs₂ hden hEL hEU
      (δ := (X : ℝ) ^ (-1 / 4 : ℝ) / 2) (by positivity)
      (fun j hj hj' => by
        obtain ⟨W, hW, hWcard, hSepW⟩ := hSep j hj hj'
        exact ⟨W, hW.trans hY₀, hSepW, hFour W hWcard⟩)
    exact ⟨T, hTE.trans (hE.trans hInterval), fun b hb => hDiv b (hE (hTE hb)), hT⟩
  obtain ⟨X₀, hX₀⟩ := eventually_atTop.mp hEventually
  exact ⟨X₀, hC₀, fun X hX => hX₀ X hX⟩

end LeanAB.PaperB.Closure

