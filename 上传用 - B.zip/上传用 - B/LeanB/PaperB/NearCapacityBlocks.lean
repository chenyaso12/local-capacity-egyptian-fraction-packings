module

public import PaperB.CapacityApproximation
public import PaperB.RepairBudget
meta import Mathlib.Tactic

/-! The surviving indivisible blocks in the near-capacity construction. -/

@[expose] public section

open Finset
open scoped BigOperators Topology

namespace LeanAB.PaperB
namespace NearCapacity

open Closure

/-- The stock after reserving the exact-repair denominators and removing high powers. -/
noncomputable def available (N : ℕ) (z : ℝ) (M S R : Finset ℕ) : Finset ℕ :=
  interval 2 N \ repairExclusions 2 N z M S R

/-- The remaining possible medium primes, with the markers excluded. -/
def mediumPrimes (N z : ℕ) (M : Finset ℕ) : Finset ℕ :=
  (Nat.primesLE (Nat.sqrt N)).filter fun p => z < p ∧ p ∉ M

theorem mem_mediumPrimes {N z p : ℕ} {M : Finset ℕ} :
    p ∈ mediumPrimes N z M ↔ p.Prime ∧ p ≤ Nat.sqrt N ∧ z < p ∧ p ∉ M := by
  rw [mediumPrimes, mem_filter, Nat.mem_primesLE]
  tauto

private theorem dvd_lcmUpto_of_le {b z : ℕ} (hb : 0 < b) (hbz : b ≤ z) :
    b ∣ Nat.lcmUpto z := by
  unfold Nat.lcmUpto
  exact dvd_lcm (mem_Icc.mpr ⟨hb, hbz⟩)

private theorem prime_not_dvd_prime_product {p : ℕ} (hp : p.Prime) {Q : Finset ℕ}
    (hQ : ∀ q ∈ Q, q.Prime) (hpQ : p ∉ Q) :
    ¬ p ∣ ∏ q ∈ Q, q := by
  induction Q using Finset.induction_on with
  | empty => simpa using hp.not_dvd_one
  | @insert q Q hq ih =>
    rw [prod_insert hq]
    intro hd
    rcases hp.dvd_mul.mp hd with h | h
    · exact hpQ (mem_insert.mpr (Or.inl
        ((Nat.prime_dvd_prime_iff_eq hp (hQ q (mem_insert_self _ _))).mp h)))
    · exact ih (fun t ht => hQ t (mem_insert_of_mem ht)) (fun h => hpQ (mem_insert_of_mem h)) h

private theorem mediumDenominator_pos (N z : ℕ) (M : Finset ℕ) :
    0 < mediumDenominator z (mediumPrimes N z M) := by
  exact Nat.mul_pos (Nat.lcmUpto_pos z)
    (prod_pos fun q hq => (mem_mediumPrimes.mp hq).1.pos)

private theorem large_not_dvd_mediumDenominator {N z p : ℕ} {M : Finset ℕ}
    (hp : p ∈ largePrimes N) (hz : z ≤ Nat.sqrt N) :
    ¬ p ∣ mediumDenominator z (mediumPrimes N z M) := by
  obtain ⟨hprime, _, hlarge⟩ := mem_largePrimes.mp hp
  intro hdiv
  rcases hprime.dvd_mul.mp hdiv with hlcm | hprod
  · exact prime_not_dvd_smooth hprime (hz.trans_lt hlarge) (dvd_refl _) hlcm
  · refine prime_not_dvd_prime_product hprime (fun _ hq => (mem_mediumPrimes.mp hq).1) ?_ hprod
    intro h
    exact hlarge.not_ge (mem_mediumPrimes.mp h).2.1

/-- Each powersmooth cofactor of a large prime makes a usable denominator,
even after the exclusions have been applied. -/
theorem mul_mem_unreserved_of_smooth {d N p b : ℕ} {z : ℝ} {M S R : Finset ℕ}
    (hz : 0 ≤ z) (hz₁ : 1 ≤ ⌊z⌋₊) (hzN : ⌊z⌋₊ ≤ Nat.sqrt N)
    (hp : p ∈ largePrimes N) (hb : 0 < b) (hpb : p * b ≤ N) (hd : d ≤ p * b)
    (hbSmooth : b ∣ Nat.lcmUpto ⌊z⌋₊)
    (hNotMarker : p ∉ M) (hM : ∀ q ∈ M, q.Prime ∧ ⌊z⌋₊ < q)
    (hS : ∀ n ∈ S, ∃ q ∈ mediumPrimes N ⌊z⌋₊ M, q ∣ n)
    (hR : ∀ n ∈ R, n ∣ Nat.lcmUpto ⌊z⌋₊) :
    p * b ∈ interval d N \ repairExclusions d N z M S R := by
  classical
  obtain ⟨hp', _, hpLarge⟩ := mem_largePrimes.mp hp
  have hpSquare : N < p * p := Nat.sqrt_lt.mp hpLarge
  have hn : p * b ∈ interval d N :=
    mem_Icc.mpr ⟨max_le (Nat.mul_pos hp'.pos hb) hd, hpb⟩
  refine mem_sdiff.mpr ⟨hn, ?_⟩
  simp only [repairExclusions, mem_union, mem_biUnion, primePart, mem_filter]
  have hmedium (q : ℕ) (hq : q.Prime) (hqz : ⌊z⌋₊ < q) (hqN : q ≤ Nat.sqrt N) :
      ¬ q ∣ p * b := by
    intro hd
    rcases hq.dvd_mul.mp hd with h | h
    · have heq := (Nat.prime_dvd_prime_iff_eq hq hp').mp h
      exact hpLarge.not_ge (heq ▸ hqN)
    · exact prime_not_dvd_smooth hq hqz hbSmooth h
  rintro (((⟨d, hd, -, hdn⟩ | ⟨q, hq, -, hdiv⟩) | hpool) | hsmooth)
  · obtain ⟨q, hq, hqd⟩ := mem_biUnion.mp hd
    obtain ⟨e, he, rfl⟩ := mem_image.mp hqd
    have hqe := Nat.mem_primesLE.mp hq
    have he' : 2 ≤ e ∧ z < (q : ℝ) ^ e := (mem_filter.mp he).2
    by_cases heq : q = p
    · subst q
      have hdiv : p ^ 2 ∣ p * b := (pow_dvd_pow p he'.1).trans hdn
      have hl : p ^ 2 ≤ N := (Nat.le_of_dvd (Nat.mul_pos hp'.pos hb) hdiv).trans hpb
      exact hpSquare.not_ge (by simpa only [pow_two] using hl)
    · have hcp : (q ^ e).Coprime p :=
        (Nat.coprime_pow_left_iff (by omega : 0 < e) q p).2
          ((Nat.coprime_primes hqe.2 hp').2 heq)
      have hbd := hcp.dvd_of_dvd_mul_left hdn
      have hr := (dvd_lcmUpto_iff_prime_powers_le hb hz₁).mp hbSmooth q hqe.2 e hbd
      exact he'.2.not_ge (by simpa only [Nat.cast_pow] using (Nat.le_floor_iff hz).mp hr)
  · rcases (hM q hq).1.dvd_mul.mp hdiv with hqp | hqb
    · exact hNotMarker (((Nat.prime_dvd_prime_iff_eq (hM q hq).1 hp').mp hqp) ▸ hq)
    · exact prime_not_dvd_smooth (hM q hq).1 (hM q hq).2 hbSmooth hqb
  · obtain ⟨q, hq, hdiv⟩ := hS _ hpool
    obtain ⟨hprime, hl, hlarge, _⟩ := mem_mediumPrimes.mp hq
    exact hmedium q hprime hlarge hl hdiv
  · exact prime_not_dvd_smooth hp' (hzN.trans_lt hpLarge) (hR _ hsmooth) (dvd_mul_right p b)

/-- Unreserved denominators whose prime factors are within the large-prime cutoff. -/
noncomputable def unreservedCutoffStock (d N : ℕ) (z Z : ℝ) (M S R : Finset ℕ) : Finset ℕ := by
  classical
  exact (interval d N \ repairExclusions d N z M S R).filter
    (fun n => ∀ q : ℕ, q.Prime → q ∣ n → (q : ℝ) ≤ Z)

/-- The dilated cofactor grid for an unmarked prime remains available after
the repair reservations and the baseline large-prime cutoff. -/
theorem scaled_grid_mem_unreserved_cutoff {d N p t A : ℕ} {z Z : ℝ} {M S R : Finset ℕ}
    (hz : 0 ≤ z) (hz₁ : 1 ≤ ⌊z⌋₊) (hzN : ⌊z⌋₊ ≤ Nat.sqrt N)
    (hcut : (⌊z⌋₊ : ℝ) ≤ Z) (hp : p ∈ largePrimes N) (hpZ : (p : ℝ) ≤ Z)
    (ht : 0 < t) (hd : d ≤ p) (htop : p * (t * A) ≤ N)
    (hSmooth : ∀ b ∈ interval 1 A, t * b ∣ Nat.lcmUpto ⌊z⌋₊)
    (hNotMarker : p ∉ M) (hM : ∀ q ∈ M, q.Prime ∧ ⌊z⌋₊ < q)
    (hS : ∀ n ∈ S, ∃ q ∈ mediumPrimes N ⌊z⌋₊ M, q ∣ n)
    (hR : ∀ n ∈ R, n ∣ Nat.lcmUpto ⌊z⌋₊) :
    mark p (mark t (interval 1 A)) ⊆ unreservedCutoffStock d N z Z M S R := by
  classical
  intro n hn
  obtain ⟨k,hk,rfl⟩ := mem_image.mp hn
  obtain ⟨b,hb,rfl⟩ := mem_image.mp hk
  have hb₁ : 1 ≤ b := (mem_Icc.mp hb).1
  have htb : 0 < t * b := Nat.mul_pos ht hb₁
  have hN := (Nat.mul_le_mul_left p (Nat.mul_le_mul_left t (mem_Icc.mp hb).2)).trans htop
  have hlow := hd.trans (by simpa only [mul_one] using Nat.mul_le_mul_left p (show 1 ≤ t * b from htb))
  unfold unreservedCutoffStock
  refine mem_filter.mpr ⟨mul_mem_unreserved_of_smooth hz hz₁ hzN hp htb hN hlow
    (hSmooth b hb) hNotMarker hM hS hR, ?_⟩
  intro q hq hqd
  rcases hq.dvd_mul.mp hqd with hqp | hqk
  · have hh := (Nat.prime_dvd_prime_iff_eq hq (mem_largePrimes.mp hp).1).mp hqp
    simpa only [hh] using hpZ
  · have hFloor : q ≤ ⌊z⌋₊ := le_of_not_gt fun h =>
      prime_not_dvd_smooth hq h (hSmooth b hb) hqk
    exact (by exact_mod_cast hFloor : (q : ℝ) ≤ (⌊z⌋₊ : ℝ)).trans hcut

/-- The marker range in the near-capacity case implies that the large prime is unmarked. -/
theorem mul_mem_available_of_smooth {N p b : ℕ} {z : ℝ} {M S R : Finset ℕ}
    (hz : 0 ≤ z) (hz₁ : 1 ≤ ⌊z⌋₊) (hzN : ⌊z⌋₊ ≤ Nat.sqrt N)
    (hp : p ∈ largePrimes N) (hb : 0 < b) (hpb : p * b ≤ N)
    (hbSmooth : b ∣ Nat.lcmUpto ⌊z⌋₊)
    (hM : ∀ q ∈ M, q.Prime ∧ ⌊z⌋₊ < q ∧ q ≤ Nat.sqrt N)
    (hS : ∀ n ∈ S, ∃ q ∈ mediumPrimes N ⌊z⌋₊ M, q ∣ n)
    (hR : ∀ n ∈ R, n ∣ Nat.lcmUpto ⌊z⌋₊) :
    p * b ∈ available N z M S R := by
  refine mul_mem_unreserved_of_smooth hz hz₁ hzN hp hb hpb ?_ hbSmooth ?_
    (fun q hq => ⟨(hM q hq).1,(hM q hq).2.1⟩) hS hR
  · exact (mem_largePrimes.mp hp).1.two_le.trans (by
      simpa only [mul_one] using Nat.mul_le_mul_left p (show 1 ≤ b from hb))
  · intro hm
    exact (mem_largePrimes.mp hp).2.2.not_ge (hM p hm).2.2

/-- A retained integer divides the common denominator after accounting for
at most its unique large-prime factor p. Use p = 1 for singletons. -/
theorem available_dvd_common {N n p : ℕ} {z : ℝ} {M S R : Finset ℕ}
    (hz : 0 ≤ z) (hn : n ∈ available N z M S R) (hp : 0 < p)
    (hLarge : ∀ q : ℕ, q.Prime → Nat.sqrt N < q → q ∣ n → q = p) :
    n ∣ p * mediumDenominator ⌊z⌋₊ (mediumPrimes N ⌊z⌋₊ M) := by
  have hn' := mem_sdiff.mp hn
  have hn₂ := mem_Icc.mp hn'.1
  have hn₀ : 0 < n := by omega
  let D := mediumDenominator ⌊z⌋₊ (mediumPrimes N ⌊z⌋₊ M)
  have hD : 0 < D := mediumDenominator_pos N _ M
  apply (Nat.factorization_prime_le_iff_dvd hn₀.ne' (Nat.mul_pos hp hD).ne').mp
  intro q hq
  apply (hq.pow_dvd_iff_le_factorization (Nat.mul_pos hp hD).ne').mp
  let e := n.factorization q
  change q ^ e ∣ p * D
  have hd : q ^ e ∣ n := (hq.pow_dvd_iff_le_factorization hn₀.ne').mpr le_rfl
  by_cases hqz : q ^ e ≤ ⌊z⌋₊
  · exact ((dvd_lcmUpto_of_le (Nat.pow_pos hq.pos) hqz).trans
      (dvd_mul_right _ _)).trans (dvd_mul_left _ _)
  · have hz' : z < (q : ℝ) ^ e := by
      simpa only [Nat.cast_pow] using (Nat.floor_lt hz).mp (lt_of_not_ge hqz)
    have he : e < 2 := by
      by_contra! hh
      have hmem := mem_highPrimePowers_of_dvd hn₀ hn₂.2 hq hh hz' hd
      apply hn'.2
      exact mem_union_left _ (mem_union_left _ (mem_union_left _ (mem_biUnion.mpr
        ⟨q ^ e, hmem, mem_filter.mpr ⟨hn'.1, hd⟩⟩)))
    by_cases he0 : e = 0
    · simp [he0]
    have he1 : e = 1 := by omega
    rw [he1, pow_one] at hd ⊢
    by_cases hqN : Nat.sqrt N < q
    · rw [hLarge q hq hqN hd]
      exact dvd_mul_right _ _
    · have hm : q ∉ M := by
        intro hmem
        exact hn'.2 (mem_union_left _ (mem_union_left _ (mem_union_right _ (mem_biUnion.mpr
          ⟨q, hmem, mem_filter.mpr ⟨hn'.1, hd⟩⟩))))
      have hqz' : ⌊z⌋₊ < q := by simpa only [he1, pow_one] using lt_of_not_ge hqz
      have hqQ : q ∈ mediumPrimes N ⌊z⌋₊ M :=
        mem_mediumPrimes.mpr ⟨hq, le_of_not_gt hqN, hqz', hm⟩
      exact ((dvd_prod_of_mem (fun q : ℕ => q) hqQ).trans
        (dvd_mul_left _ _)).trans (dvd_mul_left _ _)

private theorem mem_denominators_of_available {N n : ℕ} {z : ℝ} {M S R : Finset ℕ}
    (hn : n ∈ available N z M S R) : n ∈ denominators N := by
  obtain ⟨hn₀, hnN⟩ := mem_Icc.mp (mem_sdiff.mp hn).1
  exact mem_Icc.mpr ⟨by omega, hnN⟩

private theorem unique_large {N p n : ℕ} (hp : p ∈ largePrimes N)
    (hn : n ∈ primePart p (denominators N)) :
    ∀ q : ℕ, q.Prime → Nat.sqrt N < q → q ∣ n → q = p := by
  intro q hq hqN hqd
  have hq' : q ∈ largePrimes N := mem_largePrimes.mpr ⟨hq, (Nat.le_of_dvd
    (mem_Icc.mp (mem_filter.mp hn).1).1 hqd).trans (mem_Icc.mp (mem_filter.mp hn).1).2, hqN⟩
  by_contra h
  exact disjoint_left.mp (primePart_disjoint hq' hp h) (mem_filter.mpr
    ⟨(mem_filter.mp hn).1, hqd⟩) hn

private theorem mass_den_dvd_of_localResidue_zero {N p D : ℕ} (hp : p ∈ largePrimes N)
    (hD : 0 < D) (T : Finset ℕ) (hT : T ⊆ primePart p (denominators N))
    (hCofactor : ∀ n ∈ T, n / p ∣ D) (hZero : localResidue p T = 0) :
    (mass T).den ∣ D := by
  let hp' := (mem_largePrimes.mp hp).1
  let _ : Fact p.Prime := ⟨hp'⟩
  let J := T.image (· / p)
  have hDiv (n : ℕ) (hn : n ∈ T) : p ∣ n := (mem_filter.mp (hT hn)).2
  have hC (b : ℕ) (hb : b ∈ J) : b ∣ D := by
    obtain ⟨n, hn, rfl⟩ := mem_image.mp hb
    exact hCofactor n hn
  have hJ : mark p J = T := by
    ext n
    simp only [mark, J, image_image, mem_image, Function.comp_apply]
    refine ⟨?_, ?_⟩
    · rintro ⟨a, ha, rfl⟩
      rwa [mul_comm, Nat.div_mul_cancel (hDiv a ha)]
    · intro hn
      exact ⟨n, hn, by rw [mul_comm, Nat.div_mul_cancel (hDiv n hn)]⟩
  have hZero' : cofactorResidue p J = 0 := by
    have hFilter : primePart p T = T := filter_true_of_mem hDiv
    have hInj : Set.InjOn (fun n : ℕ => n / p) T := by
      intro n hn m hm he
      change n / p = m / p at he
      calc
        n = n / p * p := (Nat.div_mul_cancel (hDiv n hn)).symm
        _ = m / p * p := by rw [he]
        _ = m := Nat.div_mul_cancel (hDiv m hm)
    rw [localResidue, hFilter] at hZero
    change cofactorResidue p (T.image (· / p)) = 0
    rwa [cofactorResidue, sum_image (fun _ ha _ hb he => hInj ha hb he)]
  let A : ℕ := ∑ b ∈ J, D / b
  have hD₀ : (D : ℚ) ≠ 0 := by exact_mod_cast hD.ne'
  have hquot (b : ℕ) (hb : b ∈ J) : D / b * b = D := Nat.div_mul_cancel (hC b hb)
  have hAq : (A : ℚ) = (D : ℚ) * mass J := by
    unfold A mass
    rw [Nat.cast_sum, mul_sum]
    apply sum_congr rfl
    intro b hb
    have hb₀ : b ≠ 0 := fun he => hD.ne' (zero_dvd_iff.mp (he ▸ hC b hb))
    rw [← div_eq_mul_inv, eq_div_iff (Nat.cast_ne_zero.mpr hb₀)]
    exact_mod_cast hquot b hb
  have hAZ : (A : ZMod p) = (D : ZMod p) * cofactorResidue p J := by
    unfold A cofactorResidue
    rw [Nat.cast_sum, mul_sum]
    apply sum_congr rfl
    intro b hb
    have hb' : b ∈ cofactorBlock N p := by
      obtain ⟨n, hn, rfl⟩ := mem_image.mp hb
      obtain ⟨hn₀, hnN⟩ := mem_Icc.mp (mem_filter.mp (hT hn)).1
      exact mem_Icc.mpr ⟨Nat.div_pos (Nat.le_of_dvd hn₀ (hDiv n hn)) hp'.pos,
        Nat.div_le_div_right hnN⟩
    have hbZ : (b : ZMod p) ≠ 0 := fun h =>
      (not_le_of_gt ((mem_Icc.mp hb').2.trans_lt (cofactor_lt_prime hp)))
        (Nat.le_of_dvd (mem_Icc.mp hb').1 ((ZMod.natCast_eq_zero_iff _ _).mp h))
    rw [← div_eq_mul_inv, eq_div_iff hbZ, ← Nat.cast_mul, hquot b hb]
  have hAp : p ∣ A := (ZMod.natCast_eq_zero_iff _ _).mp (by rw [hAZ, hZero', mul_zero])
  obtain ⟨a, ha⟩ := hAp
  have hMa : mass J = (A : ℚ) / D := (eq_div_iff hD₀).mpr (by rw [mul_comm, hAq])
  have hMass : mass T = (a : ℚ) / D := by
    rw [← hJ, mass_mark p hp'.pos, hMa, ha, Nat.cast_mul]
    field_simp [show (p : ℚ) ≠ 0 by exact_mod_cast hp'.ne_zero]
  apply Int.ofNat_dvd.mp
  rw [hMass]
  simpa only [Rat.divInt_eq_div, Int.cast_natCast] using Rat.den_dvd (a : ℤ) (D : ℤ)

private theorem primePart_available_subset {N p : ℕ} {z : ℝ} {M S R : Finset ℕ} :
    primePart p (available N z M S R) ⊆ primePart p (denominators N) :=
  fun _ hn => mem_filter.mpr ⟨mem_denominators_of_available (mem_filter.mp hn).1, (mem_filter.mp hn).2⟩

private theorem available_primePart_dvd {N p n : ℕ} {z : ℝ} {M S R : Finset ℕ}
    (hz : 0 ≤ z) (hp : p ∈ largePrimes N) (hn : n ∈ primePart p (available N z M S R)) :
    n ∣ p * mediumDenominator ⌊z⌋₊ (mediumPrimes N ⌊z⌋₊ M) :=
  available_dvd_common hz (mem_filter.mp hn).1 (mem_largePrimes.mp hp).1.pos
    (unique_large hp (primePart_available_subset hn))

/-- Above the final cutoff the full original block is still usable. An optimal
original deletion retains exactly the weight assigned by local capacity. -/
theorem exists_undamaged_optimum {N p : ℕ} {z : ℝ} {M S R : Finset ℕ}
    (hz : 0 ≤ z) (hz₁ : 1 ≤ ⌊z⌋₊) (hzN : ⌊z⌋₊ ≤ Nat.sqrt N)
    (hp : p ∈ largePrimes N) (hSmallCofactors : N / p ≤ ⌊z⌋₊)
    (hM : ∀ q ∈ M, q.Prime ∧ ⌊z⌋₊ < q ∧ q ≤ Nat.sqrt N)
    (hS : ∀ n ∈ S, ∃ q ∈ mediumPrimes N ⌊z⌋₊ M, q ∣ n)
    (hR : ∀ n ∈ R, n ∣ Nat.lcmUpto ⌊z⌋₊) :
    ∃ T ⊆ primePart p (available N z M S R),
      (mass T).den ∣ mediumDenominator ⌊z⌋₊ (mediumPrimes N ⌊z⌋₊ M) ∧
      mass (primePart p (available N z M S R)) - mass T = deletionCost N p / p := by
  have hp' := (mem_largePrimes.mp hp).1
  have hAvail : primePart p (available N z M S R) = primePart p (denominators N) := by
    refine Subset.antisymm primePart_available_subset ?_
    intro n hn
    obtain ⟨hn', hDiv⟩ := mem_filter.mp hn
    obtain ⟨hn₀, hnN⟩ := mem_Icc.mp hn'
    let b := n / p
    have hb : 0 < b := Nat.div_pos (Nat.le_of_dvd hn₀ hDiv) hp'.pos
    have hpEq : p * b = n := by rw [mul_comm, Nat.div_mul_cancel hDiv]
    have hbSmooth := dvd_lcmUpto_of_le hb ((Nat.div_le_div_right hnN).trans hSmallCofactors)
    exact mem_filter.mpr ⟨hpEq ▸ mul_mem_available_of_smooth hz hz₁ hzN hp hb
      (by rwa [hpEq]) hbSmooth hM hS hR, hDiv⟩
  obtain ⟨T, hT, hZero, hOpt⟩ := (local_block_optimum hp).1
  have hT' : T ⊆ primePart p (available N z M S R) := by rwa [hAvail]
  refine ⟨T, hT', ?_, ?_⟩
  · refine mass_den_dvd_of_localResidue_zero hp (mediumDenominator_pos N _ M) T hT ?_ hZero
    intro n hn
    apply Nat.dvd_of_mul_dvd_mul_left hp'.pos
    rw [mul_comm p (n / p), Nat.div_mul_cancel (mem_filter.mp (hT hn)).2]
    exact available_primePart_dvd hz hp (hT' hn)
  · rw [hAvail, hOpt]
    ring

/-- A scaled cover inside a damaged block cancels its large prime without
assuming any optimal subset of that damaged block still exists. -/
theorem exists_damaged_correction {N p A t B : ℕ} {z : ℝ} {M S R : Finset ℕ}
    (hz : 0 ≤ z) (hz₁ : 1 ≤ ⌊z⌋₊) (hzN : ⌊z⌋₊ ≤ Nat.sqrt N)
    (hp : p ∈ largePrimes N) (hA : 0 < A) (ht : 0 < t)
    (htUpper : p * (t * A) ≤ N) (htLower : N ≤ B * A * p * t)
    (hSmooth : ∀ b ∈ interval 1 A, t * b ∣ Nat.lcmUpto ⌊z⌋₊)
    (hCover : CoversResidues p (interval 1 A))
    (hM : ∀ q ∈ M, q.Prime ∧ ⌊z⌋₊ < q ∧ q ≤ Nat.sqrt N)
    (hS : ∀ n ∈ S, ∃ q ∈ mediumPrimes N ⌊z⌋₊ M, q ∣ n)
    (hR : ∀ n ∈ R, n ∣ Nat.lcmUpto ⌊z⌋₊) :
    ∃ T ⊆ primePart p (available N z M S R),
      (mass T).den ∣ mediumDenominator ⌊z⌋₊ (mediumPrimes N ⌊z⌋₊ M) ∧
      mass (primePart p (available N z M S R)) - mass T ≤
        (B : ℚ) * (A : ℚ) * mass (interval 1 A) / (N : ℚ) := by
  obtain ⟨hp', hpN, hpLarge⟩ := mem_largePrimes.mp hp
  let V := primePart p (available N z M S R)
  let D := mediumDenominator ⌊z⌋₊ (mediumPrimes N ⌊z⌋₊ M)
  have hAvail : mark p (mark t (interval 1 A)) ⊆ V := by
    intro n hn
    obtain ⟨u, hu, rfl⟩ := mem_image.mp hn
    obtain ⟨b, hb, rfl⟩ := mem_image.mp hu
    have hb' := mem_Icc.mp hb
    refine mem_filter.mpr ⟨mul_mem_available_of_smooth hz hz₁ hzN hp (Nat.mul_pos ht hb'.1)
      ((Nat.mul_le_mul_left p (Nat.mul_le_mul_left t hb'.2)).trans htUpper)
      (hSmooth b hb) hM hS hR, dvd_mul_right _ _⟩
  have htNot : ¬ p ∣ t := by
    intro h
    have hOne : 1 ∈ interval 1 A := mem_Icc.mpr ⟨le_rfl, hA⟩
    have hsmooth : t ∣ Nat.lcmUpto ⌊z⌋₊ := by simpa only [mul_one] using hSmooth 1 hOne
    exact prime_not_dvd_smooth hp' (hzN.trans_lt hpLarge) hsmooth h
  exact exists_scaled_block_cancellation hp' ht (mediumDenominator_pos N _ M)
    (hp'.pos.trans_le hpN) (large_not_dvd_mediumDenominator hp hzN) htNot V
    (mass_den_dvd (fun _ h => available_primePart_dvd hz hp h)) hAvail
    (fun b hb => (hSmooth b hb).trans (dvd_mul_right _ _)) hCover htLower

/-- Large-prime blocks with more cofactors than the final smooth cutoff
will be charged a proxy deletion. -/
def proxyPrimes (N z : ℕ) : Finset ℕ :=
  (largePrimes N).filter fun p => z < N / p

theorem card_proxyPrimes_le {N z : ℕ} (hz : 0 < z) :
    (proxyPrimes N z).card ≤ N / z := by
  have hsub : proxyPrimes N z ⊆ interval 1 (N / z) := by
    intro p hp
    obtain ⟨hpG, hzlt⟩ := mem_filter.mp hp
    have hprime := (mem_largePrimes.mp hpG).1
    exact mem_Icc.mpr ⟨hprime.one_le, (Nat.le_div_iff_mul_le hz).mpr
      ((Nat.mul_comm ..).symm ▸ Nat.mul_le_of_le_div _ _ _ hzlt.le)⟩
  exact (card_le_card hsub).trans (by simp [interval, Nat.card_Icc])

/-- The actual finite family used for allocation, including the availability
of all small singletons and the common reduced-denominator bound. -/
structure RetainedBlocks (N : ℕ) (z : ℝ) (M S R : Finset ℕ) (loss : ℚ) where
  family : Finset (Finset ℕ)
  disjoint : (↑family : Set (Finset ℕ)).PairwiseDisjoint id
  good : ∀ T ∈ family, T.Nonempty ∧ T ⊆ available N z M S R ∧
    (mass T).den ∣ mediumDenominator ⌊z⌋₊ (mediumPrimes N ⌊z⌋₊ M) ∧
    ((∃ n : ℕ, T = {n}) ∨
      ((∀ n ∈ T, Nat.sqrt N < n) ∧ mass T ≤ mass (denominators N) / (Nat.sqrt N : ℚ)))
  small : ∀ n ∈ available N z M S R, n ≤ Nat.sqrt N → {n} ∈ family
  weight : capacity N - 1 - mass (repairExclusions 2 N z M S R) - loss ≤ ∑ T ∈ family, mass T

private theorem mass_union_of_disjoint {U V : Finset ℕ} (h : Disjoint U V) :
    mass (U ∪ V) = mass U + mass V :=
  sum_union h

private theorem mass_biUnion_of_disjoint {ι : Type*} (F : Finset ι) (T : ι → Finset ℕ)
    (h : (↑F : Set ι).PairwiseDisjoint T) :
    mass (F.biUnion T) = ∑ i ∈ F, mass (T i) :=
  sum_biUnion h

private theorem mass_available_ge {N : ℕ} {z : ℝ} {M S R : Finset ℕ} (hN : 0 < N) :
    mass (denominators N) - 1 - mass (repairExclusions 2 N z M S R) ≤
      mass (available N z M S R) := by
  let E := repairExclusions 2 N z M S R
  let I := interval 2 N
  have hV : available N z M S R = I \ (I ∩ E) := by
    ext n
    simp only [available, I, E, mem_sdiff, mem_inter]
    tauto
  have hI : interval 2 N = denominators N \ {1} := by
    ext n
    simp only [denominators, interval, mem_Icc, mem_sdiff, mem_singleton]
    omega
  have hMassI : mass I = mass (denominators N) - 1 := by
    change mass (interval 2 N) = _
    rw [hI]
    have hSub : ({1} : Finset ℕ) ⊆ denominators N := by
      intro n hn
      rw [mem_singleton.mp hn]
      exact mem_Icc.mpr ⟨le_rfl, hN⟩
    rw [show mass (denominators N \ {1}) = mass (denominators N) - mass {1} from
      sum_sdiff_eq_sub hSub]
    simp [mass]
  rw [hV, show mass (I \ (I ∩ E)) = mass I - mass (I ∩ E) from
    sum_sdiff_eq_sub inter_subset_left, hMassI]
  exact sub_le_sub_left (mass_mono inter_subset_right) _

private theorem large_block_weight_le {N p : ℕ} (hp : p ∈ largePrimes N) {T : Finset ℕ}
    (hT : T ⊆ primePart p (denominators N)) :
    mass T ≤ mass (denominators N) / (Nat.sqrt N : ℚ) := by
  obtain ⟨hp', _, hpLarge⟩ := mem_largePrimes.mp hp
  have hH : mass (cofactorBlock N p) ≤ mass (denominators N) := by
    apply mass_mono
    intro b hb
    obtain ⟨h₁, h₂⟩ := mem_Icc.mp hb
    exact mem_Icc.mpr ⟨h₁, h₂.trans (Nat.div_le_self _ _)⟩
  calc
    _ ≤ mass (primePart p (denominators N)) := mass_mono hT
    _ = mass (cofactorBlock N p) / p := mass_primePart hp'.pos
    _ ≤ mass (denominators N) / p := div_le_div_of_nonneg_right hH (by positivity)
    _ ≤ _ := by
      apply div_le_div_of_nonneg_left (mass_nonneg _)
      · exact_mod_cast Nat.sqrt_pos.mpr (hp'.pos.trans_le (mem_largePrimes.mp hp).2.1)
      · exact_mod_cast hpLarge.le

/-- Assemble the exact and proxy corrections into a finite family, charging the
full proxy cost per damaged block without borrowing its original optimum. -/
theorem exists_retainedBlocks_of_corrections {N : ℕ} {z : ℝ} {M S R : Finset ℕ}
    (hN : 0 < N) (hz : 0 ≤ z) {cost : ℚ}
    (hCorrect : ∀ p ∈ largePrimes N, ∃ T ⊆ primePart p (available N z M S R),
      (mass T).den ∣ mediumDenominator ⌊z⌋₊ (mediumPrimes N ⌊z⌋₊ M) ∧
      mass (primePart p (available N z M S R)) - mass T ≤
        (if p ∈ proxyPrimes N ⌊z⌋₊ then cost else deletionCost N p / p)) :
    Nonempty (RetainedBlocks N z M S R ((proxyPrimes N ⌊z⌋₊).card * cost)) := by
  classical
  let V := available N z M S R
  let G := largePrimes N
  let W (p : ℕ) := primePart p V
  let B := G.biUnion W
  let U := V \ B
  let T (p : ℕ) : Finset ℕ := if hp : p ∈ G then (hCorrect p hp).choose else ∅
  have hT (p : ℕ) (hp : p ∈ G) : T p ⊆ W p ∧
      (mass (T p)).den ∣ mediumDenominator ⌊z⌋₊ (mediumPrimes N ⌊z⌋₊ M) ∧
      mass (W p) - mass (T p) ≤
        (if p ∈ proxyPrimes N ⌊z⌋₊ then cost else deletionCost N p / p) := by
    simpa only [T, dite_eq_left hp] using (hCorrect p hp).choose_spec
  let F := U.image (fun n => ({n} : Finset ℕ)) ∪ ((G.image T).erase ∅)
  have hMem (A : Finset ℕ) : A ∈ F ↔
      (∃ n ∈ U, ({n} : Finset ℕ) = A) ∨ (A.Nonempty ∧ ∃ p ∈ G, T p = A) := by
    simp only [F, mem_union, mem_image, mem_erase, nonempty_iff_ne_empty]
  have hWsub : ∀ p : ℕ, W p ⊆ V := fun _ => filter_subset ..
  have hBsub : B ⊆ V := by
    intro n hn
    obtain ⟨p, _, ha⟩ := mem_biUnion.mp hn
    exact hWsub _ ha
  have hDis (p : ℕ) (hp : p ∈ G) (q : ℕ) (hq : q ∈ G) (hne : p ≠ q) :
      Disjoint (W p) (W q) :=
    (primePart_disjoint hp hq hne).mono primePart_available_subset primePart_available_subset
  have hPair : (↑F : Set (Finset ℕ)).PairwiseDisjoint id := by
    intro A ha C hc hne
    rcases (hMem A).mp ha with ⟨a, haU, rfl⟩ | ⟨_, p, hp, rfl⟩
    · rcases (hMem C).mp hc with ⟨c, _, rfl⟩ | ⟨_, q, hq, rfl⟩
      · apply disjoint_singleton.mpr
        intro h
        exact hne (by rw [h])
      · exact disjoint_singleton_left.mpr fun ht => (mem_sdiff.mp haU).2
          (mem_biUnion.mpr ⟨q, hq, (hT q hq).1 ht⟩)
    · rcases (hMem C).mp hc with ⟨c, hcU, rfl⟩ | ⟨_, q, hq, rfl⟩
      · exact (disjoint_singleton_left.mpr fun ht => (mem_sdiff.mp hcU).2
          (mem_biUnion.mpr ⟨p, hp, (hT p hp).1 ht⟩)).symm
      · exact (hDis p hp q hq (fun e => hne (congrArg T e))).mono (hT p hp).1 (hT q hq).1
  refine ⟨⟨F, hPair, ?_, ?_, ?_⟩⟩
  · intro A ha
    rcases (hMem A).mp ha with ⟨n, hn, rfl⟩ | ⟨hn, p, hp, rfl⟩
    · have hnV : n ∈ V := (mem_sdiff.mp hn).1
      refine ⟨singleton_nonempty _, singleton_subset_iff.mpr hnV, ?_, Or.inl ⟨n, rfl⟩⟩
      apply mass_den_dvd
      intro a ha
      rw [mem_singleton.mp ha]
      simpa only [one_mul] using
        available_dvd_common hz hnV (p := 1) (by norm_num) (fun q _ hq hqd => False.elim
          ((mem_sdiff.mp hn).2 (mem_biUnion.mpr ⟨q, mem_largePrimes.mpr
            ⟨‹q.Prime›, (Nat.le_of_dvd (mem_Icc.mp (mem_denominators_of_available hnV)).1 hqd).trans
              (mem_Icc.mp (mem_denominators_of_available hnV)).2, hq⟩,
              mem_filter.mpr ⟨hnV, hqd⟩⟩)))
    · have hs : T p ⊆ W p := (hT p hp).1
      refine ⟨hn, hs.trans (hWsub p), (hT p hp).2.1, Or.inr ⟨?_, ?_⟩⟩
      · intro n hn'
        exact (mem_largePrimes.mp hp).2.2.trans_le (Nat.le_of_dvd
          (mem_Icc.mp (mem_denominators_of_available ((hWsub p) (hs hn')))).1
          (mem_filter.mp (hs hn')).2)
      · exact large_block_weight_le hp (hs.trans primePart_available_subset)
  · intro n hn hsmall
    apply (hMem _).mpr
    refine Or.inl ⟨n, mem_sdiff.mpr ⟨hn, ?_⟩, rfl⟩
    intro h
    obtain ⟨p, hp, hw⟩ := mem_biUnion.mp h
    have hdiv := (mem_filter.mp hw).2
    have hpos := (mem_Icc.mp (mem_denominators_of_available hn)).1
    exact ((mem_largePrimes.mp hp).2.2.not_ge ((Nat.le_of_dvd hpos hdiv).trans hsmall))
  · have hUnion : F.biUnion id = U ∪ G.biUnion T := by
      ext n
      constructor
      · intro h
        obtain ⟨A, hA, hn⟩ := mem_biUnion.mp h
        rcases (hMem A).mp hA with ⟨a, ha, rfl⟩ | ⟨_, p, hp, rfl⟩
        · exact mem_union_left _ ((mem_singleton.mp hn).symm ▸ ha)
        · exact mem_union_right _ (mem_biUnion.mpr ⟨p, hp, hn⟩)
      · intro h
        rcases mem_union.mp h with h | h
        · exact mem_biUnion.mpr ⟨{n}, (hMem _).mpr (Or.inl ⟨n, h, rfl⟩), mem_singleton_self n⟩
        · obtain ⟨p, hp, hn⟩ := mem_biUnion.mp h
          exact mem_biUnion.mpr ⟨T p, (hMem _).mpr (Or.inr ⟨⟨n, hn⟩, p, hp, rfl⟩), hn⟩
    have hUdisB : Disjoint U B := sdiff_disjoint
    have hBTsub : G.biUnion T ⊆ B := by
      intro n hn
      obtain ⟨p, hp, hn⟩ := mem_biUnion.mp hn
      exact mem_biUnion.mpr ⟨p, hp, (hT p hp).1 hn⟩
    have hTV : mass V = mass U + ∑ p ∈ G, mass (W p) := by
      rw [← mass_biUnion_of_disjoint G W hDis, ← mass_union_of_disjoint hUdisB,
        sdiff_union_of_subset hBsub]
    have hFam : (∑ A ∈ F, mass A) = mass U + ∑ p ∈ G, mass (T p) := by
      change (∑ A ∈ F, mass (id A)) = _
      rw [← mass_biUnion_of_disjoint F id hPair, hUnion,
        mass_union_of_disjoint (hUdisB.mono_right hBTsub)]
      rw [mass_biUnion_of_disjoint G T (fun p hp q hq hne =>
        (hDis p hp q hq hne).mono (hT p hp).1 (hT q hq).1)]
    have hLoss : (∑ p ∈ G, (mass (W p) - mass (T p))) ≤
        (∑ p ∈ G, deletionCost N p / p) + (proxyPrimes N ⌊z⌋₊).card * cost := by
      have hs : (∑ p ∈ G, if p ∈ proxyPrimes N ⌊z⌋₊ then cost else 0) =
          (proxyPrimes N ⌊z⌋₊).card * cost := by
        rw [← sum_filter]
        have he : G.filter (fun p => p ∈ proxyPrimes N ⌊z⌋₊) = proxyPrimes N ⌊z⌋₊ := by
          ext p
          simp only [G, proxyPrimes, mem_filter]
          tauto
        rw [he, sum_const, nsmul_eq_mul]
      rw [← hs, ← sum_add_distrib]
      apply sum_le_sum
      intro p hp
      have hc := (hT p hp).2.2
      have hdc : 0 ≤ deletionCost N p / p :=
        div_nonneg (deletionCost_nonneg N p) (Nat.cast_nonneg p)
      split_ifs at hc ⊢ <;> linarith
    rw [sum_sub_distrib] at hLoss
    have hStock : mass (denominators N) - 1 - mass (repairExclusions 2 N z M S R) ≤ mass V :=
      mass_available_ge hN
    rw [capacity, hFam]
    linarith only [hStock, hTV, hLoss]

open Filter

/-- Maximum cofactor index of the proxy modular cover used after reservations. -/
noncomputable def proxyWidth (N : ℕ) : ℕ :=
  2 * ⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊

/-- The total charge allowed for damaged large-prime blocks. -/
noncomputable def proxyCharge (N z : ℕ) : ℚ :=
  (proxyPrimes N z).card * ((173 : ℚ) * (proxyWidth N : ℚ) * mass (interval 1 (proxyWidth N)) / N)

private theorem cutoff_eq (N : ℕ) (D : ℝ) :
    (D * (N : ℝ) ^ (1 / 12 : ℝ)) ^ 2 = D ^ 2 * (N : ℝ) ^ (1 / 6 : ℝ) := by
  rw [mul_pow, ← Real.rpow_natCast ((N : ℝ) ^ (1 / 12 : ℝ)) 2,
    ← Real.rpow_mul (Nat.cast_nonneg N)]
  norm_num

private theorem proxyWidth_le_four_log {N : ℕ} (hL : 1 ≤ Real.log (N : ℝ)) :
    (proxyWidth N : ℝ) ≤ 4 * Real.log (N : ℝ) ^ (12 : ℕ) := by
  have hl := one_le_pow₀ hL (n := 12)
  have hc := Nat.ceil_lt_add_one (pow_nonneg (zero_le_one.trans hL) 12)
  rw [proxyWidth, Nat.cast_mul, Nat.cast_ofNat]
  linarith

private theorem mass_interval_le_height (A : ℕ) : mass (interval 1 A) ≤ A := by
  calc
    mass (interval 1 A) ≤ ∑ _a ∈ interval 1 A, (1 : ℚ) := by
      apply sum_le_sum
      intro a ha
      have ha₁ : (1 : ℚ) ≤ a := by exact_mod_cast (mem_Icc.mp ha).1
      exact inv_le_one_of_one_le₀ ha₁
    _ = A := by simp [interval, Nat.card_Icc]

/-- The proxy charges are in fact O(N^(-1/8)), using just the elementary bound
H_A ≤ A; this is more than sufficient for the N^(-1/12) final budget. -/
theorem eventually_proxyCharge_le {D : ℝ} (hD : 0 < D) :
    ∀ᶠ N : ℕ in atTop,
      (proxyCharge N ⌊(D * (N : ℝ) ^ (1 / 12 : ℝ)) ^ 2⌋₊ : ℝ) ≤
        (5536 / D ^ 2) / (N : ℝ) ^ (1 / 8 : ℝ) := by
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hlarge : Tendsto (fun N : ℕ => D ^ 2 * (N : ℝ) ^ (1 / 6 : ℝ)) atTop atTop :=
    ((tendsto_rpow_atTop (show 0 < (1 / 6 : ℝ) by norm_num)).comp hcast).const_mul_atTop
      (sq_pos_of_pos hD)
  filter_upwards [hlarge.eventually_ge_atTop 2, (Real.tendsto_log_atTop.comp hcast).eventually_ge_atTop 1,
    eventually_ge_atTop (1 : ℕ),
    eventually_log_pow_le_rpow 24 (show 0 < (1 / 24 : ℝ) by norm_num)]
    with N hZ hL hN hLogPow
  change 1 ≤ Real.log (N : ℝ) at hL
  let z : ℝ := D ^ 2 * (N : ℝ) ^ (1 / 6 : ℝ)
  let Y := ⌊z⌋₊
  let A := proxyWidth N
  have hN₀ : 0 < (N : ℝ) := Nat.cast_pos.mpr hN
  have hY : z / 2 ≤ (Y : ℝ) := by
    have hy := Nat.lt_floor_add_one z
    change 2 ≤ z at hZ
    change z / 2 ≤ (⌊z⌋₊ : ℝ)
    linarith
  have hY₀ : 0 < Y := by
    exact_mod_cast (lt_of_lt_of_le (by positivity : (0 : ℝ) < z / 2) hY)
  have hCard : ((proxyPrimes N Y).card : ℝ) ≤ (N : ℝ) / (Y : ℝ) := by
    exact (Nat.cast_le.mpr (card_proxyPrimes_le hY₀)).trans Nat.cast_div_le
  have hA : (A : ℝ) ≤ 4 * Real.log (N : ℝ) ^ (12 : ℕ) := proxyWidth_le_four_log hL
  have hA2 : (A : ℝ) ^ 2 ≤ 16 * (N : ℝ) ^ (1 / 24 : ℝ) := calc
    _ ≤ (4 * Real.log (N : ℝ) ^ (12 : ℕ)) ^ 2 := pow_le_pow_left₀ (Nat.cast_nonneg _) hA _
    _ = 16 * Real.log (N : ℝ) ^ (24 : ℕ) := by ring
    _ ≤ _ := by linarith only [hLogPow]
  have hMass : (mass (interval 1 A) : ℝ) ≤ (A : ℝ) := by
    exact_mod_cast mass_interval_le_height A
  have hMass₀ : (0 : ℝ) ≤ mass (interval 1 A) := by exact_mod_cast mass_nonneg (interval 1 A)
  have hq : (proxyCharge N Y : ℝ) ≤ 173 * (A : ℝ) ^ 2 / Y := calc
    _ = ((proxyPrimes N Y).card : ℝ) * (173 * (A : ℝ) * (mass (interval 1 A) : ℝ) / N) := by
      unfold proxyCharge A
      push_cast
      rfl
    _ ≤ ((N : ℝ) / Y) * (173 * (A : ℝ) * (A : ℝ) / N) := by
      apply mul_le_mul hCard _ (by positivity) (by positivity)
      exact div_le_div_of_nonneg_right
        (mul_le_mul_of_nonneg_left hMass (by positivity)) hN₀.le
    _ = _ := by field_simp [hN₀.ne', show (Y : ℝ) ≠ 0 by exact_mod_cast hY₀.ne']
  have hz : 0 < z := by positivity
  rw [cutoff_eq]
  calc
    (proxyCharge N Y : ℝ) ≤ 173 * (A : ℝ) ^ 2 / Y := hq
    _ ≤ 173 * ((A : ℝ) ^ 2) / (z / 2) :=
      div_le_div_of_nonneg_left (by positivity) (by positivity) hY
    _ ≤ 173 * (16 * (N : ℝ) ^ (1 / 24 : ℝ)) / (z / 2) :=
      div_le_div_of_nonneg_right (by linarith only [hA2]) (by positivity)
    _ = _ := by
      have hpow : (N : ℝ) ^ (1 / 24 : ℝ) * (N : ℝ) ^ (1 / 8 : ℝ) =
          (N : ℝ) ^ (1 / 6 : ℝ) := by rw [← Real.rpow_add hN₀]; congr 1; norm_num
      dsimp only [z]
      field_simp [hD.ne', (Real.rpow_pos_of_pos hN₀ _).ne']
      rw [← hpow]
      ring

/-- The canonical large-prime proxy widths fit inside the polynomial cutoff. -/
theorem eventually_proxyWidth_le {D : ℝ} (hD : 0 < D) :
    ∀ᶠ N : ℕ in atTop,
      0 < proxyWidth N ∧ proxyWidth N ≤ ⌊(D * (N : ℝ) ^ (1 / 12 : ℝ)) ^ 2⌋₊ := by
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hb := (isLittleO_log_rpow_rpow_atTop (s := (1 / 6 : ℝ)) 12 (by norm_num)).bound
    (show (0 : ℝ) < D ^ 2 / 4 by positivity)
  filter_upwards [(Real.tendsto_log_atTop.comp hcast).eventually_ge_atTop 1, hcast.eventually hb]
    with N hL hB
  change 1 ≤ Real.log (N : ℝ) at hL
  have hL₀ := zero_le_one.trans hL
  have hB' : Real.log (N : ℝ) ^ (12 : ℕ) ≤ D ^ 2 / 4 * (N : ℝ) ^ (1 / 6 : ℝ) := by
    simpa only [Real.norm_eq_abs, show (12 : ℝ) = ((12 : ℕ) : ℝ) by norm_num, Real.rpow_natCast,
      abs_of_nonneg (pow_nonneg hL₀ 12), abs_of_nonneg (Real.rpow_nonneg (Nat.cast_nonneg N) _)]
      using hB
  refine ⟨?_, (Nat.le_floor_iff (sq_nonneg _)).mpr ?_⟩
  · unfold proxyWidth
    exact Nat.mul_pos (by decide) (Nat.one_le_ceil_iff.mpr (pow_pos (zero_lt_one.trans_le hL) _))
  rw [cutoff_eq]
  exact (proxyWidth_le_four_log hL).trans (by linarith only [hB'])

/-- The actual near-capacity block family for the four F2 exclusion families. -/
theorem eventually_retainedBlocks {D : ℝ} (hD : 0 < D) :
    ∀ᶠ N : ℕ in atTop,
      let z := (D * (N : ℝ) ^ (1 / 12 : ℝ)) ^ 2
      ∀ M S R : Finset ℕ,
        ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ ≤ ⌊z⌋₊ → ⌊z⌋₊ ≤ Nat.sqrt N →
        (∀ q ∈ M, q.Prime ∧ ⌊z⌋₊ < q ∧ q ≤ Nat.sqrt N) →
        (∀ n ∈ S, ∃ q ∈ mediumPrimes N ⌊z⌋₊ M, q ∣ n) →
        (∀ n ∈ R, n ∣ Nat.lcmUpto ⌊z⌋₊) →
        Nonempty (RetainedBlocks N z M S R (proxyCharge N ⌊z⌋₊)) := by
  obtain ⟨P, hcover⟩ := eventually_atTop.mp eventually_pointwise_reciprocal_cover
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  filter_upwards [eventually_proxyWidth_le hD, eventually_powersmooth_dilation,
    (Real.tendsto_log_atTop.comp hcast).eventually_ge_atTop 1, eventually_ge_atTop (P * P),
    eventually_ge_atTop (1 : ℕ)] with N hWidth hDil hL hP hN
  change 1 ≤ Real.log (N : ℝ) at hL
  dsimp only
  intro M S R hY hz₁ hM hS hR
  let z := (D * (N : ℝ) ^ (1 / 12 : ℝ)) ^ 2
  let A := proxyWidth N
  have hSmall : 1 ≤ ⌊z⌋₊ := hWidth.1.trans_le hWidth.2
  apply exists_retainedBlocks_of_corrections hN (sq_nonneg _)
  intro p hp
  obtain ⟨hprime, hpN, hpLarge⟩ := mem_largePrimes.mp hp
  by_cases hpProxy : p ∈ proxyPrimes N ⌊z⌋₊
  · rw [ite_eq_left hpProxy]
    have hAQ : A ≤ N / p := hWidth.2.trans (mem_filter.mp hpProxy).2.le
    have hpA : p * A ≤ N := by
      rw [mul_comm]
      exact Nat.mul_le_of_le_div _ _ _ hAQ
    have hpy : ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ < p := ((hY.trans hz₁).trans_lt hpLarge)
    obtain ⟨t, ht, htl, htu, hs⟩ := hDil A hWidth.1 le_rfl p hprime hpy hpA
    have hpq : 0 < (p : ℚ) := Nat.cast_pos.mpr hprime.pos
    have hAq : 0 < (A : ℚ) := Nat.cast_pos.mpr hWidth.1
    have hUpper : p * (t * A) ≤ N := by
      have hh := (le_div_iff₀ (mul_pos hpq hAq)).mp htu
      have hNat : t * (p * A) ≤ N := by exact_mod_cast hh
      simpa only [mul_left_comm] using hNat
    have hLower : N ≤ 173 * A * p * t := by
      have hh := (div_le_iff₀ (mul_pos (mul_pos (by norm_num : (0 : ℚ) < 173) hpq) hAq)).mp htl
      have hNat : N ≤ t * (173 * p * A) := by exact_mod_cast hh
      convert hNat using 1
      ring
    have hpCover : P ≤ p := ((Nat.le_sqrt.mpr (by simpa only [pow_two] using hP)).trans hpLarge.le)
    have hLogp : 0 ≤ Real.log (p : ℝ) := Real.log_nonneg (by exact_mod_cast hprime.one_le)
    have hLogpN : Real.log (p : ℝ) ≤ Real.log (N : ℝ) :=
      Real.log_le_log (Nat.cast_pos.mpr hprime.pos) (by exact_mod_cast hpN)
    have hCWidth : ⌈Real.log (p : ℝ) ^ (4 : ℕ)⌉₊ ≤ A := by
      unfold A proxyWidth
      have he : Real.log (p : ℝ) ^ (4 : ℕ) ≤ Real.log (N : ℝ) ^ (12 : ℕ) :=
        (pow_le_pow_left₀ hLogp hLogpN 4).trans (pow_le_pow_right₀ hL (by norm_num))
      exact (Nat.ceil_mono he).trans (by omega)
    have hCover : CoversResidues p (interval 1 A) := by
      intro k
      obtain ⟨J, hJ, hJmod⟩ := hcover p hpCover hprime k
      exact ⟨J, hJ.trans (Finset.Icc_subset_Icc le_rfl hCWidth), hJmod⟩
    exact exists_damaged_correction (sq_nonneg _) hSmall hz₁ hp hWidth.1 ht hUpper hLower
      (fun b hb => ((hs b (mem_Icc.mp hb).1 (mem_Icc.mp hb).2).1).trans
        (Nat.lcmUpto_dvd_lcmUpto hY))
      hCover hM hS hR
  · rw [ite_eq_right hpProxy]
    have hsmall : N / p ≤ ⌊z⌋₊ := by
      by_contra! hh
      exact hpProxy (mem_filter.mpr ⟨hp, hh⟩)
    obtain ⟨T, hT, hden, hOpt⟩ := exists_undamaged_optimum (sq_nonneg _) hSmall hz₁ hp hsmall hM hS hR
    exact ⟨T, hT, hden, hOpt.le⟩

end NearCapacity
end LeanAB.PaperB
