module

public import Common
public import Mathlib.Algebra.Field.ZMod
public import Mathlib.Algebra.GCDMonoid.FinsetLemmas
public import Mathlib.Analysis.SpecialFunctions.Pow.NthRootLemmas
public import Mathlib.NumberTheory.Chebyshev
public import Mathlib.NumberTheory.Divisors
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
meta import Mathlib.Tactic.Positivity
meta import Mathlib.Tactic.FieldSimp
meta import Mathlib.Tactic.Linarith
meta import Mathlib.Tactic.NormNum
meta import Mathlib.Tactic.Ring

/-! Finite shared-pool and marked-prime repair steps for simultaneous closure. -/

@[expose] public section

namespace LeanAB.PaperB.Closure

open scoped BigOperators
open Finset

theorem exists_subset_weight_between {α : Type*} (S : Finset α)
    (w : α → ℚ) {q η : ℚ} (hq : 0 ≤ q) (hη : 0 ≤ η)
    (hSmall : ∀ a ∈ S, w a ≤ η) (hMass : q ≤ ∑ a ∈ S, w a) :
    ∃ T ⊆ S, q - η ≤ ∑ a ∈ T, w a ∧ ∑ a ∈ T, w a ≤ q := by
  classical
  induction S using Finset.induction_on generalizing q with
  | empty =>
    have hzero : q = 0 := le_antisymm (by simpa using hMass) hq
    exact ⟨∅, subset_rfl, by simpa [hzero] using hη, by simp [hzero]⟩
  | @insert a S has ih =>
    have hMass' : q ≤ w a + ∑ b ∈ S, w b := by simpa only [sum_insert has] using hMass
    by_cases hStop : q ≤ η
    · exact ⟨∅, empty_subset _, by simp [sub_nonpos.mpr hStop], by simpa⟩
    · have hqa : w a ≤ q := (hSmall a (mem_insert_self _ _)).trans (le_of_lt (lt_of_not_ge hStop))
      obtain ⟨T, hT, hLo, hHi⟩ := ih (sub_nonneg.mpr hqa)
        (fun b hb => hSmall b (mem_insert_of_mem hb)) (by linarith)
      have hat : a ∉ T := fun h => has (hT h)
      refine ⟨insert a T, insert_subset_insert _ hT, ?_, ?_⟩ <;>
        rw [sum_insert hat] <;> linarith

/-- Share one finite pool among finitely many demands. Each group gets a sum within
one atom below its demand, and the chosen subsequences of the pool are disjoint. -/
theorem exists_pool_approximation {ι : Type*} (groups : Finset ι)
    (demand : ι → ℚ) (Pool : Finset ℕ) {η : ℚ} (hη : 0 ≤ η)
    (hSmall : ∀ a ∈ Pool, (a : ℚ)⁻¹ ≤ η)
    (hDemand : ∀ i ∈ groups, 0 ≤ demand i)
    (hMass : (∑ i ∈ groups, demand i) ≤ mass Pool) :
    ∃ E : ι → Finset ℕ, (↑groups : Set ι).PairwiseDisjoint E ∧
      ∀ i ∈ groups, E i ⊆ Pool ∧ demand i - η ≤ mass (E i) ∧ mass (E i) ≤ demand i := by
  classical
  induction groups using Finset.induction_on generalizing Pool with
  | empty => exact ⟨fun _ => ∅, by simp, by simp⟩
  | @insert i groups hi ih =>
    have hiMass : demand i ≤ mass Pool := by
      have hrest : 0 ≤ ∑ j ∈ groups, demand j :=
        sum_nonneg fun j hj => hDemand j (mem_insert_of_mem hj)
      rw [sum_insert hi] at hMass
      linarith
    obtain ⟨T, hT, hTLow, hTHigh⟩ := exists_subset_weight_between Pool
      (fun a => (a : ℚ)⁻¹) (hDemand i (mem_insert_self _ _)) hη hSmall hiMass
    have hremaining : (∑ j ∈ groups, demand j) ≤ mass (Pool \ T) := by
      rw [mass, sum_sdiff_eq_sub hT]
      rw [sum_insert hi] at hMass
      change (∑ j ∈ groups, demand j) ≤ mass Pool - mass T
      change mass T ≤ demand i at hTHigh
      linarith
    obtain ⟨F, hFDisj, hF⟩ := ih (Pool \ T)
      (fun a ha => hSmall a (mem_sdiff.mp ha).1)
      (fun j hj => hDemand j (mem_insert_of_mem hj)) hremaining
    let E := Function.update F i T
    have hFE (j : ι) (hj : j ∈ groups) : E j = F j := by
      have hji : j ≠ i := fun h => hi (h ▸ hj)
      exact Function.update_of_ne hji _ _
    have hFDisjoint (j : ι) (hj : j ∈ groups) : Disjoint T (F j) :=
      disjoint_left.mpr fun a ha hFj => (mem_sdiff.mp ((hF j hj).1 hFj)).2 ha
    refine ⟨E, ?_, ?_⟩
    · intro j hj k hk hjk
      change Disjoint (E j) (E k)
      rcases mem_insert.mp hj with hji | hgj
      · subst j
        have hgk := (mem_insert.mp hk).resolve_left hjk.symm
        rw [show E i = T from Function.update_self _ _ _, hFE k hgk]
        exact hFDisjoint k hgk
      · rcases mem_insert.mp hk with hki | hgk
        · subst k
          rw [hFE j hgj, show E i = T from Function.update_self _ _ _]
          exact (hFDisjoint j hgj).symm
        · rw [hFE j hgj, hFE k hgk]
          exact hFDisj hgj hgk hjk
    · intro j hj
      rcases mem_insert.mp hj with hji | hgj
      · subst j
        rw [show E i = T from Function.update_self _ _ _]
        exact ⟨hT, hTLow, hTHigh⟩
      · rw [hFE j hgj]
        exact ⟨(hF j hgj).1.trans sdiff_subset, (hF j hgj).2⟩

/-- If all denominators of a finite set divide D, so does its reciprocal mass. -/
theorem mass_den_dvd {S : Finset ℕ} {D : ℕ} (hD : ∀ a ∈ S, a ∣ D) :
    (mass S).den ∣ D := by
  unfold mass
  exact (Rat.den_sum_dvd_lcm_den _ _).trans (lcm_dvd fun a ha => by
    by_cases hz : a = 0
    · simp [hz]
    · rw [Rat.inv_natCast_den_of_pos (Nat.pos_of_ne_zero hz)]
      exact hD a ha)

/-- For positive denominators bounded by N, each contribution of a reciprocal
sum pays at least 1/N toward the number of denominators used. -/
theorem card_le_mul_mass {d N : ℕ} {S : Finset ℕ} (hS : S ⊆ interval d N) :
    (S.card : ℚ) ≤ (N : ℚ) * mass S := by
  unfold mass
  rw [mul_sum]
  calc
    _ = ∑ a ∈ S, (1 : ℚ) := by simp
    _ ≤ _ := sum_le_sum fun a ha => by
      have hh := mem_Icc.mp (hS ha)
      have hapos : (0 : ℚ) < a := Nat.cast_pos.mpr (by omega)
      rw [← div_eq_mul_inv]
      exact (le_div_iff₀ hapos).2 (by simpa using (Nat.cast_le.mpr hh.2 : (a : ℚ) ≤ N))

/-- The shared powersmooth pool takes all residuals into intervals of width 2/N
above specified nonnegative lower endpoints. -/
theorem shared_smooth_pool {ι : Type*} [Fintype ι] {d N y : ℕ} (hN : 0 < N)
    (Pool : Finset ℕ) (hPool : Pool ⊆ interval d N)
    (hHalf : ∀ a ∈ Pool, N ≤ 2 * a)
    (hSmooth : ∀ a ∈ Pool, a ∣ Nat.lcmUpto y)
    (residual lower : ι → ℚ) (hLower : ∀ i, 0 ≤ lower i)
    (hRange : ∀ i, lower i ≤ residual i)
    (hDen : ∀ i, (residual i).den ∣ Nat.lcmUpto y)
    (hMass : ∑ i, residual i ≤ mass Pool) :
    ∃ E : ι → Finset ℕ, Pairwise (fun i j => Disjoint (E i) (E j)) ∧
      ∀ i, E i ⊆ Pool ∧
        lower i ≤ residual i - mass (E i) ∧
        residual i - mass (E i) ≤ lower i + 2 / (N : ℚ) ∧
        (residual i - mass (E i)).den ∣ Nat.lcmUpto y ∧
        ((E i).card : ℚ) ≤ (N : ℚ) * residual i := by
  have hNq : (0 : ℚ) < N := Nat.cast_pos.mpr hN
  have hSmall (a : ℕ) (ha : a ∈ Pool) : (a : ℚ)⁻¹ ≤ 2 / (N : ℚ) := by
    have ha0 : (0 : ℚ) < a := Nat.cast_pos.mpr (by have := (mem_Icc.mp (hPool ha)).1; omega)
    rw [← one_div]
    exact (div_le_div_iff₀ ha0 hNq).2 (by
      rw [one_mul]
      exact_mod_cast hHalf a ha)
  have hDemand : (∑ i, (residual i - lower i)) ≤ mass Pool :=
    (sum_le_sum fun i _ => sub_le_self _ (hLower i)).trans hMass
  obtain ⟨E, hDisj, hE⟩ := exists_pool_approximation univ (fun i => residual i - lower i)
    Pool (div_nonneg (by norm_num) hNq.le) hSmall
    (fun i _ => sub_nonneg.mpr (hRange i)) hDemand
  refine ⟨E, fun i j hij => hDisj (mem_univ i) (mem_univ j) hij, fun i => ?_⟩
  obtain ⟨hi, hlo, hhi⟩ := hE i (mem_univ i)
  refine ⟨hi, by linarith, by linarith, ?_, ?_⟩
  · exact (Rat.sub_den_dvd_lcm _ _).trans
      (Nat.lcm_dvd (hDen i) (mass_den_dvd fun a ha => hSmooth a (hi ha)))
  · exact (card_le_mul_mass (hi.trans hPool)).trans
      (mul_le_mul_of_nonneg_left (hhi.trans (sub_le_self _ (hLower i))) hNq.le)


/-- The uniform smooth-closure input at F2 lines 117–119, with an integer enlargement
of the upper scale C₀. Nat.nthRoot gives exactly the floor of X^(1/5). -/
def UniformSmoothClosure (C₀ X₀ : ℕ) : Prop :=
  1 < C₀ ∧ ∀ X : ℕ, X₀ ≤ X → 0 < X →
    ∀ s : ℚ, (1 / 2 : ℚ) ≤ s → s ≤ 3 / 4 →
      s.den ∣ Nat.lcmUpto (Nat.nthRoot 5 X) →
      ∃ T : Finset ℕ, T ⊆ interval X (C₀ * X) ∧
        (∀ b ∈ T, b ∣ Nat.lcmUpto (Nat.nthRoot 5 X)) ∧ mass T = s

/-- The scale of the cofactor interval for a group with marker prime P. -/
def markerScale (N C₀ P : ℕ) : ℕ :=
  N / (C₀ * P)

/-- The lower endpoint for the post-pool residual of a group with marker prime P. -/
def markerLower (P : ℕ) : ℚ :=
  1 / (2 * (P : ℚ))

/-- Multiply every denominator by one common positive factor. -/
def mark (P : ℕ) (T : Finset ℕ) : Finset ℕ :=
  T.image (P * ·)

theorem mass_mark (P : ℕ) (hP : 0 < P) (T : Finset ℕ) :
    mass (mark P T) = mass T / P := by
  rw [mass, mark, sum_image (fun a _ b _ h => Nat.eq_of_mul_eq_mul_left hP h),
    mass, div_eq_mul_inv, sum_mul]
  simp [Nat.cast_mul, mul_comm]

theorem card_mark (P : ℕ) (hP : 0 < P) (T : Finset ℕ) :
    (mark P T).card = T.card :=
  card_image_of_injective _ (fun _ _ h => Nat.eq_of_mul_eq_mul_left hP h)

/-- A prime strictly above the smooth cutoff cannot divide a smooth denominator. -/
theorem prime_not_dvd_smooth {p y t : ℕ} (hp : p.Prime) (hpy : y < p)
    (ht : t ∣ Nat.lcmUpto y) : ¬p ∣ t := by
  intro h
  have hmem := hp.mem_primeFactors (h.trans ht) (Nat.lcmUpto_ne_zero y)
  rw [Nat.primeFactors_lcmUpto] at hmem
  exact hpy.not_ge (Nat.le_of_mem_primesLE hmem)

/-- Conditional on uniform smooth closure, carry out every marked repair at its
paper scale and bound its actual denominator count. Every repaired denominator
is divisible by its own marker and by no other group's marker. -/
theorem exists_marked_repairs {ι : Type*} {d N y C₀ X₀ : ℕ} (hN : 0 < N)
    (hClosure : UniformSmoothClosure C₀ X₀)
    (P : ι → ℕ) (hP : ∀ i, (P i).Prime) (hPdistinct : Function.Injective P)
    (hEight : ∀ i, 8 * P i ≤ N)
    (hScale : ∀ i, X₀ ≤ markerScale N C₀ (P i) ∧
      0 < markerScale N C₀ (P i) ∧ d ≤ P i * markerScale N C₀ (P i))
    (hCutoff : ∀ i, y ≤ Nat.nthRoot 5 (markerScale N C₀ (P i)))
    (hDistinctCutoff : ∀ i j, Nat.nthRoot 5 (markerScale N C₀ (P i)) < P j)
    (θ : ι → ℚ) (hθ : ∀ i, markerLower (P i) ≤ θ i ∧
      θ i ≤ markerLower (P i) + 2 / (N : ℚ))
    (hDen : ∀ i, (θ i).den ∣ Nat.lcmUpto y) :
    ∃ G : ι → Finset ℕ, Pairwise (fun i j => Disjoint (G i) (G j)) ∧
      ∀ i, G i ⊆ interval d N ∧ mass (G i) = θ i ∧
        (G i).card ≤ C₀ * markerScale N C₀ (P i) ∧
        ∀ j a, a ∈ G i → (P j ∣ a ↔ j = i) := by
  classical
  let X (i : ι) := markerScale N C₀ (P i)
  have hT (i : ι) : ∃ T : Finset ℕ, T ⊆ interval (X i) (C₀ * X i) ∧
      (∀ b ∈ T, b ∣ Nat.lcmUpto (Nat.nthRoot 5 (X i))) ∧ mass T = (P i : ℚ) * θ i := by
    have hi : (0 : ℚ) < P i := Nat.cast_pos.mpr (hP i).pos
    have hNq : (0 : ℚ) < N := Nat.cast_pos.mpr hN
    have hHalf : (P i : ℚ) * markerLower (P i) = 1 / 2 := by
      unfold markerLower
      field_simp [hi.ne']
    have hQuarter : (2 * (P i : ℚ)) / (N : ℚ) ≤ 1 / 4 :=
      (div_le_iff₀ hNq).2 (by
        have h8 : (8 : ℚ) * (P i : ℚ) ≤ N := by exact_mod_cast hEight i
        linarith)
    have hLow : (1 / 2 : ℚ) ≤ (P i : ℚ) * θ i := by
      rw [← hHalf]
      exact mul_le_mul_of_nonneg_left (hθ i).1 hi.le
    have hHigh : (P i : ℚ) * θ i ≤ 3 / 4 := calc
      _ ≤ (P i : ℚ) * (markerLower (P i) + 2 / (N : ℚ)) :=
        mul_le_mul_of_nonneg_left (hθ i).2 hi.le
      _ = 1 / 2 + 2 * (P i : ℚ) / (N : ℚ) := by
        rw [mul_add, hHalf, ← mul_div_assoc, mul_comm (P i : ℚ) 2]
      _ ≤ _ := by linarith
    have hD : ((P i : ℚ) * θ i).den ∣ Nat.lcmUpto (Nat.nthRoot 5 (X i)) :=
      (by simpa using Rat.mul_den_dvd (P i : ℚ) (θ i) :
        ((P i : ℚ) * θ i).den ∣ (θ i).den).trans
        ((hDen i).trans (Nat.lcmUpto_dvd_lcmUpto (hCutoff i)))
    exact hClosure.2 (X i) (hScale i).1 (hScale i).2.1 ((P i : ℚ) * θ i) hLow hHigh hD
  choose T hTSubset hTSmooth hTMass using hT
  let G (i : ι) := mark (P i) (T i)
  have hFactors (i j : ι) (a : ℕ) (ha : a ∈ G i) : P j ∣ a ↔ j = i := by
    obtain ⟨b, hb, rfl⟩ := mem_image.mp ha
    constructor
    · intro h
      rcases (hP j).dvd_mul.mp h with hd | hd
      · exact hPdistinct ((Nat.prime_dvd_prime_iff_eq (hP j) (hP i)).mp hd)
      · exact (prime_not_dvd_smooth (hP j) (hDistinctCutoff i j) (hTSmooth i b hb) hd).elim
    · rintro rfl
      exact dvd_mul_right _ _
  refine ⟨G, ?_, fun i => ⟨?_, ?_, ?_, hFactors i⟩⟩
  · intro i j hij
    apply disjoint_left.mpr
    intro a hi hj
    exact hij ((hFactors j i a hj).mp ((hFactors i i a hi).mpr rfl))
  · intro a ha
    obtain ⟨b, hb, rfl⟩ := mem_image.mp ha
    have hbr := mem_Icc.mp (hTSubset i hb)
    have hLower : X i ≤ b := (le_max_right _ _).trans hbr.1
    have hPos : 0 < P i * b := Nat.mul_pos (hP i).pos ((hScale i).2.1.trans_le hLower)
    have hN' : P i * (C₀ * X i) ≤ N := by
      rw [← Nat.mul_assoc, Nat.mul_comm (P i) C₀, Nat.mul_comm (C₀ * P i)]
      exact Nat.div_mul_le_self N (C₀ * P i)
    exact mem_Icc.mpr ⟨max_le (by omega) ((hScale i).2.2.trans (Nat.mul_le_mul_left _ hLower)),
      (Nat.mul_le_mul_left _ hbr.2).trans hN'⟩
  · change mass (mark (P i) (T i)) = θ i
    rw [mass_mark _ (hP i).pos, hTMass]
    rw [mul_comm (P i : ℚ), mul_div_cancel_right₀ _ (Nat.cast_ne_zero.mpr (hP i).ne_zero)]
  · change (mark (P i) (T i)).card ≤ C₀ * X i
    rw [card_mark _ (hP i).pos]
    calc
      _ ≤ (interval 1 (C₀ * X i)).card := card_le_card fun b hb => by
        have hh := mem_Icc.mp (hTSubset i hb)
        exact mem_Icc.mpr ⟨by omega, hh.2⟩
      _ = _ := by simp [interval, Nat.card_Icc]


private theorem mass_union {S T : Finset ℕ} (h : Disjoint S T) :
    mass (S ∪ T) = mass S + mass T := sum_union h

/-- A medium-prime repair whose total mass is at most aδ/2 leaves the residual
in the interval used by the shared smooth-pool step of the paper. -/
theorem medium_residual_bounds (r a δ η residual cost : ℚ)
    (hR : a ≤ r) (hR₀ : 0 ≤ r) (hδ : 0 ≤ δ) (hη : η ≤ δ)
    (hLower : r * δ ≤ residual) (hUpper : residual ≤ r * (δ + η))
    (hCost₀ : 0 ≤ cost) (hCost : cost ≤ a * δ / 2) :
    a * δ / 2 ≤ residual - cost ∧ residual - cost ≤ 2 * r * δ := by
  have hrδ := mul_le_mul_of_nonneg_right hR hδ
  have hrη := mul_le_mul_of_nonneg_left (add_le_add le_rfl hη : δ + η ≤ δ + δ) hR₀
  constructor
  · linarith
  · nlinarith

/-- Join the smooth-pool and prime-marked repairs to already disjoint base sets.
A base set may already include its medium-prime repairs. The remaining explicit
analytic input is UniformSmoothClosure, uniform in the residual and the scale. -/
theorem finish_smooth_and_marked_closure {ι : Type*} [Fintype ι]
    {d N y C₀ X₀ : ℕ} (hN : 0 < N) (hClosure : UniformSmoothClosure C₀ X₀)
    (P : ι → ℕ) (hP : ∀ i, (P i).Prime) (hPdistinct : Function.Injective P)
    (hEight : ∀ i, 8 * P i ≤ N)
    (hScale : ∀ i, X₀ ≤ markerScale N C₀ (P i) ∧
      0 < markerScale N C₀ (P i) ∧ d ≤ P i * markerScale N C₀ (P i))
    (hCutoff : ∀ i, y ≤ Nat.nthRoot 5 (markerScale N C₀ (P i)))
    (hDistinctCutoff : ∀ i j, Nat.nthRoot 5 (markerScale N C₀ (P i)) < P j)
    (Base : ι → Finset ℕ) (hBase : ∀ i, Base i ⊆ interval d N)
    (hBasesDisjoint : Pairwise (fun i j => Disjoint (Base i) (Base j)))
    (hBaseAvoid : ∀ i a, a ∈ Base i → ∀ j, ¬P j ∣ a)
    (Pool : Finset ℕ) (hPool : Pool ⊆ interval d N)
    (hHalf : ∀ a ∈ Pool, N ≤ 2 * a)
    (hPoolSmooth : ∀ a ∈ Pool, a ∣ Nat.lcmUpto y)
    (hPoolDisjoint : ∀ i, Disjoint (Base i) Pool)
    (r : ι → ℚ)
    (hRange : ∀ i, markerLower (P i) ≤ r i - mass (Base i))
    (hDen : ∀ i, (r i - mass (Base i)).den ∣ Nat.lcmUpto y)
    (hMass : ∑ i, (r i - mass (Base i)) ≤ mass Pool) :
    ∃ E G : ι → Finset ℕ,
      Pairwise (fun i j => Disjoint (Base i ∪ E i ∪ G i) (Base j ∪ E j ∪ G j)) ∧
      ∀ i, E i ⊆ Pool ∧ (Base i ∪ E i ∪ G i) ⊆ interval d N ∧
        mass (Base i ∪ E i ∪ G i) = r i ∧
        ((Base i ∪ E i ∪ G i).card : ℚ) ≤ (Base i).card +
          (N : ℚ) * (r i - mass (Base i)) + (C₀ * markerScale N C₀ (P i) : ℕ) := by
  let residual (i : ι) := r i - mass (Base i)
  let lower (i : ι) := markerLower (P i)
  have hLower (i : ι) : 0 ≤ lower i :=
    div_nonneg (by norm_num) (mul_nonneg (by norm_num) (Nat.cast_nonneg _))
  obtain ⟨E, hEDisjoint, hE⟩ := shared_smooth_pool hN Pool hPool hHalf hPoolSmooth
    residual lower hLower hRange hDen hMass
  let θ (i : ι) := residual i - mass (E i)
  obtain ⟨G, hGDisjoint, hG⟩ := exists_marked_repairs hN hClosure P hP hPdistinct
    hEight hScale hCutoff hDistinctCutoff θ (fun i => ⟨(hE i).2.1, (hE i).2.2.1⟩)
    (fun i => (hE i).2.2.2.1)
  have hBE (i j : ι) : Disjoint (Base i) (E j) :=
    (hPoolDisjoint i).mono_right (hE j).1
  have hGB (i j : ι) : Disjoint (G i) (Base j) :=
    disjoint_left.mpr fun a ha hb => hBaseAvoid j a hb i (((hG i).2.2.2 i a ha).2 rfl)
  have hGE (i j : ι) : Disjoint (G i) (E j) := by
    apply disjoint_left.mpr
    intro a ha he
    have hPy := (hCutoff i).trans_lt (hDistinctCutoff i i)
    exact prime_not_dvd_smooth (hP i) hPy (hPoolSmooth a ((hE j).1 he))
      (((hG i).2.2.2 i a ha).2 rfl)
  refine ⟨E, G, ?_, fun i => ⟨(hE i).1, ?_, ?_, ?_⟩⟩
  · intro i j hij
    refine disjoint_union_left.mpr ⟨disjoint_union_left.mpr ⟨?_, ?_⟩, ?_⟩
    · exact disjoint_union_right.mpr ⟨disjoint_union_right.mpr
        ⟨hBasesDisjoint hij, hBE i j⟩, (hGB j i).symm⟩
    · exact disjoint_union_right.mpr ⟨disjoint_union_right.mpr
        ⟨(hBE j i).symm, hEDisjoint hij⟩, (hGE j i).symm⟩
    · exact disjoint_union_right.mpr ⟨disjoint_union_right.mpr
        ⟨hGB i j, hGE i j⟩, hGDisjoint hij⟩
  · exact union_subset (union_subset (hBase i) ((hE i).1.trans hPool)) (hG i).1
  · have hUG : Disjoint (Base i ∪ E i) (G i) :=
      disjoint_union_left.mpr ⟨(hGB i i).symm, (hGE i i).symm⟩
    rw [mass_union hUG, mass_union (hBE i i), (hG i).2.1]
    dsimp [θ, residual]
    ring
  · have hcNat : (Base i ∪ E i ∪ G i).card ≤ (Base i).card + (E i).card + (G i).card :=
      (card_union_le _ _).trans (Nat.add_le_add_right (card_union_le _ _) _)
    have hc : ((Base i ∪ E i ∪ G i).card : ℚ) ≤
        ((Base i).card : ℚ) + ((E i).card : ℚ) + ((G i).card : ℚ) := by exact_mod_cast hcNat
    have hGCard : ((G i).card : ℚ) ≤ ((C₀ * markerScale N C₀ (P i) : ℕ) : ℚ) := by
      exact_mod_cast (hG i).2.2.1
    exact hc.trans (add_le_add (add_le_add le_rfl (hE i).2.2.2.2) hGCard)


/-- Finite reciprocal subset-sum coverage of all residues modulo p. -/
def CoversResidues (p : ℕ) (C : Finset ℕ) : Prop :=
  ∀ z : ZMod p, ∃ J ⊆ C, ∑ b ∈ J, (b : ZMod p)⁻¹ = z

private theorem exists_int_div_of_den_dvd (s : ℚ) {D : ℕ} (hD : 0 < D)
    (h : s.den ∣ D) : ∃ z : ℤ, s = (z : ℚ) / (D : ℚ) := by
  obtain ⟨k, hk⟩ := h
  have hk₀ : k ≠ 0 := by
    intro h0
    simp [h0] at hk
    omega
  refine ⟨s.num * (k : ℤ), ?_⟩
  calc
    _ = (s.num : ℚ) / (s.den : ℚ) := (Rat.num_div_den s).symm
    _ = _ := by
      rw [hk]
      push_cast
      field_simp [show (k : ℚ) ≠ 0 by exact_mod_cast hk₀]

private theorem den_dvd_of_eq_int_div {s : ℚ} {z : ℤ} {D : ℕ}
    (hs : s = (z : ℚ) / (D : ℚ)) : s.den ∣ D := by
  apply Int.ofNat_dvd.mp
  rw [hs]
  simpa only [Rat.divInt_eq_div, Int.cast_natCast] using Rat.den_dvd z (D : ℤ)

/-- One modular cover removes a prime from the common denominator of the
remaining residual while preserving every other exponent bound. The cofactors
of the repair denominators divide D, and p itself does not divide D. -/
theorem exists_prime_cancellation {p D : ℕ} (hp : p.Prime) (hD : 0 < D)
    (hpD : ¬ p ∣ D) (s : ℚ) (hs : s.den ∣ p * D)
    (C : Finset ℕ) (hC : ∀ b ∈ C, b ∣ D) (hCover : CoversResidues p C) :
    ∃ J ⊆ C, (s - mass (mark p J)).den ∣ D := by
  let _ : Fact p.Prime := ⟨hp⟩
  have hpZ : (D : ZMod p) ≠ 0 :=
    fun h => hpD ((ZMod.natCast_eq_zero_iff _ _).mp h)
  obtain ⟨z, hz⟩ := exists_int_div_of_den_dvd s (Nat.mul_pos hp.pos hD) hs
  obtain ⟨J, hJ, hMod⟩ := hCover ((z : ZMod p) / (D : ZMod p))
  refine ⟨J, hJ, ?_⟩
  let A : ℕ := ∑ b ∈ J, D / b
  have hquot (b : ℕ) (hb : b ∈ J) : D / b * b = D :=
    Nat.div_mul_cancel (hC b (hJ hb))
  have hAq : (A : ℚ) = (D : ℚ) * mass J := by
    unfold A mass
    rw [Nat.cast_sum, mul_sum]
    apply sum_congr rfl
    intro b hb
    have hb₀ : b ≠ 0 := by
      intro h
      have hd := hC b (hJ hb)
      simp [h, hD.ne'] at hd
    have hbq : (b : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr hb₀
    rw [← div_eq_mul_inv, eq_div_iff hbq]
    exact_mod_cast hquot b hb
  have hAZ : (A : ZMod p) = (D : ZMod p) * ∑ b ∈ J, (b : ZMod p)⁻¹ := by
    unfold A
    rw [Nat.cast_sum, mul_sum]
    apply sum_congr rfl
    intro b hb
    have hbZ : (b : ZMod p) ≠ 0 :=
      fun hz => hpD (((ZMod.natCast_eq_zero_iff _ _).mp hz).trans (hC b (hJ hb)))
    rw [← div_eq_mul_inv, eq_div_iff hbZ, ← Nat.cast_mul, hquot b hb]
  have hAZ' : (A : ZMod p) = (z : ZMod p) := by
    rw [hAZ, hMod, ← mul_div_assoc, mul_comm (D : ZMod p), mul_div_cancel_right₀ _ hpZ]
  obtain ⟨v, hv⟩ : (p : ℤ) ∣ z - (A : ℤ) := by
    apply (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mp
    rw [Int.cast_sub, Int.cast_natCast, hAZ', sub_self]
  have hcast : (z : ℚ) - (A : ℚ) = (p : ℚ) * (v : ℚ) := by exact_mod_cast hv
  have hpq : (p : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr hp.ne_zero
  have hDq : (D : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr hD.ne'
  apply den_dvd_of_eq_int_div (z := v)
  rw [hz, Nat.cast_mul, mass_mark p hp.pos]
  have hMass : mass J = (A : ℚ) / (D : ℚ) := by
    apply (eq_div_iff hDq).2
    rw [mul_comm, ← hAq]
  rw [hMass, div_div, mul_comm (D : ℚ), ← sub_div, hcast]
  field_simp [hpq, hDq]


/-- Scaling a cofactor pool by a nonzero factor modulo p preserves full coverage. -/
theorem coversResidues_mark {p t : ℕ} (hp : p.Prime) (ht : 0 < t) (hpt : ¬ p ∣ t)
    (C : Finset ℕ) (hC : CoversResidues p C) : CoversResidues p (mark t C) := by
  let _ : Fact p.Prime := ⟨hp⟩
  intro z
  have htZ : (t : ZMod p) ≠ 0 := fun h => hpt ((ZMod.natCast_eq_zero_iff _ _).mp h)
  obtain ⟨J, hJ, hMod⟩ := hC ((t : ZMod p) * z)
  refine ⟨mark t J, image_subset_image hJ, ?_⟩
  rw [mark, sum_image (fun a _ b _ h => Nat.eq_of_mul_eq_mul_left ht h)]
  simp only [Nat.cast_mul, mul_inv_rev, mul_comm _ ((t : ZMod p)⁻¹), ← mul_sum]
  rw [hMod, inv_mul_cancel_left₀ htZ]

/-- The common denominator with its remaining medium primes. With y equal to the
integer cutoff and Q the medium primes, this is the denominator in F2 line 49. -/
def mediumDenominator (y : ℕ) (Q : Finset ℕ) : ℕ :=
  Nat.lcmUpto y * ∏ p ∈ Q, p

/-- The union of the reserved denominator pools for these medium primes. -/
def mediumPool (Q : Finset ℕ) (C : ℕ → Finset ℕ) : Finset ℕ :=
  Q.biUnion (fun p => mark p (C p))

private theorem prime_not_dvd_other_prime_product {p : ℕ} (hp : p.Prime)
    (Q : Finset ℕ) (hQ : ∀ q ∈ Q, q.Prime) (hpQ : p ∉ Q) :
    ¬ p ∣ ∏ q ∈ Q, q := by
  induction Q using Finset.induction_on with
  | empty => simpa using hp.not_dvd_one
  | @insert q Q hq ih =>
    rw [prod_insert hq]
    intro hd
    rcases hp.dvd_mul.mp hd with h | h
    · exact hpQ (mem_insert.mpr (Or.inl
          ((Nat.prime_dvd_prime_iff_eq hp (hQ q (mem_insert_self _ _))).mp h)))
    · exact ih (fun t ht => hQ t (mem_insert_of_mem ht))
        (fun h => hpQ (mem_insert_of_mem h)) h

/-- Iterate cancellation once per remaining prime. Each chosen denominator comes
from the reserved pool and the final reduced denominator divides the smooth lcm. -/
theorem exists_medium_repairs (y : ℕ) (Q : Finset ℕ) (C : ℕ → Finset ℕ)
    (hQ : ∀ p ∈ Q, p.Prime ∧ y < p)
    (hSmooth : ∀ p ∈ Q, ∀ b ∈ C p, b ∣ Nat.lcmUpto y)
    (hCover : ∀ p ∈ Q, CoversResidues p (C p))
    (s : ℚ) (hs : s.den ∣ mediumDenominator y Q) :
    ∃ F ⊆ mediumPool Q C, (s - mass F).den ∣ Nat.lcmUpto y := by
  induction Q using Finset.induction_on generalizing s with
  | empty =>
    exact ⟨∅, empty_subset _, by simpa [mediumDenominator, mass] using hs⟩
  | @insert p Q hpQ ih =>
    obtain ⟨hp, hpy⟩ := hQ p (mem_insert_self _ _)
    have hQ' (q : ℕ) (hq : q ∈ Q) := hQ q (mem_insert_of_mem hq)
    have hD : 0 < mediumDenominator y Q := by
      unfold mediumDenominator
      exact Nat.mul_pos (Nat.lcmUpto_pos y) (prod_pos fun q hq => (hQ' q hq).1.pos)
    have hpD : ¬ p ∣ mediumDenominator y Q := by
      unfold mediumDenominator
      intro hd
      rcases hp.dvd_mul.mp hd with h | h
      · exact prime_not_dvd_smooth hp hpy (dvd_refl _) h
      · exact prime_not_dvd_other_prime_product hp Q (fun q hq => (hQ' q hq).1) hpQ h
    have hSplit : mediumDenominator y (insert p Q) = p * mediumDenominator y Q := by
      simp only [mediumDenominator, prod_insert hpQ, Nat.mul_left_comm]
    have hSmoothp (b : ℕ) (hb : b ∈ C p) :
        b ∣ mediumDenominator y Q :=
      (hSmooth p (mem_insert_self _ _) b hb).trans (dvd_mul_right _ _)
    obtain ⟨J, hJ, hJden⟩ := exists_prime_cancellation hp hD hpD s
      (hSplit ▸ hs) (C p) hSmoothp (hCover p (mem_insert_self _ _))
    obtain ⟨F, hF, hFinal⟩ := ih hQ'
      (fun q hq => hSmooth q (mem_insert_of_mem hq))
      (fun q hq => hCover q (mem_insert_of_mem hq)) (s - mass (mark p J)) hJden
    have hDisj : Disjoint (mark p J) F := by
      apply disjoint_left.mpr
      intro a ha hFa
      obtain ⟨q, hq, ha'⟩ := mem_biUnion.mp (hF hFa)
      obtain ⟨b, hb, hba⟩ := mem_image.mp ha'
      have hpa : p ∣ a := by
        obtain ⟨_, _, rfl⟩ := mem_image.mp ha
        exact dvd_mul_right _ _
      rw [← hba] at hpa
      rcases hp.dvd_mul.mp hpa with hd | hd
      · exact hpQ (((Nat.prime_dvd_prime_iff_eq hp (hQ' q hq).1).mp hd).symm ▸ hq)
      · exact prime_not_dvd_smooth hp hpy (hSmooth q (mem_insert_of_mem hq) b hb) hd
    refine ⟨mark p J ∪ F, ?_, ?_⟩
    · unfold mediumPool
      rw [biUnion_insert]
      exact union_subset_union (image_subset_image hJ) hF
    · rw [mass_union hDisj, ← sub_sub]
      exact hFinal

/-- Bounds for an actual selection from reserved medium-prime pools. -/
theorem medium_repair_bounds {Q : Finset ℕ} {C : ℕ → Finset ℕ}
    (hQ : ∀ p ∈ Q, 0 < p) {F : Finset ℕ} (hF : F ⊆ mediumPool Q C) :
    F.card ≤ (∑ p ∈ Q, (C p).card) ∧
      mass F ≤ mass (mediumPool Q C) := by
  refine ⟨(card_le_card hF).trans ?_, mass_mono hF⟩
  unfold mediumPool
  refine card_biUnion_le.trans (le_of_eq ?_)
  exact sum_congr rfl fun p hp => card_mark p (hQ p hp) (C p)


/-- Reserved pools are disjoint across groups when their same-prime cofactor
families are disjoint. Distinct medium primes are separated by the smoothness
of their cofactors. -/
theorem medium_pool_pairwise_disjoint {ι : Type*} (y : ℕ) (Q : Finset ℕ)
    (C : ι → ℕ → Finset ℕ) (hQ : ∀ p ∈ Q, p.Prime ∧ y < p)
    (hSmooth : ∀ i p, p ∈ Q → ∀ b ∈ C i p, b ∣ Nat.lcmUpto y)
    (hC : ∀ p ∈ Q, Pairwise (fun i j => Disjoint (C i p) (C j p))) :
    Pairwise (fun i j => Disjoint (mediumPool Q (C i)) (mediumPool Q (C j))) := by
  intro i j hij
  apply disjoint_left.mpr
  intro a hai haj
  obtain ⟨p, hp, hap⟩ := mem_biUnion.mp hai
  obtain ⟨q, hq, haq⟩ := mem_biUnion.mp haj
  obtain ⟨b, hb, hbp⟩ := mem_image.mp hap
  obtain ⟨c, hc, hcq⟩ := mem_image.mp haq
  by_cases hpq : p = q
  · subst q
    have hbc := Nat.eq_of_mul_eq_mul_left (hQ p hp).1.pos (hbp.trans hcq.symm)
    exact disjoint_left.mp (hC p hp hij) hb (hbc ▸ hc)
  · have hpa : p ∣ q * c := ⟨b, hcq.trans hbp.symm⟩
    rcases (hQ p hp).1.dvd_mul.mp hpa with h | h
    · exact hpq ((Nat.prime_dvd_prime_iff_eq (hQ p hp).1 (hQ q hq).1).mp h)
    · exact prime_not_dvd_smooth (hQ p hp).1 (hQ p hp).2 (hSmooth j q hq c hc) h

/-- For each group perform all its medium-prime repairs independently, keeping
its revised residual positive and powersmooth. The bound counts denominators,
and exposes the precise per-group cost assumption used here. -/
theorem medium_repairs_by_group {ι : Type*} {d N y : ℕ} (Q : Finset ℕ)
    (C : ι → ℕ → Finset ℕ) (hQ : ∀ p ∈ Q, p.Prime ∧ y < p)
    (hSmooth : ∀ i p, p ∈ Q → ∀ b ∈ C i p, b ∣ Nat.lcmUpto y)
    (hCover : ∀ i p, p ∈ Q → CoversResidues p (C i p))
    (hC : ∀ p ∈ Q, Pairwise (fun i j => Disjoint (C i p) (C j p)))
    (hPool : ∀ i, mediumPool Q (C i) ⊆ interval d N)
    (Base : ι → Finset ℕ) (hBase : ∀ i, Base i ⊆ interval d N)
    (hBasePairwise : Pairwise (fun i j => Disjoint (Base i) (Base j)))
    (hBaseDisjoint : ∀ i j, Disjoint (Base i) (mediumPool Q (C j)))
    (r : ι → ℚ) {a δ η : ℚ} (ha : 0 < a) (hδ : 0 < δ) (hη : η ≤ δ)
    (hTarget : ∀ i, a ≤ r i)
    (hDen : ∀ i, (r i - mass (Base i)).den ∣ mediumDenominator y Q)
    (hGap : ∀ i, r i * δ ≤ r i - mass (Base i) ∧ r i - mass (Base i) ≤ r i * (δ + η))
    (hCost : ∀ i, mass (mediumPool Q (C i)) ≤ a * δ / 2) :
    ∃ F : ι → Finset ℕ, Pairwise (fun i j => Disjoint (Base i ∪ F i) (Base j ∪ F j)) ∧
      ∀ i, F i ⊆ mediumPool Q (C i) ∧
        (Base i ∪ F i) ⊆ interval d N ∧
        (r i - mass (Base i ∪ F i)).den ∣ Nat.lcmUpto y ∧
        a * δ / 2 ≤ r i - mass (Base i ∪ F i) ∧
        r i - mass (Base i ∪ F i) ≤ 2 * r i * δ ∧
        (F i).card ≤ ∑ p ∈ Q, (C i p).card := by
  classical
  have hExists (i : ι) := exists_medium_repairs y Q (C i) hQ (hSmooth i) (hCover i)
    (r i - mass (Base i)) (hDen i)
  choose F hF hFden using hExists
  have hFPairwise : Pairwise (fun i j => Disjoint (F i) (F j)) :=
    fun i j hij => Disjoint.mono (hF i) (hF j)
      (medium_pool_pairwise_disjoint y Q C hQ hSmooth hC hij)
  have hBF (i j : ι) : Disjoint (Base i) (F j) := (hBaseDisjoint i j).mono_right (hF j)
  refine ⟨F, ?_, fun i => ⟨hF i, union_subset (hBase i) ((hF i).trans (hPool i)), ?_⟩⟩
  · intro i j hij
    exact disjoint_union_left.mpr
      ⟨disjoint_union_right.mpr ⟨hBasePairwise hij, hBF i j⟩,
        disjoint_union_right.mpr ⟨(hBF j i).symm, hFPairwise hij⟩⟩
  · rw [mass_union (hBF i i), ← sub_sub]
    have hcap := medium_repair_bounds (fun p hp => (hQ p hp).1.pos) (hF i)
    have hbounds := medium_residual_bounds (r i) a δ η (r i - mass (Base i)) (mass (F i))
      (hTarget i) ((ha.trans_le (hTarget i)).le) hδ.le hη
      (hGap i).1 (hGap i).2 (mass_nonneg _) (hcap.2.trans (hCost i))
    exact ⟨hFden i, hbounds.1, hbounds.2, hcap.1⟩


/-- A product of primes at most B has a divisor within factor B of any
intermediate target T. This is the finite step of the dilation argument. -/
theorem exists_bounded_divisor {M B : ℕ} {T : ℚ} (hM : 0 < M) (hB : 0 < B)
    (hT : 1 ≤ T) (hMT : T ≤ (M : ℚ))
    (hPrimes : ∀ p, p.Prime → p ∣ M → p ≤ B) :
    ∃ t : ℕ, 0 < t ∧ t ∣ M ∧ T / (B : ℚ) ≤ (t : ℚ) ∧ (t : ℚ) ≤ T := by
  let choices := M.divisors.filter (fun t : ℕ => (t : ℚ) ≤ T)
  have hChoices : choices.Nonempty := ⟨1, mem_filter.mpr
    ⟨Nat.mem_divisors.mpr ⟨one_dvd _, hM.ne'⟩, by simpa using hT⟩⟩
  let t := choices.max' hChoices
  have ht : t ∈ choices := max'_mem _ _
  obtain ⟨htDiv, _⟩ := Nat.mem_divisors.mp (mem_filter.mp ht).1
  have htT : (t : ℚ) ≤ T := (mem_filter.mp ht).2
  have ht₀ : 0 < t := by
    by_contra! hz
    have : t = 0 := Nat.eq_zero_of_le_zero hz
    exact hM.ne' (by simpa [this] using htDiv)
  refine ⟨t, ht₀, htDiv, ?_, htT⟩
  by_contra! hsmall
  have hsmall' : (t : ℚ) * (B : ℚ) < T := (lt_div_iff₀ (Nat.cast_pos.mpr hB)).mp hsmall
  have hne : t ≠ M := by
    intro heq
    have hb₁ : (1 : ℚ) ≤ B := by exact_mod_cast hB
    have hm : (M : ℚ) ≤ (M : ℚ) * (B : ℚ) := by
      simpa only [mul_one] using mul_le_mul_of_nonneg_left hb₁ (Nat.cast_nonneg M)
    rw [heq] at hsmall'
    exact (not_lt_of_ge (hMT.trans hm)) hsmall'
  obtain ⟨p, hp, hpM, htp⟩ := Nat.exists_prime_and_dvd_and_dvd_div htDiv hne
  have hm : t * p ∣ M := by
    simpa only [Nat.mul_comm p t] using (Nat.dvd_div_iff_mul_dvd hpM).mp htp
  have hmT : ((t * p : ℕ) : ℚ) ≤ T := by
    rw [Nat.cast_mul]
    exact (mul_le_mul_of_nonneg_left (Nat.cast_le.mpr (hPrimes p hp hpM))
      (Nat.cast_nonneg t)).trans hsmall'.le
  have hmax : t * p ≤ t := le_max' _ _ (mem_filter.mpr
    ⟨Nat.mem_divisors.mpr ⟨hm, hM.ne'⟩, hmT⟩)
  have hlt : t < t * p := by
    simpa only [Nat.mul_one] using Nat.mul_lt_mul_of_pos_left hp.one_lt ht₀
  exact (not_lt_of_ge hmax) hlt

/-- The divisor-of-lcm convention stands for the bound on each positive prime
power dividing the number. -/
theorem dvd_lcmUpto_iff_prime_powers_le {n y : ℕ} (hn : 0 < n) (hy : 0 < y) :
    n ∣ Nat.lcmUpto y ↔
      ∀ p : ℕ, p.Prime → ∀ k : ℕ, p ^ k ∣ n → p ^ k ≤ y := by
  rw [← Nat.factorization_prime_le_iff_dvd hn.ne' (Nat.lcmUpto_ne_zero y)]
  constructor
  · intro ha p hp k hk
    refine (Nat.le_log_iff_pow_le hp.one_lt hy.ne').1 ?_
    exact ((hp.pow_dvd_iff_le_factorization hn.ne').1 hk).trans
      (by simpa only [Nat.factorization_lcmUpto y hp] using ha p hp)
  · intro ha p hp
    rw [Nat.factorization_lcmUpto y hp]
    exact (Nat.le_log_iff_pow_le hp.one_lt hy.ne').2
      (ha p hp _ ((hp.pow_dvd_iff_le_factorization hn.ne').2 le_rfl))

/-- Multiplication by a denominator a≤A raises each prime-power component
of the multiplier by at most A. -/
theorem powersmooth_mul_of_divides_lcm {t a A y : ℕ} (ht : 0 < t) (ha₀ : 0 < a)
    (ha : a ≤ A) (hCut : 0 < y / A) (htDiv : t ∣ Nat.lcmUpto (y / A)) :
    t * a ∣ Nat.lcmUpto y := by
  have hy : 0 < y := hCut.trans_le (Nat.div_le_self _ _)
  rw [← Nat.factorization_prime_le_iff_dvd (Nat.mul_pos ht ha₀).ne' (Nat.lcmUpto_ne_zero y)]
  intro p hp
  rw [Nat.factorization_lcmUpto y hp, Nat.factorization_mul ht.ne' ha₀.ne', Finsupp.add_apply]
  apply (Nat.le_log_iff_pow_le hp.one_lt hy.ne').2
  rw [pow_add]
  have htPow : p ^ t.factorization p ≤ y / A :=
    (dvd_lcmUpto_iff_prime_powers_le ht hCut).mp htDiv p hp _
      ((hp.pow_dvd_iff_le_factorization ht.ne').2 le_rfl)
  have haPow : p ^ a.factorization p ≤ A :=
    (Nat.le_of_dvd ha₀ ((hp.pow_dvd_iff_le_factorization ha₀.ne').2 le_rfl)).trans ha
  exact (Nat.mul_le_mul htPow haPow).trans (Nat.div_mul_le_self _ _)

/-- The finite powersmooth dilation used to construct medium- and large-prime
covers, under the explicit product-size condition for the available factors. -/
theorem finite_powersmooth_dilation {N A p y B M : ℕ}
    (hp : p.Prime) (hpy : y < p) (hA : 0 < A) (hpA : p * A ≤ N)
    (hCut : 0 < y / A) (hB : 0 < B) (hM : 0 < M)
    (hMdiv : M ∣ Nat.lcmUpto (y / A))
    (hPrimes : ∀ l, l.Prime → l ∣ M → l ≤ B)
    (hSupply : (N : ℚ) / ((p : ℚ) * A) ≤ (M : ℚ)) :
    ∃ t : ℕ, 0 < t ∧
      (N : ℚ) / ((B : ℚ) * p * A) ≤ (t : ℚ) ∧ (t : ℚ) ≤ (N : ℚ) / ((p : ℚ) * A) ∧
      ∀ a : ℕ, 0 < a → a ≤ A → t * a ∣ Nat.lcmUpto y ∧ ¬ p ∣ t * a := by
  have hT : (1 : ℚ) ≤ (N : ℚ) / ((p : ℚ) * A) := by
    apply (le_div_iff₀ (mul_pos (Nat.cast_pos.mpr hp.pos) (Nat.cast_pos.mpr hA))).2
    rw [one_mul]
    exact_mod_cast hpA
  obtain ⟨t, ht, htDiv, hLo, hHi⟩ := exists_bounded_divisor hM hB hT hSupply hPrimes
  have hLo' : (N : ℚ) / ((B : ℚ) * p * A) ≤ (t : ℚ) := by
    convert hLo using 1
    rw [div_div]
    ring_nf
  refine ⟨t, ht, hLo', hHi, fun a ha₀ ha => ?_⟩
  have hta := powersmooth_mul_of_divides_lcm ht ha₀ ha hCut (htDiv.trans hMdiv)
  exact ⟨hta, prime_not_dvd_smooth hp hpy hta⟩


/-- The entire finite three-step repair, with explicit modular coverage, uniform
smooth closure, pool bounds, and marker-scale hypotheses. The length bound counts
the actual denominators chosen at each step. -/
theorem finite_three_stage_repair_of_distinct_markers {ι : Type*} [Fintype ι]
    {d N y C₀ X₀ : ℕ} (hN : 0 < N) (hClosure : UniformSmoothClosure C₀ X₀)
    (P : ι → ℕ) (hP : ∀ i, (P i).Prime) (hPdistinct : Function.Injective P)
    (hEight : ∀ i, 8 * P i ≤ N)
    (hScale : ∀ i, X₀ ≤ markerScale N C₀ (P i) ∧
      0 < markerScale N C₀ (P i) ∧ d ≤ P i * markerScale N C₀ (P i))
    (hCutoff : ∀ i, y ≤ Nat.nthRoot 5 (markerScale N C₀ (P i)))
    (hDistinctCutoff : ∀ i j, Nat.nthRoot 5 (markerScale N C₀ (P i)) < P j)
    (Q : Finset ℕ) (C : ι → ℕ → Finset ℕ) (hQ : ∀ p ∈ Q, p.Prime ∧ y < p)
    (hNotMarker : ∀ p ∈ Q, ∀ i, p ≠ P i)
    (hSmooth : ∀ i p, p ∈ Q → ∀ b ∈ C i p, b ∣ Nat.lcmUpto y)
    (hCover : ∀ i p, p ∈ Q → CoversResidues p (C i p))
    (hC : ∀ p ∈ Q, Pairwise (fun i j => Disjoint (C i p) (C j p)))
    (hMedium : ∀ i, mediumPool Q (C i) ⊆ interval d N)
    (Base : ι → Finset ℕ) (hBase : ∀ i, Base i ⊆ interval d N)
    (hBasePairwise : Pairwise (fun i j => Disjoint (Base i) (Base j)))
    (hBaseMedium : ∀ i j, Disjoint (Base i) (mediumPool Q (C j)))
    (hBaseAvoid : ∀ i a, a ∈ Base i → ∀ j, ¬P j ∣ a)
    (Pool : Finset ℕ) (hPool : Pool ⊆ interval d N)
    (hHalf : ∀ a ∈ Pool, N ≤ 2 * a)
    (hPoolSmooth : ∀ a ∈ Pool, a ∣ Nat.lcmUpto y)
    (hBaseSmooth : ∀ i, Disjoint (Base i) Pool)
    (r : ι → ℚ) {a δ η : ℚ} (ha : 0 < a) (hδ : 0 < δ) (hη : η ≤ δ)
    (hTarget : ∀ i, a ≤ r i)
    (hDen : ∀ i, (r i - mass (Base i)).den ∣ mediumDenominator y Q)
    (hGap : ∀ i, r i * δ ≤ r i - mass (Base i) ∧ r i - mass (Base i) ≤ r i * (δ + η))
    (hCost : ∀ i, mass (mediumPool Q (C i)) ≤ a * δ / 2)
    (hLower : ∀ i, markerLower (P i) ≤ a * δ / 2)
    (hVolume : ∑ i, 2 * r i * δ ≤ mass Pool) :
    ∃ F E G : ι → Finset ℕ,
      Pairwise (fun i j => Disjoint (Base i ∪ F i ∪ E i ∪ G i)
        (Base j ∪ F j ∪ E j ∪ G j)) ∧
      ∀ i, F i ⊆ mediumPool Q (C i) ∧ E i ⊆ Pool ∧
        (Base i ∪ F i ∪ E i ∪ G i) ⊆ interval d N ∧
        mass (Base i ∪ F i ∪ E i ∪ G i) = r i ∧
        ((Base i ∪ F i ∪ E i ∪ G i).card : ℚ) ≤ (Base i).card +
          (∑ p ∈ Q, ((C i p).card : ℚ)) +
          (N : ℚ) * (2 * r i * δ) + (C₀ * markerScale N C₀ (P i) : ℕ) := by
  obtain ⟨F, hFPair, hF⟩ := medium_repairs_by_group Q C hQ hSmooth hCover hC hMedium
    Base hBase hBasePairwise hBaseMedium r ha hδ hη hTarget hDen hGap hCost
  let Augmented (i : ι) := Base i ∪ F i
  have hAugAvoid (i b) (hb : b ∈ Augmented i) (j) : ¬ P j ∣ b := by
    rcases mem_union.mp hb with hb | hb
    · exact hBaseAvoid i b hb j
    · obtain ⟨p, hp, hbp⟩ := mem_biUnion.mp ((hF i).1 hb)
      obtain ⟨c, hc, rfl⟩ := mem_image.mp hbp
      intro hd
      rcases (hP j).dvd_mul.mp hd with hd | hd
      · exact hNotMarker p hp j (((Nat.dvd_prime (hQ p hp).1).mp hd).resolve_left (hP j).ne_one).symm
      · exact prime_not_dvd_smooth (hP j) ((hCutoff j).trans_lt (hDistinctCutoff j j))
          (hSmooth i p hp c hc) hd
  have hAugPool (i : ι) : Disjoint (Augmented i) Pool := by
    refine disjoint_union_left.mpr ⟨hBaseSmooth i, disjoint_left.mpr ?_⟩
    intro b hb hbPool
    obtain ⟨p, hp, hbp⟩ := mem_biUnion.mp ((hF i).1 hb)
    obtain ⟨c, hc, rfl⟩ := mem_image.mp hbp
    exact prime_not_dvd_smooth (hQ p hp).1 (hQ p hp).2 (hPoolSmooth _ hbPool) (dvd_mul_right _ _)
  have hAugVolume : ∑ i, (r i - mass (Augmented i)) ≤ mass Pool :=
    (sum_le_sum fun i _ => (hF i).2.2.2.2.1).trans hVolume
  obtain ⟨E, G, hEGPair, hEG⟩ := finish_smooth_and_marked_closure hN hClosure P hP hPdistinct
    hEight hScale hCutoff hDistinctCutoff Augmented (fun i => (hF i).2.1)
    hFPair hAugAvoid Pool hPool hHalf hPoolSmooth hAugPool r
      (fun i => (hLower i).trans (hF i).2.2.2.1) (fun i => (hF i).2.2.1) hAugVolume
  refine ⟨F, E, G, hEGPair, fun i => ⟨(hF i).1, (hEG i).1, (hEG i).2.1, (hEG i).2.2.1, ?_⟩⟩
  have hCardNat := (card_union_le (Base i) (F i)).trans
    (Nat.add_le_add_left (hF i).2.2.2.2.2 (Base i).card)
  have hCard : ((Augmented i).card : ℚ) ≤ (Base i).card + ∑ p ∈ Q, ((C i p).card : ℚ) := by
    exact_mod_cast hCardNat
  exact (hEG i).2.2.2.trans
    (add_le_add (add_le_add hCard (mul_le_mul_of_nonneg_left (hF i).2.2.2.2.1 (Nat.cast_nonneg N))) le_rfl)


/-- The entire finite three-step repair, with explicit modular coverage, uniform
smooth closure, pool bounds, and marker-scale hypotheses. The length bound counts
the actual denominators chosen at each step. -/
theorem finite_three_stage_repair {ι : Type*} [Fintype ι]
    {d N y C₀ X₀ : ℕ} (hN : 0 < N) (hClosure : UniformSmoothClosure C₀ X₀)
    (P : ι → ℕ) (hP : ∀ i, (P i).Prime) (hPdistinct : Function.Injective P)
    (hEight : ∀ i, 8 * P i ≤ N)
    (hScale : ∀ i, X₀ ≤ markerScale N C₀ (P i) ∧
      0 < markerScale N C₀ (P i) ∧ d ≤ P i * markerScale N C₀ (P i))
    (hCutoff : ∀ i, y ≤ Nat.nthRoot 5 (markerScale N C₀ (P i)))
    (hDistinctCutoff : ∀ i j, Nat.nthRoot 5 (markerScale N C₀ (P i)) < P j)
    (Q : Finset ℕ) (C : ι → ℕ → Finset ℕ) (hQ : ∀ p ∈ Q, p.Prime ∧ y < p)
    (hOrdering : ∀ p ∈ Q, ∀ i, p < P i)
    (hSmooth : ∀ i p, p ∈ Q → ∀ b ∈ C i p, b ∣ Nat.lcmUpto y)
    (hCover : ∀ i p, p ∈ Q → CoversResidues p (C i p))
    (hC : ∀ p ∈ Q, Pairwise (fun i j => Disjoint (C i p) (C j p)))
    (hMedium : ∀ i, mediumPool Q (C i) ⊆ interval d N)
    (Base : ι → Finset ℕ) (hBase : ∀ i, Base i ⊆ interval d N)
    (hBasePairwise : Pairwise (fun i j => Disjoint (Base i) (Base j)))
    (hBaseMedium : ∀ i j, Disjoint (Base i) (mediumPool Q (C j)))
    (hBaseAvoid : ∀ i a, a ∈ Base i → ∀ j, ¬P j ∣ a)
    (Pool : Finset ℕ) (hPool : Pool ⊆ interval d N)
    (hHalf : ∀ a ∈ Pool, N ≤ 2 * a)
    (hPoolSmooth : ∀ a ∈ Pool, a ∣ Nat.lcmUpto y)
    (hBaseSmooth : ∀ i, Disjoint (Base i) Pool)
    (r : ι → ℚ) {a δ η : ℚ} (ha : 0 < a) (hδ : 0 < δ) (hη : η ≤ δ)
    (hTarget : ∀ i, a ≤ r i)
    (hDen : ∀ i, (r i - mass (Base i)).den ∣ mediumDenominator y Q)
    (hGap : ∀ i, r i * δ ≤ r i - mass (Base i) ∧ r i - mass (Base i) ≤ r i * (δ + η))
    (hCost : ∀ i, mass (mediumPool Q (C i)) ≤ a * δ / 2)
    (hLower : ∀ i, markerLower (P i) ≤ a * δ / 2)
    (hVolume : ∑ i, 2 * r i * δ ≤ mass Pool) :
    ∃ F E G : ι → Finset ℕ,
      Pairwise (fun i j => Disjoint (Base i ∪ F i ∪ E i ∪ G i)
        (Base j ∪ F j ∪ E j ∪ G j)) ∧
      ∀ i, F i ⊆ mediumPool Q (C i) ∧ E i ⊆ Pool ∧
        (Base i ∪ F i ∪ E i ∪ G i) ⊆ interval d N ∧
        mass (Base i ∪ F i ∪ E i ∪ G i) = r i ∧
        ((Base i ∪ F i ∪ E i ∪ G i).card : ℚ) ≤ (Base i).card +
          (∑ p ∈ Q, ((C i p).card : ℚ)) +
          (N : ℚ) * (2 * r i * δ) + (C₀ * markerScale N C₀ (P i) : ℕ) :=
  finite_three_stage_repair_of_distinct_markers hN hClosure P hP hPdistinct hEight hScale hCutoff
    hDistinctCutoff Q C hQ (fun p hp i => (hOrdering p hp i).ne) hSmooth hCover hC hMedium
    Base hBase hBasePairwise hBaseMedium hBaseAvoid Pool hPool hHalf hPoolSmooth hBaseSmooth
    r ha hδ hη hTarget hDen hGap hCost hLower hVolume


/-- The product of the maximal powers of the primes up to B supplies the
bounded prime factors for the finite dilation. -/
theorem exists_dilation_supply (B Y : ℕ) (hB : 0 < B) (hBY : B ≤ Y) :
    ∃ M : ℕ, 0 < M ∧ M ∣ Nat.lcmUpto Y ∧
      (∀ p, p.Prime → p ∣ M → p ≤ B) ∧
      (Y / B) ^ (Nat.primesLE B).card ≤ M := by
  let M := ∏ q ∈ Nat.primesLE B, q ^ q.log Y
  have hM : 0 < M :=
    prod_pos fun q hq => pow_pos (Nat.prime_of_mem_primesLE hq).pos _
  have hDiv : M ∣ Nat.lcmUpto Y := by
    rw [Nat.lcmUpto_eq_prod_pow_log]
    exact prod_dvd_prod_of_subset _ _ _ (Nat.primesLE_mono hBY)
  refine ⟨M, hM, hDiv, ?_, ?_⟩
  · intro p hp hpM
    by_contra! hlt
    have hn (S : Finset ℕ) (hS : S ⊆ Nat.primesLE B) :
        ¬ p ∣ ∏ q ∈ S, q ^ q.log Y := by
      induction S using Finset.induction_on with
      | empty => simpa using hp.not_dvd_one
      | @insert q S hq ih =>
        rw [prod_insert hq]
        intro hd
        rcases hp.dvd_mul.mp hd with he | he
        · have hdq := hp.dvd_of_dvd_pow he
          exact hlt.not_ge ((Nat.le_of_dvd (Nat.prime_of_mem_primesLE (hS (mem_insert_self _ _))).pos hdq).trans
            (Nat.le_of_mem_primesLE (hS (mem_insert_self _ _))))
        · exact ih (fun u hu => hS (mem_insert_of_mem hu)) he
    exact hn _ subset_rfl hpM
  · calc
      _ = ∏ _q ∈ Nat.primesLE B, (Y / B) := by simp
      _ ≤ M := by
        apply prod_le_prod
        intro q hq
        have hlt := Nat.lt_pow_succ_log_self (Nat.prime_of_mem_primesLE hq).one_lt Y
        rw [pow_succ] at hlt
        exact ((Nat.div_lt_iff_lt_mul hB).2 (hlt.trans_le
          (Nat.mul_le_mul_left _ (Nat.le_of_mem_primesLE hq)))).le

/-- The first 40 primes provide the paper's explicit dilation constant, with the
remaining analytic supply inequality exposed as a single natural-number bound. -/
theorem finite_powersmooth_dilation_first_primes {N A p y : ℕ}
    (hp : p.Prime) (hpy : y < p) (hA : 0 < A) (hpA : p * A ≤ N)
    (hCut : 173 ≤ y / A) (hSupply : N ≤ ((y / A) / 173) ^ 40) :
    ∃ t : ℕ, 0 < t ∧
      (N : ℚ) / ((173 : ℚ) * p * A) ≤ (t : ℚ) ∧ (t : ℚ) ≤ (N : ℚ) / ((p : ℚ) * A) ∧
      ∀ a : ℕ, 0 < a → a ≤ A → t * a ∣ Nat.lcmUpto y ∧ ¬ p ∣ t * a := by
  obtain ⟨M, hM, hD, hB, hL⟩ := exists_dilation_supply 173 (y / A) (by decide) hCut
  have h40 : (Nat.primesLE 173).card = 40 := by decide +kernel
  rw [h40] at hL
  have hMN : (N : ℚ) ≤ M := by exact_mod_cast hSupply.trans hL
  have hDenom : (1 : ℚ) ≤ (p : ℚ) * (A : ℚ) := by
    exact_mod_cast (Nat.mul_pos hp.pos hA : 1 ≤ p * A)
  have hle : (N : ℚ) / ((p : ℚ) * (A : ℚ)) ≤ (N : ℚ) :=
    div_le_self (Nat.cast_nonneg _) hDenom
  exact finite_powersmooth_dilation hp hpy hA hpA (by omega) (by decide) hM hD hB (hle.trans hMN)


/-- Remove a modularly selected subset from an available block. This proves
finite large-prime deletion when the block and the cover meet the hypotheses. -/
theorem exists_block_cancellation {p D : ℕ} (hp : p.Prime) (hD : 0 < D)
    (hpD : ¬ p ∣ D) (V C : Finset ℕ) (hDen : (mass V).den ∣ p * D)
    (hAvail : mark p C ⊆ V) (hC : ∀ b ∈ C, b ∣ D) (hCover : CoversResidues p C) :
    ∃ S ⊆ V, (mass S).den ∣ D ∧ mass V - mass S ≤ mass C / (p : ℚ) := by
  obtain ⟨J, hJ, hJden⟩ := exists_prime_cancellation hp hD hpD (mass V) hDen C hC hCover
  have hdel : mark p J ⊆ V := (image_subset_image hJ).trans hAvail
  have heq : mass (V \ mark p J) = mass V - mass (mark p J) :=
    sum_sdiff_eq_sub hdel
  refine ⟨V \ mark p J, sdiff_subset, ?_, ?_⟩
  · rwa [heq]
  · rw [heq, sub_sub_cancel, mass_mark p hp.pos]
    exact div_le_div_of_nonneg_right (mass_mono hJ) (Nat.cast_nonneg p)

/-- A scaled cover with the dilation lower bound yields the exact per-block
deletion cost used in F2 lines 275–298. -/
theorem exists_scaled_block_cancellation {p t D N B Q : ℕ}
    (hp : p.Prime) (ht : 0 < t) (hD : 0 < D) (hN : 0 < N) (hpD : ¬ p ∣ D)
    (hpt : ¬ p ∣ t) (V : Finset ℕ) (hDen : (mass V).den ∣ p * D)
    (hAvail : mark p (mark t (interval 1 Q)) ⊆ V)
    (hC : ∀ b ∈ interval 1 Q, t * b ∣ D)
    (hCover : CoversResidues p (interval 1 Q))
    (hLower : N ≤ B * Q * p * t) :
    ∃ S ⊆ V, (mass S).den ∣ D ∧
      mass V - mass S ≤ (B : ℚ) * (Q : ℚ) * mass (interval 1 Q) / (N : ℚ) := by
  obtain ⟨S, hS, hSden, hCost⟩ := exists_block_cancellation hp hD hpD V
    (mark t (interval 1 Q)) hDen hAvail
    (fun b hb => by obtain ⟨a, ha, rfl⟩ := mem_image.mp hb; exact hC a ha)
    (coversResidues_mark hp ht hpt _ hCover)
  refine ⟨S, hS, hSden, hCost.trans ?_⟩
  rw [mass_mark t ht, div_div]
  apply (div_le_div_iff₀ (mul_pos (Nat.cast_pos.mpr ht) (Nat.cast_pos.mpr hp.pos))
    (Nat.cast_pos.mpr hN)).2
  have hq : (N : ℚ) ≤ (B : ℚ) * (Q : ℚ) * (p : ℚ) * (t : ℚ) := by exact_mod_cast hLower
  have hMul := mul_le_mul_of_nonneg_right hq (mass_nonneg (interval 1 Q))
  nlinarith

open Filter
open scoped Topology


theorem eventually_dilation_supply :
    ∀ᶠ N : ℕ in atTop, ∀ A : ℕ, 0 < A →
      A ≤ 2 * ⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ →
      173 ≤ ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ / A ∧
        N ≤ ((⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ / A) / 173) ^ 40 := by
  have hNat : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hGrowth : Tendsto (fun N : ℕ => (N : ℝ) ^ (1 / 100 : ℝ)) atTop atTop :=
    (tendsto_rpow_atTop (show (0 : ℝ) < 1 / 100 by norm_num)).comp hNat
  have hLogPow := (isLittleO_log_rpow_rpow_atTop 12 (show (0 : ℝ) < 1 / 100 by norm_num)).bound
    (show (0 : ℝ) < 1 / 4 by norm_num)
  filter_upwards [hGrowth.eventually_ge_atTop 346, hNat.eventually hLogPow,
    eventually_ge_atTop (1 : ℕ)] with N hLarge hSmall hN A hA hAb
  have hNreal : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hN₀ : (0 : ℝ) ≤ N := (by norm_num : (0 : ℝ) ≤ 1).trans hNreal
  let R : ℕ := ⌈(N : ℝ) ^ (1 / 40 : ℝ)⌉₊
  have hR₁ : (1 : ℝ) ≤ (N : ℝ) ^ (1 / 40 : ℝ) :=
    Real.one_le_rpow hNreal (by norm_num)
  have hRpos : 0 < R := by
    have hceil : (N : ℝ) ^ (1 / 40 : ℝ) ≤ (R : ℝ) := Nat.le_ceil _
    exact_mod_cast (show (0 : ℝ) < R by linarith)
  have hR : (R : ℝ) ≤ 2 * (N : ℝ) ^ (1 / 40 : ℝ) := by
    have hceil : (R : ℝ) < (N : ℝ) ^ (1 / 40 : ℝ) + 1 :=
      Nat.ceil_lt_add_one (by positivity)
    linarith
  have hC : Real.log (N : ℝ) ^ (12 : ℕ) ≤ (1 / 4 : ℝ) * (N : ℝ) ^ (1 / 100 : ℝ) := by
    have hRpow : Real.log (N : ℝ) ^ (12 : ℝ) = Real.log (N : ℝ) ^ (12 : ℕ) := by
      simpa only [Nat.cast_ofNat] using Real.rpow_natCast (Real.log (N : ℝ)) 12
    change ‖Real.log (N : ℝ) ^ (12 : ℝ)‖ ≤ (1 / 4 : ℝ) * ‖(N : ℝ) ^ (1 / 100 : ℝ)‖ at hSmall
    rw [hRpow, Real.norm_of_nonneg (by positivity), Real.norm_of_nonneg (by positivity)] at hSmall
    exact hSmall
  have hA' : (A : ℝ) ≤ (N : ℝ) ^ (1 / 100 : ℝ) := by
    have hAb' : (A : ℝ) ≤ 2 * (⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ : ℕ) := by exact_mod_cast hAb
    have hc := Nat.ceil_lt_add_one (show 0 ≤ Real.log (N : ℝ) ^ (12 : ℕ) by positivity)
    linarith
  have hFloor : 173 * R * A ≤ ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ := by
    apply Nat.le_floor
    push_cast
    calc
      _ ≤ 173 * (2 * (N : ℝ) ^ (1 / 40 : ℝ)) * (N : ℝ) ^ (1 / 100 : ℝ) := by
        exact mul_le_mul (mul_le_mul_of_nonneg_left hR (by norm_num)) hA' (by positivity) (by positivity)
      _ = (346 : ℝ) * (N : ℝ) ^ (1 / 40 : ℝ) * (N : ℝ) ^ (1 / 100 : ℝ) := by ring
      _ ≤ (N : ℝ) ^ (1 / 100 : ℝ) * (N : ℝ) ^ (1 / 40 : ℝ) * (N : ℝ) ^ (1 / 100 : ℝ) :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hLarge (by positivity)) (by positivity)
      _ = (N : ℝ) ^ (9 / 200 : ℝ) := by
        rw [← Real.rpow_add (by positivity : (0 : ℝ) < N), ← Real.rpow_add (by positivity : (0 : ℝ) < N)]
        norm_num
      _ ≤ (N : ℝ) ^ (1 / 20 : ℝ) := Real.rpow_le_rpow_of_exponent_le hNreal (by norm_num)
  have hCut : 173 * R ≤ ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ / A :=
    (Nat.le_div_iff_mul_le hA).2 hFloor
  have hRoot : R ≤ (⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ / A) / 173 :=
    (Nat.le_div_iff_mul_le (by decide : 0 < 173)).2 (by simpa [Nat.mul_comm] using hCut)
  have h173 : 173 ≤ ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ / A := by
    have hh : 173 * 1 ≤ 173 * R := Nat.mul_le_mul_left _ hRpos
    simpa only [Nat.mul_one] using hh.trans hCut
  refine ⟨h173, ?_⟩
  have hRp : (N : ℝ) ≤ (R : ℝ) ^ (40 : ℕ) := by
    calc
      _ = ((N : ℝ) ^ (1 / 40 : ℝ)) ^ (40 : ℕ) := by
        rw [← Real.rpow_natCast, ← Real.rpow_mul hN₀]
        norm_num
      _ ≤ _ := pow_le_pow_left₀ (by positivity) (Nat.le_ceil _) _
  exact (by exact_mod_cast hRp : N ≤ R ^ 40).trans (Nat.pow_le_pow_left hRoot _)

/-- F2 powersmooth dilation, uniformly for all allowed lengths A and primes p
once N is sufficiently large. -/
theorem eventually_powersmooth_dilation :
    ∀ᶠ N : ℕ in atTop, ∀ A : ℕ, 0 < A →
      A ≤ 2 * ⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ →
      ∀ p : ℕ, p.Prime → ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ < p → p * A ≤ N →
        ∃ t : ℕ, 0 < t ∧
          (N : ℚ) / ((173 : ℚ) * p * A) ≤ (t : ℚ) ∧
          (t : ℚ) ≤ (N : ℚ) / ((p : ℚ) * A) ∧
          ∀ a : ℕ, 0 < a → a ≤ A →
            t * a ∣ Nat.lcmUpto ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ ∧ ¬ p ∣ t * a := by
  filter_upwards [eventually_dilation_supply] with N hN A hA hAb p hp hpy hpA
  exact finite_powersmooth_dilation_first_primes hp hpy hA hpA (hN A hA hAb).1 (hN A hA hAb).2

end LeanAB.PaperB.Closure
