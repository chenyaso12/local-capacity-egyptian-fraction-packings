module

public import PaperB.Allocation
public import PaperB.Obstruction.PrimeMass
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
public import Mathlib.Analysis.SpecialFunctions.Pow.NthRootLemmas
public import Mathlib.Data.List.Sort
public import Mathlib.Data.List.Nodup
meta import Mathlib.Tactic

/-! Greedy allocation of the actual near-capacity blocks into unit targets. -/

@[expose] public section

namespace LeanAB.PaperB.Allocation

open scoped BigOperators
open Finset

/-- Any finite family of disjoint nonempty blocks can be indexed in increasing
effective denominator, keeping every actual denominator set. -/
theorem exists_sorted_blockList {d N : ℕ} (F : Finset (Finset ℕ))
    (hF : ∀ S ∈ F, S.Nonempty ∧ S ⊆ interval d N)
    (hDisj : (↑F : Set (Finset ℕ)).PairwiseDisjoint id) :
    ∃ B : BlockList d N, (range B.length).image B.block = F ∧
      Set.InjOn B.block (↑(range B.length) : Set ℕ) := by
  classical
  let eff (S : Finset ℕ) : ℚ := (S.card : ℚ) / mass S
  let cmp (S T : Finset ℕ) : Bool := decide (eff S ≤ eff T)
  let L := F.toList.mergeSort cmp
  have hPerm : L.Perm F.toList := List.mergeSort_perm _ _
  have hMem (S : Finset ℕ) : S ∈ L ↔ S ∈ F := hPerm.mem_iff.trans Finset.mem_toList
  have hNodup : L.Nodup := hPerm.nodup_iff.mpr F.nodup_toList
  have hSort : L.Pairwise (fun S T => cmp S T = true) := by
    apply List.pairwise_mergeSort
    · intro a b c hab hbc
      exact decide_eq_true ((of_decide_eq_true hab : eff a ≤ eff b).trans
        (of_decide_eq_true hbc : eff b ≤ eff c))
    · intro a b
      rcases le_total (eff a) (eff b) with h | h
      · simp [cmp, h]
      · simp [cmp, h]
  let block (k : ℕ) := if hk : k < L.length then L.get ⟨k, hk⟩ else ∅
  have hGet (k : ℕ) (hk : k < L.length) : block k = L.get ⟨k, hk⟩ := dite_eq_left hk
  have hBlockMem {k : ℕ} (hk : k < L.length) : block k ∈ F := by
    rw [hGet _ hk, ← hMem]
    exact List.mem_iff_get.mpr ⟨⟨k, hk⟩, rfl⟩
  have hInj : Set.InjOn block (↑(range L.length) : Set ℕ) := by
    intro k hk l hl heq
    rw [hGet k (mem_range.mp hk), hGet l (mem_range.mp hl)] at heq
    exact congrArg Fin.val (hNodup.injective_get heq)
  have hDis : (↑(range L.length) : Set ℕ).PairwiseDisjoint block := by
    intro k hk l hl hkl
    exact hDisj (hBlockMem (mem_range.mp hk)) (hBlockMem (mem_range.mp hl))
      (fun h => hkl (hInj hk hl h))
  have hOrdered : MonotoneOn (fun k => ((block k).card : ℚ) / mass (block k))
      {k | k < L.length} := by
    intro k hk l hl hkl
    change k < L.length at hk
    change l < L.length at hl
    rcases eq_or_lt_of_le hkl with rfl | h
    · rfl
    · simpa [eff, hGet _ hk, hGet _ hl] using
        (of_decide_eq_true (List.pairwise_iff_get.mp hSort
          (⟨k, hk⟩ : Fin L.length) ⟨l, hl⟩ h) : eff (L.get ⟨k, hk⟩) ≤ eff (L.get ⟨l, hl⟩))
  refine ⟨⟨L.length, block, fun _ hk => (hF _ (hBlockMem hk)).1,
    fun _ hk => (hF _ (hBlockMem hk)).2, hDis, hOrdered⟩, ?_, hInj⟩
  ext S
  change S ∈ (range L.length).image block ↔ S ∈ F
  constructor
  · intro hS
    obtain ⟨k, hk, rfl⟩ := mem_image.mp hS
    exact hBlockMem (mem_range.mp hk)
  · intro hS
    obtain ⟨k, hk⟩ := List.mem_iff_get.mp ((hMem S).mpr hS)
    exact mem_image.mpr ⟨k, mem_range.mpr k.isLt, (hGet _ k.isLt).trans hk⟩

/-- The finite unit-target allocation used in the near-capacity proof. Its
prefix estimates leave a fixed margin for the at most 100 exceptional groups. -/
theorem nearCapacity_unit_allocation {N m D : ℕ} (hm : 100 < m)
    (B : BlockList 2 N) (E : Finset ℕ)
    (hBlockDen : ∀ k < B.length, (B.weight k).den ∣ D)
    (hAvoid : ∀ k < B.length, Disjoint (B.block k) E)
    {early base : ℕ} (he : early ≤ base) (hb : base ≤ B.length)
    {δ η X : ℚ} (hδ : 0 < δ) (hδsmall : δ ≤ 1 / 5)
    (hη : 0 ≤ η) (hηsmall : η ≤ 1 / 100) (hX : 0 ≤ X)
    (hSingleton : ∀ k < early, ∃ n : ℕ, B.block k = {n})
    (hEarlyWeight : ∑ k ∈ range early, B.weight k ≤ (13 / 50 : ℚ) * m)
    (hLater : ∀ k, early ≤ k → k < B.length → B.weight k ≤ η)
    (hMass : (m : ℚ) ≤ ∑ k ∈ range B.length, B.weight k)
    (hCutoff : ∀ k < base, B.effective k ≤ X)
    (hPrefix : (3 / 10 : ℚ) * m + 100 ≤ ∑ k ∈ range base, B.weight k) :
    ∃ A : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (A i) (A j)) ∧
      ∀ i, A i ⊆ interval 2 N ∧ Disjoint (A i) E ∧
        δ ≤ 1 - mass (A i) ∧ 1 - mass (A i) ≤ δ + η ∧
        (1 - mass (A i)).den ∣ D ∧
        ((A i).card : ℚ) ≤ X + (N : ℚ) / (↑(m - 100 : ℕ) : ℚ) + 2 * η * N := by
  classical
  let : Nonempty (Fin m) := ⟨⟨0, by omega⟩⟩
  let r : Fin m → ℚ := fun _ => 1
  let special := B.specialGroups r early 100
  let regular := univ \ special
  have hr : ∀ i, 0 < r i := fun _ => by norm_num [r]
  have hR (S : Finset (Fin m)) : (∑ i ∈ S, r i) = (S.card : ℚ) := by simp [r]
  have hAll : (∑ i, r i) = (m : ℚ) := by rw [hR, card_univ, Fintype.card_fin]
  have hSpecial : special.card ≤ 100 := B.card_specialGroups_le r (he.trans hb) 100
  have hDiff : regular.card = m - special.card := by
    have hSplit := card_sdiff_add_card_eq_card (subset_univ special)
    rw [card_univ, Fintype.card_fin] at hSplit
    change regular.card + special.card = m at hSplit
    omega
  have hOther : univ \ regular = special := by
    ext i
    simp [regular]
  have hRegLower : m - 100 ≤ regular.card := by omega
  have hRegPos : 0 < ∑ i ∈ regular, r i := by
    rw [hR]
    exact_mod_cast (show 0 < regular.card by omega)
  have hRegUpper : regular.card ≤ m := by omega
  have hEarlyMass : ∑ k ∈ range early, B.weight k ≤ (13 / 50 : ℚ) * ∑ i, r i := by
    rwa [hAll]
  have hEarly : ∀ i, load B.weight r early i ≤ 1 - δ := by
    intro i
    have hh := B.initial_singleton_load_le r hr (he.trans hb) (by norm_num) (a := 1)
      (by norm_num) hEarlyMass hSingleton i (by simp [r])
    norm_num at hh
    linarith
  have hRegEarly : ∀ i ∈ regular, load B.weight r early i ≤ (27 / 100 : ℚ) := by
    intro i hi
    have his : i ∉ special := (mem_sdiff.mp hi).2
    have hh := B.regular_initial_singleton_load_le r hr (D := 100) (a := 1)
      (by norm_num) (by norm_num) (by norm_num) hEarlyMass hSingleton i (by simp [r]) his
    norm_num at hh ⊢
    exact hh
  have hCross : ((27 / 100 : ℚ) + η) * (∑ i ∈ regular, r i) + (∑ i ∈ univ \ regular, r i) <
      ∑ k ∈ range base, B.weight k := by
    rw [hOther, hR, hR]
    have hUpper : (regular.card : ℚ) ≤ m := by exact_mod_cast hRegUpper
    have hExceptional : (special.card : ℚ) ≤ 100 := by exact_mod_cast hSpecial
    have hmpos : (0 : ℚ) < m := by exact_mod_cast (show 0 < m by omega)
    have hProd : ((27 / 100 : ℚ) + η) * (regular.card : ℚ) ≤ (28 / 100 : ℚ) * m :=
      mul_le_mul (by linarith) hUpper (Nat.cast_nonneg _) (by norm_num)
    linarith
  obtain ⟨t, _, ht, _, hDisj, hA⟩ := greedy_reciprocal_allocation B r hr
    hBlockDen (fun _ => by simp [r]) he hb hδ hη hX hEarly
    (fun k hk hk' _ => by simpa [r] using hLater k hk hk')
    (by rw [hAll]; exact hMass) hCutoff regular hRegPos hRegEarly hCross
  refine ⟨B.allocated r t, hDisj, fun i => ?_⟩
  obtain ⟨hSub, _, hLow, hHigh, hDen, hCard⟩ := hA i
  have hAvoid' : Disjoint (B.allocated r t i) E := by
    apply disjoint_left.mpr
    intro a ha hEa
    obtain ⟨k, hk, hb⟩ := mem_biUnion.mp ha
    exact disjoint_left.mp (hAvoid k ((mem_range.mp (mem_filter.mp hk).1).trans_le ht)) hb hEa
  refine ⟨hSub, hAvoid', by simpa [r] using hLow, by simpa [r] using hHigh,
    by simpa [r] using hDen, ?_⟩
  have hDenPos : (0 : ℚ) < (↑(m - 100 : ℕ) : ℚ) := by
    exact_mod_cast (show 0 < m - 100 by omega)
  have hDLe : (↑(m - 100 : ℕ) : ℚ) ≤ (regular.card : ℚ) := by exact_mod_cast hRegLower
  have hFrac := mul_le_mul_of_nonneg_right (one_div_le_one_div_of_le hDenPos hDLe)
    (Nat.cast_nonneg N : (0 : ℚ) ≤ N)
  have hCard' : ((B.allocated r t i).card : ℚ) ≤ X + (1 / (regular.card : ℚ)) * N + 2 * η * N := by
    simpa [r, hR] using hCard
  calc
    _ ≤ _ := hCard'
    _ ≤ X + (1 / (↑(m - 100 : ℕ) : ℚ)) * N + 2 * η * N := by linarith
    _ = _ := by ring

private theorem effective_prefix {d N : ℕ} (B : BlockList d N) (X : ℚ) :
    ∃ t ≤ B.length, (∀ k < t, B.effective k ≤ X) ∧
      (∀ k, t ≤ k → k < B.length → X < B.effective k) := by
  classical
  let bad (k : ℕ) := B.length ≤ k ∨ X < B.effective k
  have h : ∃ k, bad k := ⟨B.length, Or.inl le_rfl⟩
  let t := Nat.find h
  have ht : t ≤ B.length := Nat.find_min' h (Or.inl le_rfl)
  refine ⟨t, ht, ?_, ?_⟩
  · intro k hk
    exact le_of_not_gt (fun hX => Nat.find_min h hk (Or.inr hX))
  · intro k htk hk
    obtain hEnd | hX := (Nat.find_spec h : bad t)
    · omega
    · exact hX.trans_le (B.ordered (htk.trans_lt hk) hk htk)

private theorem effective_singleton {d N : ℕ} (B : BlockList d N) {k n : ℕ}
    (h : B.block k = {n}) : B.effective k = (n : ℚ) := by
  rw [BlockList.effective, BlockList.weight, h]
  simp [mass]

private theorem effective_ge_of_denominators_ge {d N : ℕ} (B : BlockList d N) {k b : ℕ}
    (hk : k < B.length) (h : ∀ n ∈ B.block k, b ≤ n) :
    (b : ℚ) ≤ B.effective k := by
  apply (le_div_iff₀ (B.weight_pos hk)).2
  unfold BlockList.weight mass
  rw [mul_sum]
  calc
    _ ≤ ∑ n ∈ B.block k, (1 : ℚ) := by
      apply sum_le_sum
      intro n hn
      have hnPos : (0 : ℚ) < n := by
        have hm := (mem_Icc.mp (B.subset k hk hn)).1
        exact_mod_cast (show 0 < n by omega)
      rw [← div_eq_mul_inv]
      exact (div_le_iff₀ hnPos).2 (by simpa using (Nat.cast_le.mpr (h n hn) : (b : ℚ) ≤ n))
    _ = _ := by simp

private theorem prefixWeight_eq_mass {d N : ℕ} (B : BlockList d N) {t : ℕ}
    (ht : t ≤ B.length) :
    ∑ k ∈ range t, B.weight k = mass ((range t).biUnion B.block) := by
  symm
  exact sum_biUnion (B.disjoint.subset fun _ hk =>
    mem_range.mpr ((mem_range.mp hk).trans_le ht))

private theorem mass_sdiff_lower (U E : Finset ℕ) : mass U - mass E ≤ mass (U \ E) := by
  have hSet : U \ (U ∩ E) = U \ E := by
    ext n
    simp only [mem_sdiff, mem_inter]
    tauto
  have hm : mass (U \ (U ∩ E)) + mass (U ∩ E) = mass U :=
    sum_sdiff (inter_subset_left : U ∩ E ⊆ U)
  have hMass := mass_mono (inter_subset_right : U ∩ E ⊆ E)
  linarith [hSet ▸ hm]

/-- The effective-denominator cutoffs for a corrected block family have the
required small singleton prefix and sufficient mass in the larger prefix. -/
theorem nearCapacity_prefix_estimates {d N : ℕ} (B : BlockList d N) (E : Finset ℕ)
    {X₁ X₂ : ℕ} (hX₁ : 0 < X₁) (hX₁₂ : X₁ ≤ X₂) (hX₂ : X₂ ≤ Nat.sqrt N)
    {η : ℚ} (hEtaInv : 1 / (X₁ : ℚ) ≤ η)
    (hShape : ∀ k < B.length, (∃ n : ℕ, B.block k = {n}) ∨
      ((∀ n ∈ B.block k, Nat.sqrt N < n) ∧ B.weight k ≤ η))
    (hSurvivors : ∀ n ∈ interval d X₂ \ E, ∃ k < B.length, n ∈ B.block k) :
    ∃ early base, early ≤ base ∧ base ≤ B.length ∧
      (∀ k < early, ∃ n : ℕ, B.block k = {n}) ∧
      (∑ k ∈ range early, B.weight k ≤ mass (interval d X₁)) ∧
      (∀ k, early ≤ k → k < B.length → B.weight k ≤ η) ∧
      (∀ k < base, B.effective k ≤ (X₂ : ℚ)) ∧
      mass (interval d X₂) - mass E ≤ ∑ k ∈ range base, B.weight k := by
  obtain ⟨early, he, heBefore, heAfter⟩ := effective_prefix B (X₁ : ℚ)
  obtain ⟨base, hb, hbBefore, hbAfter⟩ := effective_prefix B (X₂ : ℚ)
  have heB : early ≤ base := by
    by_contra! hh
    have hAbove := hbAfter base le_rfl (hh.trans_le he)
    have hBelow := heBefore base hh
    exact not_lt_of_ge ((Nat.cast_le.mpr hX₁₂ : (X₁ : ℚ) ≤ X₂)) (hAbove.trans_le hBelow)
  have heSmall (k : ℕ) (hk : k < early) : ∃ n : ℕ, B.block k = {n} ∧ n ≤ X₁ := by
    rcases hShape k (hk.trans_le he) with ⟨n, hn⟩ | hLarge
    · exact ⟨n, hn, Nat.cast_le.mp ((effective_singleton B hn).symm ▸ heBefore k hk)⟩
    · have hEff := effective_ge_of_denominators_ge B (hk.trans_le he)
        (b := Nat.sqrt N + 1) hLarge.1
      have hgt : (X₁ : ℚ) < (Nat.sqrt N + 1 : ℕ) := by
        exact_mod_cast (show X₁ < Nat.sqrt N + 1 by omega)
      exact False.elim ((not_lt_of_ge (heBefore k hk)) (hgt.trans_le hEff))
  have heMass : ∑ k ∈ range early, B.weight k ≤ mass (interval d X₁) := by
    rw [prefixWeight_eq_mass B he]
    apply mass_mono
    intro n hn
    obtain ⟨k, hk, hn⟩ := mem_biUnion.mp hn
    obtain ⟨a, ha, haX⟩ := heSmall k (mem_range.mp hk)
    have hna : n = a := by simpa [ha] using hn
    subst a
    exact mem_Icc.mpr ⟨(mem_Icc.mp (B.subset k ((mem_range.mp hk).trans_le he) hn)).1, haX⟩
  have hAfter (k : ℕ) (hek : early ≤ k) (hk : k < B.length) : B.weight k ≤ η := by
    rcases hShape k hk with ⟨n, hn⟩ | hLarge
    · have hnQ : (X₁ : ℚ) ≤ n := by
        have hgt := heAfter k hek hk
        rw [effective_singleton B hn] at hgt
        exact hgt.le
      rw [BlockList.weight, hn, mass, sum_singleton, ← one_div]
      exact (one_div_le_one_div_of_le (Nat.cast_pos.mpr hX₁) hnQ).trans hEtaInv
    · exact hLarge.2
  have hSurvSub : interval d X₂ \ E ⊆ (range base).biUnion B.block := by
    intro n hn
    have hnX := (mem_Icc.mp (mem_sdiff.mp hn).1).2
    obtain ⟨k, hk, hnB⟩ := hSurvivors n hn
    have hSingleton : B.block k = {n} := by
      rcases hShape k hk with ⟨a, ha⟩ | hh
      · have hna : n = a := by simpa [ha] using hnB
        simpa only [hna] using ha
      · exact False.elim ((not_lt_of_ge (hnX.trans hX₂)) (hh.1 n hnB))
    have hkBefore : k < base := by
      by_contra! hb'
      have heq := effective_singleton B hSingleton
      exact (not_lt_of_ge (show B.effective k ≤ (X₂ : ℚ) by rw [heq]; exact_mod_cast hnX))
        (hbAfter k hb' hk)
    exact mem_biUnion.mpr ⟨k, mem_range.mpr hkBefore, hnB⟩
  have hSingletonEarly (k : ℕ) (hk : k < early) : ∃ n : ℕ, B.block k = {n} := by
    obtain ⟨n, hn, _⟩ := heSmall k hk
    exact ⟨n, hn⟩
  refine ⟨early, base, heB, hb, hSingletonEarly, heMass, hAfter, hbBefore, ?_⟩
  rw [prefixWeight_eq_mass B hb]
  exact (mass_sdiff_lower _ _).trans (mass_mono hSurvSub)

private theorem mass_interval_two {n : ℕ} (hn : 0 < n) :
    mass (interval 2 n) = harmonic n - 1 := by
  have h : denominators n = insert 1 (interval 2 n) := by
    ext b
    change (b ∈ interval 1 n) ↔ b ∈ insert 1 (interval 2 n)
    simp only [interval, max_self, mem_Icc, mem_insert]
    omega
  rw [← mass_denominators_eq_harmonic, h]
  have hOne : (1 : ℕ) ∉ interval 2 n := by simp [interval]
  simp [mass, sum_insert hOne]

private theorem nthRoot_le_real_rpow {N u : ℕ} (hu : 0 < u) :
    (Nat.nthRoot u N : ℝ) ≤ (N : ℝ) ^ (1 / (u : ℝ)) := by
  rw [one_div]
  apply (Real.le_rpow_inv_iff_of_pos (by positivity) (by positivity)
    (show (0 : ℝ) < u by exact_mod_cast hu)).mpr
  rw [Real.rpow_natCast]
  exact_mod_cast (Nat.pow_nthRoot_le (n := u) (a := N) (Or.inl (Nat.ne_of_gt hu)))

private theorem real_rpow_le_nthRoot_add_one {N u : ℕ} (hu : 0 < u) :
    (N : ℝ) ^ (1 / (u : ℝ)) ≤ (Nat.nthRoot u N : ℝ) + 1 := by
  rw [one_div]
  apply (Real.rpow_inv_le_iff_of_pos (by positivity) (by positivity)
    (show (0 : ℝ) < u by exact_mod_cast hu)).mpr
  rw [Real.rpow_natCast]
  exact_mod_cast (Nat.lt_pow_nthRoot_add_one (Nat.ne_of_gt hu) N).le

open Filter in
private theorem eventually_nearCapacity_allocation_estimates (K : ℝ) (hK : 0 ≤ K) :
    ∀ᶠ N : ℕ in atTop, ∀ m : ℕ, |(m : ℝ) - Real.log N| ≤ K →
      let X₁ := Nat.nthRoot 4 N
      let X₂ := Nat.nthRoot 3 N
      let δ : ℚ := 1 / (Nat.nthRoot 8 N : ℚ)
      let η : ℚ := 1 / (X₁ : ℚ)
      100 < m ∧ 0 < X₁ ∧ X₁ ≤ X₂ ∧ X₂ ≤ Nat.sqrt N ∧
      0 < δ ∧ δ ≤ 1 / 5 ∧ 0 ≤ η ∧ η ≤ 1 / 100 ∧
      harmonic N / (Nat.sqrt N : ℚ) ≤ η ∧
      mass (interval 2 X₁) ≤ (13 / 50 : ℚ) * m ∧
      (3 / 10 : ℚ) * m + 100 ≤ mass (interval 2 X₂) - 1 ∧
      (X₂ : ℝ) + (N : ℝ) / (↑(m - 100 : ℕ) : ℝ) + 2 * (η : ℝ) * N ≤
        (N : ℝ) / Real.log N + (2 * K + 205) * (N : ℝ) / (Real.log N) ^ 2 := by
  have hCast : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hCast
  have hSmall := (isLittleO_log_rpow_rpow_atTop (s := 1 / 4) 2 (by norm_num)).bound
    (show (0 : ℝ) < 1 / 4 by norm_num)
  filter_upwards [hLog.eventually_ge_atTop (2000 * (K + 101)),
    hCast.eventually hSmall, eventually_ge_atTop ((100 : ℕ) ^ 4),
    eventually_ge_atTop ((5 : ℕ) ^ 8)] with N hBig hSlow hN4 hN8 m hm
  dsimp only [Function.comp_apply] at hBig
  let L := Real.log (N : ℝ)
  let X₁ := Nat.nthRoot 4 N
  let X₂ := Nat.nthRoot 3 N
  let X₈ := Nat.nthRoot 8 N
  let q := (N : ℝ) ^ (1 / 4 : ℝ)
  let δ : ℚ := 1 / (X₈ : ℚ)
  let η : ℚ := 1 / (X₁ : ℚ)
  have hL₁ : 1 ≤ L := by dsimp [L]; linarith
  have hL : 0 < L := by linarith
  have hmLow : L - K ≤ (m : ℝ) := by have h := (abs_le.mp hm).1; linarith
  have hmHigh : (m : ℝ) ≤ L + K := by have h := (abs_le.mp hm).2; linarith
  have hm100R : (100 : ℝ) < m := by dsimp [L] at *; linarith
  have hm100 : 100 < m := by exact_mod_cast hm100R
  have hN1 : 1 ≤ N := by norm_num at hN4; omega
  have hNR1 : 1 ≤ (N : ℝ) := by exact_mod_cast hN1
  have hNR : 0 < (N : ℝ) := by exact_mod_cast (show 0 < N by omega)
  have hX₁100 : 100 ≤ X₁ := (Nat.le_nthRoot_iff (by decide : 4 ≠ 0)).mpr hN4
  have hX₁ : 0 < X₁ := by omega
  have hX₁₂ : X₁ ≤ X₂ := (Nat.le_nthRoot_iff (by decide : 3 ≠ 0)).mpr
    ((Nat.pow_le_pow_right hX₁ (by decide : 3 ≤ 4)).trans
      (Nat.pow_nthRoot_le (Or.inl (by decide : 4 ≠ 0))))
  have hX₂Pos : 0 < X₂ := hX₁.trans_le hX₁₂
  have hX₂ : X₂ ≤ Nat.sqrt N := Nat.le_sqrt'.mpr
    ((Nat.pow_le_pow_right hX₂Pos (by decide : 2 ≤ 3)).trans
      (Nat.pow_nthRoot_le (Or.inl (by decide : 3 ≠ 0))))
  have hX₈5 : 5 ≤ X₈ := (Nat.le_nthRoot_iff (by decide : 8 ≠ 0)).mpr hN8
  have hX₈ : 0 < X₈ := by omega
  have hδ : 0 < δ := by dsimp [δ]; positivity
  have hδSmall : δ ≤ 1 / 5 := one_div_le_one_div_of_le (by norm_num)
    (by exact_mod_cast hX₈5)
  have hη : 0 ≤ η := by dsimp [η]; positivity
  have hηSmall : η ≤ 1 / 100 := one_div_le_one_div_of_le (by norm_num)
    (by exact_mod_cast hX₁100)
  have hq : 0 < q := Real.rpow_pos_of_pos hNR _
  have hSlow' : L ^ 2 ≤ (1 / 4 : ℝ) * q := by
    simpa only [L, q, Real.norm_eq_abs, Real.rpow_two,
      abs_of_nonneg (sq_nonneg (Real.log (N : ℝ))),
      abs_of_nonneg (Real.rpow_nonneg hNR.le (1 / 4 : ℝ))] using hSlow
  have hSlowLe : L ^ 2 ≤ q := by linarith
  have hX₁q : (X₁ : ℝ) ≤ q := nthRoot_le_real_rpow (by decide)
  have hqX₁ : q / 2 ≤ (X₁ : ℝ) := by
    have h := real_rpow_le_nthRoot_add_one (N := N) (u := 4) (by decide)
    have hOne : 1 ≤ (X₁ : ℝ) := by exact_mod_cast (show 1 ≤ X₁ by omega)
    dsimp [q, X₁] at *
    linarith
  have hqSquare : q * q = Real.sqrt (N : ℝ) := by
    change ((N : ℝ) ^ (1 / 4 : ℝ)) * ((N : ℝ) ^ (1 / 4 : ℝ)) = Real.sqrt (N : ℝ)
    rw [← Real.rpow_add hNR, Real.sqrt_eq_rpow]
    congr 1
    norm_num
  have hNSq : 0 < Nat.sqrt N := Nat.sqrt_pos.mpr (by omega)
  have hSqrtHalf : Real.sqrt (N : ℝ) / 2 ≤ (Nat.sqrt N : ℝ) := by
    have hReal : (N : ℝ) ≤ ((Nat.sqrt N : ℝ) + 1) ^ 2 := by
      exact_mod_cast (Nat.lt_succ_sqrt' N).le
    have hUp := (Real.sqrt_le_left (by positivity)).mpr hReal
    have hOne : 1 ≤ (Nat.sqrt N : ℝ) := by exact_mod_cast hNSq
    linarith
  have hHarm : (harmonic N : ℝ) ≤ 1 + L := harmonic_le_one_add_log N
  have hHalf : 1 + L ≤ q / 2 := by nlinarith [sq_nonneg (L - 1)]
  have hLarge : harmonic N / (Nat.sqrt N : ℚ) ≤ η := by
    apply (Rat.cast_le (K := ℝ)).mp
    change ((harmonic N / (Nat.sqrt N : ℚ) : ℚ) : ℝ) ≤ ((1 / (X₁ : ℚ) : ℚ) : ℝ)
    push_cast
    have hProd : (harmonic N : ℝ) * (X₁ : ℝ) ≤ (Nat.sqrt N : ℝ) := calc
      _ ≤ (1 + L) * (X₁ : ℝ) := mul_le_mul_of_nonneg_right hHarm (by positivity)
      _ ≤ (1 + L) * q := mul_le_mul_of_nonneg_left hX₁q (by positivity)
      _ ≤ (q / 2) * q := mul_le_mul_of_nonneg_right hHalf hq.le
      _ = Real.sqrt (N : ℝ) / 2 := by rw [← hqSquare]; ring
      _ ≤ _ := hSqrtHalf
    exact (div_le_div_iff₀ (by exact_mod_cast hNSq) (by exact_mod_cast hX₁)).mpr (by simpa using hProd)
  have hLogX₁ : Real.log (X₁ : ℝ) ≤ L / 4 := by
    have hh := Real.log_le_log (by exact_mod_cast hX₁)
      (show (X₁ : ℝ) ≤ q from hX₁q)
    change Real.log (X₁ : ℝ) ≤ Real.log ((N : ℝ) ^ (1 / 4 : ℝ)) at hh
    rw [Real.log_rpow hNR] at hh
    linarith
  have hLogX₂ : L / 3 ≤ (harmonic X₂ : ℝ) := by
    have hPowN : (N : ℝ) ≤ ((X₂ : ℝ) + 1) ^ 3 :=
      by exact_mod_cast (Nat.lt_pow_nthRoot_add_one (by decide : 3 ≠ 0) N).le
    have hLogN := Real.log_le_log hNR hPowN
    rw [Real.log_pow] at hLogN
    have hH := log_add_one_le_harmonic X₂
    push_cast at hH
    norm_num at hLogN
    dsimp only [L]
    linarith only [hLogN, hH]
  have hUpper : mass (interval 2 X₁) ≤ (13 / 50 : ℚ) * m := by
    apply (Rat.cast_le (K := ℝ)).mp
    rw [mass_interval_two hX₁, Rat.cast_sub, Rat.cast_mul]
    push_cast
    have hh := harmonic_le_one_add_log X₁
    dsimp [L] at *
    linarith
  have hLower : (3 / 10 : ℚ) * m + 100 ≤ mass (interval 2 X₂) - 1 := by
    apply (Rat.cast_le (K := ℝ)).mp
    rw [mass_interval_two hX₂Pos]
    push_cast
    dsimp [L] at *
    linarith
  have hX₂L : (X₂ : ℝ) ≤ (N : ℝ) / L ^ 2 := by
    apply (le_div_iff₀ (sq_pos_of_pos hL)).mpr
    have hX₂Pow : (X₂ : ℝ) ≤ (N : ℝ) ^ (1 / 3 : ℝ) := nthRoot_le_real_rpow (by decide)
    have hL₂Pow : L ^ 2 ≤ (N : ℝ) ^ (2 / 3 : ℝ) :=
      hSlowLe.trans (Real.rpow_le_rpow_of_exponent_le hNR1 (by norm_num))
    calc
      _ ≤ (N : ℝ) ^ (1 / 3 : ℝ) * (N : ℝ) ^ (2 / 3 : ℝ) :=
        mul_le_mul hX₂Pow hL₂Pow (sq_nonneg _) (by positivity)
      _ = _ := by rw [← Real.rpow_add hNR, show ((1 / 3 : ℝ) + 2 / 3) = 1 by norm_num,
          Real.rpow_one]
  have hEtaReal : (η : ℝ) ≤ 2 / q := by
    change ((1 / (X₁ : ℚ) : ℚ) : ℝ) ≤ 2 / q
    push_cast
    exact (div_le_div_iff₀ (by exact_mod_cast hX₁) hq).mpr (by linarith)
  have hEtaL : 2 * (η : ℝ) * N ≤ 4 * (N : ℝ) / L ^ 2 := calc
    _ ≤ (2 * (2 / q)) * N := mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left hEtaReal (by norm_num)) (by positivity)
    _ = 4 * (N : ℝ) / q := by ring
    _ ≤ _ := div_le_div_of_nonneg_left (by positivity) (sq_pos_of_pos hL) hSlowLe
  let M : ℝ := (↑(m - 100 : ℕ) : ℝ)
  have hM : M = (m : ℝ) - 100 := by
    dsimp [M]
    rw [Nat.cast_sub hm100.le]
    norm_num
  have hMhalf : L / 2 ≤ M := by rw [hM]; dsimp [L] at *; linarith
  have hMpos : 0 < M := (half_pos hL).trans_le hMhalf
  have hMN : (N : ℝ) / M ≤ (N : ℝ) / L + (2 * (K + 100)) * (N : ℝ) / L ^ 2 := by
    have hIdentity : (N : ℝ) / M - (N : ℝ) / L =
        ((N : ℝ) * (L - M)) / (L * M) := by field_simp
    have hBound : ((N : ℝ) * (L - M)) / (L * M) ≤
        (2 * (K + 100)) * (N : ℝ) / L ^ 2 := by
      have hMul : L ^ 2 / 2 ≤ L * M := by nlinarith [mul_le_mul_of_nonneg_left hMhalf hL.le]
      calc
        _ ≤ ((N : ℝ) * (K + 100)) / (L * M) := div_le_div_of_nonneg_right
          (mul_le_mul_of_nonneg_left (by rw [hM]; linarith) (by positivity)) (by positivity)
        _ ≤ ((N : ℝ) * (K + 100)) / (L ^ 2 / 2) :=
          div_le_div_of_nonneg_left (by positivity) (by positivity) hMul
        _ = _ := by ring
    linarith
  have hLength : (X₂ : ℝ) + (N : ℝ) / M + 2 * (η : ℝ) * N ≤
      (N : ℝ) / L + (2 * K + 205) * (N : ℝ) / L ^ 2 := by
    calc
      _ ≤ (N : ℝ) / L ^ 2 + ((N : ℝ) / L + (2 * (K + 100)) * N / L ^ 2) +
          4 * (N : ℝ) / L ^ 2 := add_le_add (add_le_add hX₂L hMN) hEtaL
      _ = _ := by ring
  exact ⟨hm100, hX₁, hX₁₂, hX₂, hδ, hδSmall, hη, hηSmall, hLarge, hUpper, hLower, hLength⟩

open Filter in
/-- For the retained blocks of the near-capacity construction, allocate enough
actual denominators to every unit group with the stated uniform length bound. -/
theorem eventually_nearCapacity_unit_allocation (K : ℝ) (hK : 0 ≤ K) :
    ∀ᶠ N : ℕ in atTop, ∀ (m : ℕ) (E : Finset ℕ) (F : Finset (Finset ℕ)) (D : ℕ),
      |(m : ℝ) - Real.log N| ≤ K →
      mass E ≤ 1 →
      (∀ T ∈ F, T.Nonempty ∧ T ⊆ interval 2 N \ E ∧ (mass T).den ∣ D ∧
        ((∃ n : ℕ, T = {n}) ∨
          ((∀ n ∈ T, Nat.sqrt N < n) ∧ mass T ≤ harmonic N / (Nat.sqrt N : ℚ)))) →
      (↑F : Set (Finset ℕ)).PairwiseDisjoint id →
      (m : ℚ) ≤ ∑ T ∈ F, mass T →
      (∀ n ∈ interval 2 N \ E, n ≤ Nat.sqrt N → ∃ T ∈ F, n ∈ T) →
      ∃ A : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (A i) (A j)) ∧
        ∀ i, A i ⊆ interval 2 N ∧ Disjoint (A i) E ∧
          1 / (Nat.nthRoot 8 N : ℚ) ≤ 1 - mass (A i) ∧
          1 - mass (A i) ≤ 1 / (Nat.nthRoot 8 N : ℚ) + 1 / (Nat.nthRoot 4 N : ℚ) ∧
          (1 - mass (A i)).den ∣ D ∧
          ((A i).card : ℝ) ≤
            (N : ℝ) / Real.log N + (2 * K + 205) * (N : ℝ) / (Real.log N) ^ 2 := by
  filter_upwards [eventually_nearCapacity_allocation_estimates K hK] with N hEst m E F D
    hClose hE hGood hDisj hTotal hSurv
  obtain ⟨hm100, hX₁, hX₁₂, hX₂, hδ, hδSmall, hη, hηSmall, hLarge,
    hUpper, hLower, hLength⟩ := hEst m hClose
  obtain ⟨B, hImage, hInj⟩ := exists_sorted_blockList F
    (fun T hT => ⟨(hGood T hT).1, (hGood T hT).2.1.trans sdiff_subset⟩) hDisj
  have hMembers (k : ℕ) (hk : k < B.length) : B.block k ∈ F :=
    hImage ▸ mem_image.mpr ⟨k, mem_range.mpr hk, rfl⟩
  have hBlockDen : ∀ k < B.length, (B.weight k).den ∣ D :=
    fun k hk => (hGood _ (hMembers k hk)).2.2.1
  have hAvoid : ∀ k < B.length, Disjoint (B.block k) E := by
    intro k hk
    exact disjoint_left.mpr fun n hn => (mem_sdiff.mp ((hGood _ (hMembers k hk)).2.1 hn)).2
  have hSum : (m : ℚ) ≤ ∑ k ∈ range B.length, B.weight k := by
    have h := sum_image (f := mass) hInj
    rw [hImage] at h
    exact hTotal.trans_eq h
  have hSurv' : ∀ n ∈ interval 2 (Nat.nthRoot 3 N) \ E,
      ∃ k < B.length, n ∈ B.block k := by
    intro n hn
    obtain ⟨hnInt, hnE⟩ := mem_sdiff.mp hn
    obtain ⟨hnLo, hnHi⟩ := mem_Icc.mp hnInt
    have hnSmall : n ≤ Nat.sqrt N := hnHi.trans hX₂
    have hnAvailable : n ∈ interval 2 N \ E :=
      mem_sdiff.mpr ⟨mem_Icc.mpr ⟨hnLo, hnSmall.trans (Nat.sqrt_le_self N)⟩, hnE⟩
    obtain ⟨T, hT, hnT⟩ := hSurv n hnAvailable hnSmall
    rw [← hImage] at hT
    obtain ⟨k, hk, rfl⟩ := mem_image.mp hT
    exact ⟨k, mem_range.mp hk, hnT⟩
  have hShape : ∀ k < B.length, (∃ n : ℕ, B.block k = {n}) ∨
      ((∀ n ∈ B.block k, Nat.sqrt N < n) ∧ B.weight k ≤ 1 / (Nat.nthRoot 4 N : ℚ)) := by
    intro k hk
    exact ((hGood _ (hMembers k hk)).2.2.2).imp_right
      (fun hh => ⟨hh.1, hh.2.trans hLarge⟩)
  obtain ⟨early, base, he, hb, hs, hEarlyMass, hLater, hCutoff, hBaseMass⟩ :=
    nearCapacity_prefix_estimates B E hX₁ hX₁₂ hX₂
      (show 1 / (Nat.nthRoot 4 N : ℚ) ≤ 1 / (Nat.nthRoot 4 N : ℚ) from le_rfl) hShape hSurv'
  have hBaseLower : (3 / 10 : ℚ) * m + 100 ≤ ∑ k ∈ range base, B.weight k :=
    hLower.trans ((sub_le_sub_left hE _).trans hBaseMass)
  obtain ⟨A, hPair, hA⟩ := nearCapacity_unit_allocation hm100 B E hBlockDen hAvoid he hb
    hδ hδSmall hη hηSmall (by positivity) hs (hEarlyMass.trans hUpper) hLater hSum hCutoff hBaseLower
  refine ⟨A, hPair, fun i => ?_⟩
  obtain ⟨hSub, hAvoid, hResidualLo, hResidualHi, hDen, hCard⟩ := hA i
  refine ⟨hSub, hAvoid, hResidualLo, hResidualHi, hDen, ?_⟩
  have hCardR := (Rat.cast_le (K := ℝ)).mpr hCard
  push_cast at hCardR hLength
  exact hCardR.trans hLength

end LeanAB.PaperB.Allocation

