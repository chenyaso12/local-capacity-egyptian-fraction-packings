module

public import PaperB.NearCapacityBlocks
public import PaperB.ShortPointwiseCover
public import PaperB.BaselineCutoff
public import PaperB.RepairBudget
public import PaperB.FixedTargets
meta import Mathlib.Tactic

/-! Corrected blocks for the baseline packing theorem in F2. -/

@[expose] public section

open Finset Filter
open scoped BigOperators Topology

namespace LeanAB.PaperB.Baseline

open Closure NearCapacity

/-- The unreserved denominators whose prime factors are at most the cutoff. -/
noncomputable def stock (d N : ℕ) (M S R : Finset ℕ)
    (Z : ℝ := baselineCutoff 4 N) : Finset ℕ :=
  unreservedCutoffStock d N (smoothCutoff N) Z M S R

/-- The large primes whose blocks still need a correction. -/
noncomputable def correctionPrimes (N : ℕ) (M : Finset ℕ)
    (Z : ℝ := baselineCutoff 4 N) : Finset ℕ := by
  classical
  exact (largePrimes N).filter fun p => (p : ℝ) ≤ Z ∧ p ∉ M

theorem mem_correctionPrimes {N p : ℕ} {Z : ℝ} {M : Finset ℕ} :
    p ∈ correctionPrimes N M (Z := Z) ↔ p ∈ largePrimes N ∧ (p : ℝ) ≤ Z ∧ p ∉ M := by
  classical
  exact mem_filter

theorem mem_stock {d N n : ℕ} {Z : ℝ} {M S R : Finset ℕ} :
    n ∈ stock d N M S R (Z := Z) ↔ n ∈ interval d N ∧
      n ∉ repairExclusions d N (smoothCutoff N) M S R ∧
      ∀ q : ℕ, q.Prime → q ∣ n → (q : ℝ) ≤ Z := by
  classical
  unfold stock unreservedCutoffStock
  constructor
  · intro h
    exact ⟨(mem_sdiff.mp (mem_filter.mp h).1).1,
      (mem_sdiff.mp (mem_filter.mp h).1).2, (mem_filter.mp h).2⟩
  · rintro ⟨h₁,h₂,h₃⟩
    exact mem_filter.mpr ⟨mem_sdiff.mpr ⟨h₁,h₂⟩,h₃⟩

theorem stock_eq_sdiff_of_nonneg {d N : ℕ} {Z : ℝ} {M S R : Finset ℕ}
    (hZ : 0 ≤ Z) :
    stock d N M S R (Z := Z) = interval d N \
      (repairExclusions d N (smoothCutoff N) M S R ∪ cutoffPart d N Z) := by
  classical
  ext n
  constructor
  · intro h
    obtain ⟨hn,he,hf⟩ := mem_stock.mp h
    apply mem_sdiff.mpr ⟨hn,?_⟩
    intro hh
    rcases mem_union.mp hh with hE | hC
    · exact he hE
    · obtain ⟨_,p,hp,hz,hd⟩ := (mem_cutoffPart hZ).mp hC
      exact hz.not_ge (hf p hp hd)
  · intro h
    obtain ⟨hn,h⟩ := mem_sdiff.mp h
    refine mem_stock.mpr ⟨hn, fun hE => h (mem_union_left _ hE), ?_⟩
    intro p hp hd
    by_contra! hf
    exact h (mem_union_right _ ((mem_cutoffPart hZ).mpr ⟨hn,p,hp,hf,hd⟩))

/-- Every subset of the stock is disjoint from both repair pools and
contains no multiple of a reserved marker. -/
theorem avoids_reservations_of_subset_stock {d N : ℕ} {Z : ℝ} {M S R A : Finset ℕ}
    (hA : A ⊆ stock d N M S R (Z := Z)) :
    Disjoint A S ∧ Disjoint A R ∧ ∀ n ∈ A, ∀ p ∈ M, ¬ p ∣ n := by
  classical
  refine ⟨disjoint_left.mpr ?_,disjoint_left.mpr ?_,?_⟩
  · intro n hn hs
    exact (mem_stock.mp (hA hn)).2.1 (mem_union_left _ (mem_union_right _ hs))
  · intro n hn hr
    exact (mem_stock.mp (hA hn)).2.1 (mem_union_right _ hr)
  · intro n hn p hp hpn
    obtain ⟨hI,hE,_⟩ := mem_stock.mp (hA hn)
    have ht : n ∈ M.biUnion (fun q => primePart q (interval d N)) :=
      mem_biUnion.mpr ⟨p,hp,mem_filter.mpr ⟨hI,hpn⟩⟩
    exact hE (mem_union_left _ (mem_union_left _ (mem_union_right _ ht)))

/-- The mass of the initial stock loses at most the two explicitly deleted masses. -/
theorem mass_stock_ge_of_nonneg (d N : ℕ) (M S R : Finset ℕ) {Z : ℝ}
    (hZ : 0 ≤ Z) :
    mass (interval d N) - mass (repairExclusions d N (smoothCutoff N) M S R) -
      mass (cutoffPart d N Z) ≤ mass (stock d N M S R (Z := Z)) := by
  classical
  let I := interval d N
  let E := repairExclusions d N (smoothCutoff N) M S R
  let C := cutoffPart d N Z
  have hm (A B : Finset ℕ) : mass (A \ B) = mass A - mass (A ∩ B) := by
    have hs : A \ B = A \ (A ∩ B) := by ext n; simp
    rw [hs]
    exact sum_sdiff_eq_sub inter_subset_left
  have hsplit : I \ (E ∪ C) = (I \ E) \ C := by ext n; simp [and_assoc]
  change mass I - mass E - mass C ≤ mass (stock d N M S R (Z := Z))
  rw [stock_eq_sdiff_of_nonneg hZ, hsplit, hm, hm]
  have hE := mass_mono (S := I ∩ E) (T := E) inter_subset_right
  have hC := mass_mono (S := (I \ E) ∩ C) (T := C) inter_subset_right
  linarith only [hE, hC]

/-- Markers above the square root do not change the medium-prime factor of D_N. -/
theorem mediumDenominator_eq_permitted {N : ℕ} {M : Finset ℕ}
    (hM : ∀ q ∈ M, Nat.sqrt N < q) :
    mediumDenominator ⌊smoothCutoff N⌋₊ (mediumPrimes N ⌊smoothCutoff N⌋₊ M) =
      permittedDenominator N := by
  unfold mediumDenominator permittedDenominator
  congr 2
  ext p
  rw [mem_mediumPrimes, mem_filter, Nat.mem_primesLE]
  constructor
  · rintro ⟨hp, hq, ht, _⟩
    exact ⟨⟨hq, hp⟩, ht⟩
  · rintro ⟨⟨hq, hp⟩, ht⟩
    exact ⟨hp, hq, ht, fun hm => (hM p hm).not_ge hq⟩

private theorem stock_mem_available {d N n : ℕ} {Z : ℝ} {M S R : Finset ℕ}
    (hn : n ∈ stock d N M S R (Z := Z)) (h₂ : 2 ≤ n) :
    n ∈ NearCapacity.available N (smoothCutoff N) M S R := by
  classical
  obtain ⟨hI, hE, _⟩ := mem_stock.mp hn
  refine mem_sdiff.mpr ⟨mem_Icc.mpr ⟨h₂, (mem_Icc.mp hI).2⟩, ?_⟩
  intro hx
  apply hE
  simp only [repairExclusions, mem_union, mem_biUnion, primePart, mem_filter] at hx ⊢
  rcases hx with ((⟨q,hq,_,hdq⟩ | ⟨q,hq,_,hdq⟩) | hS) | hR
  · exact Or.inl (Or.inl (Or.inl ⟨q, hq, hI, hdq⟩))
  · exact Or.inl (Or.inl (Or.inr ⟨q, hq, hI, hdq⟩))
  · exact Or.inl (Or.inr hS)
  · exact Or.inr hR

private theorem stock_subset_denominators {d N : ℕ} {Z : ℝ} {M S R : Finset ℕ} :
    stock d N M S R (Z := Z) ⊆ denominators N := by
  intro n hn
  obtain ⟨h₁,h₂⟩ := mem_Icc.mp (mem_stock.mp hn).1
  exact mem_Icc.mpr ⟨(le_max_left 1 d).trans h₁, h₂⟩

private theorem stock_factor_correction {d N n p : ℕ} {Z : ℝ} {M S R : Finset ℕ}
    (hn : n ∈ stock d N M S R (Z := Z)) (hp : p.Prime) (hpl : Nat.sqrt N < p) (hpn : p ∣ n) :
    p ∈ correctionPrimes N M (Z := Z) := by
  classical
  obtain ⟨hI,hE,hZ⟩ := mem_stock.mp hn
  have hden := mem_Icc.mp (stock_subset_denominators hn)
  refine mem_correctionPrimes.mpr ⟨mem_largePrimes.mpr
    ⟨hp, (Nat.le_of_dvd hden.1 hpn).trans hden.2, hpl⟩, hZ p hp hpn, ?_⟩
  intro hM
  apply hE
  simp only [repairExclusions, mem_union, mem_biUnion, primePart, mem_filter]
  exact Or.inl (Or.inl (Or.inr ⟨p, hM, hI, hpn⟩))

private theorem permittedDenominator_pos (N : ℕ) : 0 < permittedDenominator N := by
  unfold permittedDenominator
  exact Nat.mul_pos (Nat.lcmUpto_pos _) (prod_pos fun p hp =>
    (Nat.mem_primesLE.mp (mem_filter.mp hp).1).2.pos)

private theorem stock_primePart_dvd {d N p n : ℕ} {Z : ℝ} {M S R : Finset ℕ}
    (hM : ∀ q ∈ M, Nat.sqrt N < q) (hp : p ∈ largePrimes N)
    (hn : n ∈ primePart p (stock d N M S R (Z := Z))) :
    n ∣ p * permittedDenominator N := by
  obtain ⟨hnV,hd⟩ := mem_filter.mp hn
  have hnD := stock_subset_denominators hnV
  have hnD' := mem_Icc.mp hnD
  have hpN := mem_largePrimes.mp hp
  have hn₂ : 2 ≤ n := hpN.1.two_le.trans (Nat.le_of_dvd hnD'.1 hd)
  have hUnique (q : ℕ) (hq : q.Prime) (hlarge : Nat.sqrt N < q) (hqd : q ∣ n) : q = p := by
    have hq' := mem_largePrimes.mpr ⟨hq, (Nat.le_of_dvd hnD'.1 hqd).trans hnD'.2, hlarge⟩
    by_contra hne
    exact disjoint_left.mp (primePart_disjoint hp hq' (Ne.symm hne))
      (mem_filter.mpr ⟨hnD, hd⟩) (mem_filter.mpr ⟨hnD, hqd⟩)
  rw [← mediumDenominator_eq_permitted hM]
  exact available_dvd_common (show 0 ≤ smoothCutoff N by unfold smoothCutoff; positivity)
    (stock_mem_available hnV hn₂) hpN.1.pos hUnique

/-- One scaled cover corrects the entire stock block of an unmarked large prime. -/
theorem exists_corrected_stock_block {d N p t Q : ℕ} {Z : ℝ} {M S R : Finset ℕ}
    (hN : 0 < N) (hY : 1 ≤ ⌊smoothCutoff N⌋₊)
    (hYS : ⌊smoothCutoff N⌋₊ ≤ Nat.sqrt N)
    (hYZ : (⌊smoothCutoff N⌋₊ : ℝ) ≤ Z)
    (hp : p ∈ correctionPrimes N M (Z := Z)) (hd : d ≤ p) (ht : 0 < t)
    (htUpper : p * (t * Q) ≤ N)
    (htLower : N ≤ 173 * Q * p * t)
    (hSmooth : ∀ b ∈ interval 1 Q, t * b ∣ Nat.lcmUpto ⌊smoothCutoff N⌋₊)
    (hpt : ¬ p ∣ t)
    (hCover : CoversResidues p (interval 1 Q))
    (hM : ∀ q ∈ M, q.Prime ∧ Nat.sqrt N < q)
    (hS : ∀ n ∈ S, ∃ q ∈ mediumPrimes N ⌊smoothCutoff N⌋₊ M, q ∣ n)
    (hR : ∀ n ∈ R, n ∣ Nat.lcmUpto ⌊smoothCutoff N⌋₊) :
    ∃ T ⊆ primePart p (stock d N M S R (Z := Z)),
      (mass T).den ∣ permittedDenominator N ∧
      mass (primePart p (stock d N M S R (Z := Z))) - mass T ≤
        (173 : ℚ) * (Q : ℚ) * mass (interval 1 Q) /
        (N : ℚ) := by
  classical
  obtain ⟨hpg,hpZ,hpM⟩ := mem_correctionPrimes.mp hp
  obtain ⟨hp',_,hpl⟩ := mem_largePrimes.mp hpg
  have hz : 0 ≤ smoothCutoff N := by unfold smoothCutoff; positivity
  have hAvail := scaled_grid_mem_unreserved_cutoff hz hY hYS hYZ hpg hpZ ht hd htUpper
    hSmooth hpM (fun q hq => ⟨(hM q hq).1,hYS.trans_lt (hM q hq).2⟩) hS hR
  have hGrid : mark p (mark t (interval 1 Q)) ⊆
      primePart p (stock d N M S R (Z := Z)) := by
    intro n hn
    refine mem_filter.mpr ⟨hAvail hn, ?_⟩
    obtain ⟨a,_,rfl⟩ := mem_image.mp hn
    exact dvd_mul_right _ _
  exact exists_scaled_block_cancellation hp' ht (permittedDenominator_pos N)
    hN (not_dvd_permittedDenominator_of_sqrt_lt hN hp' hpl) hpt _
    (mass_den_dvd (fun _ hn => stock_primePart_dvd (fun q hq => (hM q hq).2) hpg hn))
    hGrid (fun b hb => (hSmooth b hb).trans (dvd_mul_right _ _)) hCover htLower

private theorem large_block_weight_le {N p : ℕ} (hp : p ∈ largePrimes N) {T : Finset ℕ}
    (hT : T ⊆ primePart p (denominators N)) :
    mass T ≤ harmonic N / (Nat.sqrt N : ℚ) := by
  obtain ⟨hp', hpN, hpLarge⟩ := mem_largePrimes.mp hp
  have hH : mass (cofactorBlock N p) ≤ mass (denominators N) := by
    apply mass_mono
    intro b hb
    obtain ⟨h₁, h₂⟩ := mem_Icc.mp hb
    exact mem_Icc.mpr ⟨h₁, h₂.trans (Nat.div_le_self _ _)⟩
  rw [← mass_denominators_eq_harmonic]
  calc
    _ ≤ mass (primePart p (denominators N)) := mass_mono hT
    _ = mass (cofactorBlock N p) / p := mass_primePart hp'.pos
    _ ≤ mass (denominators N) / p := div_le_div_of_nonneg_right hH (by positivity)
    _ ≤ _ := by
      apply div_le_div_of_nonneg_left (mass_nonneg _)
      · exact_mod_cast Nat.sqrt_pos.mpr (hp'.pos.trans_le hpN)
      · exact_mod_cast hpLarge.le

/-- The finite corrected baseline family, with surviving singleton information. -/
structure RetainedBlocks (d N : ℕ) (M S R : Finset ℕ) (loss : ℚ)
    (Z : ℝ := baselineCutoff 4 N) where
  family : Finset (Finset ℕ)
  disjoint : (↑family : Set (Finset ℕ)).PairwiseDisjoint id
  good : ∀ T ∈ family, T.Nonempty ∧ T ⊆ stock d N M S R (Z := Z) ∧
    (mass T).den ∣ permittedDenominator N ∧
    ((∃ n : ℕ, T = {n}) ∨
      ((∀ n ∈ T, Nat.sqrt N < n) ∧ mass T ≤ harmonic N / (Nat.sqrt N : ℚ)))
  small : ∀ n ∈ stock d N M S R (Z := Z), n ≤ Nat.sqrt N → {n} ∈ family
  weight : mass (stock d N M S R (Z := Z)) - loss ≤ ∑ T ∈ family, mass T

/-- Assemble one correction for each surviving large prime and keep all other
denominators as singletons. The mass bound charges each correction once. -/
theorem exists_retainedBlocks_of_corrections {d N : ℕ} {Z : ℝ} {M S R : Finset ℕ}
    (hM : ∀ q ∈ M, Nat.sqrt N < q) {cost : ℚ}
    (hCorrect : ∀ p ∈ correctionPrimes N M (Z := Z), ∃ T ⊆ primePart p (stock d N M S R (Z := Z)),
      (mass T).den ∣ permittedDenominator N ∧
      mass (primePart p (stock d N M S R (Z := Z))) - mass T ≤ cost) :
    Nonempty (RetainedBlocks d N M S R ((correctionPrimes N M (Z := Z)).card * cost) (Z := Z)) := by
  classical
  let V := stock d N M S R (Z := Z)
  let G := correctionPrimes N M (Z := Z)
  let W (p : ℕ) := primePart p V
  let B := G.biUnion W
  let U := V \ B
  let T (p : ℕ) : Finset ℕ := if hp : p ∈ G then (hCorrect p hp).choose else ∅
  have hT (p : ℕ) (hp : p ∈ G) : T p ⊆ W p ∧
      (mass (T p)).den ∣ permittedDenominator N ∧ mass (W p) - mass (T p) ≤ cost := by
    simpa only [T, dite_eq_left hp] using (hCorrect p hp).choose_spec
  let F := U.image (fun n => ({n} : Finset ℕ)) ∪ ((G.image T).erase ∅)
  have hMem (A : Finset ℕ) : A ∈ F ↔
      (∃ n ∈ U, ({n} : Finset ℕ) = A) ∨ (A.Nonempty ∧ ∃ p ∈ G, T p = A) := by
    simp only [F, mem_union, mem_image, mem_erase, nonempty_iff_ne_empty]
  have hWsub : ∀ p : ℕ, W p ⊆ V := fun _ => filter_subset .. 
  have hBsub : B ⊆ V := by
    intro n hn
    obtain ⟨p, _, ha⟩ := mem_biUnion.mp hn
    exact hWsub _ ha
  have hWden (p : ℕ) : W p ⊆ primePart p (denominators N) :=
    fun _ hn => mem_filter.mpr ⟨stock_subset_denominators (mem_filter.mp hn).1, (mem_filter.mp hn).2⟩
  have hLarge (p : ℕ) (hp : p ∈ G) : p ∈ largePrimes N := (mem_correctionPrimes.mp hp).1
  have hDis (p : ℕ) (hp : p ∈ G) (q : ℕ) (hq : q ∈ G) (hne : p ≠ q) :
      Disjoint (W p) (W q) :=
    (primePart_disjoint (hLarge p hp) (hLarge q hq) hne).mono (hWden _) (hWden _)
  have hPair : (↑F : Set (Finset ℕ)).PairwiseDisjoint id := by
    intro A ha C hc hne
    rcases (hMem A).mp ha with ⟨a, haU, rfl⟩ | ⟨_, p, hp, rfl⟩
    · rcases (hMem C).mp hc with ⟨c, _, rfl⟩ | ⟨_, q, hq, rfl⟩
      · apply disjoint_singleton.mpr
        intro h
        exact hne (by rw [h])
      · exact disjoint_singleton_left.mpr fun ht => (mem_sdiff.mp haU).2
          (mem_biUnion.mpr ⟨q, hq, (hT q hq).1 ht⟩)
    · rcases (hMem C).mp hc with ⟨c, hcU, rfl⟩ | ⟨_, q, hq, rfl⟩
      · exact (disjoint_singleton_left.mpr fun ht => (mem_sdiff.mp hcU).2
          (mem_biUnion.mpr ⟨p, hp, (hT p hp).1 ht⟩)).symm
      · exact (hDis p hp q hq (fun e => hne (congrArg T e))).mono (hT p hp).1 (hT q hq).1
  refine ⟨⟨F, hPair, ?_, ?_, ?_⟩⟩
  · intro A ha
    rcases (hMem A).mp ha with ⟨n, hn, rfl⟩ | ⟨hn, p, hp, rfl⟩
    · have hnV : n ∈ V := (mem_sdiff.mp hn).1
      refine ⟨singleton_nonempty _, singleton_subset_iff.mpr hnV, ?_, Or.inl ⟨n, rfl⟩⟩
      apply mass_den_dvd
      intro b hb
      have hb' := mem_singleton.mp hb
      subst b
      by_cases h₂ : 2 ≤ n
      · rw [← mediumDenominator_eq_permitted hM]
        simpa only [one_mul] using
          available_dvd_common (show 0 ≤ smoothCutoff N by unfold smoothCutoff; positivity)
            (stock_mem_available hnV h₂) (p := 1) (by norm_num) (fun q hq hql hqd =>
              False.elim ((mem_sdiff.mp hn).2 (mem_biUnion.mpr
                ⟨q, stock_factor_correction hnV hq hql hqd, mem_filter.mpr ⟨hnV, hqd⟩⟩)))
      · have h₁ := (mem_Icc.mp (stock_subset_denominators hnV)).1
        have hn₁ : n = 1 := by omega
        simp [hn₁]
    · have hs : T p ⊆ W p := (hT p hp).1
      refine ⟨hn, hs.trans (hWsub p), (hT p hp).2.1, Or.inr ⟨?_, ?_⟩⟩
      · intro n hn'
        exact (mem_largePrimes.mp (hLarge p hp)).2.2.trans_le (Nat.le_of_dvd
          (mem_Icc.mp ((mem_filter.mp (hWden p (hs hn'))).1)).1
          (mem_filter.mp (hs hn')).2)
      · exact large_block_weight_le (hLarge p hp) (hs.trans (hWden p))
  · intro n hn hsmall
    apply (hMem _).mpr
    refine Or.inl ⟨n, mem_sdiff.mpr ⟨hn, ?_⟩, rfl⟩
    intro h
    obtain ⟨p, hp, hw⟩ := mem_biUnion.mp h
    have hdiv := (mem_filter.mp hw).2
    have hpos := (mem_Icc.mp (stock_subset_denominators hn)).1
    exact ((mem_largePrimes.mp (hLarge p hp)).2.2.not_ge ((Nat.le_of_dvd hpos hdiv).trans hsmall))
  · have hUnion : F.biUnion id = U ∪ G.biUnion T := by
      ext n
      constructor
      · intro h
        obtain ⟨A, hA, hn⟩ := mem_biUnion.mp h
        rcases (hMem A).mp hA with ⟨a, ha, rfl⟩ | ⟨_, p, hp, rfl⟩
        · exact mem_union_left _ ((mem_singleton.mp hn).symm ▸ ha)
        · exact mem_union_right _ (mem_biUnion.mpr ⟨p, hp, hn⟩)
      · intro h
        rcases mem_union.mp h with h | h
        · exact mem_biUnion.mpr ⟨{n}, (hMem _).mpr (Or.inl ⟨n, h, rfl⟩), mem_singleton_self n⟩
        · obtain ⟨p, hp, hn⟩ := mem_biUnion.mp h
          exact mem_biUnion.mpr ⟨T p, (hMem _).mpr (Or.inr ⟨⟨n, hn⟩, p, hp, rfl⟩), hn⟩
    have hUdisB : Disjoint U B := sdiff_disjoint
    have hBTsub : G.biUnion T ⊆ B := by
      intro n hn
      obtain ⟨p, hp, hn⟩ := mem_biUnion.mp hn
      exact mem_biUnion.mpr ⟨p, hp, (hT p hp).1 hn⟩
    have hTV : mass V = mass U + ∑ p ∈ G, mass (W p) := by
      have hm : mass B = ∑ p ∈ G, mass (W p) := sum_biUnion hDis
      have hUB : mass (U ∪ B) = mass U + mass B := sum_union hUdisB
      rw [← hm, ← hUB, sdiff_union_of_subset hBsub]
    have hFam : (∑ A ∈ F, mass A) = mass U + ∑ p ∈ G, mass (T p) := by
      have hm : mass (F.biUnion id) = ∑ A ∈ F, mass (id A) := sum_biUnion hPair
      have hUB : mass (U ∪ G.biUnion T) = mass U + mass (G.biUnion T) :=
        sum_union (hUdisB.mono_right hBTsub)
      have hGT : mass (G.biUnion T) = ∑ p ∈ G, mass (T p) := sum_biUnion
        (fun p hp q hq hne => (hDis p hp q hq hne).mono (hT p hp).1 (hT q hq).1)
      rw [← hGT, ← hUB, ← hUnion, hm]
      rfl
    have hLoss : (∑ p ∈ G, (mass (W p) - mass (T p))) ≤ G.card * cost := by
      exact (sum_le_sum (fun p hp => (hT p hp).2.2)).trans_eq (by simp [nsmul_eq_mul])
    rw [sum_sub_distrib] at hLoss
    rw [hFam]
    linarith only [hTV, hLoss]

theorem stock_eq_sdiff {d N : ℕ} {M S R : Finset ℕ} :
    stock d N M S R = interval d N \
      (repairExclusions d N (smoothCutoff N) M S R ∪ baselineCutoffPart 4 d N) :=
  stock_eq_sdiff_of_nonneg (div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _))

theorem mass_stock_ge (d N : ℕ) (M S R : Finset ℕ) :
    mass (interval d N) - mass (repairExclusions d N (smoothCutoff N) M S R) -
      mass (baselineCutoffPart 4 d N) ≤ mass (stock d N M S R) :=
  mass_stock_ge_of_nonneg d N M S R (div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _))

private theorem sqrt_cast_le_real (N : ℕ) : (Nat.sqrt N : ℝ) ≤ Real.sqrt N :=
  (Real.le_sqrt (Nat.cast_nonneg _) (Nat.cast_nonneg _)).2
    (by exact_mod_cast Nat.sqrt_le' N)

private theorem eventually_geometry (d : ℕ) :
    ∀ᶠ N : ℕ in atTop,
      0 < N ∧ 1 ≤ ⌊smoothCutoff N⌋₊ ∧
      ⌊smoothCutoff N⌋₊ ≤ Nat.sqrt N ∧
      (⌊smoothCutoff N⌋₊ : ℝ) ≤ baselineCutoff 4 N ∧
      d ≤ Nat.sqrt N ∧
      0 < baselineCoverBound 4 N ∧
      baselineCoverBound 4 N ≤ 2 * ⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ := by
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  filter_upwards [eventually_ge_atTop (max 1 (d * d)), eventually_baselineCutoff_gt_sqrt 4,
    eventually_baselineCoverBound_logs 4,
    (Real.tendsto_log_atTop.comp hcast).eventually_ge_atTop 1] with N hN hZ hQ hL
  change 1 ≤ Real.log (N : ℝ) at hL
  have hN₁ := (le_max_left _ _).trans hN
  have hx : (1 : ℝ) ≤ N := by exact_mod_cast hN₁
  have hy : 1 ≤ ⌊smoothCutoff N⌋₊ :=
    Nat.le_floor (by
      rw [Nat.cast_one, smoothCutoff]
      exact Real.one_le_rpow hx (by norm_num))
  have hyS : ⌊smoothCutoff N⌋₊ ≤ Nat.sqrt N := by
    apply Nat.le_sqrt'.mpr
    have hyR : (⌊smoothCutoff N⌋₊ : ℝ) ≤ Real.sqrt N := by
      refine (Nat.floor_le (show 0 ≤ smoothCutoff N by unfold smoothCutoff; positivity)).trans ?_
      rw [smoothCutoff, Real.sqrt_eq_rpow]
      exact Real.rpow_le_rpow_of_exponent_le hx (by norm_num)
    exact_mod_cast (show (⌊smoothCutoff N⌋₊ : ℝ) ^ 2 ≤ (N : ℝ) from
      (Real.le_sqrt (Nat.cast_nonneg _) (Nat.cast_nonneg _)).mp hyR)
  refine ⟨hN₁, hy, hyS, ?_, Nat.le_sqrt.mpr ((le_max_right _ _).trans hN), hQ.1, ?_⟩
  · exact (Nat.cast_le.mpr hyS).trans ((sqrt_cast_le_real N).trans hZ.le)
  · have hQ' : (baselineCoverBound 4 N : ℝ) ≤ 2 * Real.log (N : ℝ) ^ (5 : ℕ) := hQ.2.1
    have hP := pow_le_pow_right₀ hL (show (5 : ℕ) ≤ 12 by decide)
    exact_mod_cast hQ'.trans (mul_le_mul_of_nonneg_left (hP.trans (Nat.le_ceil _)) (by norm_num))

/-- The total correction charge at a specified cofactor width. -/
noncomputable def correctionChargeAt (N : ℕ) (M : Finset ℕ) (Q : ℕ) : ℚ :=
  (correctionPrimes N M (Z := (N : ℝ) / Q)).card *
    ((173 : ℚ) * (Q : ℚ) * mass (interval 1 Q) / (N : ℚ))

noncomputable def correctionCharge (N : ℕ) (M : Finset ℕ) : ℚ :=
  correctionChargeAt N M (baselineCoverBound 4 N)

/-- The corrected block family for any cofactor width with the expected
geometry and covers outside the marked primes. -/
theorem eventually_retainedBlocks_at_width (d : ℕ) (width : ℕ → ℕ)
    (excluded : ℕ → Finset ℕ)
    (hWidth : ∀ᶠ N : ℕ in atTop, 0 < width N ∧
      Real.sqrt N < (N : ℝ) / width N ∧ width N ≤ 2 * ⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊)
    (hCover : ∀ᶠ N : ℕ in atTop, ∀ p ∈ largePrimes N,
      (p : ℝ) ≤ (N : ℝ) / width N → p ∉ excluded N →
      CoversResidues p (interval 1 (width N))) :
    ∀ᶠ N : ℕ in atTop, ∀ M S R : Finset ℕ, excluded N ⊆ M →
      (∀ q ∈ M, q.Prime ∧ Nat.sqrt N < q) →
      (∀ n ∈ S, ∃ q ∈ mediumPrimes N ⌊smoothCutoff N⌋₊ M, q ∣ n) →
      (∀ n ∈ R, n ∣ Nat.lcmUpto ⌊smoothCutoff N⌋₊) →
      Nonempty (RetainedBlocks d N M S R (correctionChargeAt N M (width N))
        (Z := (N : ℝ) / width N)) := by
  filter_upwards [eventually_geometry d, eventually_powersmooth_dilation,
    hWidth, hCover] with N hGeom hDil hWidth hCover
  intro M S R hExcluded hM hS hR
  obtain ⟨hN, hy, hyS, _, hd, _, _⟩ := hGeom
  obtain ⟨hQ, hZ, hQlarge⟩ := hWidth
  let Q := width N
  let Z := (N : ℝ) / Q
  have hyZ : (⌊smoothCutoff N⌋₊ : ℝ) ≤ Z :=
    (Nat.cast_le.mpr hyS).trans ((sqrt_cast_le_real N).trans hZ.le)
  unfold correctionChargeAt
  apply exists_retainedBlocks_of_corrections (fun q hq => (hM q hq).2)
  intro p hp
  obtain ⟨hpg, hpz, hpM⟩ := mem_correctionPrimes.mp hp
  obtain ⟨hprime, _, hpl⟩ := mem_largePrimes.mp hpg
  have hpq : (0 : ℚ) < p := Nat.cast_pos.mpr hprime.pos
  have hQq : (0 : ℚ) < Q := Nat.cast_pos.mpr hQ
  have hpQ : p * Q ≤ N := by
    exact_mod_cast (le_div_iff₀ (Nat.cast_pos.mpr hQ : (0 : ℝ) < Q)).mp hpz
  obtain ⟨t, ht, htl, htu, hs⟩ := hDil Q hQ hQlarge p hprime (hyS.trans_lt hpl) hpQ
  have htU : p * (t * Q) ≤ N := by
    have hh := (le_div_iff₀ (mul_pos hpq hQq)).mp htu
    have hNat : t * (p * Q) ≤ N := by exact_mod_cast hh
    simpa only [mul_left_comm] using hNat
  have htL : N ≤ 173 * Q * p * t := by
    have hh := (div_le_iff₀ (mul_pos (mul_pos (by norm_num : (0 : ℚ) < 173) hpq) hQq)).mp htl
    have hNat : N ≤ t * (173 * p * Q) := by exact_mod_cast hh
    convert hNat using 1
    ring
  exact exists_corrected_stock_block hN hy hyS hyZ hp (hd.trans hpl.le) ht htU htL
    (fun b hb => (hs b (mem_Icc.mp hb).1 (mem_Icc.mp hb).2).1)
    (by simpa only [mul_one] using (hs 1 (by decide) hQ).2)
    (hCover p hpg hpz (fun hb => hpM (hExcluded hb))) hM hS hR

/-- Baseline specialization of the corrected block construction. -/
theorem eventually_retainedBlocks (h : ShortPointwise.LiuSawhneyPrimeHeight) (d : ℕ) :
    ∀ᶠ N : ℕ in atTop, ∀ M S R : Finset ℕ,
      (∀ q ∈ M, q.Prime ∧ Nat.sqrt N < q) →
      (∀ n ∈ S, ∃ q ∈ mediumPrimes N ⌊smoothCutoff N⌋₊ M, q ∣ n) →
      (∀ n ∈ R, n ∣ Nat.lcmUpto ⌊smoothCutoff N⌋₊) →
      Nonempty (RetainedBlocks d N M S R (correctionCharge N M)) := by
  have hW : ∀ᶠ N : ℕ in atTop, 0 < baselineCoverBound 4 N ∧
      Real.sqrt N < (N : ℝ) / baselineCoverBound 4 N ∧
      baselineCoverBound 4 N ≤ 2 * ⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ := by
    filter_upwards [eventually_geometry d, eventually_baselineCutoff_gt_sqrt 4] with N hG hZ
    exact ⟨hG.2.2.2.2.2.1, hZ, hG.2.2.2.2.2.2⟩
  have hCov : ∀ᶠ N : ℕ in atTop, ∀ p ∈ largePrimes N,
      (p : ℝ) ≤ (N : ℝ) / baselineCoverBound 4 N → p ∉ (∅ : Finset ℕ) →
      CoversResidues p (interval 1 (baselineCoverBound 4 N)) :=
    (ShortPointwise.eventually_baseline_common_cover_of_LiuSawhney h).mono
      fun _ hN p hp _ _ => (hN p hp).1
  filter_upwards [eventually_retainedBlocks_at_width d (baselineCoverBound 4) (fun _ => ∅)
    hW hCov] with N hN M S R hM hS hR
  exact hN M S R (empty_subset _) hM hS hR

private theorem eventually_real_primeCounting_le :
    ∀ᶠ x : ℝ in atTop, (Nat.primeCounting ⌊x⌋₊ : ℝ) ≤ 2 * (x / Real.log x) := by
  have h := (Asymptotics.isEquivalent_iff_tendsto_one (by
    filter_upwards [eventually_gt_atTop (1 : ℝ)] with x hx
    exact div_ne_zero (zero_lt_one.trans hx).ne' (Real.log_pos hx).ne')).mp
      Nat.isEquivalent_primeCounting
  filter_upwards [h.eventually_lt_const (show (1 : ℝ) < 2 by norm_num),
    eventually_gt_atTop (1 : ℝ)] with x hr hx
  exact ((div_lt_iff₀ (div_pos (zero_lt_one.trans hx) (Real.log_pos hx))).mp hr).le

/-- The total correction charge is at most `2076 * U / L` when the
cofactor width satisfies the logarithmic and square-root window bounds. -/
theorem eventually_correctionCharge_le_at_width (width : ℕ → ℕ)
    (hWidth : ∀ᶠ N : ℕ in atTop, 0 < width N ∧
      Real.sqrt N < (N : ℝ) / width N ∧
      Real.log (width N : ℝ) ≤ 2 * Real.log (Real.log (N : ℝ)) ∧
      2 * Real.log (width N : ℝ) ≤ Real.log (N : ℝ)) :
    ∀ᶠ N : ℕ in atTop, ∀ M : Finset ℕ,
      (correctionChargeAt N M (width N) : ℝ) ≤ 2076 * Real.log (Real.log N) / Real.log N := by
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hlog := Real.tendsto_log_atTop.comp hcast
  have hZTop : Tendsto (fun N : ℕ => (N : ℝ) / width N) atTop atTop := by
    apply tendsto_atTop.2
    intro x
    filter_upwards [(Real.tendsto_sqrt_atTop.comp hcast).eventually_ge_atTop x,
      hWidth] with N h₁ h₂
    exact h₁.trans h₂.2.1.le
  filter_upwards [hWidth,
    hZTop.eventually eventually_real_primeCounting_le,
    hlog.eventually_ge_atTop 1, (Real.tendsto_log_atTop.comp hlog).eventually_ge_atTop 1,
    eventually_ge_atTop (1 : ℕ)] with N hQ hP hL hU hN M
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let Q := width N
  let Z := (N : ℝ) / Q
  let w := Real.log (Q : ℝ)
  change 1 ≤ L at hL
  change 1 ≤ U at hU
  obtain ⟨hQ₀,_,hw,hwl⟩ := hQ
  change w ≤ 2 * U at hw
  change 2 * w ≤ L at hwl
  have hL₀ : 0 < L := zero_lt_one.trans_le hL
  have hQp : (0 : ℝ) < Q := Nat.cast_pos.mpr hQ₀
  have hN₀ : (0 : ℝ) < N := Nat.cast_pos.mpr hN
  have hZe : Z = (N : ℝ) / Q := rfl
  have hZ₀ : 0 < Z := by rw [hZe]; positivity
  have hZL : Real.log Z = L - w := by rw [hZe, Real.log_div hN₀.ne' hQp.ne']
  have hZL₀ : 0 < Real.log Z := by rw [hZL]; linarith only [hwl,hL₀]
  have hcard : ((correctionPrimes N M (Z := Z)).card : ℝ) ≤ 4 * Z / L := by
    have hs : correctionPrimes N M (Z := Z) ⊆ Nat.primesLE ⌊Z⌋₊ := by
      intro p hp
      exact Nat.mem_primesLE.mpr
        ⟨Nat.le_floor (mem_correctionPrimes.mp hp).2.1, (mem_largePrimes.mp (mem_correctionPrimes.mp hp).1).1⟩
    calc
      _ ≤ (Nat.primeCounting ⌊Z⌋₊ : ℝ) := by
        rw [← Nat.primesLE_card_eq_primeCounting]
        exact_mod_cast card_le_card hs
      _ ≤ 2 * (Z / Real.log Z) := hP
      _ = (2 * Z) / Real.log Z := by ring
      _ ≤ 4 * Z / L := by
        have hl : L / 2 ≤ Real.log Z := by rw [hZL]; linarith only [hwl]
        calc
          _ ≤ (2 * Z) / (L / 2) := div_le_div_of_nonneg_left (by positivity) (by positivity) hl
          _ = _ := by ring
  have hH : (mass (interval 1 Q) : ℝ) ≤ 3 * U := by
    have hh := harmonic_le_one_add_log Q
    rw [← mass_denominators_eq_harmonic] at hh
    change (mass (interval 1 Q) : ℝ) ≤ 1 + w at hh
    linarith only [hh, hw, hU]
  have hQR : 0 ≤ (mass (interval 1 Q) : ℝ) := by exact_mod_cast mass_nonneg (interval 1 Q)
  have hC : (0 : ℝ) ≤ ((173 : ℝ) * Q * (mass (interval 1 Q) : ℝ) / N) := by positivity
  change (correctionChargeAt N M Q : ℝ) ≤ 2076 * U / L
  unfold correctionChargeAt
  push_cast only [Rat.cast_mul, Rat.cast_div, Rat.cast_natCast, Rat.cast_ofNat]
  calc
    _ ≤ (4 * Z / L) * (173 * (Q : ℝ) * (mass (interval 1 Q) : ℝ) / N) :=
      mul_le_mul_of_nonneg_right hcard hC
    _ ≤ (4 * Z / L) * (173 * (Q : ℝ) * (3 * U) / N) := by
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hH (by positivity)) hN₀.le
    _ = _ := by rw [hZe]; field_simp; norm_num

theorem eventually_correctionCharge_le :
    ∀ᶠ N : ℕ in atTop, ∀ M : Finset ℕ,
      (correctionCharge N M : ℝ) ≤ 2076 * Real.log (Real.log N) / Real.log N := by
  apply eventually_correctionCharge_le_at_width (baselineCoverBound 4)
  filter_upwards [eventually_baselineCoverBound_logs 4, eventually_baselineCutoff_gt_sqrt 4]
    with N hQ hZ
  exact ⟨hQ.1, hZ, hQ.2.2.2.2.1, hQ.2.2.2.2.2⟩

/-- Small denominators missing from the stock can only have been excluded
by the repair reservations, provided the entire prefix is below the cutoff. -/
theorem prefix_sdiff_stock_subset_exclusions {d N X : ℕ} {M S R : Finset ℕ} {Z : ℝ}
    (hXN : X ≤ N) (hXZ : (X : ℝ) ≤ Z) :
    interval d X \ stock d N M S R (Z := Z) ⊆ repairExclusions d N (smoothCutoff N) M S R := by
  classical
  intro n hn
  obtain ⟨hI,hV⟩ := mem_sdiff.mp hn
  obtain ⟨hn₁,hnX⟩ := mem_Icc.mp hI
  by_contra hE
  apply hV
  refine mem_stock.mpr ⟨mem_Icc.mpr ⟨hn₁,hnX.trans hXN⟩,hE,?_⟩
  intro p _ hpn
  exact (Nat.cast_le.mpr ((Nat.le_of_dvd ((le_max_left 1 d).trans hn₁) hpn).trans hnX)).trans hXZ

/-- The actual retained family has the baseline total mass, and only the repair
exclusion budget can affect its small singleton prefix. -/
theorem eventually_retainedBlocks_with_mass
    (h : ShortPointwise.LiuSawhneyPrimeHeight) (d : ℕ) (E : ℝ) (hE : 0 ≤ E) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ M S R : Finset ℕ,
      (∀ q ∈ M, q.Prime ∧ Nat.sqrt N < q) →
      (∀ n ∈ S, ∃ q ∈ mediumPrimes N ⌊smoothCutoff N⌋₊ M, q ∣ n) →
      (∀ n ∈ R, n ∣ Nat.lcmUpto ⌊smoothCutoff N⌋₊) →
      (mass (repairExclusions d N (smoothCutoff N) M S R) : ℝ) ≤ E / Real.log (N : ℝ) ^ 4 →
      ∃ B : RetainedBlocks d N M S R (correctionCharge N M),
        (mass (interval d N) : ℝ) - FixedTargets.sufficientLoss N C ≤
          (∑ T ∈ B.family, (mass T : ℝ)) ∧
        mass (interval d N \ stock d N M S R) ≤ 1 ∧
        ∀ X : ℕ, X ≤ Nat.sqrt N → mass (interval d X \ stock d N M S R) ≤ 1 := by
  obtain ⟨K,hK,hCut⟩ := eventually_baselineCutoffPart_mass 4 d
  let C := K + E + 2076
  refine ⟨C, by dsimp [C]; positivity, ?_⟩
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hlog := Real.tendsto_log_atTop.comp hcast
  have hLoglog := Real.tendsto_log_atTop.comp hlog
  have hLogloglog := Real.tendsto_log_atTop.comp hLoglog
  have hCnonneg : 0 ≤ C := by dsimp [C]; positivity
  filter_upwards [eventually_retainedBlocks h d, eventually_correctionCharge_le, hCut,
    hlog.eventually_ge_atTop 1, hLoglog.eventually_ge_atTop 1, hLogloglog.eventually_ge_atTop 1,
    FixedTargets.eventually_losses_between_zero_one 0 C le_rfl hCnonneg]
    with N hRet hCharge hCutN hL hU hV hLoss M S R hM hS hR hRes
  obtain ⟨B⟩ := hRet M S R hM hS hR
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let Z := Real.log U
  change 1 ≤ L at hL
  change 1 ≤ U at hU
  change 1 ≤ Z at hV
  have hL₀ : 0 < L := zero_lt_one.trans_le hL
  have hU₀ : 0 ≤ U := zero_le_one.trans hU
  have hUZ : 1 ≤ U * Z := le_trans hU (le_mul_of_one_le_right hU₀ hV)
  have hE' : E / L ^ 4 ≤ E * U * Z / L := by
    calc
      _ ≤ E / L := div_le_div_of_nonneg_left hE hL₀
        (by simpa only [pow_one] using pow_le_pow_right₀ hL (show (1 : ℕ) ≤ 4 by decide))
      _ ≤ _ := div_le_div_of_nonneg_right (by
        rw [mul_assoc]
        exact le_mul_of_one_le_right hE hUZ) hL₀.le
  have hUpper := (abs_le.mp hCutN).2
  have hGlobal : mass (interval d N \ stock d N M S R) ≤ 1 := by
    classical
    let H := repairExclusions d N (smoothCutoff N) M S R
    let Q := baselineCutoffPart 4 d N
    let I := interval d N
    have hSub : I \ stock d N M S R ⊆ H ∪ Q := by
      intro n hn
      by_contra hq
      exact (mem_sdiff.mp hn).2 (stock_eq_sdiff.symm ▸
        (mem_sdiff.mpr ⟨(mem_sdiff.mp hn).1,hq⟩ : n ∈ I \ (H ∪ Q)))
    have hUnion : mass (H ∪ Q) ≤ mass H + mass Q := by
      have hh := sum_union_inter (s₁ := H) (s₂ := Q) (f := fun a : ℕ => (a : ℚ)⁻¹)
      change mass (H ∪ Q) + mass (H ∩ Q) = mass H + mass Q at hh
      linarith only [hh, mass_nonneg (H ∩ Q)]
    have hh := (mass_mono hSub).trans hUnion
    have hh' := (Rat.cast_le.mpr hh :
      (mass (I \ stock d N M S R) : ℝ) ≤ ((mass H + mass Q : ℚ) : ℝ))
    rw [Rat.cast_add] at hh'
    have h₀ : (mass (I \ stock d N M S R) : ℝ) ≤ FixedTargets.sufficientLoss N C := by
      change (mass (I \ stock d N M S R) : ℝ) ≤ U ^ 2 / (2 * L) + C * U * Z / L
      have hConv₀ : 0 ≤ (2076 : ℝ) * U * Z / L := by positivity
      change _ ≤ _ at hh'
      dsimp only [H, Q] at hh'
      have heq : C * U * Z / L = K * U * Z / L + E * U * Z / L + 2076 * U * Z / L := by
        dsimp only [C]; ring
      rw [heq]
      linarith only [hh', hUpper, hRes, hE', hConv₀]
    have hOne := h₀.trans hLoss.2.2.le
    exact_mod_cast hOne
  refine ⟨B, ?_, hGlobal, ?_⟩
  · have hCh := hCharge M
    have hConv : 2076 * U / L ≤ 2076 * U * Z / L := by
      apply div_le_div_of_nonneg_right _ hL₀.le
      exact le_mul_of_one_le_right (mul_nonneg (by norm_num) hU₀) hV
    have hW := (Rat.cast_le.mpr B.weight :
      ((mass (stock d N M S R) - correctionCharge N M : ℚ) : ℝ) ≤
      (↑(∑ T ∈ B.family, mass T) : ℝ))
    have hSt := (Rat.cast_le.mpr (mass_stock_ge d N M S R) :
      ((mass (interval d N) - mass (repairExclusions d N (smoothCutoff N) M S R) -
        mass (baselineCutoffPart 4 d N) : ℚ) : ℝ) ≤ (mass (stock d N M S R) : ℝ))
    rw [Rat.cast_sub, Rat.cast_sum] at hW
    rw [Rat.cast_sub, Rat.cast_sub] at hSt
    change (mass (interval d N) : ℝ) - (U ^ 2 / (2 * L) + C * U * Z / L) ≤ _
    calc
      _ = (mass (interval d N) : ℝ) - (U ^ 2 / (2 * L) + K * U * Z / L) -
          E * U * Z / L - 2076 * U * Z / L := by dsimp only [C]; ring
      _ ≤ _ := by linarith only [hW, hSt, hUpper, hRes, hE', hCh, hConv]
  · intro X hX
    apply le_trans (mass_mono ?_) hGlobal
    intro n hn
    obtain ⟨hnI, hnS⟩ := mem_sdiff.mp hn
    exact mem_sdiff.mpr ⟨Icc_subset_Icc le_rfl (hX.trans (Nat.sqrt_le_self N)) hnI, hnS⟩


/-- Supplies enough corrected stock uniformly for all permissible repair pools. -/
def HasRetainedBlockMass (width : ℕ → ℕ) (excluded : ℕ → Finset ℕ)
    (loss : ℕ → ℝ → ℝ) : Prop :=
  ∀ (d : ℕ) (E : ℝ), 0 ≤ E → ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
    ∀ M S R : Finset ℕ,
      (∀ q ∈ M, q.Prime ∧ Nat.sqrt N < q) →
      (∀ n ∈ S, ∃ q ∈ mediumPrimes N ⌊smoothCutoff N⌋₊ M, q ∣ n) →
      (∀ n ∈ R, n ∣ Nat.lcmUpto ⌊smoothCutoff N⌋₊) →
      (mass (repairExclusions d N (smoothCutoff N) M S R) : ℝ) ≤ E / Real.log (N : ℝ) ^ 4 →
      let Z := (N : ℝ) / width N
      let M' := M ∪ excluded N
      ∃ B : RetainedBlocks d N M' S R (correctionChargeAt N M' (width N)) (Z := Z),
        (mass (interval d N) : ℝ) - loss N C ≤ (∑ T ∈ B.family, (mass T : ℝ)) ∧
        mass (interval d N \ stock d N M' S R (Z := Z)) ≤ 1

/-- The original stock estimate uses the empty extra exclusion set. -/
theorem hasRetainedBlockMass_of_LiuSawhney (h : ShortPointwise.LiuSawhneyPrimeHeight) :
    HasRetainedBlockMass (baselineCoverBound 4) (fun _ => ∅) FixedTargets.sufficientLoss := by
  intro d E hE
  obtain ⟨C, hC, hAll⟩ := eventually_retainedBlocks_with_mass h d E hE
  refine ⟨C, hC, hAll.mono ?_⟩
  intro N hN M S R hM hS hR hBudget
  obtain ⟨B, hW, hFew, _⟩ := hN M S R hM hS hR hBudget
  let HasMass (F : Finset ℕ) : Prop := ∃ A : RetainedBlocks d N F S R (correctionCharge N F),
    (mass (interval d N) : ℝ) - FixedTargets.sufficientLoss N C ≤
      (∑ T ∈ A.family, (mass T : ℝ)) ∧ mass (interval d N \ stock d N F S R) ≤ 1
  change HasMass (M ∪ ∅)
  rw [union_empty]
  exact ⟨B, hW, hFew⟩

end LeanAB.PaperB.Baseline
