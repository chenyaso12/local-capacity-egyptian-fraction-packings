module

public import PaperB.NearCapacityCount
meta import Mathlib.Tactic

/-! The inverse-height consequences of attaining local capacity, as in F2. -/

@[expose] public section

namespace LeanAB.PaperB

open Filter FixedTargets
open scoped Topology

theorem exists_height_of_capacity (j : ℕ) : ∃ N : ℕ, (j : ℝ) ≤ (capacity N : ℝ) := by
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hE : ∀ᶠ N : ℕ in atTop, (j : ℝ) ≤ (capacity N : ℝ) := by
    filter_upwards [capacityNearHarmonic, hLog.eventually_ge_atTop ((j : ℝ) + 1)]
      with N hClose hL
    change (j : ℝ) + 1 ≤ Real.log (N : ℝ) at hL
    have hClose' : |(capacity N : ℝ) - (harmonic N : ℝ)| ≤ 1 := hClose
    have hLo : Real.log (N : ℝ) ≤ (harmonic N : ℝ) := by
      simpa only [Nat.floor_natCast] using log_le_harmonic_floor (N : ℝ) (by positivity)
    linarith only [hL, hLo, (abs_le.mp hClose').1]
  exact hE.exists

/-- The least height whose local capacity reaches the given integer target. -/
noncomputable def localCapacityHeight (j : ℕ) : ℕ :=
  Nat.find (exists_height_of_capacity j)

theorem localCapacityHeight_spec (j : ℕ) :
    (j : ℝ) ≤ (capacity (localCapacityHeight j) : ℝ) ∧
      ∀ M < localCapacityHeight j, (capacity M : ℝ) < (j : ℝ) := by
  unfold localCapacityHeight
  exact ⟨Nat.find_spec (exists_height_of_capacity j),
    fun M hM => lt_of_not_ge (Nat.find_min (exists_height_of_capacity j) hM)⟩

theorem tendsto_localCapacityHeight : Tendsto localCapacityHeight atTop atTop := by
  refine tendsto_atTop.mpr fun X => ?_
  filter_upwards [eventually_gt_atTop ⌈(capacity X : ℝ)⌉₊] with j hj
  by_contra! h
  have hCap : (capacity (localCapacityHeight j) : ℝ) ≤ (capacity X : ℝ) :=
    Rat.cast_le.mpr (capacity_mono h.le)
  have hjR : (⌈(capacity X : ℝ)⌉₊ : ℝ) < (j : ℝ) := by exact_mod_cast hj
  exact (Nat.le_ceil (capacity X : ℝ) |>.trans_lt hjR).not_ge
    ((localCapacityHeight_spec j).1.trans hCap)

theorem exists_unit_height_of_attainment {A : ℝ} (hA : 0 ≤ A)
    (hAttain : CapacityAttainment A) (j : ℕ) : ∃ N, j ≤ k N := by
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hEventually : ∀ᶠ N : ℕ in atTop, j ≤ k N := by
    filter_upwards [eventually_nearCapacityGroupCount A hA, hAttain,
      hLog.eventually_ge_atTop ((j : ℝ) + 4)] with N hCount hLower hL
    change (j : ℝ) + 4 ≤ Real.log (N : ℝ) at hL
    have hj : j ≤ nearCapacityGroupCount A N := by
      have hm : (j : ℝ) ≤ (nearCapacityGroupCount A N : ℝ) := by
        linarith only [hL, (abs_le.mp hCount.2.1).1]
      exact_mod_cast hm
    rw [← hCount.2.2.2.2] at hLower
    omega
  exact hEventually.exists

theorem exists_integer_height_of_attainment {A : ℝ} (hA : 0 ≤ A)
    (hAttain : CapacityAttainment A) (j : ℕ) : ∃ N, j ∈ representedIntegers N := by
  obtain ⟨N, hN⟩ := exists_unit_height_of_attainment hA hAttain j
  exact ⟨N, integer_represented_of_le_k hN⟩

theorem localCapacityHeight_le_integerHeight (j : ℕ)
    (hInteger : ∃ N, j ∈ representedIntegers N) :
    localCapacityHeight j ≤ integerHeight j hInteger := by
  let T := integerHeight j hInteger
  have hjh : j ≤ h T := (h_isGreatest T).2 (mem_representedIntegers.mp
    (integerHeight_spec j hInteger).1)
  have hjh' : (j : ℤ) ≤ (h T : ℤ) := by exact_mod_cast hjh
  have hjC : (j : ℤ) ≤ ⌊capacity T⌋ := hjh'.trans (h_le_floor_capacity T)
  have hjC' : (j : ℚ) ≤ capacity T := by simpa only [Int.cast_natCast] using Int.le_floor.mp hjC
  exact Nat.find_min' _ (by exact_mod_cast hjC')

/-- Move at most \(O(X^{11/12})\) past X to attain every integer up to
the local capacity at X. The loss in the packing construction is paid for
by actual growth of capacity over this window. -/
theorem eventually_nearCapacity_height_window {A : ℝ} (hA : 0 ≤ A)
    (hAttain : CapacityAttainment A) :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ X : ℕ in atTop, ∃ N : ℕ,
      X ≤ N ∧ (N : ℝ) ≤ (X : ℝ) + D * (X : ℝ) ^ (11 / 12 : ℝ) ∧
        ∀ j : ℕ, (j : ℝ) ≤ (capacity X : ℝ) → j ≤ k N := by
  obtain ⟨T, hT⟩ := eventually_atTop.mp hAttain
  let K : ℝ := 4 + 57600 * A
  have hK : 4 ≤ K := by dsimp [K]; linarith only [hA]
  have hK₀ : 0 < K := by linarith
  refine ⟨K + 1, by linarith, ?_⟩
  have hPow : Tendsto (fun X : ℕ => (X : ℝ) ^ (1 / 12 : ℝ)) atTop atTop :=
    (tendsto_rpow_atTop (show 0 < (1 / 12 : ℝ) by norm_num)).comp tendsto_natCast_atTop_atTop
  filter_upwards [eventually_capacity_window_growth, eventually_ge_atTop T, hPow.eventually_ge_atTop (K + 1),
    eventually_ge_atTop (1 : ℕ)] with X hGrow hXT hLarge hX
  let x : ℝ := X
  let P := x ^ (1 / 12 : ℝ)
  let Q := x ^ (11 / 12 : ℝ)
  let Y := ⌈K * Q⌉₊
  let N := X + Y
  have hx₁ : 1 ≤ x := by dsimp [x]; exact_mod_cast hX
  have hx₀ : 0 < x := zero_lt_one.trans_le hx₁
  have hP : 0 < P := Real.rpow_pos_of_pos hx₀ _
  have hQ : 0 < Q := Real.rpow_pos_of_pos hx₀ _
  have hQ₁ : 1 ≤ Q := Real.one_le_rpow hx₁ (by norm_num)
  have hProduct : Q * P = x := by
    dsimp only [Q, P]
    rw [← Real.rpow_add hx₀, show (11 / 12 : ℝ) + 1 / 12 = 1 by norm_num, Real.rpow_one]
  have hLenLo : K * Q ≤ (Y : ℝ) := Nat.le_ceil _
  have hLenUp : (Y : ℝ) ≤ (K + 1) * Q := by
    have h := (Nat.ceil_lt_add_one (mul_nonneg hK₀.le hQ.le)).le
    change (Y : ℝ) ≤ K * Q + 1 at h
    calc
      _ ≤ K * Q + 1 := h
      _ ≤ K * Q + Q := add_le_add le_rfl hQ₁
      _ = _ := by ring
  have hLenX : (Y : ℝ) ≤ x := hLenUp.trans (by
    have hh : K + 1 ≤ P := hLarge
    rw [← hProduct, mul_comm Q P]
    exact mul_le_mul_of_nonneg_right hh hQ.le)
  have hNafter : X ≤ N := by dsimp [N]; omega
  have hNcalc : (N : ℝ) = x + (Y : ℝ) := Nat.cast_add _ _
  have hNu : (N : ℝ) ≤ 2 * x := by linarith only [hNcalc, hLenX]
  have hWide : 4 * (x ^ (2 / 3 : ℝ)) ≤ (N : ℝ) - x := by
    rw [hNcalc, add_sub_cancel_left]
    have hPowOrder : x ^ (2 / 3 : ℝ) ≤ Q :=
      Real.rpow_le_rpow_of_exponent_le hx₁ (by norm_num)
    exact (mul_le_mul_of_nonneg hK hPowOrder (by positivity) hQ.le).trans hLenLo
  have hG := hGrow x (N : ℝ) le_rfl hNu hWide
  change ((N : ℝ) - x) / (57600 * x) ≤
    (capacity ⌊(N : ℝ)⌋₊ : ℝ) - (capacity ⌊(X : ℝ)⌋₊ : ℝ) at hG
  rw [Nat.floor_natCast, Nat.floor_natCast, hNcalc, add_sub_cancel_left] at hG
  have hPay : A / P ≤ (Y : ℝ) / (57600 * x) := by
    apply (div_le_div_iff₀ hP (by positivity)).mpr
    have hK' : 57600 * A ≤ K := by dsimp [K]; linarith
    calc
      _ = ((57600 * A) * Q) * P := by rw [mul_assoc, hProduct]; ring
      _ ≤ (K * Q) * P :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hK' hQ.le) hP.le
      _ ≤ _ := mul_le_mul_of_nonneg_right hLenLo hP.le
  have hNX : x ≤ (N : ℝ) := by dsimp [x]; exact_mod_cast hNafter
  have hLoss : A / (N : ℝ) ^ (1 / 12 : ℝ) ≤ A / P :=
    div_le_div_of_nonneg_left hA hP (Real.rpow_le_rpow hx₀.le hNX (by norm_num))
  have hAtt := hT N (hXT.trans hNafter)
  refine ⟨N, hNafter, hNcalc.le.trans (add_le_add le_rfl hLenUp), ?_⟩
  intro j hj
  have hMargin : (j : ℝ) ≤ (capacity N : ℝ) - A / (N : ℝ) ^ (1 / 12 : ℝ) := by
    linarith only [hj, hG, hPay, hLoss]
  have hFloor : (j : ℤ) ≤ ⌊(capacity N : ℝ) - A / (N : ℝ) ^ (1 / 12 : ℝ)⌋ :=
    Int.le_floor.mpr (by simpa only [Int.cast_natCast] using hMargin)
  exact_mod_cast hFloor.trans hAtt

/-- With capacity attainment, the inverse heights differ from the least
capacity height by at most the window size from F2. -/
theorem eventually_nearCapacity_inverse_heights {A : ℝ} (hA : 0 ≤ A)
    (hAttain : CapacityAttainment A) :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ j : ℕ in atTop,
      let M := localCapacityHeight j
      let T := integerHeight j (exists_integer_height_of_attainment hA hAttain j)
      let N := unitHeight j (exists_unit_height_of_attainment hA hAttain j)
      M ≤ T ∧ T ≤ N ∧ (N : ℝ) ≤ (M : ℝ) + D * (M : ℝ) ^ (11 / 12 : ℝ) := by
  obtain ⟨D, hD, hWindow⟩ := eventually_nearCapacity_height_window hA hAttain
  refine ⟨D, hD, ?_⟩
  filter_upwards [tendsto_localCapacityHeight.eventually hWindow] with j hw
  let M := localCapacityHeight j
  let hInteger := exists_integer_height_of_attainment hA hAttain j
  let hUnit := exists_unit_height_of_attainment hA hAttain j
  let T := integerHeight j hInteger
  let N := unitHeight j hUnit
  obtain ⟨U, _, hUwindow, hUunit⟩ := hw
  have hNu : N ≤ U := Nat.find_min' hUnit (hUunit j (localCapacityHeight_spec j).1)
  refine ⟨localCapacityHeight_le_integerHeight j hInteger,
    integerHeight_le_unitHeight j hInteger hUnit, ?_⟩
  exact (Nat.cast_le.mpr hNu : (N : ℝ) ≤ (U : ℝ)).trans hUwindow

/-- The logarithmic inverse-height gap has the exponential scale in F2. -/
theorem eventually_nearCapacity_inverse_log_gap {A : ℝ} (hA : 0 ≤ A)
    (hAttain : CapacityAttainment A) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ j : ℕ in atTop,
      let T := integerHeight j (exists_integer_height_of_attainment hA hAttain j)
      let N := unitHeight j (exists_unit_height_of_attainment hA hAttain j)
      0 ≤ Real.log (N : ℝ) - Real.log (T : ℝ) ∧
      Real.log (N : ℝ) - Real.log (T : ℝ) ≤ C * Real.exp (-(j : ℝ) / 12) := by
  obtain ⟨D, hD, hHeights⟩ := eventually_nearCapacity_inverse_heights hA hAttain
  refine ⟨D * Real.exp (1 / 6), mul_pos hD (Real.exp_pos _), ?_⟩
  have hClose : ∀ᶠ X : ℕ in atTop, |(capacity X : ℝ) - (harmonic X : ℝ)| ≤ 1 :=
    capacityNearHarmonic
  filter_upwards [hHeights, tendsto_localCapacityHeight.eventually hClose,
    tendsto_localCapacityHeight.eventually_ge_atTop (1 : ℕ)] with j hBounds hNear hM
  let M := localCapacityHeight j
  let T := integerHeight j (exists_integer_height_of_attainment hA hAttain j)
  let N := unitHeight j (exists_unit_height_of_attainment hA hAttain j)
  let x : ℝ := M
  have hMpos : 0 < x := by dsimp [x]; exact_mod_cast (show 0 < M by omega)
  have hMT : x ≤ (T : ℝ) := by dsimp [x]; exact_mod_cast hBounds.1
  have hTN : (T : ℝ) ≤ (N : ℝ) := by exact_mod_cast hBounds.2.1
  have hTpos := hMpos.trans_le hMT
  have hNpos := hTpos.trans_le hTN
  have hLogT := Real.log_le_log hMpos hMT
  constructor
  · exact sub_nonneg.mpr (Real.log_le_log hTpos hTN)
  have hGap : Real.log (N : ℝ) - Real.log (T : ℝ) ≤ D / x ^ (1 / 12 : ℝ) := by
    have hProd : x ^ (11 / 12 : ℝ) * x ^ (1 / 12 : ℝ) = x := by
      rw [← Real.rpow_add hMpos, show (11 / 12 : ℝ) + 1 / 12 = 1 by norm_num, Real.rpow_one]
    have hDiff : (N : ℝ) - x ≤ D * x ^ (11 / 12 : ℝ) := by linarith only [hBounds.2.2]
    calc
      _ ≤ Real.log (N : ℝ) - Real.log x := sub_le_sub_left hLogT _
      _ = Real.log ((N : ℝ) / x) := (Real.log_div hNpos.ne' hMpos.ne').symm
      _ ≤ (N : ℝ) / x - 1 := Real.log_le_sub_one_of_pos (div_pos hNpos hMpos)
      _ = ((N : ℝ) - x) / x := by rw [sub_div, div_self hMpos.ne']
      _ ≤ D * x ^ (11 / 12 : ℝ) / x := div_le_div_of_nonneg_right hDiff hMpos.le
      _ = _ := by
        field_simp [hMpos.ne', (Real.rpow_pos_of_pos hMpos (1 / 12 : ℝ)).ne']
        exact hProd
  have hH := harmonic_le_one_add_log M
  have hj := (localCapacityHeight_spec j).1
  have hNear' : |(capacity M : ℝ) - (harmonic M : ℝ)| ≤ 1 := hNear
  have hMexp : Real.exp ((j : ℝ) - 2) ≤ x := by
    calc
      _ ≤ Real.exp (Real.log x) := Real.exp_le_exp.mpr
        (by dsimp [x]; linarith only [hH, hj, (abs_le.mp hNear').2])
      _ = _ := Real.exp_log hMpos
  have hMpow : Real.exp (((j : ℝ) - 2) / 12) ≤ x ^ (1 / 12 : ℝ) := by
    rw [div_eq_mul_inv, ← one_div (12 : ℝ), Real.exp_mul]
    exact Real.rpow_le_rpow (Real.exp_pos _).le hMexp (by norm_num)
  calc
    _ ≤ D / x ^ (1 / 12 : ℝ) := hGap
    _ ≤ D / Real.exp (((j : ℝ) - 2) / 12) :=
      div_le_div_of_nonneg_left hD.le (Real.exp_pos _) hMpow
    _ = _ := by
      rw [div_eq_mul_inv, ← Real.exp_neg, show -(((j : ℝ) - 2) / 12) =
        1 / 6 + (-(j : ℝ) / 12) by ring, Real.exp_add]
      ring

end LeanAB.PaperB

