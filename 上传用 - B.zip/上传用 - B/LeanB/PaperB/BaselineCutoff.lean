module

public import PaperB.Obstruction.Published
public import PaperB.RepairBudget
meta import Mathlib.Tactic

/-! Quantitative cost of the baseline's initial large-prime exclusion. -/

@[expose] public section

open Filter Finset
open scoped Topology

namespace LeanAB.PaperB

/-- The original baseline uses k=4, and the Yokota variant uses k=5. -/
noncomputable def baselineCoverBound (k N : ℕ) : ℕ :=
  ⌈Real.log (N : ℝ) * (Real.log (Real.log (N : ℝ))) ^ k⌉₊

/-- Real cutoff: the retained large primes satisfy p ≤ N/Q. -/
noncomputable def baselineCutoff (k N : ℕ) : ℝ :=
  (N : ℝ) / (baselineCoverBound k N : ℝ)

/-- The denominators with a prime factor above the given cutoff. -/
noncomputable def cutoffPart (d N : ℕ) (z : ℝ) : Finset ℕ :=
  (primesBetween z N).biUnion (fun p => primePart p (interval d N))

theorem mem_cutoffPart {d N n : ℕ} {z : ℝ} (hz₀ : 0 ≤ z) :
    n ∈ cutoffPart d N z ↔ n ∈ interval d N ∧
      ∃ p : ℕ, p.Prime ∧ z < (p : ℝ) ∧ p ∣ n := by
  constructor
  · intro hn
    obtain ⟨p, hp, hn⟩ := mem_biUnion.mp hn
    obtain ⟨hz, _, hpr⟩ := (mem_primesBetween hz₀ (Nat.cast_nonneg _)).mp hp
    obtain ⟨hInt, hpN⟩ := mem_filter.mp hn
    exact ⟨hInt, p, hpr, hz, hpN⟩
  · rintro ⟨hn, p, hpr, hz, hdiv⟩
    have hInt := mem_Icc.mp hn
    have hnPos : 0 < n := (Nat.zero_lt_succ 0).trans_le ((le_max_left 1 d).trans hInt.1)
    have hpN : p ≤ N := (Nat.le_of_dvd hnPos hdiv).trans hInt.2
    exact mem_biUnion.mpr ⟨p,
      (mem_primesBetween hz₀ (Nat.cast_nonneg _)).mpr ⟨hz, by exact_mod_cast hpN, hpr⟩,
      mem_filter.mpr ⟨hn, hdiv⟩⟩

/-- The actual denominators excluded by the baseline cofactor cutoff. -/
noncomputable def baselineCutoffPart (k d N : ℕ) : Finset ℕ :=
  cutoffPart d N (baselineCutoff k N)

theorem mem_baselineCutoffPart {k d N n : ℕ} :
    n ∈ baselineCutoffPart k d N ↔ n ∈ interval d N ∧
      ∃ p : ℕ, p.Prime ∧ baselineCutoff k N < (p : ℝ) ∧ p ∣ n :=
  mem_cutoffPart (div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _))


/-- Ceiling the cofactor scale preserves the logarithmic window and keeps it
within the range of the uniform prime-mass estimate. -/
theorem eventually_baselineCoverBound_logs (k : ℕ) :
    ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      let U := Real.log L
      let Q := baselineCoverBound k N
      let w := Real.log (Q : ℝ)
      0 < Q ∧ (Q : ℝ) ≤ 2 * L ^ (k + 1) ∧ U ≤ w ∧
        |w - U| ≤ ((k : ℝ) + 1) * Real.log U ∧ w ≤ 2 * U ∧ 2 * w ≤ L := by
  have hCast : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hCast
  have hLogLog := Real.tendsto_log_atTop.comp hLog
  have hLittleU := Real.isLittleO_log_id_atTop.bound (by positivity :
    (0 : ℝ) < 1 / ((k : ℝ) + 1))
  have hLittleL := Real.isLittleO_log_id_atTop.bound (by norm_num : (0 : ℝ) < 1 / 4)
  filter_upwards [hLog.eventually_ge_atTop 1, hLogLog.eventually_ge_atTop 2,
    hLogLog.eventually hLittleU, hLog.eventually hLittleL] with N hL hU hSlowU hSlowL
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let Q := baselineCoverBound k N
  let w := Real.log (Q : ℝ)
  let A := L * U ^ k
  change 1 ≤ L at hL
  change 2 ≤ U at hU
  have hL₀ : 0 < L := zero_lt_one.trans_le hL
  have hU₁ : 1 ≤ U := by linarith
  have hU₀ : 0 < U := zero_lt_one.trans_le hU₁
  have hlogU : 0 ≤ Real.log U := Real.log_nonneg hU₁
  have hA : 1 ≤ A := by
    change (1 : ℝ) ≤ L * U ^ k
    calc
      1 ≤ L := hL
      _ = L * 1 := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (one_le_pow₀ hU₁) hL₀.le
  have hA₀ : 0 < A := zero_lt_one.trans_le hA
  have hQ : 0 < Q := Nat.ceil_pos.mpr hA₀
  have hQ₀ : (0 : ℝ) < Q := Nat.cast_pos.mpr hQ
  have hQle : (Q : ℝ) ≤ 2 * A := by
    have hC := Nat.ceil_lt_add_one hA₀.le
    change (Q : ℝ) < A + 1 at hC
    linarith only [hC, hA]
  have hUL : U ≤ L := by
    have h := Real.log_le_sub_one_of_pos hL₀
    change U ≤ L - 1 at h
    linarith
  have hQL : (Q : ℝ) ≤ 2 * L ^ (k + 1) := calc
    _ ≤ 2 * A := hQle
    _ ≤ 2 * (L * L ^ k) := by
      have hPow : U ^ k ≤ L ^ k := pow_le_pow_left₀ hU₀.le hUL _
      exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hPow hL₀.le) (by norm_num)
    _ = _ := by rw [pow_succ]; ring
  have hLogA : Real.log A = U + (k : ℝ) * Real.log U := by
    change Real.log (L * U ^ k) = _
    rw [Real.log_mul hL₀.ne' (pow_ne_zero _ hU₀.ne'), Real.log_pow]
  have hWLo : U ≤ w := by
    have h := Real.log_le_log hA₀ (Nat.le_ceil A)
    change Real.log A ≤ w at h
    rw [hLogA] at h
    linarith [mul_nonneg (Nat.cast_nonneg k : (0 : ℝ) ≤ k) hlogU]
  have hWHi : w ≤ U + ((k : ℝ) + 1) * Real.log U := by
    have h := Real.log_le_log hQ₀ hQle
    change w ≤ Real.log (2 * A) at h
    rw [Real.log_mul (by norm_num) hA₀.ne', hLogA] at h
    have h2 := Real.log_le_log (show (0 : ℝ) < 2 by norm_num) hU
    linarith
  have hTol : ((k : ℝ) + 1) * Real.log U ≤ U := by
    change ‖Real.log U‖ ≤ (1 / ((k : ℝ) + 1)) * ‖U‖ at hSlowU
    simp only [Real.norm_eq_abs, abs_of_nonneg hlogU, abs_of_nonneg hU₀.le,
      one_div_mul_eq_div] at hSlowU
    simpa only [mul_comm ((k : ℝ) + 1)] using
      (le_div_iff₀ (show (0 : ℝ) < (k : ℝ) + 1 by positivity)).mp hSlowU
  have hFour : 4 * U ≤ L := by
    change ‖U‖ ≤ (1 / 4 : ℝ) * ‖L‖ at hSlowL
    simp only [Real.norm_eq_abs, abs_of_nonneg hU₀.le, abs_of_nonneg hL₀.le] at hSlowL
    linarith
  have hWTwo : w ≤ 2 * U := by linarith
  refine ⟨hQ, hQL, hWLo, ?_, hWTwo, by linarith⟩
  rw [abs_of_nonneg (sub_nonneg.mpr hWLo)]
  linarith

/-- The rounded cofactor bound is negligible relative to sqrt N. -/
theorem tendsto_baselineCoverBound_div_sqrt (k : ℕ) :
    Tendsto (fun N : ℕ => (baselineCoverBound k N : ℝ) / Real.sqrt (N : ℝ)) atTop (𝓝 0) := by
  have hCast : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLim : Tendsto (fun N : ℕ => 2 * (N : ℝ) ^ (-(1 / 4 : ℝ))) atTop (𝓝 0) := by
    simpa only [Function.comp_apply, mul_zero] using
      (((tendsto_rpow_neg_atTop (show (0 : ℝ) < 1 / 4 by norm_num)).comp hCast).const_mul (2 : ℝ))
  apply squeeze_zero' (Eventually.of_forall fun _ => by positivity) _ hLim
  filter_upwards [eventually_baselineCoverBound_logs k,
    Closure.eventually_log_pow_le_rpow (k + 1) (show (0 : ℝ) < 1 / 4 by norm_num),
    eventually_ge_atTop (1 : ℕ)] with N hQ hPow hN
  have hNr : (0 : ℝ) < N := Nat.cast_pos.mpr (zero_lt_one.trans_le hN)
  calc
    _ ≤ (2 * (N : ℝ) ^ (1 / 4 : ℝ)) / Real.sqrt N :=
      div_le_div_of_nonneg_right
        (hQ.2.1.trans (mul_le_mul_of_nonneg_left hPow (by norm_num))) (Real.sqrt_nonneg _)
    _ = _ := by rw [Real.sqrt_eq_rpow, mul_div_assoc, ← Real.rpow_sub hNr,
        show ((1 / 4 : ℝ) - 1 / 2) = -(1 / 4 : ℝ) by norm_num]

private theorem baselineCutoff_eq_windowLeft {k N : ℕ} (hQ : 0 < baselineCoverBound k N) :
    (N : ℝ) * Real.exp (-Real.log (baselineCoverBound k N : ℝ)) = baselineCutoff k N := by
  rw [Real.exp_neg, Real.exp_log (Nat.cast_pos.mpr hQ), baselineCutoff, div_eq_mul_inv]

theorem eventually_baselineCutoff_gt_sqrt (k : ℕ) :
    ∀ᶠ N : ℕ in atTop, Real.sqrt (N : ℝ) < baselineCutoff k N := by
  filter_upwards [eventually_baselineCoverBound_logs k,
    (tendsto_baselineCoverBound_div_sqrt k).eventually_lt_const (by norm_num : (0 : ℝ) < 1),
    eventually_ge_atTop (1 : ℕ)] with N hQ hSmall hN
  have hNr : (0 : ℝ) < N := Nat.cast_pos.mpr (zero_lt_one.trans_le hN)
  have hSqrt : 0 < Real.sqrt (N : ℝ) := Real.sqrt_pos.mpr hNr
  have hSmall' : (baselineCoverBound k N : ℝ) < Real.sqrt (N : ℝ) := by
    have h := (div_lt_iff₀ hSqrt).mp hSmall
    simpa only [one_mul] using h
  unfold baselineCutoff
  apply (lt_div_iff₀ (Nat.cast_pos.mpr hQ.1)).mpr
  exact (mul_lt_mul_of_pos_left hSmall' hSqrt).trans_eq (Real.mul_self_sqrt hNr.le)

private theorem baselineCutoffPart_eq_full {k d N : ℕ}
    (hd : (d : ℝ) ≤ baselineCutoff k N) :
    baselineCutoffPart k d N = baselineCutoffPart k 1 N := by
  ext n
  rw [mem_baselineCutoffPart, mem_baselineCutoffPart]
  constructor
  · rintro ⟨hn, h⟩
    obtain ⟨hlo, hhi⟩ := mem_Icc.mp hn
    exact ⟨mem_Icc.mpr ⟨(le_max_left 1 d).trans hlo, hhi⟩, h⟩
  · rintro ⟨hn, p, hp, hpZ, hdiv⟩
    obtain ⟨hlo, hhi⟩ := mem_Icc.mp hn
    have hnPos : 0 < n := (Nat.zero_lt_succ 0).trans_le hlo
    have hd' : d ≤ p := by exact_mod_cast (hd.trans hpZ.le)
    exact ⟨mem_Icc.mpr ⟨max_le (Nat.succ_le_of_lt hnPos) (hd'.trans (Nat.le_of_dvd hnPos hdiv)),
      hhi⟩, p, hp, hpZ, hdiv⟩

/-- Absolute estimate of the mass of the actual removed denominators. Both
the rounded cutoff and the lower endpoint d agree with the paper's sets. -/
theorem eventually_baselineCutoffPart_mass (k d : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      let U := Real.log L
      |(mass (baselineCutoffPart k d N) : ℝ) - U ^ 2 / (2 * L)| ≤
        C * U * Real.log U / L := by
  obtain ⟨C, hC, hError⟩ :=
    eventually_windowPrimeMass_error_loglog ((k : ℝ) + 1) (by positivity)
  let C' := C + 2 * ((k : ℝ) + 1)
  refine ⟨C', by dsimp [C']; positivity, ?_⟩
  have hCast : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hCast
  have hLogLog := Real.tendsto_log_atTop.comp hLog
  filter_upwards [eventually_baselineCoverBound_logs k, hError, hLog.eventually_ge_atTop 1,
    hLogLog.eventually_ge_atTop (Real.exp 1), eventually_ge_atTop (d ^ 2),
    eventually_ge_atTop (1 : ℕ)] with N hQ hError hL hU hNlarge hN
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let w := Real.log (baselineCoverBound k N : ℝ)
  obtain ⟨hQ₀, _, hUle, hWindow, hWTwo, hWHalf⟩ := hQ
  have hN₀ : 0 < N := zero_lt_one.trans_le hN
  have hL₀ : 0 < L := zero_lt_one.trans_le hL
  have hNR : (0 : ℝ) < N := Nat.cast_pos.mpr hN₀
  have hU₀ : 0 < U := (Real.exp_pos (1 : ℝ)).trans_le hU
  have hUlog : 1 ≤ Real.log U := by
    have h := Real.log_le_log (Real.exp_pos (1 : ℝ)) hU
    rwa [Real.log_exp] at h
  have hZ : (d : ℝ) ≤ baselineCutoff k N := calc
    _ ≤ Real.sqrt (N : ℝ) := (Real.le_sqrt (Nat.cast_nonneg d) hNR.le).mpr
      (by exact_mod_cast hNlarge)
    _ ≤ _ := (baselineCutoff_eq_windowLeft hQ₀) ▸ sqrt_le_windowLeft hNR hWHalf
  have hMass : (mass (baselineCutoffPart k d N) : ℝ) = windowPrimeMass N w := by
    rw [baselineCutoffPart_eq_full hZ]
    rw [windowPrimeMass_eq_union_mass hN₀ hWHalf, baselineCutoff_eq_windowLeft hQ₀]
    rfl
  have hError' := hError w hWindow
  have hSquare : |w ^ 2 / (2 * L) - U ^ 2 / (2 * L)| ≤
      (2 * ((k : ℝ) + 1)) * U * Real.log U / L := by
    have hW₀ : 0 ≤ w := hU₀.le.trans hUle
    have hSub₀ : 0 ≤ w - U := sub_nonneg.mpr hUle
    have hSum₀ : 0 ≤ w + U := add_nonneg hW₀ hU₀.le
    have hLogU₀ : 0 ≤ Real.log U := zero_le_one.trans hUlog
    have hDelta : w - U ≤ ((k : ℝ) + 1) * Real.log U :=
      (le_abs_self _).trans hWindow
    have hSquare₀ : 0 ≤ w ^ 2 - U ^ 2 := sub_nonneg.mpr (pow_le_pow_left₀ hU₀.le hUle _)
    rw [← sub_div, abs_div, abs_of_nonneg hSquare₀, abs_of_pos (by positivity : 0 < 2 * L)]
    calc
      _ = ((w - U) * (w + U)) / (2 * L) := by ring
      _ ≤ ((((k : ℝ) + 1) * Real.log U) * (4 * U)) / (2 * L) := by
        apply div_le_div_of_nonneg_right _ (by positivity)
        exact mul_le_mul hDelta (by linarith) hSum₀
          (mul_nonneg (by positivity) hLogU₀)
      _ = _ := by ring
  change |(mass (baselineCutoffPart k d N) : ℝ) - U ^ 2 / (2 * L)| ≤ _
  rw [hMass]
  have hTerm : C * U / L ≤ C * U * Real.log U / L :=
    div_le_div_of_nonneg_right
      (le_mul_of_one_le_right (mul_nonneg hC.le hU₀.le) hUlog) hL₀.le
  calc
    _ ≤ |windowPrimeMass N w - w ^ 2 / (2 * L)| +
        |w ^ 2 / (2 * L) - U ^ 2 / (2 * L)| := abs_sub_le _ _ _
    _ ≤ C * U * Real.log U / L + (2 * ((k : ℝ) + 1)) * U * Real.log U / L :=
      add_le_add (hError'.trans hTerm) hSquare
    _ = _ := by dsimp [C']; ring

end LeanAB.PaperB

