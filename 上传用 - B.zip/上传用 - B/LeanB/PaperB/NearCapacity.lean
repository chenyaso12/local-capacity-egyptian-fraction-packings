module

public import PaperB.NearCapacityBlocks
public import PaperB.NearCapacityAllocation
public import PaperB.NearCapacityRepair
public import PaperB.NearCapacityHeights
meta import Mathlib.Tactic

/-! Attainment of the local capacity up to the paper's power saving. -/

@[expose] public section

open Filter Finset
open scoped Topology

namespace LeanAB.PaperB.NearCapacity

open Closure FixedTargets

/-- The further groups before restoring the singleton at 1. Constants are
chosen before height; all the sets are actual witnesses. -/
theorem eventually_ordered_unit_groups :
    ∃ A : ℝ, 0 < A ∧ ∀ᶠ N : ℕ in atTop,
      ∃ G : Fin (nearCapacityGroupCount A N) → Finset ℕ,
        Pairwise (fun i j => Disjoint (G i) (G j)) ∧
        ∀ i, G i ⊆ interval 2 N ∧ mass (G i) = 1 ∧
          ((G i).card : ℝ) ≤ (N : ℝ) / Real.log N + 219 * (N : ℝ) / (Real.log N) ^ 2 := by
  classical
  obtain ⟨C, X₀, hClosure⟩ := exists_uniformSmoothClosure
  let D := nearCapacityCutoffFactor C
  have hD : 0 < D := nearCapacityCutoffFactor_pos (zero_lt_one.trans hClosure.1)
  obtain ⟨A₁, hA₁, hRes⟩ := eventually_nearCapacity_repair_reserves hD (by norm_num : (0 : ℝ) < 2)
  let A₂ : ℝ := 5536 / D ^ 2
  have hA₂ : 0 < A₂ := by dsimp only [A₂]; positivity
  have hProxy := eventually_proxyCharge_le hD
  let A := A₁ + A₂
  have hA : 0 < A := add_pos hA₁ hA₂
  refine ⟨A, hA, ?_⟩
  have hcast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hGrow := (tendsto_rpow_atTop (show 0 < (1 / 12 : ℝ) by norm_num)).comp hcast
  filter_upwards [hRes, hProxy, eventually_retainedBlocks hD,
    eventually_nearCapacityGroupCount A hA.le,
    eventually_nearCapacity_marker_geometry C X₀ hClosure.1,
    eventually_floor_twentieth_le_nearCapacityCutoff C (zero_lt_one.trans hClosure.1),
    Allocation.eventually_nearCapacity_unit_allocation 4 (by norm_num),
    eventually_nearCapacity_close_bases C X₀ hClosure, hGrow.eventually_ge_atTop A₁,
    eventually_ge_atTop (1 : ℕ)]
    with N hResN hProxyN hRetained hCount hGeom hY hAllocate hClose hSmall hN
  let m := nearCapacityGroupCount A N
  let z : ℝ := (D * (N : ℝ) ^ (1 / 12 : ℝ)) ^ 2
  let Y : ℕ := nearCapacityCutoff N C
  have hYZ : Y = ⌊z⌋₊ := rfl
  have hm : 0 < m := hCount.1
  have hm₂ : (m : ℝ) ≤ 2 * Real.log N := hCount.2.2.1
  obtain ⟨P, hInj, hP, hPools⟩ := hResN m hm₂
  let M : Finset ℕ := univ.image P
  let Q := mediumPrimes N Y M
  have hpr (p : ℕ) (hp : p ∈ Q) := mem_mediumPrimes.mp hp
  have hNo (p : ℕ) (hp : p ∈ Q) (i : Fin m) : p ≠ P i := by
    intro h
    exact (hpr p hp).2.2.2 (mem_image.mpr ⟨i, mem_univ _, h.symm⟩)
  obtain ⟨Cof,S,R,hCof,hCPair,hSContains,hS,hR,hRSize,hRPower,_,hRMass,_,hSFactor,hSMass,hDeleted⟩ :=
    hPools Q (fun p hp => ⟨(hpr p hp).1, hY.trans_lt (hpr p hp).2.2.1, (hpr p hp).2.1⟩) hNo
  have hMarkers (p : ℕ) (hp : p ∈ M) : p.Prime ∧ Y < p ∧ p ≤ Nat.sqrt N := by
    obtain ⟨i, _, rfl⟩ := mem_image.mp hp
    obtain ⟨_, _, _, hz, hBelow, hSqrt, _, _⟩ := hGeom (P i) (hP i).2.1 (hP i).2.2
    exact ⟨(hP i).1, hz.trans_lt (by exact_mod_cast hBelow.trans (hP i).2.1), hSqrt⟩
  have hYS : Y ≤ Nat.sqrt N := by
    let i : Fin m := ⟨0, hm⟩
    have hp := hMarkers (P i) (mem_image.mpr ⟨i, mem_univ _, rfl⟩)
    exact hp.2.1.le.trans hp.2.2
  have hSUses (a : ℕ) (ha : a ∈ S) : ∃ p ∈ mediumPrimes N ⌊z⌋₊ M, p ∣ a := by
    obtain ⟨p, hp, b, _, rfl⟩ := hSFactor a ha
    exact ⟨p, hYZ ▸ hp, dvd_mul_right _ _⟩
  let E := repairExclusions 2 N z M S R
  obtain ⟨B⟩ := hRetained M S R (hYZ ▸ hY) (hYZ ▸ hYS)
    (fun p hp => ⟨(hMarkers p hp).1,hYZ ▸ (hMarkers p hp).2.1,(hMarkers p hp).2.2⟩)
    hSUses (fun a ha => by
      rw [← hYZ]
      exact (hRPower a ha).2.trans (Nat.lcmUpto_dvd_lcmUpto hY))
  have hExc : (mass E : ℝ) ≤ A₁ / (N : ℝ) ^ (1 / 12 : ℝ) := hDeleted
  have hEN : mass E ≤ 1 := by
    have hd : 0 < (N : ℝ) ^ (1 / 12 : ℝ) := Real.rpow_pos_of_pos
      (by exact_mod_cast (Nat.succ_le_iff.mp hN)) _
    have hh : (mass E : ℝ) ≤ 1 := hExc.trans ((div_le_iff₀ hd).mpr (by simpa using hSmall))
    exact_mod_cast hh
  have hMass : (m : ℚ) ≤ ∑ T ∈ B.family, mass T := by
    have hv' : (((capacity N : ℚ) - 1 - mass E - proxyCharge N ⌊z⌋₊ : ℚ) : ℝ) ≤
        ((∑ T ∈ B.family, mass T : ℚ) : ℝ) := Rat.cast_le.mpr B.weight
    have hv : (capacity N : ℝ) - 1 - (mass E : ℝ) - (proxyCharge N ⌊z⌋₊ : ℝ) ≤
        ∑ T ∈ B.family, (mass T : ℝ) := by
      simpa only [Rat.cast_sub, Rat.cast_one, Rat.cast_sum] using hv'
    have hx : 1 ≤ (N : ℝ) := by exact_mod_cast hN
    have hPx : (proxyCharge N ⌊z⌋₊ : ℝ) ≤ A₂ / (N : ℝ) ^ (1 / 12 : ℝ) :=
      hProxyN.trans (div_le_div_of_nonneg_left hA₂.le (by positivity)
        (Real.rpow_le_rpow_of_exponent_le hx (by norm_num)))
    have hAll : (mass E : ℝ) + (proxyCharge N ⌊z⌋₊ : ℝ) ≤ A / (N : ℝ) ^ (1 / 12 : ℝ) :=
      (add_le_add hExc hPx).trans_eq (by dsimp [A]; ring)
    have hM : (m : ℝ) ≤ ∑ T ∈ B.family, (mass T : ℝ) := by
      linarith only [hCount.2.2.2.1, hv, hAll]
    exact_mod_cast hM
  have hSurv (n : ℕ) (hn : n ∈ interval 2 N \ E) (hSqrt : n ≤ Nat.sqrt N) :
      ∃ T ∈ B.family, n ∈ T :=
    ⟨{n}, B.small n hn hSqrt, mem_singleton_self n⟩
  have hBlockGood (T : Finset ℕ) (hT : T ∈ B.family) :
      T.Nonempty ∧ T ⊆ interval 2 N \ E ∧ (mass T).den ∣ mediumDenominator Y Q ∧
      ((∃ n : ℕ, T = {n}) ∨
        ((∀ n ∈ T, Nat.sqrt N < n) ∧ mass T ≤ harmonic N / (Nat.sqrt N : ℚ))) := by
    simpa only [available, E, Q, hYZ, mass_denominators_eq_harmonic] using (B.good T hT)
  obtain ⟨Base, hBPair, hB⟩ := hAllocate m E B.family (mediumDenominator Y Q)
    hCount.2.1 hEN hBlockGood B.disjoint hMass hSurv
  have hBase (i : Fin m) : Base i ⊆ interval 2 N ∧ Disjoint (Base i) S ∧ Disjoint (Base i) R ∧
      (∀ b ∈ Base i, ∀ j, ¬ P j ∣ b) ∧ (1 - mass (Base i)).den ∣ mediumDenominator Y Q ∧
      nearCapacityDelta N ≤ 1 - mass (Base i) ∧
      1 - mass (Base i) ≤ nearCapacityDelta N + nearCapacityEta N := by
    have hSS : S ⊆ E := subset_union_right.trans subset_union_left
    have hRR : R ⊆ E := subset_union_right
    refine ⟨(hB i).1, (hB i).2.1.mono_right hSS,(hB i).2.1.mono_right hRR, ?_, (hB i).2.2.2.2.1,
      ?_, ?_⟩
    · intro b hb j hDvd
      have hpm : P j ∈ M := mem_image.mpr ⟨j, mem_univ _, rfl⟩
      have hb' : b ∈ primePart (P j) (interval 2 N) := mem_filter.mpr ⟨(hB i).1 hb, hDvd⟩
      have hv : b ∈ M.biUnion (fun p => primePart p (interval 2 N)) := mem_biUnion.mpr ⟨_, hpm, hb'⟩
      have hVE : b ∈ E := mem_union_left _ (mem_union_left _ (mem_union_right _ hv))
      exact disjoint_left.mp (hB i).2.1 hb hVE
    · simpa only [nearCapacityDelta, one_div] using (hB i).2.2.1
    · simpa only [nearCapacityDelta, nearCapacityEta, one_div] using (hB i).2.2.2.1
  obtain ⟨Out, hOutPair, hOut⟩ := hClose m hm₂ P hInj hP Q Cof S R
    (fun p hp => ⟨(hpr p hp).1,(hpr p hp).2.2.1,(hpr p hp).2.1⟩) hNo
    hCof hCPair hSContains hS hSMass hR hRSize hRPower hRMass Base hBPair hBase
  refine ⟨Out,hOutPair,fun i => ⟨(hOut i).2.1,(hOut i).2.2.1, ?_⟩⟩
  calc
    _ ≤ (Base i).card + 6 * ((N : ℝ) / (Real.log N) ^ 2) := (hOut i).2.2.2
    _ ≤ ((N : ℝ) / Real.log N + (2 * 4 + 205) * (N : ℝ) / (Real.log N) ^ 2) +
          6 * ((N : ℝ) / (Real.log N) ^ 2) := add_le_add_left (hB i).2.2.2.2.2 _
    _ = _ := by ring

/-- F2's near-capacity theorem, including actual disjoint sets and the
per-group length bound at the floor of the stated loss. -/
theorem attains_local_capacity :
    ∃ A B : ℝ, 0 < A ∧ 0 < B ∧ ∀ᶠ N : ℕ in atTop,
      ⌊(capacity N : ℝ) - A / (N : ℝ) ^ (1 / 12 : ℝ)⌋ ≤ (k N : ℤ) ∧
      k N ≤ h N ∧ (h N : ℤ) ≤ ⌊capacity N⌋ ∧
      ∃ F : Finset (Finset ℕ), UnitPacking N F ∧
        (F.card : ℤ) = ⌊(capacity N : ℝ) - A / (N : ℝ) ^ (1 / 12 : ℝ)⌋ ∧
        ∀ S ∈ F, (S.card : ℝ) ≤ (N : ℝ) / Real.log N + B * (N : ℝ) / (Real.log N) ^ 2 := by
  obtain ⟨A,hA,h⟩ := eventually_ordered_unit_groups
  have hh := eventually_nearCapacity_unitPacking_of_ordered hA.le (by norm_num : 0 ≤ (219 : ℝ)) h
  have hAttain := capacityAttainment_of_nearCapacity_ordered hA.le
    (h.mono fun N hN => by
      obtain ⟨G,hPair,hG⟩ := hN
      exact ⟨G,hPair,fun i => ⟨(hG i).1,(hG i).2.1⟩⟩)
  exact ⟨A,219,hA,by norm_num,by
    filter_upwards [hh,hAttain] with N hF hLow
    exact ⟨hLow,k_le_h N,h_le_floor_capacity N,hF⟩⟩

/-- The exception count is unconditional once the near-capacity construction
is substituted into the integer-band estimate. -/
theorem capacity_integer_values_except :
    ∃ C : ℝ, 0 < C ∧ ∀ X : ℕ, ∃ E ⊆ Icc 1 X,
      (E.card : ℝ) ≤ C * ((X : ℝ) ^ (11 / 12 : ℝ)) ∧
      ∀ n ∈ Icc 1 X, n ∉ E → (k n : ℤ) = ⌊capacity n⌋ ∧ (h n : ℤ) = ⌊capacity n⌋ := by
  obtain ⟨A,_,hA,_,h⟩ := attains_local_capacity
  exact capacity_integer_values_except_band_of_attainment hA.le (h.mono fun _ hN => hN.1)

/-- F2's inverse-height comparison and logarithmic gap, with no
capacity-attainment premise. -/
theorem capacity_inverse_heights :
    ∃ (eI : ∀ j : ℕ, ∃ N : ℕ, j ∈ representedIntegers N) (eU : ∀ j : ℕ, ∃ N : ℕ, j ≤ k N),
      ∃ C D : ℝ, 0 < C ∧ 0 < D ∧ ∀ᶠ j : ℕ in atTop,
        let M := localCapacityHeight j
        let T := integerHeight j (eI j)
        let N := unitHeight j (eU j)
        M ≤ T ∧ T ≤ N ∧ (N : ℝ) ≤ (M : ℝ) + C * (M : ℝ) ^ (11 / 12 : ℝ) ∧
        0 ≤ Real.log (N : ℝ) - Real.log (T : ℝ) ∧
        Real.log (N : ℝ) - Real.log (T : ℝ) ≤ D * Real.exp (-(j : ℝ) / 12) := by
  obtain ⟨A, _, hA, _, h⟩ := attains_local_capacity
  have ha : CapacityAttainment A := h.mono (fun _ hh => hh.1)
  obtain ⟨C, hC, hc⟩ := eventually_nearCapacity_inverse_heights hA.le ha
  obtain ⟨D, hD, hd⟩ := eventually_nearCapacity_inverse_log_gap hA.le ha
  refine ⟨exists_integer_height_of_attainment hA.le ha, exists_unit_height_of_attainment hA.le ha,
    C, D, hC, hD, ?_⟩
  filter_upwards [hc, hd] with j h₁ h₂
  exact ⟨h₁.1, h₁.2.1, h₁.2.2, h₂⟩

end LeanAB.PaperB.NearCapacity
