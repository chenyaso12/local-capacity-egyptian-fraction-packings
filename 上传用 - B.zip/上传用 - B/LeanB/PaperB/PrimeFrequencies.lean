module

public import PaperB.AverageCover
public import PaperB.LargeSieve

meta import Mathlib.Tactic

@[expose] public section

namespace LeanAB.PaperB.Closure

/-- Distinct reduced nonzero prime fractions in the same dyadic window are
separated by \(1/(4P^2)\) modulo every integer. -/
lemma prime_frequency_separated {P : ℝ} {p q b c : ℕ}
    (hp : p.Prime) (hq : q.Prime) (hpMax : (p : ℝ) ≤ 2 * P)
    (hqMax : (q : ℝ) ≤ 2 * P) (hb0 : 0 < b) (hbp : b < p)
    (hc0 : 0 < c) (hcq : c < q) (hpair : (p, b) ≠ (q, c)) (k : ℤ) :
    1 / (4 * P ^ 2) ≤ |(b : ℝ) / p - (c : ℝ) / q - (k : ℝ)| := by
  have hpR : (0 : ℝ) < p := by exact_mod_cast hp.pos
  have hqR : (0 : ℝ) < q := by exact_mod_cast hq.pos
  let x : ℝ := (b : ℝ) / p
  let y : ℝ := (c : ℝ) / q
  change 1 / (4 * P ^ 2) ≤ |x - y - (k : ℝ)|
  have hx0 : 0 < x := div_pos (by exact_mod_cast hb0) hpR
  have hy0 : 0 < y := div_pos (by exact_mod_cast hc0) hqR
  have hx1 : x < 1 := (div_lt_one hpR).mpr (by exact_mod_cast hbp)
  have hy1 : y < 1 := (div_lt_one hqR).mpr (by exact_mod_cast hcq)
  have hxy : x ≠ y := by
    intro heq
    have hcrossR : (b : ℝ) * q = (c : ℝ) * p :=
      (div_eq_div_iff hpR.ne' hqR.ne').mp heq
    have hcross : b * q = c * p := by exact_mod_cast hcrossR
    have hpq : p = q := by
      have hdvd : p ∣ b * q := hcross.symm ▸ dvd_mul_left p c
      rcases hp.dvd_mul.mp hdvd with hb | hq'
      · exact (not_lt_of_ge (Nat.le_of_dvd hb0 hb) hbp).elim
      · exact (Nat.prime_dvd_prime_iff_eq hp hq).mp hq'
    subst q
    have hbc : b = c := Nat.eq_of_mul_eq_mul_right hp.pos hcross
    exact hpair (by rw [hbc])
  have hpq : (0 : ℝ) < (p : ℝ) * q := mul_pos hpR hqR
  let n : ℤ := (b : ℤ) * q - (c : ℤ) * p - k * ((p : ℤ) * q)
  have hscaled : (n : ℝ) = (x - y - (k : ℝ)) * ((p : ℝ) * q) := by
    dsimp only [n, x, y]
    push_cast
    field_simp [hpR.ne', hqR.ne']
  have hn : n ≠ 0 := by
    intro hz
    have hprod : (x - y - (k : ℝ)) * ((p : ℝ) * q) = 0 := by
      rw [← hscaled, hz, Int.cast_zero]
    have hk : x - y = (k : ℝ) :=
      sub_eq_zero.mp ((mul_eq_zero.mp hprod).resolve_right hpq.ne')
    have hkl : (-1 : ℤ) < k := by
      exact_mod_cast (show (-1 : ℝ) < (k : ℝ) by rw [← hk]; linarith)
    have hku : k < (1 : ℤ) := by
      exact_mod_cast (show (k : ℝ) < (1 : ℝ) by rw [← hk]; linarith)
    have hk0 : k = 0 := by omega
    exact hxy (sub_eq_zero.mp (by simpa [hk0] using hk))
  have hnInt : (1 : ℤ) ≤ |n| := by
    have hpos := abs_pos.mpr hn
    omega
  have hnR : (1 : ℝ) ≤ |(n : ℝ)| := by exact_mod_cast hnInt
  rw [hscaled, abs_mul, abs_of_pos hpq] at hnR
  have hbound : (p : ℝ) * q ≤ 4 * P ^ 2 := by
    calc
      (p : ℝ) * q ≤ (2 * P) * (2 * P) :=
        mul_le_mul hpMax hqMax hqR.le (hpR.le.trans hpMax)
      _ = 4 * P ^ 2 := by ring
  exact (one_div_le_one_div_of_le hpq hbound).trans ((div_le_iff₀ hpq).mpr hnR)

/-- Pairs \((p,b)\) indexing all nonzero frequencies over a finite set of moduli. -/
def primeFrequencyPairs (primes : Finset ℕ) : Finset (ℕ × ℕ) :=
  primes.biUnion fun p => (Finset.Ioo 0 p).map
    ⟨fun b => (p, b), fun _ _ h => congrArg Prod.snd h⟩

@[simp]
lemma mem_primeFrequencyPairs {primes : Finset ℕ} {p b : ℕ} :
    (p, b) ∈ primeFrequencyPairs primes ↔ p ∈ primes ∧ 0 < b ∧ b < p := by
  unfold primeFrequencyPairs
  constructor
  · intro h
    obtain ⟨q, hq, hb⟩ := Finset.mem_biUnion.mp h
    obtain ⟨c, hc, heq⟩ := Finset.mem_map.mp hb
    change (q, c) = (p, b) at heq
    obtain ⟨rfl, rfl⟩ := (Prod.mk.injEq q c p b).mp heq
    exact ⟨hq, (Finset.mem_Ioo.mp hc).1, (Finset.mem_Ioo.mp hc).2⟩
  · rintro ⟨hp, hb, hbp⟩
    exact Finset.mem_biUnion.mpr ⟨p, hp, Finset.mem_map.mpr
      ⟨b, Finset.mem_Ioo.mpr ⟨hb, hbp⟩, rfl⟩⟩

/-- The real frequency corresponding to a pair \((p,b)\). -/
noncomputable def primeFrequencyValue (i : ℕ × ℕ) : ℝ := (i.2 : ℝ) / i.1

lemma primeFrequencyValue_mem_Ioo {primes : Finset ℕ} {i : ℕ × ℕ}
    (hi : i ∈ primeFrequencyPairs primes) : primeFrequencyValue i ∈ Set.Ioo (0 : ℝ) 1 := by
  obtain ⟨p, b⟩ := i
  obtain ⟨_, hb, hbp⟩ := mem_primeFrequencyPairs.mp hi
  have hpR : (0 : ℝ) < p := by exact_mod_cast hb.trans hbp
  exact ⟨div_pos (by exact_mod_cast hb) hpR, (div_lt_one hpR).mpr (by exact_mod_cast hbp)⟩

lemma primeFrequencyPairs_separated {P : ℝ} {primes : Finset ℕ}
    (hprime : ∀ p ∈ primes, p.Prime) (hP : ∀ p ∈ primes, (p : ℝ) ≤ 2 * P)
    {i j : ℕ × ℕ} (hi : i ∈ primeFrequencyPairs primes)
    (hj : j ∈ primeFrequencyPairs primes) (hij : i ≠ j) (k : ℤ) :
    1 / (4 * P ^ 2) ≤ |primeFrequencyValue i - primeFrequencyValue j - (k : ℝ)| := by
  obtain ⟨p, b⟩ := i
  obtain ⟨q, c⟩ := j
  obtain ⟨hp, hb0, hbp⟩ := mem_primeFrequencyPairs.mp hi
  obtain ⟨hq, hc0, hcq⟩ := mem_primeFrequencyPairs.mp hj
  exact prime_frequency_separated (hprime p hp) (hprime q hq) (hP p hp) (hP q hq)
    hb0 hbp hc0 hcq hij k

/-- Energy of the Fourier sum of an integer set at the real frequency \(b/p\). -/
noncomputable def primeFrequencyPairEnergy (A : Finset ℤ) (i : ℕ × ℕ) : ℝ :=
  ‖∑ a ∈ A, fourier (T := 1) a (primeFrequencyValue i : AddCircle (1 : ℝ))‖ ^ 2

private lemma zmod_nonzero_values (p : ℕ) [NeZero p] :
    ((Finset.univ : Finset (ZMod p)).erase 0).map
        ⟨ZMod.val, ZMod.val_injective p⟩ = Finset.Ioo 0 p := by
  ext b
  simp only [Finset.mem_map, Function.Embedding.coeFn_mk, Finset.mem_erase, Finset.mem_univ,
    and_true, Finset.mem_Ioo]
  constructor
  · rintro ⟨a, ha, rfl⟩
    exact ⟨Nat.pos_of_ne_zero (fun h => ha ((ZMod.val_injective p)
      (h.trans (ZMod.val_zero (n := p)).symm))), ZMod.val_lt a⟩
  · rintro ⟨hb, hp⟩
    have hv : (b : ZMod p).val = b := ZMod.val_natCast_of_lt hp
    refine ⟨(b : ZMod p), ?_, hv⟩
    intro hz
    rw [hz, ZMod.val_zero] at hv
    exact hb.ne' hv.symm

lemma sum_primeFrequencyPairEnergy_eq (A : Finset ℤ) (p : ℕ) [NeZero p] :
    ∑ b ∈ Finset.Ioo 0 p, primeFrequencyPairEnergy A (p, b) =
      ∑ h ∈ (Finset.univ : Finset (ZMod p)).erase 0,
        ‖∑ a ∈ A, ZMod.stdAddChar (h * (a : ZMod p))‖ ^ 2 := by
  rw [← zmod_nonzero_values p, Finset.sum_map]
  refine Finset.sum_congr rfl fun h _ => ?_
  unfold primeFrequencyPairEnergy
  have hF : (∑ a ∈ A, fourier (T := 1) a (primeFrequencyValue (p, h.val) : AddCircle (1 : ℝ))) =
      ∑ a ∈ A, ZMod.stdAddChar (h * (a : ZMod p)) := by
    refine Finset.sum_congr rfl fun a _ => ?_
    have hcast : h * (a : ZMod p) = (((h.val : ℤ) * a : ℤ) : ZMod p) := by
      push_cast
      rw [ZMod.natCast_zmod_val]
    rw [fourier_coe_apply, hcast, ZMod.stdAddChar_coe]
    dsimp only [primeFrequencyValue]
    push_cast
    congr 1
    ring
  rw [show (⟨ZMod.val, ZMod.val_injective p⟩ : ZMod p ↪ ℕ) h = h.val from rfl, hF]

/-- The primes whose image occupies at most half of the residue classes. -/
def smallPrimeImageExceptions (primes : Finset ℕ) (A : Finset ℤ) : Finset ℕ :=
  primes.filter fun p => 2 * (A.image fun a : ℤ => (a : ZMod p)).card ≤ p

private lemma sum_primeFrequencyPairs (primes : Finset ℕ) (energy : ℕ × ℕ → ℝ) :
    ∑ i ∈ primeFrequencyPairs primes, energy i =
      ∑ p ∈ primes, ∑ b ∈ Finset.Ioo 0 p, energy (p, b) := by
  unfold primeFrequencyPairs
  rw [Finset.sum_biUnion]
  · simp only [Finset.sum_map]
    rfl
  · intro p _ q _ hpq
    apply Finset.disjoint_left.mpr
    intro i hi hj
    obtain ⟨b, _, rfl⟩ := Finset.mem_map.mp hi
    obtain ⟨c, _, h⟩ := Finset.mem_map.mp hj
    exact hpq ((congrArg Prod.fst h).symm)

/-- Convert any bound for the separated-frequency energy to an upper bound on
the number of primes for which at most half of the residues are occupied. -/
theorem card_smallPrimeImageExceptions_le_of_pairEnergy (primes : Finset ℕ)
    (hprime : ∀ p ∈ primes, p.Prime) (A : Finset ℤ) (hA : A.Nonempty) (B : ℝ)
    (hbudget : ∑ i ∈ primeFrequencyPairs primes, primeFrequencyPairEnergy A i ≤
      B * (A.card : ℝ)) :
    ((smallPrimeImageExceptions primes A).card : ℝ) ≤ B / (A.card : ℝ) := by
  let E := fun p => ∑ b ∈ Finset.Ioo 0 p, primeFrequencyPairEnergy A (p, b)
  rw [sum_primeFrequencyPairs] at hbudget
  have hsub : smallPrimeImageExceptions primes A ⊆ primes := Finset.filter_subset _ _
  have hnonneg (p : ℕ) : 0 ≤ E p := by
    simp only [E, primeFrequencyPairEnergy]
    exact Finset.sum_nonneg fun b _ => sq_nonneg _
  apply card_exceptions_le_of_energy _ E _ (by exact_mod_cast hA.card_pos)
  · exact (Finset.sum_le_sum_of_subset_of_nonneg hsub
      (fun p _ _ => hnonneg p)).trans hbudget
  · intro p hp
    let _ : NeZero p := ⟨(hprime p (hsub hp)).ne_zero⟩
    rw [show E p = _ from sum_primeFrequencyPairEnergy_eq A p]
    exact integerSet_nonzero_energy_ge A (Finset.mem_filter.mp hp).2

/-- Prime-frequency large sieve for the indicator of a finite integer set. -/
theorem sum_primeFrequencyPairEnergy_le {P H : ℝ} (hP : 1 ≤ P) (primes : Finset ℕ)
    (hprime : ∀ p ∈ primes, p.Prime) (hupper : ∀ p ∈ primes, (p : ℝ) ≤ 2 * P)
    (A : Finset ℤ) (hH : 0 ≤ H) (hband : ∀ n ∈ A, |(n : ℝ)| ≤ H) :
    (∑ i ∈ primeFrequencyPairs primes, primeFrequencyPairEnergy A i) ≤
      3 * (4 * P ^ 2 + 4 * Real.pi * (H + 1)) * (A.card : ℝ) := by
  have hden : 1 ≤ 4 * P ^ 2 := by nlinarith [sq_nonneg (P - 1)]
  have hdenPos : 0 < 4 * P ^ 2 := zero_lt_one.trans_le hden
  have hδ₁ : (4 * P ^ 2)⁻¹ ≤ 1 := by
    rw [← one_div, div_le_iff₀ hdenPos, one_mul]
    exact hden
  have hc (i : ℕ × ℕ) (hi : i ∈ primeFrequencyPairs primes) :
      primeFrequencyValue i ∈ Set.Icc (0 : ℝ) 1 :=
    ⟨(primeFrequencyValue_mem_Ioo hi).1.le, (primeFrequencyValue_mem_Ioo hi).2.le⟩
  have hsep (i : ℕ × ℕ) (hi : i ∈ primeFrequencyPairs primes)
      (j : ℕ × ℕ) (hj : j ∈ primeFrequencyPairs primes) (hij : i ≠ j) :
      (4 * P ^ 2)⁻¹ ≤ |primeFrequencyValue i - primeFrequencyValue j| := by
    simpa only [one_div, Int.cast_zero, sub_zero] using
      primeFrequencyPairs_separated hprime hupper hi hj hij (0 : ℤ)
  have hsieve := LargeSieve.sum_trigSum_sq_le_of_separated
    (primeFrequencyPairs primes) primeFrequencyValue (inv_pos.mpr hdenPos) hδ₁
    hc hsep A (fun _ => 1) hH hband
  simpa only [LargeSieve.trigSum, one_mul, primeFrequencyPairEnergy, inv_inv,
    norm_one, one_pow, Finset.sum_const, nsmul_eq_mul, mul_one] using hsieve

end LeanAB.PaperB.Closure
