module

public import PaperB.AverageLift
public import PaperB.ShortPointwiseCover
public import PaperB.RepairPools

meta import Mathlib.Tactic

@[expose] public section

namespace LeanAB.PaperB.ShortPointwise

open Filter Finset Closure
open scoped Topology

private theorem eventually_averageHeight_le_log_sq {C : ℝ} (hC : 0 < C) :
    ∀ᶠ x : ℝ in atTop,
      C * Real.log x * Real.log (Real.log x) * Real.log (Real.log (Real.log x)) ^ 4 ≤
        Real.log x ^ 2 := by
  have hL := Real.tendsto_log_atTop
  have hU := Real.tendsto_log_atTop.comp hL
  have hV := Real.tendsto_log_atTop.comp hU
  have hSmall := (isLittleO_log_rpow_rpow_atTop (5 : ℝ) (s := 1) one_pos).bound
    (one_div_pos.mpr hC)
  filter_upwards [hL.eventually_ge_atTop 1, hU.eventually_ge_atTop 1,
    hV.eventually_ge_atTop 1, hL.eventually hSmall] with x hL₁ hU₁ hV₁ hSmall
  let L := Real.log x
  let U := Real.log L
  let V := Real.log U
  have hL₀ : 0 ≤ L := zero_le_one.trans hL₁
  have hU₀ : 0 ≤ U := zero_le_one.trans hU₁
  have hV₀ : 0 ≤ V := zero_le_one.trans hV₁
  have hVU : V ≤ U := (Real.log_le_sub_one_of_pos (zero_lt_one.trans_le hU₁)).trans
    (sub_le_self _ zero_le_one)
  change ‖U ^ (5 : ℝ)‖ ≤ (1 / C) * ‖L ^ (1 : ℝ)‖ at hSmall
  have hUfive : U ^ (5 : ℕ) ≤ (1 / C) * L := by
    simpa only [show (5 : ℝ) = ((5 : ℕ) : ℝ) by norm_num, Real.rpow_natCast, Real.rpow_one,
      Real.norm_eq_abs, abs_of_nonneg (pow_nonneg hU₀ 5), abs_of_nonneg hL₀] using hSmall
  calc
    _ ≤ C * L * U * U ^ 4 :=
      mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hV₀ hVU 4) (by positivity)
    _ = C * L * U ^ 5 := by ring
    _ ≤ C * L * ((1 / C) * L) := mul_le_mul_of_nonneg_left hUfive (by positivity)
    _ = Real.log x ^ 2 := by change _ = L ^ 2; field_simp [hC.ne']

private theorem eventually_auxiliary_primes_and_cofactors :
    ∀ᶠ x : ℝ in atTop,
      ∃ P : Finset ℕ,
        let T := ⌈Real.log (4 * x) ^ 2⌉₊
        (5 / 4 : ℝ) * x ≤ Real.log ((∏ q ∈ P, q : ℕ) : ℝ) ∧
        (P.card : ℝ) * Real.log x ≤ 2 * x ∧
        (∀ q ∈ P, q.Prime ∧ x < (q : ℝ) ∧ (q : ℝ) ≤ (5 / 2 : ℝ) * x) ∧
        (∀ q ∈ P, CoversResidues q (interval 1 T)) := by
  classical
  obtain ⟨C, hC, hAverage⟩ := eventually_average_reciprocal_cover
  have hBase := hAverage (1 / 8) (by norm_num)
  have hHeight := eventually_averageHeight_le_log_sq hC
  have h₂ : Tendsto (fun x : ℝ => 2 * x) atTop atTop :=
    tendsto_id.const_mul_atTop (by norm_num)
  have h₄ : Tendsto (fun x : ℝ => 4 * x) atTop atTop :=
    tendsto_id.const_mul_atTop (by norm_num)
  have hp := eventually_retained_prime_window_log_product
    (a := 1) (b := 5 / 2) (ε := 1 / 4) (by norm_num) (by norm_num) (by norm_num)
  have hm := eventually_prime_window_log_mass
    (a := 1) (b := 5 / 2) (ε := 1 / 4) (by norm_num) (by norm_num) (by norm_num)
  filter_upwards [eventually_ge_atTop (1 : ℝ), hBase, h₂.eventually hBase, h₄.eventually hBase,
    hHeight, h₂.eventually hHeight, h₄.eventually hHeight, eventually_dyadic_bad_count, hp, hm]
    with x hx hb₁ hb₂ hb₄ hw₁ hw₂ hw₄ hDyadic hProd hMass
  let T := ⌈Real.log (4 * x) ^ 2⌉₊
  let G := primesBetween x ((5 / 2 : ℝ) * x)
  let bad (q : ℕ) := ¬ CoversResidues q (interval 1 T)
  let P := G.filter fun q => CoversResidues q (interval 1 T)
  have hGx (q : ℕ) (hq : q ∈ G) :
      x < (q : ℝ) ∧ (q : ℝ) ≤ (5 / 2 : ℝ) * x ∧ q.Prime :=
    (mem_primesBetween (zero_le_one.trans hx) (by positivity)).mp hq
  have hCard {y : ℝ} (hy : 1 ≤ y) (hy₄ : y ≤ 4 * x)
      (hHeight : C * Real.log y * Real.log (Real.log y) * Real.log (Real.log (Real.log y)) ^ 4 ≤
        Real.log y ^ 2)
      (hb : ∃ B : Finset ℕ, (B.card : ℝ) ≤ y ^ (1 / 2 + 1 / 8 : ℝ) ∧
        ∀ q : ℕ, q.Prime → y ≤ (q : ℝ) → (q : ℝ) ≤ 2 * y → q ∉ B →
          ∃ t : ℕ, t < q ∧
            (t : ℝ) ≤ C * Real.log y * Real.log (Real.log y) * Real.log (Real.log (Real.log y)) ^ 4 ∧
            CoversResidues q (interval 1 t)) :
      (((primesBetween y (2 * y)).filter bad).card : ℝ) ≤ y ^ (5 / 8 : ℝ) := by
    obtain ⟨B, hBCard, hBGood⟩ := hb
    have hSub : ((primesBetween y (2 * y)).filter bad) ⊆ B := by
      intro q hq
      by_contra hnB
      obtain ⟨hmem, hn⟩ := mem_filter.mp hq
      obtain ⟨hyl, hyr, hqPrime⟩ := (mem_primesBetween (zero_le_one.trans hy) (by positivity)).mp hmem
      obtain ⟨t, _, ht, hc⟩ := hBGood q hqPrime hyl.le hyr hnB
      have hLog := Real.log_le_log (zero_lt_one.trans_le hy) hy₄
      have h' : (t : ℝ) ≤ (T : ℝ) := ht.trans (hHeight.trans
        ((pow_le_pow_left₀ (Real.log_nonneg hy) hLog 2).trans (Nat.le_ceil _)))
      have htT : t ≤ T := by exact_mod_cast h'
      apply hn
      intro v
      obtain ⟨S, hS, hEq⟩ := hc v
      exact ⟨S, hS.trans (Icc_subset_Icc_right htT), hEq⟩
    exact (Nat.cast_le.mpr (card_le_card hSub)).trans
      (by simpa only [show (1 / 2 + 1 / 8 : ℝ) = 5 / 8 by norm_num] using hBCard)
  have hB₁ := hCard hx (by linarith only [hx]) hw₁ hb₁
  have hB₂ : (((primesBetween (2 * x) (4 * x)).filter bad).card : ℝ) ≤ (2 * x) ^ (5 / 8 : ℝ) := by
    simpa only [show (2 : ℝ) * (2 * x) = 4 * x by ring] using
      hCard (by linarith only [hx]) (by linarith only [hx]) hw₂ hb₂
  have hB₄ : (((primesBetween (4 * x) (8 * x)).filter bad).card : ℝ) ≤ (4 * x) ^ (5 / 8 : ℝ) := by
    simpa only [show (2 : ℝ) * (4 * x) = 8 * x by ring] using
      hCard (by linarith only [hx]) le_rfl hw₄ hb₄
  have hSub : P ⊆ G := filter_subset _ _
  have hDiff : G \ P = G.filter bad := by
    ext q
    simp only [P, bad, Finset.mem_sdiff, mem_filter]
    tauto
  have hOmit : ((G \ P).card : ℝ) ≤ x ^ (3 / 4 : ℝ) := by
    rw [hDiff]
    exact (hDyadic bad hB₁ hB₂ hB₄).1
  have hProd' := hProd P (by simpa only [one_mul] using hSub)
    (by simpa only [one_mul] using hOmit)
  have hLogMass : (∑ q ∈ G, Real.log (q : ℝ)) ≤ 2 * x := by
    norm_num only [one_mul] at hMass
    linarith only [(le_abs_self _).trans hMass, hx]
  have hCardP : (P.card : ℝ) * Real.log x ≤ 2 * x := calc
    _ = ∑ _q ∈ P, Real.log x := by rw [sum_const, nsmul_eq_mul]
    _ ≤ ∑ q ∈ P, Real.log (q : ℝ) :=
      sum_le_sum fun q hq => Real.log_le_log (zero_lt_one.trans_le hx) (hGx q (hSub hq)).1.le
    _ ≤ ∑ q ∈ G, Real.log (q : ℝ) :=
      sum_le_sum_of_subset_of_nonneg hSub fun q hq _ =>
        Real.log_nonneg (hx.trans (hGx q hq).1.le)
    _ ≤ _ := hLogMass
  refine ⟨P, ?_, hCardP, fun q hq => ?_, fun q hq => (mem_filter.mp hq).2⟩
  · linarith only [neg_abs_le (Real.log ((∏ q ∈ P, q : ℕ) : ℝ) - ((5 / 2 : ℝ) - 1) * x), hProd']
  · obtain ⟨hl, hr, hp⟩ := hGx q (hSub hq)
    exact ⟨hp, hl, hr⟩

/-- Resources for the original all-primes short cover. The two scales separate
the large CRT blocks from the small smooth correction. -/
theorem eventually_shortPointwiseResources {C₀ : ℝ} (hC₀ : 0 < C₀) (X₀ : ℕ) :
    ∀ᶠ p : ℕ in atTop, ∃ P : Finset ℕ, ∃ T X : ℕ,
      20 * p < (∏ q ∈ P, q) ∧ T ^ 5 ≤ X ∧ X₀ ≤ X ∧
      C₀ * (X : ℝ) ≤ coverWidth p ∧
      mass (primeCofactorPool P T) ≤ (1 / 6 : ℚ) ∧
      (∀ q ∈ P, q.Prime ∧ T < q ∧ q < p ∧ q * T ≤ coverWidth p ∧ C₀ * (X : ℝ) < q) ∧
      (∀ q ∈ P, CoversResidues q (interval 1 T)) := by
  let A := 17 + C₀ * ((X₀ : ℝ) + 17 ^ 5)
  have hA : 0 < A := by dsimp only [A]; positivity
  have hCast : Tendsto (fun p : ℕ => (p : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hX := Real.tendsto_log_atTop.comp hCast
  have hL := Real.tendsto_log_atTop.comp hX
  have hSlowX := (isLittleO_log_rpow_rpow_atTop (10 : ℝ) (s := 1) one_pos).bound
    (one_div_pos.mpr (show 0 < 2 * A by positivity))
  have hSlowL := Real.isLittleO_log_id_atTop.bound (show (0 : ℝ) < 1 / 48 by norm_num)
  have hSlowP := Real.isLittleO_log_id_atTop.bound (show (0 : ℝ) < 1 / 4 by norm_num)
  filter_upwards [hX.eventually eventually_auxiliary_primes_and_cofactors,
    hX.eventually_ge_atTop (max 1 (4 * Real.log 20 + 1)),
    hL.eventually_ge_atTop (max 7 (24 * (1 + Real.log 17))),
    hX.eventually hSlowX, hL.eventually hSlowL, hCast.eventually hSlowP,
    eventually_ge_atTop (1 : ℕ)] with p hAux hx hL hSlowX hSlowL hSlowP hp
  let x := Real.log (p : ℝ)
  let L := Real.log x
  let T := ⌈Real.log (4 * x) ^ 2⌉₊
  let X := max X₀ (T ^ 5)
  obtain ⟨P, hProduct, hCount, hPrimes, hCover⟩ := hAux
  let M : ℕ := ∏ q ∈ P, q
  change max 1 (4 * Real.log 20 + 1) ≤ x at hx
  change max 7 (24 * (1 + Real.log 17)) ≤ L at hL
  have hx₁ : 1 ≤ x := (le_max_left _ _).trans hx
  have hx₀ : 0 < x := zero_lt_one.trans_le hx₁
  have hL₇ : 7 ≤ L := (le_max_left _ _).trans hL
  have hL₁ : 1 ≤ L := (by norm_num : (1 : ℝ) ≤ 7).trans hL₇
  have hL₀ : 0 < L := zero_lt_one.trans_le hL₁
  have hp₀ : (0 : ℝ) < p := Nat.cast_pos.mpr (zero_lt_one.trans_le hp)
  have hM₀ : (0 : ℝ) < M := Nat.cast_pos.mpr (prod_pos fun q hq => (hPrimes q hq).1.pos)
  have hMlarge : 20 * p < M := by
    have hlog : Real.log ((20 : ℝ) * p) < Real.log (M : ℝ) := by
      rw [Real.log_mul (by norm_num) hp₀.ne']
      linarith only [show (5 / 4 : ℝ) * x ≤ Real.log (M : ℝ) from hProduct,
        (le_max_right (1 : ℝ) (4 * Real.log 20 + 1)).trans hx]
    have h := (Real.log_lt_log_iff (by positivity) hM₀).mp hlog
    exact_mod_cast h
  have hPrimeMax : (5 / 2 : ℝ) * x < p := by
    change ‖x‖ ≤ (1 / 4 : ℝ) * ‖(p : ℝ)‖ at hSlowP
    simp only [Real.norm_eq_abs, abs_of_nonneg hx₀.le, abs_of_nonneg hp₀.le] at hSlowP
    linarith only [hSlowP, hp₀]
  have hLogFour : Real.log (4 * x) = Real.log 4 + L := Real.log_mul (by norm_num) hx₀.ne'
  have hLogFour₀ : 0 < Real.log (4 * x) := by
    linarith only [hLogFour, hL₀, Real.log_nonneg (show (1 : ℝ) ≤ 4 by norm_num)]
  have hLogFourHi : Real.log (4 * x) ≤ 4 * L := by
    linarith only [hLogFour, hL₁, Real.log_le_sub_one_of_pos (show (0 : ℝ) < 4 by norm_num)]
  have hT₀ : (0 : ℝ) < T := Nat.cast_pos.mpr (Nat.ceil_pos.mpr (sq_pos_of_pos hLogFour₀))
  have hT : (T : ℝ) ≤ 17 * L ^ 2 := by
    have hceil : (T : ℝ) < Real.log (4 * x) ^ 2 + 1 := Nat.ceil_lt_add_one (sq_nonneg _)
    have hsq := pow_le_pow_left₀ hLogFour₀.le hLogFourHi 2
    have hLsq := one_le_pow₀ (n := 2) hL₁
    nlinarith only [hceil, hsq, hLsq]
  have hPowTen : L ^ (10 : ℕ) ≤ (1 / (2 * A)) * x := by
    change ‖L ^ (10 : ℝ)‖ ≤ (1 / (2 * A)) * ‖x ^ (1 : ℝ)‖ at hSlowX
    simpa only [show (10 : ℝ) = ((10 : ℕ) : ℝ) by norm_num, Real.rpow_natCast,
      Real.rpow_one, Real.norm_eq_abs, abs_of_nonneg (pow_nonneg hL₀.le 10),
      abs_of_nonneg hx₀.le] using hSlowX
  have hScale : A * L ^ (10 : ℕ) ≤ x / 2 := calc
    _ ≤ A * ((1 / (2 * A)) * x) := mul_le_mul_of_nonneg_left hPowTen hA.le
    _ = _ := by field_simp [hA.ne']
  have hTsmall : (T : ℝ) < x := by
    have hTo : (T : ℝ) ≤ A * L ^ (10 : ℕ) := calc
      _ ≤ 17 * L ^ 2 := hT
      _ ≤ 17 * L ^ (10 : ℕ) := mul_le_mul_of_nonneg_left
        (pow_le_pow_right₀ hL₁ (by norm_num)) (by norm_num)
      _ ≤ _ := mul_le_mul_of_nonneg_right
        (by
          dsimp only [A]
          have hNonneg : 0 ≤ C₀ * ((X₀ : ℝ) + 17 ^ 5) := by positivity
          linarith only [hNonneg]) (pow_nonneg hL₀.le _)
    linarith only [hTo, hScale, hx₀]
  have hXsmall : C₀ * (X : ℝ) < x := by
    have hXBound : (X : ℝ) ≤ ((X₀ : ℝ) + 17 ^ 5) * L ^ (10 : ℕ) := calc
      _ = max (X₀ : ℝ) ((T : ℝ) ^ 5) := by simp only [X, Nat.cast_max, Nat.cast_pow]
      _ ≤ (X₀ : ℝ) + (T : ℝ) ^ 5 := max_le (le_add_of_nonneg_right (by positivity))
        (le_add_of_nonneg_left (by positivity))
      _ ≤ (X₀ : ℝ) * L ^ (10 : ℕ) + (17 * L ^ 2) ^ 5 := add_le_add
        (le_mul_of_one_le_right (Nat.cast_nonneg X₀) (one_le_pow₀ hL₁))
        (pow_le_pow_left₀ hT₀.le hT 5)
      _ = _ := by ring
    have hXA : C₀ * (X : ℝ) ≤ A * L ^ (10 : ℕ) := calc
      _ ≤ C₀ * (((X₀ : ℝ) + 17 ^ 5) * L ^ (10 : ℕ)) :=
        mul_le_mul_of_nonneg_left hXBound hC₀.le
      _ = (C₀ * ((X₀ : ℝ) + 17 ^ 5)) * L ^ (10 : ℕ) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_right
        (le_add_of_nonneg_left (by norm_num)) (pow_nonneg hL₀.le _)
    linarith only [hXA, hScale, hx₀]
  have hW : x * L ^ 4 ≤ (coverWidth p : ℝ) := Nat.le_ceil _
  have hXwidth : C₀ * (X : ℝ) ≤ (coverWidth p : ℝ) :=
    hXsmall.le.trans ((le_mul_of_one_le_right hx₀.le (one_le_pow₀ hL₁)).trans hW)
  have hTerms (q : ℕ) (hq : q ∈ P) : q * T ≤ coverWidth p := by
    have hL49 : (49 : ℝ) ≤ L ^ 2 := by
      simpa only [show (7 : ℝ) ^ 2 = 49 by norm_num] using
        pow_le_pow_left₀ (show (0 : ℝ) ≤ 7 by norm_num) hL₇ 2
    have hProduct : ((q * T : ℕ) : ℝ) ≤ x * L ^ 4 := calc
      _ = (q : ℝ) * T := Nat.cast_mul _ _
      _ ≤ ((5 / 2 : ℝ) * x) * (17 * L ^ 2) :=
        mul_le_mul (hPrimes q hq).2.2 hT hT₀.le (by positivity)
      _ = (85 / 2 : ℝ) * (x * L ^ 2) := by ring
      _ ≤ L ^ 2 * (x * L ^ 2) :=
        mul_le_mul_of_nonneg_right ((by norm_num : (85 / 2 : ℝ) ≤ 49).trans hL49) (by positivity)
      _ = _ := by ring
    exact_mod_cast hProduct.trans hW
  have hLogT : Real.log (T : ℝ) ≤ Real.log 17 + 2 * Real.log L := by
    have h := Real.log_le_log hT₀ hT
    rwa [Real.log_mul (by norm_num) (pow_ne_zero _ hL₀.ne'), Real.log_pow,
      Nat.cast_ofNat] at h
  have hSlowL' : Real.log L ≤ (1 / 48 : ℝ) * L := by
    change ‖Real.log L‖ ≤ (1 / 48 : ℝ) * ‖L‖ at hSlowL
    simpa only [Real.norm_eq_abs, abs_of_nonneg (Real.log_nonneg hL₁),
      abs_of_nonneg hL₀.le] using hSlowL
  have hHarmonic : (harmonic T : ℝ) ≤ L / 12 := by
    linarith only [harmonic_le_one_add_log T, hLogT, hSlowL',
      (le_max_right (7 : ℝ) (24 * (1 + Real.log 17))).trans hL]
  have hH₀ : (0 : ℝ) ≤ harmonic T := by
    rw [← mass_denominators_eq_harmonic]
    exact Rat.cast_nonneg.mpr (Finset.sum_nonneg fun q _ => inv_nonneg.mpr (Nat.cast_nonneg q))
  have hCard : (P.card : ℝ) ≤ 2 * x / L := (le_div_iff₀ hL₀).mpr hCount
  have hPoolMass : (mass (primeCofactorPool P T) : ℝ) ≤ 1 / 6 := calc
    _ ≤ ∑ q ∈ P, (mass (mark q (interval 1 T)) : ℝ) := by
      rw [← Rat.cast_sum]
      exact Rat.cast_le.mpr (mass_biUnion_le P _)
    _ = ∑ q ∈ P, (harmonic T : ℝ) / q := by
      refine sum_congr rfl fun q hq => ?_
      rw [mass_mark q (hPrimes q hq).1.pos, show mass (interval 1 T) = harmonic T from
        mass_denominators_eq_harmonic T, Rat.cast_div, Rat.cast_natCast]
    _ ≤ ∑ _q ∈ P, (harmonic T : ℝ) / x :=
      sum_le_sum fun q hq => div_le_div_of_nonneg_left hH₀ hx₀ (hPrimes q hq).2.1.le
    _ = (P.card : ℝ) * ((harmonic T : ℝ) / x) := by rw [sum_const, nsmul_eq_mul]
    _ ≤ (2 * x / L) * ((L / 12) / x) :=
      mul_le_mul hCard (div_le_div_of_nonneg_right hHarmonic hx₀.le)
        (div_nonneg hH₀ hx₀.le) (by positivity)
    _ = _ := by field_simp [hL₀.ne', hx₀.ne']; ring
  refine ⟨P, T, X, hMlarge, le_max_right _ _, le_max_left _ _, hXwidth, ?_, ?_, hCover⟩
  · have hSix : ((1 / 6 : ℚ) : ℝ) = (1 / 6 : ℝ) := by norm_num
    exact Rat.cast_le.mp (show (mass (primeCofactorPool P T) : ℝ) ≤ ((1 / 6 : ℚ) : ℝ) by
      rwa [hSix])
  · intro q hq
    obtain ⟨hPrime, hLo, hHi⟩ := hPrimes q hq
    exact ⟨hPrime, by exact_mod_cast hTsmall.trans hLo, by exact_mod_cast hHi.trans_lt hPrimeMax,
      hTerms q hq, hXsmall.trans hLo⟩

end LeanAB.PaperB.ShortPointwise
