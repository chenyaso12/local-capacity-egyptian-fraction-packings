module

public import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
public import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic
public import Mathlib.Analysis.Fourier.AddCircle
public import Mathlib.Analysis.InnerProductSpace.Calculus
public import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
meta import Mathlib.Tactic

@[expose] public section

namespace LeanAB.PaperB.LargeSieve

open MeasureTheory
open scoped Interval

/-- A point value is at most the interval average plus the total variation. -/
theorem value_le_interval_average_add_variation {f f' : ℝ → ℝ}
    (hf : ∀ x, HasDerivAt f (f' x) x) (hcont : Continuous f')
    {l r c : ℝ} (hlr : l < r) (hc : c ∈ Set.Icc l r) :
    f c ≤ (∫ x in l..r, f x) / (r - l) + ∫ x in l..r, |f' x| := by
  let variation := ∫ x in l..r, |f' x|
  have hfc : Continuous f := continuous_iff_continuousAt.mpr fun x => (hf x).continuousAt
  have hdiff {x y : ℝ} (hx : l ≤ x) (hy : y ≤ r) (hxy : x ≤ y) :
      |f y - f x| ≤ variation := by
    rw [← intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hf t)
      (hcont.intervalIntegrable _ _)]
    calc
      |∫ t in x..y, f' t| ≤ ∫ t in x..y, |f' t| := by
        simpa only [Real.norm_eq_abs] using
          (intervalIntegral.norm_integral_le_integral_norm
            (f := f') (μ := volume) (a := x) (b := y) hxy)
      _ ≤ variation := intervalIntegral.integral_mono_interval hx hxy hy
        (ae_of_all _ fun t => abs_nonneg (f' t)) (hcont.abs.intervalIntegrable _ _)
  have hpoint (t : ℝ) (ht : t ∈ Set.Icc l r) : f c - variation ≤ f t := by
    rcases le_total t c with htc | hct
    · have h := (le_abs_self (f c - f t)).trans (hdiff ht.1 hc.2 htc)
      linarith
    · have h := (neg_le_abs (f t - f c)).trans (hdiff hc.1 ht.2 hct)
      linarith
  have havg := intervalIntegral.integral_mono_on (μ := volume) hlr.le
    (continuous_const.intervalIntegrable l r) (hfc.intervalIntegrable l r) hpoint
  rw [intervalIntegral.integral_const, smul_eq_mul] at havg
  have hdiv : f c - variation ≤ (∫ x in l..r, f x) / (r - l) :=
    (le_div_iff₀ (sub_pos.mpr hlr)).mpr (by simpa only [mul_comm] using havg)
  linarith

private theorem sum_interval_integrals_le {ι : Type*} (s : Finset ι)
    (a b : ι → ℝ) (l r : ℝ) (hlr : l ≤ r)
    (ha : ∀ i ∈ s, l ≤ a i) (hb : ∀ i ∈ s, b i ≤ r)
    (hab : ∀ i ∈ s, a i ≤ b i)
    (hdisj : (s : Set ι).Pairwise (Function.onFun Disjoint fun i => Set.Ioc (a i) (b i)))
    {f : ℝ → ℝ} (hcont : Continuous f) (hpos : ∀ x, 0 ≤ f x) :
    (∑ i ∈ s, ∫ x in a i..b i, f x) ≤ ∫ x in l..r, f x := by
  have hsubset : (⋃ i ∈ s, Set.Ioc (a i) (b i)) ⊆ Set.Ioc l r := by
    intro x hx
    simp only [Set.mem_iUnion, exists_prop] at hx
    obtain ⟨i, hi, hxi⟩ := hx
    exact Set.Ioc_subset_Ioc (ha i hi) (hb i hi) hxi
  calc
    (∑ i ∈ s, ∫ x in a i..b i, f x) = ∑ i ∈ s, ∫ x in Set.Ioc (a i) (b i), f x :=
      Finset.sum_congr rfl fun i hi => intervalIntegral.integral_of_le (hab i hi)
    _ = ∫ x in ⋃ i ∈ s, Set.Ioc (a i) (b i), f x :=
      (integral_biUnion_finset s (fun _ _ => measurableSet_Ioc) hdisj
        (fun i _ => (hcont.intervalIntegrable (a i) (b i)).1)).symm
    _ ≤ ∫ x in l..r, f x := by
      rw [intervalIntegral.integral_of_le hlr]
      exact setIntegral_mono_set (hcont.intervalIntegrable l r).1
        (ae_of_all _ hpos) hsubset.eventuallySubset

/-- Sum the point estimates over disjoint intervals of equal positive length. -/
theorem sum_values_le_interval_average_add_variation {ι : Type*} (s : Finset ι)
    (a b center : ι → ℝ) (l r δ : ℝ) (hlr : l ≤ r) (hδ : 0 < δ)
    (ha : ∀ i ∈ s, l ≤ a i) (hb : ∀ i ∈ s, b i ≤ r)
    (hlen : ∀ i ∈ s, b i - a i = δ)
    (hc : ∀ i ∈ s, center i ∈ Set.Icc (a i) (b i))
    (hdisj : (s : Set ι).Pairwise (Function.onFun Disjoint fun i => Set.Ioc (a i) (b i)))
    {f f' : ℝ → ℝ} (hf : ∀ x, HasDerivAt f (f' x) x)
    (hcont : Continuous f') (hpos : ∀ x, 0 ≤ f x) :
    (∑ i ∈ s, f (center i)) ≤ (∫ x in l..r, f x) / δ + ∫ x in l..r, |f' x| := by
  have hab (i : ι) (hi : i ∈ s) : a i < b i := by linarith [hlen i hi]
  have hfc : Continuous f := continuous_iff_continuousAt.mpr fun x => (hf x).continuousAt
  calc
    (∑ i ∈ s, f (center i)) ≤
        ∑ i ∈ s, ((∫ x in a i..b i, f x) / δ + ∫ x in a i..b i, |f' x|) := by
      apply Finset.sum_le_sum
      intro i hi
      simpa only [hlen i hi] using
        value_le_interval_average_add_variation hf hcont (hab i hi) (hc i hi)
    _ = (∑ i ∈ s, ∫ x in a i..b i, f x) / δ + (∑ i ∈ s, ∫ x in a i..b i, |f' x|) := by
      rw [Finset.sum_add_distrib, Finset.sum_div]
    _ ≤ (∫ x in l..r, f x) / δ + ∫ x in l..r, |f' x| := by
      exact add_le_add (div_le_div_of_nonneg_right
        (sum_interval_integrals_le s a b l r hlr ha hb
          (fun i hi => (hab i hi).le) hdisj hfc hpos) hδ.le)
        (sum_interval_integrals_le s a b l r hlr ha hb
          (fun i hi => (hab i hi).le) hdisj hcont.abs fun x => abs_nonneg (f' x))


/-- Sampling a nonnegative periodic function at separated centers in one period. -/
theorem sum_values_le_period_integrals_of_separated {ι : Type*} (s : Finset ι)
    (center : ι → ℝ) {δ : ℝ} (hδ : 0 < δ) (hδ₁ : δ ≤ 1)
    (hc : ∀ i ∈ s, center i ∈ Set.Icc (0 : ℝ) 1)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → δ ≤ |center i - center j|)
    {f f' : ℝ → ℝ} (hf : ∀ x, HasDerivAt f (f' x) x)
    (hcont : Continuous f') (hpos : ∀ x, 0 ≤ f x)
    (hperiod : Function.Periodic f 1) (hperiod' : Function.Periodic f' 1) :
    (∑ i ∈ s, f (center i)) ≤ 3 * ((∫ x in (0 : ℝ)..1, f x) / δ +
      ∫ x in (0 : ℝ)..1, |f' x|) := by
  let a (i : ι) := center i - δ / 2
  let b (i : ι) := center i + δ / 2
  have hleft (i : ι) (hi : i ∈ s) : -1 ≤ a i := by
    dsimp [a]
    linarith [(hc i hi).1]
  have hright (i : ι) (hi : i ∈ s) : b i ≤ 2 := by
    dsimp [b]
    linarith [(hc i hi).2]
  have hlen (i : ι) (_ : i ∈ s) : b i - a i = δ := by dsimp [a, b]; ring
  have hin (i : ι) (_ : i ∈ s) : center i ∈ Set.Icc (a i) (b i) :=
    ⟨by dsimp [a]; linarith, by dsimp [b]; linarith⟩
  have hdisj : (s : Set ι).Pairwise (Function.onFun Disjoint fun i => Set.Ioc (a i) (b i)) := by
    intro i hi j hj hij
    rw [Function.onFun, Set.disjoint_left]
    intro x hxi hxj
    have h := hsep i hi j hj hij
    rcases le_total (center i) (center j) with hout | hout
    · rw [abs_of_nonpos (sub_nonpos.mpr hout)] at h
      dsimp [a, b] at hxi hxj
      linarith [hxi.2, hxj.1]
    · rw [abs_of_nonneg (sub_nonneg.mpr hout)] at h
      dsimp [a, b] at hxi hxj
      linarith [hxi.1, hxj.2]
  have hbound := sum_values_le_interval_average_add_variation s a b center (-1) 2 δ
    (by norm_num) hδ hleft hright hlen hin hdisj hf hcont hpos
  have htriple {g : ℝ → ℝ} (hp : Function.Periodic g 1) (hg : Continuous g) :
      (∫ x in (-1 : ℝ)..2, g x) = 3 * ∫ x in (0 : ℝ)..1, g x := by
    have h1 := hp.intervalIntegral_add_zsmul_eq 3 (-1) (hg.intervalIntegrable · ·)
    have h2 := hp.intervalIntegral_add_eq (-1) 0
    norm_num [zsmul_eq_mul] at h1 h2
    rw [h1, h2]
  rw [htriple hperiod (continuous_iff_continuousAt.mpr fun x => (hf x).continuousAt),
    htriple (g := fun x => |f' x|) (fun x => congrArg abs (hperiod' x)) hcont.abs] at hbound
  rw [mul_add, ← mul_div_assoc]
  exact hbound


open scoped ComplexConjugate InnerProductSpace

private local instance : Fact (0 < (1 : ℝ)) := ⟨zero_lt_one⟩

private noncomputable def trigPolynomial (s : Finset ℤ) (a : ℤ → ℂ) :
    C(AddCircle (1 : ℝ), ℂ) := ∑ n ∈ s, a n • fourier (T := 1) n

/-- A finite trigonometric sum with integer exponents. -/
noncomputable def trigSum (s : Finset ℤ) (a : ℤ → ℂ) (x : ℝ) : ℂ :=
  ∑ n ∈ s, a n * fourier (T := 1) n (x : AddCircle (1 : ℝ))

private theorem trigPolynomial_apply (s : Finset ℤ) (a : ℤ → ℂ) (x : AddCircle (1 : ℝ)) :
    trigPolynomial s a x = ∑ n ∈ s, a n * fourier (T := 1) n x := by
  classical
  unfold trigPolynomial
  simp

private theorem trigSum_periodic (s : Finset ℤ) (a : ℤ → ℂ) :
    Function.Periodic (trigSum s a) 1 := by
  intro x
  simp only [trigSum, AddCircle.coe_add_period]

private theorem trigSum_continuous (s : Finset ℤ) (a : ℤ → ℂ) :
    Continuous (trigSum s a) := by
  let F := trigPolynomial s a
  have hcomp : trigSum s a = fun x : ℝ => F (x : AddCircle (1 : ℝ)) := by
    funext x
    exact (trigPolynomial_apply s a _).symm
  rw [hcomp]
  exact F.continuous.comp (AddCircle.continuous_mk' (1 : ℝ))

private noncomputable def diffCoeffs (a : ℤ → ℂ) (n : ℤ) : ℂ :=
  a n * (2 * (Real.pi : ℂ) * Complex.I * n)

private theorem trigSum_hasDerivAt (s : Finset ℤ) (a : ℤ → ℂ) (x : ℝ) :
    HasDerivAt (trigSum s a) (trigSum s (diffCoeffs a) x) x := by
  unfold trigSum
  refine HasDerivAt.fun_sum (u := s) (A := fun n (y : ℝ) => a n *
    fourier (T := 1) n (y : AddCircle (1 : ℝ))) (fun n _ => ?_)
  simpa only [diffCoeffs, Complex.ofReal_one, div_one, mul_assoc] using
    (hasDerivAt_fourier 1 n x).const_mul (a n)

/-- Parseval for a finite sum of integer characters on one period. -/
theorem trigSum_integral_sq (s : Finset ℤ) (a : ℤ → ℂ) :
    (∫ x in (0 : ℝ)..1, ‖trigSum s a x‖ ^ 2) = ∑ n ∈ s, ‖a n‖ ^ 2 := by
  classical
  let F := trigPolynomial s a
  let μ := AddCircle.haarAddCircle (T := 1)
  have hpol :
      ContinuousMap.toLp 2 μ ℂ F = ∑ n ∈ s, a n • fourierLp (T := 1) 2 n := by
    simp [F, trigPolynomial, μ, fourierLp]
  have hparse := (orthonormal_fourier (T := 1)).inner_sum a a s
  rw [← hpol, ContinuousMap.inner_toLp] at hparse
  have hint :
      (∫ x : AddCircle (1 : ℝ), (‖F x‖ ^ 2 : ℝ) ∂μ) = ∑ n ∈ s, ‖a n‖ ^ 2 := by
    apply Complex.ofReal_injective
    rw [Complex.ofReal_sum, ← integral_complex_ofReal]
    simpa only [Complex.ofReal_pow, ← Complex.mul_conj', mul_comm] using hparse
  have hperiod :=
    AddCircle.intervalIntegral_preimage 1 0 (fun x : AddCircle (1 : ℝ) => ‖F x‖ ^ 2)
  rw [← hint]
  unfold μ
  simpa only [zero_add, AddCircle.integral_haarAddCircle, inv_one, one_smul,
    F, trigPolynomial_apply, trigSum] using hperiod


/-- A large-sieve inequality for trigonometric sums with separated sample points. -/
theorem sum_trigSum_sq_le_of_separated {ι : Type*}
    (centers : Finset ι) (freq : ι → ℝ) {δ H : ℝ} (hδ : 0 < δ) (hδ₁ : δ ≤ 1)
    (hc : ∀ i ∈ centers, freq i ∈ Set.Icc (0 : ℝ) 1)
    (hsep : ∀ i ∈ centers, ∀ j ∈ centers, i ≠ j → δ ≤ |freq i - freq j|)
    (s : Finset ℤ) (a : ℤ → ℂ) (hH : 0 ≤ H) (hband : ∀ n ∈ s, |(n : ℝ)| ≤ H) :
    (∑ i ∈ centers, ‖trigSum s a (freq i)‖ ^ 2) ≤
      3 * (δ⁻¹ + 4 * Real.pi * (H + 1)) * ∑ n ∈ s, ‖a n‖ ^ 2 := by
  let S := trigSum s a
  let D := trigSum s (diffCoeffs a)
  let g' (x : ℝ) := 2 * inner ℝ (S x) (D x)
  let K := 2 * Real.pi * (H + 1)
  let E := ∑ n ∈ s, ‖a n‖ ^ 2
  have hK : 0 < K := by dsimp [K]; positivity
  have hS : Continuous S := trigSum_continuous s a
  have hD : Continuous D := trigSum_continuous s (diffCoeffs a)
  have hg' : Continuous g' :=
    continuous_const.mul (continuous_inner.comp (hS.prodMk hD))
  have hp : Function.Periodic S 1 := trigSum_periodic s a
  have hp' : Function.Periodic D 1 := trigSum_periodic s (diffCoeffs a)
  have hsamp := sum_values_le_period_integrals_of_separated centers freq hδ hδ₁ hc hsep
    (fun x => (trigSum_hasDerivAt s a x).norm_sq) hg'
    (fun x => sq_nonneg ‖S x‖) (fun x => by change ‖S (x + 1)‖ ^ 2 = ‖S x‖ ^ 2; rw [hp x])
    (fun x => by
      change 2 * inner ℝ (S (x + 1)) (D (x + 1)) = 2 * inner ℝ (S x) (D x)
      rw [hp x, hp' x])
  have hpoint (x : ℝ) : |g' x| ≤ K * ‖S x‖ ^ 2 + ‖D x‖ ^ 2 / K := by
    calc
      |g' x| = 2 * |inner ℝ (S x) (D x)| := by dsimp [g']; rw [abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2)]
      _ ≤ 2 * (‖S x‖ * ‖D x‖) :=
        mul_le_mul_of_nonneg_left (abs_real_inner_le_norm (S x) (D x)) (by norm_num)
      _ ≤ K * ‖S x‖ ^ 2 + ‖D x‖ ^ 2 / K := by
        apply sub_le_iff_le_add'.mp
        apply (le_div_iff₀ hK).mpr
        nlinarith [sq_nonneg (K * ‖S x‖ - ‖D x‖)]
  have hInt := intervalIntegral.integral_mono (μ := volume) (a := 0) (b := 1) (by norm_num)
    (hg'.abs.intervalIntegrable 0 1)
    (((continuous_const.mul (hS.norm.pow 2)).add ((hD.norm.pow 2).div_const K)).intervalIntegrable 0 1)
    hpoint
  have henergy : (∫ x in (0 : ℝ)..1, ‖S x‖ ^ 2) = E := trigSum_integral_sq s a
  have hdiff : (∫ x in (0 : ℝ)..1, ‖D x‖ ^ 2) ≤ K ^ 2 * E := by
    dsimp [D]
    rw [trigSum_integral_sq, Finset.mul_sum]
    apply Finset.sum_le_sum
    intro n hn
    rw [← mul_pow]
    apply pow_le_pow_left₀ (norm_nonneg _) _ 2
    rw [diffCoeffs, norm_mul]
    rw [mul_comm K]
    apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
    rw [norm_mul, norm_mul, norm_mul, Complex.norm_I, Complex.norm_intCast,
      Complex.norm_real, Real.norm_eq_abs, abs_of_pos Real.pi_pos]
    norm_num
    dsimp [K]
    have h := hband n hn
    have hπ := Real.pi_pos
    nlinarith [mul_nonneg hπ.le (sub_nonneg.mpr h)]
  have hSInt : IntervalIntegrable (fun x => K * ‖S x‖ ^ 2) volume 0 1 :=
    (continuous_const.mul (hS.norm.pow 2)).intervalIntegrable 0 1
  have hDInt : IntervalIntegrable (fun x => ‖D x‖ ^ 2 / K) volume 0 1 :=
    ((hD.norm.pow 2).div_const K).intervalIntegrable 0 1
  change (∫ x in (0 : ℝ)..1, |g' x|) ≤ ∫ x in (0 : ℝ)..1,
    K * ‖S x‖ ^ 2 + ‖D x‖ ^ 2 / K at hInt
  rw [intervalIntegral.integral_add hSInt hDInt, intervalIntegral.integral_const_mul,
    intervalIntegral.integral_div, henergy] at hInt
  have hvar : (∫ x in (0 : ℝ)..1, |g' x|) ≤ 2 * K * E := by
    have hbound : (∫ x in (0 : ℝ)..1, ‖D x‖ ^ 2) / K ≤ K * E := by
      apply (div_le_iff₀ hK).mpr
      calc
        _ ≤ K ^ 2 * E := hdiff
        _ = _ := by ring
    linarith
  change (∑ i ∈ centers, ‖S (freq i)‖ ^ 2) ≤
    3 * ((∫ x in (0 : ℝ)..1, ‖S x‖ ^ 2) / δ + ∫ x in (0 : ℝ)..1, |g' x|) at hsamp
  rw [henergy] at hsamp
  calc
    _ ≤ 3 * (E / δ + ∫ x in (0 : ℝ)..1, |g' x|) := hsamp
    _ ≤ 3 * (E / δ + 2 * K * E) :=
      mul_le_mul_of_nonneg_left (add_le_add_right hvar _) (by norm_num)
    _ = _ := by dsimp [K]; ring

end LeanAB.PaperB.LargeSieve
