module

public import Common
public import Mathlib.Algebra.Field.ZMod
public import Mathlib.Algebra.BigOperators.Ring.Finset
public import Mathlib.Algebra.GCDMonoid.FinsetLemmas
public import Mathlib.Data.Finset.Max
public import Mathlib.Data.Nat.Sqrt
public import Mathlib.Data.Rat.Floor
public import Mathlib.NumberTheory.Chebyshev
meta import Mathlib.Tactic.FieldSimp
meta import Mathlib.Tactic.Linarith
meta import Mathlib.Tactic.Positivity

/-! The exact finite local capacity of F2 and its integer upper bound. -/

@[expose] public section

open scoped BigOperators

namespace LeanAB

namespace PaperB

def denominators (N : ℕ) : Finset ℕ := interval 1 N

/-- The condition N < p² is equivalent to p > √N for natural p. -/
def largePrimes (N : ℕ) : Finset ℕ :=
  (denominators N).filter fun p => p.Prime ∧ N < p * p

theorem mem_largePrimes {N p : ℕ} :
    p ∈ largePrimes N ↔ p.Prime ∧ p ≤ N ∧ Nat.sqrt N < p := by
  simp only [largePrimes, denominators, interval, max_self, Finset.mem_filter, Finset.mem_Icc, Nat.sqrt_lt]
  exact ⟨fun h => ⟨h.2.1, h.1.2, h.2.2⟩,
    fun h => ⟨⟨h.1.one_le, h.2.1⟩, h.1, h.2.2⟩⟩

def cofactorBlock (N p : ℕ) : Finset ℕ := denominators (N / p)

def cofactorResidue (p : ℕ) (J : Finset ℕ) : ZMod p := ∑ b ∈ J, (b : ZMod p)⁻¹

/-- All deletions whose remaining cofactors have zero reciprocal residue. -/
def deletions (N p : ℕ) : Finset (Finset ℕ) :=
  (cofactorBlock N p).powerset.filter
    fun D => cofactorResidue p (cofactorBlock N p \ D) = 0

theorem deletions_nonempty (N p : ℕ) : (deletions N p).Nonempty := by
  refine ⟨cofactorBlock N p, ?_⟩
  exact Finset.mem_filter.mpr ⟨Finset.mem_powerset.mpr (Finset.Subset.refl _), by
    simp [cofactorResidue]⟩

def deletionCost (N p : ℕ) : ℚ :=
  ((deletions N p).image mass).min' ((deletions_nonempty N p).image _)

theorem deletionCost_spec (N p : ℕ) :
    IsLeast {d | ∃ D ∈ deletions N p, mass D = d} (deletionCost N p) := by
  constructor
  · exact Finset.mem_image.mp (Finset.min'_mem _ _)
  · rintro d ⟨D, hD, rfl⟩
    exact Finset.min'_le _ _ (Finset.mem_image_of_mem _ hD)

def capacity (N : ℕ) : ℚ :=
  mass (denominators N) - ∑ p ∈ largePrimes N, deletionCost N p / p

def primePart (p : ℕ) (S : Finset ℕ) : Finset ℕ := S.filter (p ∣ ·)

def localResidue (p : ℕ) (S : Finset ℕ) : ZMod p :=
  ∑ n ∈ primePart p S, ((n / p : ℕ) : ZMod p)⁻¹

def LocalFeasible (N : ℕ) (S : Finset ℕ) : Prop :=
  S ⊆ denominators N ∧ ∀ p ∈ largePrimes N, localResidue p S = 0

private def unblockedPart (N : ℕ) (S : Finset ℕ) : Finset ℕ :=
  S \ (largePrimes N).biUnion (fun p => primePart p (denominators N))

private def liftCofactors (p : ℕ) (J : Finset ℕ) : Finset ℕ := J.image (p * ·)

private def lowerMultiples (p : ℕ) (S : Finset ℕ) : Finset ℕ := S.image (· / p)

private theorem lower_lift {p : ℕ} (hp : 0 < p) (J : Finset ℕ) :
    lowerMultiples p (liftCofactors p J) = J := by
  simp [lowerMultiples, liftCofactors, Finset.image_image, Function.comp_def, Nat.mul_div_cancel_left _ hp]

private theorem lift_lower {p : ℕ} {S : Finset ℕ} (h : ∀ n ∈ S, p ∣ n) :
    liftCofactors p (lowerMultiples p S) = S := by
  rw [liftCofactors, lowerMultiples, Finset.image_image]
  ext n
  simp only [Finset.mem_image, Function.comp_apply]
  exact ⟨fun ⟨i, hi, he⟩ => by rw [mul_comm, Nat.div_mul_cancel (h i hi)] at he; exact he ▸ hi,
    fun hn => ⟨n, hn, by rw [mul_comm, Nat.div_mul_cancel (h n hn)]⟩⟩

private theorem lift_subset_block {N p : ℕ} (hp : 0 < p) {J : Finset ℕ}
    (hJ : J ⊆ cofactorBlock N p) : liftCofactors p J ⊆ primePart p (denominators N) := by
  intro n hn
  obtain ⟨b, hb, rfl⟩ := Finset.mem_image.mp hn
  have hb' := Finset.mem_Icc.mp (hJ hb)
  exact Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr
    ⟨Nat.one_le_iff_ne_zero.mpr (Nat.mul_ne_zero hp.ne' (Nat.one_le_iff_ne_zero.mp hb'.1)),
      by rw [mul_comm]; exact Nat.mul_le_of_le_div _ _ _ hb'.2⟩, dvd_mul_right _ _⟩

private theorem lower_subset_cofactor {N p : ℕ} (hp : 0 < p) {S : Finset ℕ}
    (hS : S ⊆ primePart p (denominators N)) : lowerMultiples p S ⊆ cofactorBlock N p := by
  intro b hb
  obtain ⟨n, hn, rfl⟩ := Finset.mem_image.mp hb
  obtain ⟨hn', hd⟩ := Finset.mem_filter.mp (hS hn)
  have hn'' := Finset.mem_Icc.mp hn'
  exact Finset.mem_Icc.mpr ⟨Nat.div_pos (Nat.le_of_dvd hn''.1 hd) hp, Nat.div_le_div_right hn''.2⟩

private theorem lift_cofactorBlock {N p : ℕ} (hp : 0 < p) :
    liftCofactors p (cofactorBlock N p) = primePart p (denominators N) := by
  refine Finset.Subset.antisymm (lift_subset_block hp (Finset.Subset.refl _)) ?_
  have he := lift_lower (S := primePart p (denominators N)) (fun _ h => (Finset.mem_filter.mp h).2)
  exact he ▸ Finset.image_subset_image (lower_subset_cofactor hp (Finset.Subset.refl (primePart p (denominators N))))

/-- Reciprocal mass scales inversely under multiplication of denominators. -/
theorem mass_image_mul (p : ℕ) (hp : 0 < p) (J : Finset ℕ) :
    mass (J.image (p * ·)) = mass J / p := by
  rw [mass, Finset.sum_image (fun a _ b _ h => Nat.eq_of_mul_eq_mul_left hp h),
    mass, div_eq_mul_inv, Finset.sum_mul]
  simp [Nat.cast_mul, mul_comm]

private theorem mass_lift (p : ℕ) (hp : 0 < p) (J : Finset ℕ) :
    mass (liftCofactors p J) = mass J / p := mass_image_mul p hp J

private theorem residue_lift (p : ℕ) (hp : 0 < p) (J : Finset ℕ) :
    localResidue p (liftCofactors p J) = cofactorResidue p J := by
  have hfilter : primePart p (liftCofactors p J) = liftCofactors p J := by
    apply Finset.filter_true_of_mem
    intro n hn
    obtain ⟨_, _, rfl⟩ := Finset.mem_image.mp hn
    exact dvd_mul_right _ _
  rw [localResidue, hfilter, liftCofactors,
    Finset.sum_image (fun a _ b _ h => Nat.eq_of_mul_eq_mul_left hp h), cofactorResidue]
  simp [Nat.mul_div_cancel_left _ hp]

private theorem primePart_subset {N p : ℕ} {S : Finset ℕ} (hS : S ⊆ denominators N) :
    primePart p S ⊆ primePart p (denominators N) :=
  Finset.filter_subset_filter _ hS

private theorem primePart_idem (p : ℕ) (S : Finset ℕ) :
    primePart p (primePart p S) = primePart p S := by
  simp [primePart, Finset.filter_filter]

private theorem localResidue_primePart (p : ℕ) (S : Finset ℕ) :
    localResidue p (primePart p S) = localResidue p S := by
  rw [localResidue, primePart_idem, localResidue]

/-- The best mass retained in one block after imposing its zero-residue constraint. -/
theorem local_block_optimum {N p : ℕ} (hp : p ∈ largePrimes N) :
    IsGreatest {r | ∃ T ⊆ primePart p (denominators N), localResidue p T = 0 ∧ mass T = r}
      (mass (primePart p (denominators N)) - deletionCost N p / p) := by
  have hpos := (mem_largePrimes.mp hp).1.pos
  constructor
  · obtain ⟨D, hD, hcost⟩ := (deletionCost_spec N p).1
    have hD' := Finset.mem_filter.mp hD
    have hsubset := Finset.mem_powerset.mp hD'.1
    refine ⟨liftCofactors p (cofactorBlock N p \ D), lift_subset_block hpos Finset.sdiff_subset,
      (residue_lift _ hpos _).trans hD'.2, ?_⟩
    rw [← lift_cofactorBlock hpos, mass_lift _ hpos, mass_lift _ hpos, ← hcost]
    have h := Finset.sum_sdiff_eq_sub (f := fun b : ℕ => (b : ℚ)⁻¹) hsubset
    change mass (cofactorBlock N p \ D) = mass (cofactorBlock N p) - mass D at h
    rw [h, sub_div]
  · rintro r ⟨T, hT, hzero, rfl⟩
    let J := lowerMultiples p T
    have hJ : J ⊆ cofactorBlock N p := lower_subset_cofactor hpos hT
    have hLift : liftCofactors p J = T := lift_lower (fun b hb => (Finset.mem_filter.mp (hT hb)).2)
    have hJzero : cofactorResidue p J = 0 := by rw [← residue_lift _ hpos, hLift, hzero]
    let D := cofactorBlock N p \ J
    have hD : D ∈ deletions N p := by
      refine Finset.mem_filter.mpr ⟨Finset.mem_powerset.mpr Finset.sdiff_subset, ?_⟩
      change cofactorResidue p (cofactorBlock N p \ (cofactorBlock N p \ J)) = 0
      rwa [Finset.sdiff_sdiff_eq_self hJ]
    have hcost := (deletionCost_spec N p).2 ⟨D, hD, rfl⟩
    change deletionCost N p ≤ mass (cofactorBlock N p \ J) at hcost
    rw [← hLift, ← lift_cofactorBlock hpos, mass_lift _ hpos, mass_lift _ hpos]
    have h := Finset.sum_sdiff_eq_sub (f := fun b : ℕ => (b : ℚ)⁻¹) hJ
    change mass (cofactorBlock N p \ J) = mass (cofactorBlock N p) - mass J at h
    rw [h] at hcost
    rw [← sub_div]
    exact div_le_div_of_nonneg_right (by linarith) (by positivity)

/-- The mass on full multiples of p is the cofactor mass divided by p. -/
theorem mass_primePart {N p : ℕ} (hp : 0 < p) :
    mass (primePart p (denominators N)) = mass (cofactorBlock N p) / p := by
  rw [← lift_cofactorBlock hp, mass_lift _ hp]

theorem primePart_disjoint {N p q : ℕ} (hp : p ∈ largePrimes N)
    (hq : q ∈ largePrimes N) (hne : p ≠ q) :
    Disjoint (primePart p (denominators N)) (primePart q (denominators N)) := by
  refine Finset.disjoint_left.mpr fun n hp' hq' => ?_
  obtain ⟨hpp, _, hpsq⟩ := mem_largePrimes.mp hp
  obtain ⟨hqp, _, hqsq⟩ := mem_largePrimes.mp hq
  rw [Nat.sqrt_lt] at hpsq hqsq
  obtain ⟨hn, hpdvd⟩ := Finset.mem_filter.mp hp'
  obtain ⟨hnpos, hnN⟩ := Finset.mem_Icc.mp hn
  have hqdvd := (Finset.mem_filter.mp hq').2
  have hprod := Nat.le_of_dvd hnpos
    (((Nat.coprime_primes hpp hqp).mpr hne).mul_dvd_of_dvd_of_dvd hpdvd hqdvd)
  rcases le_total p q with hpq | hqp
  · exact (not_lt_of_ge (Nat.le_trans (Nat.mul_le_mul_left p hpq) (hprod.trans hnN))) hpsq
  · exact (not_lt_of_ge (Nat.le_trans (Nat.mul_le_mul_right q hqp) (hprod.trans hnN))) hqsq

private theorem mass_decomposition {N : ℕ} {S : Finset ℕ} (hS : S ⊆ denominators N) :
    mass S = mass (unblockedPart N S) + ∑ p ∈ largePrimes N, mass (primePart p S) := by
  let T := (largePrimes N).biUnion fun p => primePart p S
  have hTS : T ⊆ S := by
    intro n hn
    obtain ⟨p, _, hnp⟩ := Finset.mem_biUnion.mp hn
    exact (Finset.mem_filter.mp hnp).1
  have hU : S \ T = unblockedPart N S := by
    ext n
    simp only [T, unblockedPart, Finset.mem_sdiff, Finset.mem_biUnion, primePart, Finset.mem_filter]
    constructor
    · rintro ⟨hn, hh⟩
      exact ⟨hn, fun ⟨p, hp, _, hd⟩ => hh ⟨p, hp, hn, hd⟩⟩
    · rintro ⟨hn, hh⟩
      exact ⟨hn, fun ⟨p, hp, _, hd⟩ => hh ⟨p, hp, hS hn, hd⟩⟩
  have hdis : ((largePrimes N : Finset ℕ) : Set ℕ).PairwiseDisjoint (fun p => primePart p S) := by
    intro p hp q hq hpq
    exact (primePart_disjoint hp hq hpq).mono (primePart_subset hS) (primePart_subset hS)
  have hsum := Finset.sum_sdiff (f := fun b : ℕ => (b : ℚ)⁻¹) hTS
  change mass (S \ T) + mass T = mass S at hsum
  rw [← hsum, hU]
  congr 1
  exact Finset.sum_biUnion hdis

private theorem capacity_decomposition (N : ℕ) :
    capacity N = mass (unblockedPart N (denominators N)) +
      ∑ p ∈ largePrimes N, (mass (primePart p (denominators N)) - deletionCost N p / p) := by
  rw [Finset.sum_sub_distrib, capacity]
  have h := mass_decomposition (N := N) (Finset.Subset.refl (denominators N))
  linarith

private theorem assemble {N : ℕ} (T : ℕ → Finset ℕ)
    (hT : ∀ p ∈ largePrimes N, T p ⊆ primePart p (denominators N))
    (hzero : ∀ p ∈ largePrimes N, localResidue p (T p) = 0) :
    ∃ S, LocalFeasible N S ∧ unblockedPart N S = unblockedPart N (denominators N) ∧
      ∀ p ∈ largePrimes N, primePart p S = T p := by
  let S := unblockedPart N (denominators N) ∪ (largePrimes N).biUnion T
  have hS : S ⊆ denominators N := by
    intro n hn
    rcases Finset.mem_union.mp hn with hn | hn
    · exact (Finset.mem_sdiff.mp hn).1
    · obtain ⟨p, hp, hn'⟩ := Finset.mem_biUnion.mp hn
      exact (Finset.mem_filter.mp (hT p hp hn')).1
  have hfilter : ∀ p ∈ largePrimes N, primePart p S = T p := by
    intro p hp
    ext n
    constructor
    · intro hn
      obtain ⟨hn, hdvd⟩ := Finset.mem_filter.mp hn
      have hnp : n ∈ primePart p (denominators N) := Finset.mem_filter.mpr ⟨hS hn, hdvd⟩
      rcases Finset.mem_union.mp hn with hn | hn
      · exact False.elim ((Finset.mem_sdiff.mp hn).2 (Finset.mem_biUnion.mpr ⟨p, hp, hnp⟩))
      · obtain ⟨q, hq, hnq⟩ := Finset.mem_biUnion.mp hn
        have hpq : p = q := by
          by_contra hne
          exact Finset.disjoint_left.mp (primePart_disjoint hp hq hne) hnp (hT q hq hnq)
        rwa [hpq]
    · intro hn
      exact Finset.mem_filter.mpr ⟨Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨p, hp, hn⟩),
        (Finset.mem_filter.mp (hT p hp hn)).2⟩
  refine ⟨S, ⟨hS, fun p hp => ?_⟩, ?_, hfilter⟩
  · rw [← localResidue_primePart p S, hfilter p hp]
    exact hzero p hp
  · ext n
    constructor
    · intro hn
      exact Finset.mem_sdiff.mpr ⟨hS (Finset.mem_sdiff.mp hn).1, (Finset.mem_sdiff.mp hn).2⟩
    · intro hn
      exact Finset.mem_sdiff.mpr ⟨Finset.mem_union_left _ hn, (Finset.mem_sdiff.mp hn).2⟩

/-- The paper's deletion formula is exactly the global optimum of the local constraints. -/
theorem capacity_isGreatest (N : ℕ) :
    IsGreatest {r | ∃ S, LocalFeasible N S ∧ mass S = r} (capacity N) := by
  constructor
  · classical
    let T : ℕ → Finset ℕ := fun p =>
      if hp : p ∈ largePrimes N then Classical.choose (local_block_optimum hp).1 else ∅
    have hT (p) (hp : p ∈ largePrimes N) :
        T p ⊆ primePart p (denominators N) ∧ localResidue p (T p) = 0 ∧
          mass (T p) = mass (primePart p (denominators N)) - deletionCost N p / p := by
      simpa only [T, dite_eq_left hp] using Classical.choose_spec (local_block_optimum hp).1
    obtain ⟨S, hS, hrest, hparts⟩ :=
      assemble T (fun p hp => (hT p hp).1) (fun p hp => (hT p hp).2.1)
    refine ⟨S, hS, ?_⟩
    rw [mass_decomposition hS.1, capacity_decomposition, hrest]
    congr 1
    exact Finset.sum_congr rfl fun p hp => (congrArg mass (hparts p hp)).trans (hT p hp).2.2
  · rintro r ⟨S, hS, rfl⟩
    rw [mass_decomposition hS.1, capacity_decomposition]
    apply add_le_add (mass_mono ?_) (Finset.sum_le_sum ?_)
    · intro n hn
      exact Finset.mem_sdiff.mpr ⟨hS.1 (Finset.mem_sdiff.mp hn).1, (Finset.mem_sdiff.mp hn).2⟩
    · intro p hp
      exact (local_block_optimum hp).2
        ⟨primePart p S, primePart_subset hS.1, (localResidue_primePart p S).trans (hS.2 p hp), rfl⟩

theorem localFeasible_mono {M N : ℕ} (hMN : M ≤ N) {S : Finset ℕ}
    (hS : LocalFeasible M S) : LocalFeasible N S := by
  refine ⟨hS.1.trans (Finset.Icc_subset_Icc le_rfl hMN), fun p hp => ?_⟩
  obtain ⟨hprime, _, hsq⟩ := mem_largePrimes.mp hp
  by_cases hpM : p ≤ M
  · exact hS.2 p (mem_largePrimes.mpr ⟨hprime, hpM, by
      rw [Nat.sqrt_lt] at hsq ⊢
      omega⟩)
  · have hEmpty : primePart p S = ∅ := by
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro n hn
      obtain ⟨hnS, hpdvd⟩ := Finset.mem_filter.mp hn
      obtain ⟨hnpos, hnle⟩ := Finset.mem_Icc.mp (hS.1 hnS)
      exact hpM ((Nat.le_of_dvd hnpos hpdvd).trans hnle)
    simp [localResidue, hEmpty]

theorem capacity_mono : Monotone capacity := by
  intro M N hMN
  obtain ⟨S, hS, hmass⟩ := (capacity_isGreatest M).1
  exact (capacity_isGreatest N).2 ⟨S, localFeasible_mono hMN hS, hmass⟩

theorem capacity_succ_ge {N : ℕ} (hsmooth : ∀ p, p.Prime → p ∣ N + 1 → p ≤ Nat.sqrt (N + 1)) :
    capacity N + (↑(N + 1) : ℚ)⁻¹ ≤ capacity (N + 1) := by
  obtain ⟨S, hS, hmass⟩ := (capacity_isGreatest N).1
  have hN : N + 1 ∉ S := fun h => by have := (Finset.mem_Icc.mp (hS.1 h)).2; omega
  have hS' := localFeasible_mono (Nat.le_succ N) hS
  have hmass' : mass (insert (N + 1) S) = capacity N + (↑(N + 1) : ℚ)⁻¹ := by
    rw [mass, Finset.sum_insert hN, ← mass, hmass, add_comm]
  refine (capacity_isGreatest (N + 1)).2 ⟨insert (N + 1) S,
    ⟨Finset.insert_subset (Finset.mem_Icc.mpr ⟨by omega, le_rfl⟩) hS'.1, ?_⟩, hmass'⟩
  intro p hp
  obtain ⟨hprime, _, hlarge⟩ := mem_largePrimes.mp hp
  have hndvd : ¬ p ∣ N + 1 := fun h => (not_le_of_gt hlarge) (hsmooth p hprime h)
  simpa [localResidue, primePart, Finset.filter_insert, hndvd] using hS'.2 p hp

/-- Exact modular reduction after multiplying a reciprocal sum by a large prime. -/
private theorem scaled_reciprocal {p n : ℕ} (hp : p.Prime) (hn : 0 < n)
    (hlarge : n < p * p) :
    let _ : Fact p.Prime := ⟨hp⟩
    let r : ℚ := (p : ℚ) * (n : ℚ)⁻¹
    (r.den : ZMod p) ≠ 0 ∧
      (r : ZMod p) = if p ∣ n then ((n / p : ℕ) : ZMod p)⁻¹ else 0 := by
  let _ : Fact p.Prime := ⟨hp⟩
  let denInv (b : ℕ) (hb : 0 < b) : ((b : ℚ)⁻¹).den = b := by
    rw [Rat.den_inv_of_ne_zero (by exact_mod_cast hb.ne'), Rat.num_natCast, Int.natAbs_natCast]
  dsimp only
  by_cases hdvd : p ∣ n
  · have hbpos : 0 < n / p := Nat.div_pos (Nat.le_of_dvd hn hdvd) hp.pos
    have hblt : n / p < p := (Nat.div_lt_iff_lt_mul hp.pos).2 hlarge
    have hbndvd : ¬p ∣ n / p := fun hd => (not_le_of_gt hblt) (Nat.le_of_dvd hbpos hd)
    have hbeq : n = p * (n / p) := by rw [mul_comm, Nat.div_mul_cancel hdvd]
    have hpQ : (p : ℚ) ≠ 0 := by exact_mod_cast hp.ne_zero
    have hbQ : ((n / p : ℕ) : ℚ) ≠ 0 := by exact_mod_cast hbpos.ne'
    have hr : (p : ℚ) * (n : ℚ)⁻¹ = ((n / p : ℕ) : ℚ)⁻¹ := by
      nth_rw 1 [hbeq]
      push_cast
      field_simp
    rw [hr, denInv _ hbpos, ite_eq_left hdvd, Rat.cast_inv_of_ne_zero]
    · exact ⟨fun h => hbndvd ((ZMod.natCast_eq_zero_iff _ _).mp h), by simp⟩
    · simpa only [Rat.num_natCast, Int.cast_natCast] using
        (fun h => hbndvd ((ZMod.natCast_eq_zero_iff (n / p) p).mp h))
  · have hnndvd : ¬ p ∣ ((p : ℚ) * (n : ℚ)⁻¹).den := by
      intro h
      have hh := h.trans (Rat.mul_den_dvd (p : ℚ) ((n : ℚ)⁻¹))
      simp [denInv _ hn, hdvd] at hh
    constructor
    · exact fun h => hnndvd ((ZMod.natCast_eq_zero_iff _ _).mp h)
    · rw [ite_eq_right hdvd, Rat.cast_mul_of_ne_zero (by simp) (by
        rw [denInv _ hn]
        exact fun h => hdvd ((ZMod.natCast_eq_zero_iff _ _).mp h))]
      simp

private theorem cast_sum_of_den_ne_zero {p : ℕ} [Fact p.Prime] {S : Finset ℕ} (f : ℕ → ℚ)
    (hf : ∀ n ∈ S, ((f n).den : ZMod p) ≠ 0) :
    ((∑ n ∈ S, f n).den : ZMod p) ≠ 0 ∧
      ((∑ n ∈ S, f n : ℚ) : ZMod p) = ∑ n ∈ S, (f n : ZMod p) := by
  induction S using Finset.induction_on with
  | empty => simp
  | @insert a S ha ih =>
    have hfa := hf a (Finset.mem_insert_self _ _)
    obtain ⟨hden, hcast⟩ := ih (fun n hn => hf n (Finset.mem_insert_of_mem hn))
    rw [Finset.sum_insert ha, Finset.sum_insert ha]
    refine ⟨?_, (Rat.cast_add_of_ne_zero hfa hden).trans (congrArg _ hcast)⟩
    intro h
    have hh := ((ZMod.natCast_eq_zero_iff _ p).mp h).trans (Rat.add_den_dvd (f a) (∑ n ∈ S, f n))
    have hmul := (ZMod.natCast_eq_zero_iff _ p).mpr hh
    push_cast at hmul
    exact (mul_ne_zero hfa hden) hmul

theorem localResidue_zero_of_den_ndvd {N p : ℕ} {S : Finset ℕ}
    (hp : p ∈ largePrimes N) (hS : S ⊆ denominators N) (hden : ¬p ∣ (mass S).den) :
    localResidue p S = 0 := by
  obtain ⟨hp', _, hlarge⟩ := mem_largePrimes.mp hp
  rw [Nat.sqrt_lt] at hlarge
  let _ : Fact p.Prime := ⟨hp'⟩
  let f (n : ℕ) := (p : ℚ) * (n : ℚ)⁻¹
  have hscaled (n) (hn : n ∈ S) :=
    scaled_reciprocal hp' ((Finset.mem_Icc.mp (hS hn)).1) ((Finset.mem_Icc.mp (hS hn)).2.trans_lt hlarge)
  have hcast := (cast_sum_of_den_ne_zero f (fun n hn => (hscaled n hn).1)).2
  have hsum : ∑ n ∈ S, f n = (p : ℚ) * mass S := by
    rw [mass, Finset.mul_sum]
  have hzero : ∑ n ∈ S, (f n : ZMod p) = 0 := by
    rw [← hcast, hsum, Rat.cast_mul_of_ne_zero (by simp)
      (fun h => hden ((ZMod.natCast_eq_zero_iff _ _).mp h))]
    simp
  rw [localResidue, primePart, Finset.sum_filter]
  exact (Finset.sum_congr rfl fun n hn => (hscaled n hn).2.symm).trans hzero

theorem integral_localFeasible {N : ℕ} {S : Finset ℕ} (hS : S ⊆ denominators N)
    {z : ℤ} (hz : mass S = z) : LocalFeasible N S := by
  refine ⟨hS, fun p hp => localResidue_zero_of_den_ndvd hp hS ?_⟩
  simpa [hz] using (mem_largePrimes.mp hp).1.not_dvd_one

/-- The positive and zero integer values represented at height N. -/
def representedIntegers (N : ℕ) : Finset ℕ :=
  (((denominators N).powerset.filter fun S => (mass S).den = 1).image
    fun S => ⌊mass S⌋₊)

theorem representedIntegers_nonempty (N : ℕ) : (representedIntegers N).Nonempty := by
  refine ⟨0, Finset.mem_image.mpr ⟨∅, ?_, ?_⟩⟩
  · exact Finset.mem_filter.mpr ⟨Finset.mem_powerset.mpr (Finset.empty_subset _), by simp [mass]⟩
  · simp [mass]

theorem mem_representedIntegers {N j : ℕ} :
    j ∈ representedIntegers N ↔ ∃ S ⊆ denominators N, mass S = (j : ℚ) := by
  constructor
  · intro h
    obtain ⟨S, hS, rfl⟩ := Finset.mem_image.mp h
    obtain ⟨hsub, hden⟩ := Finset.mem_filter.mp hS
    refine ⟨S, Finset.mem_powerset.mp hsub, ?_⟩
    have heq := (Rat.den_eq_one_iff (mass S)).1 hden
    have hn : 0 ≤ (mass S).num := by
      have hm := mass_nonneg S
      rw [← heq] at hm
      exact_mod_cast hm
    have heqNat : mass S = ((mass S).num.toNat : ℚ) := by
      rw [← Int.cast_natCast, Int.toNat_of_nonneg hn, heq]
    calc
      mass S = ((mass S).num.toNat : ℚ) := heqNat
      _ = (⌊((mass S).num.toNat : ℚ)⌋₊ : ℚ) := by simp
      _ = (⌊mass S⌋₊ : ℚ) := congrArg (fun q : ℚ => (⌊q⌋₊ : ℚ)) heqNat.symm
  · rintro ⟨S, hS, hmass⟩
    exact Finset.mem_image.mpr ⟨S, Finset.mem_filter.mpr
      ⟨Finset.mem_powerset.mpr hS, by simp [hmass]⟩, by simp [hmass]⟩

def h (N : ℕ) : ℕ := (representedIntegers N).max' (representedIntegers_nonempty N)

theorem h_isGreatest (N : ℕ) : IsGreatest {j : ℕ | ∃ S ⊆ denominators N, mass S = (j : ℚ)} (h N) := by
  exact ⟨mem_representedIntegers.mp (Finset.max'_mem _ _), fun j hj => Finset.le_max' _ _ (mem_representedIntegers.mpr hj)⟩

def UnitPacking (N : ℕ) (F : Finset (Finset ℕ)) : Prop :=
  (∀ S ∈ F, S ⊆ denominators N ∧ mass S = 1) ∧
    (↑F : Set (Finset ℕ)).PairwiseDisjoint id

open Classical in
noncomputable def packingSizes (N : ℕ) : Finset ℕ :=
  (((denominators N).powerset.powerset.filter (UnitPacking N)).image Finset.card)

theorem mem_packingSizes {N j : ℕ} : j ∈ packingSizes N ↔ ∃ F, UnitPacking N F ∧ F.card = j := by
  classical
  simp only [packingSizes, Finset.mem_image, Finset.mem_filter, Finset.mem_powerset]
  constructor
  · rintro ⟨F, ⟨_, hF⟩, rfl⟩
    exact ⟨F, hF, rfl⟩
  · rintro ⟨F, hF, rfl⟩
    exact ⟨F, ⟨fun S hS => Finset.mem_powerset.mpr (hF.1 S hS).1, hF⟩, rfl⟩

theorem packingSizes_nonempty (N : ℕ) : (packingSizes N).Nonempty := by
  refine ⟨0, mem_packingSizes.mpr ⟨∅, ?_, rfl⟩⟩
  simp [UnitPacking, Set.PairwiseDisjoint, Set.Pairwise]

noncomputable def k (N : ℕ) : ℕ := (packingSizes N).max' (packingSizes_nonempty N)

theorem k_isGreatest (N : ℕ) : IsGreatest {j | ∃ F, UnitPacking N F ∧ F.card = j} (k N) := by
  exact ⟨mem_packingSizes.mp (Finset.max'_mem _ _), fun j hj => Finset.le_max' _ _ (mem_packingSizes.mpr hj)⟩

theorem k_le_h (N : ℕ) : k N ≤ h N := by
  obtain ⟨F, hF, hcard⟩ := (k_isGreatest N).1
  refine (h_isGreatest N).2 ⟨F.biUnion id, ?_, ?_⟩
  · intro n hn
    obtain ⟨S, hSF, hnS⟩ := Finset.mem_biUnion.mp hn
    exact (hF.1 S hSF).1 hnS
  · calc
      mass (F.biUnion id) = ∑ S ∈ F, mass S := Finset.sum_biUnion hF.2
      _ = ∑ _S ∈ F, (1 : ℚ) := Finset.sum_congr rfl (fun S hSF => (hF.1 S hSF).2)
      _ = (k N : ℚ) := by simp [hcard]

theorem h_le_floor_capacity (N : ℕ) : (h N : ℤ) ≤ ⌊capacity N⌋ := by
  obtain ⟨S, hS, hmass⟩ := (h_isGreatest N).1
  have hS' : LocalFeasible N S := integral_localFeasible hS (z := (h N : ℤ)) (by simpa using hmass)
  apply Int.le_floor.mpr
  rw [Int.cast_natCast, ← hmass]
  exact (capacity_isGreatest N).2 ⟨S, hS', rfl⟩

theorem local_capacity_upper (N : ℕ) : k N ≤ h N ∧ (h N : ℤ) ≤ ⌊capacity N⌋ :=
  ⟨k_le_h N, h_le_floor_capacity N⟩

theorem capacity_nonneg (N : ℕ) : 0 ≤ capacity N :=
  (capacity_isGreatest N).2 ⟨∅, ⟨Finset.empty_subset _, by simp [localResidue, primePart]⟩,
    by simp [mass]⟩

theorem cofactor_lt_prime {N p : ℕ} (hp : p ∈ largePrimes N) : N / p < p := by
  obtain ⟨hprime, _, hlarge⟩ := mem_largePrimes.mp hp
  exact (Nat.div_lt_iff_lt_mul hprime.pos).2 (Nat.sqrt_lt.mp hlarge)

/-- Finite form of the large-prime obstruction, valid for any target with denominator
coprime to the prime. The size hypothesis prevents a positive cleared sum from being
a multiple of the prime. -/
theorem primePart_eq_empty_of_lcm_mul_mass_lt {N p : ℕ} {S : Finset ℕ}
    (hp : p ∈ largePrimes N) (hS : S ⊆ denominators N) (hden : ¬p ∣ (mass S).den)
    (hsmall : (Nat.lcmUpto (N / p) : ℚ) * mass (cofactorBlock N p) < p) :
    primePart p S = ∅ := by
  obtain ⟨hprime, _, _⟩ := mem_largePrimes.mp hp
  let _ : Fact p.Prime := ⟨hprime⟩
  let J := lowerMultiples p (primePart p S)
  let D := Nat.lcmUpto (N / p)
  have hJ : J ⊆ cofactorBlock N p := lower_subset_cofactor hprime.pos (primePart_subset hS)
  have hlift : liftCofactors p J = primePart p S :=
    lift_lower (fun _ h => (Finset.mem_filter.mp h).2)
  have hres : cofactorResidue p J = 0 := by
    rw [← residue_lift _ hprime.pos, hlift, localResidue_primePart]
    exact localResidue_zero_of_den_ndvd hp hS hden
  have hdvd (b) (hb : b ∈ J) : b ∣ D :=
    Finset.dvd_lcm (f := id) (show b ∈ Finset.Icc 1 (N / p) from hJ hb)
  have hbrange (b) (hb : b ∈ J) : 0 < b ∧ b < p := by
    obtain ⟨hpos, hle⟩ := Finset.mem_Icc.mp (hJ hb)
    exact ⟨hpos, hle.trans_lt (cofactor_lt_prime hp)⟩
  let numerator := ∑ b ∈ J, D / b
  have hmod : (numerator : ZMod p) = (D : ZMod p) * cofactorResidue p J := by
    rw [show numerator = ∑ b ∈ J, D / b from rfl, Nat.cast_sum,
      cofactorResidue, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro b hb
    have hbzero : (b : ZMod p) ≠ 0 := by
      intro hz
      exact (not_le_of_gt (hbrange b hb).2)
        (Nat.le_of_dvd (hbrange b hb).1 ((ZMod.natCast_eq_zero_iff _ _).mp hz))
    apply (eq_mul_inv_iff_mul_eq₀ hbzero).2
    rw [← Nat.cast_mul, Nat.div_mul_cancel (hdvd b hb)]
  have hsmallnum : numerator < p := by
    have hQ : (numerator : ℚ) = (D : ℚ) * mass J := by
      rw [show numerator = ∑ b ∈ J, D / b from rfl, Nat.cast_sum, mass, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro b hb
      apply (eq_mul_inv_iff_mul_eq₀ (by exact_mod_cast (hbrange b hb).1.ne' : (b : ℚ) ≠ 0)).2
      exact_mod_cast Nat.div_mul_cancel (hdvd b hb)
    have hbound : (numerator : ℚ) < p := by
      rw [hQ]
      exact (mul_le_mul_of_nonneg_left (mass_mono hJ) (Nat.cast_nonneg D)).trans_lt hsmall
    exact_mod_cast hbound
  rw [hres, mul_zero] at hmod
  have hzero : numerator = 0 := Nat.eq_zero_of_dvd_of_lt
    ((ZMod.natCast_eq_zero_iff _ _).mp hmod) hsmallnum
  have hempty : J = ∅ := by
    by_contra hne
    obtain ⟨b, hb⟩ := Finset.nonempty_iff_ne_empty.mpr hne
    have hD : 0 < D := Nat.lcmUpto_pos _
    have hbD : 0 < D / b := Nat.div_pos (Nat.le_of_dvd hD (hdvd b hb)) (hbrange b hb).1
    have hple : D / b ≤ numerator := Finset.single_le_sum (fun n _ => Nat.zero_le (D / n)) hb
    omega
  rw [← hlift, hempty]
  rfl

theorem capacity_four : capacity 4 = 7 / 4 := by cbv

theorem capacity_six : capacity 6 = 9 / 4 := by cbv

end PaperB
end LeanAB
