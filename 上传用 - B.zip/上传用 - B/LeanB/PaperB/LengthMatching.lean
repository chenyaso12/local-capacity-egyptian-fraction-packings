module

public import PaperB.FixedTargets
import Mathlib.Data.Finset.Max
import Mathlib.NumberTheory.Harmonic.Bounds
meta import Mathlib.Tactic

/-! Uniform estimates for matchings with bounded denominators and set lengths. -/

@[expose] public section

open Filter Finset Asymptotics
open scoped Topology

namespace LeanAB.PaperB.FixedTargets

private theorem harmonic_mono_nat : Monotone harmonic := by
  intro a b hab
  rw [← mass_denominators_eq_harmonic, ← mass_denominators_eq_harmonic]
  exact mass_mono (fun n hn => mem_Icc.mpr ⟨(mem_Icc.mp hn).1, (mem_Icc.mp hn).2.trans hab⟩)

/-- The reciprocal mass of a finite set of positive integers is bounded by
the harmonic sum at its cardinality. -/
theorem mass_le_harmonic_card {S : Finset ℕ} (hS : ∀ n ∈ S, 0 < n) :
    mass S ≤ harmonic S.card := by
  revert hS
  refine Finset.induction_on_max S ?_ ?_
  · intro _
    simp [mass, harmonic]
  · intro a T hMax ih hPos
    have ha : 0 < a := hPos a (mem_insert_self _ _)
    have haN : a ∉ T := fun h => (lt_irrefl a) (hMax a h)
    have hSub : insert a T ⊆ Finset.Icc 1 a := by
      intro n hn
      refine mem_Icc.mpr ⟨hPos n hn, ?_⟩
      rcases mem_insert.mp hn with rfl | hn'
      · exact le_rfl
      · exact (hMax n hn').le
    have hRank : T.card + 1 ≤ a := by
      have h := card_le_card hSub
      simpa only [card_insert_of_notMem haN, Nat.card_Icc, add_tsub_cancel_right] using h
    have hLow : mass T ≤ harmonic T.card := ih (fun n hn => hPos n (mem_insert_of_mem hn))
    have hInv : (a : ℚ)⁻¹ ≤ ((T.card + 1 : ℕ) : ℚ)⁻¹ :=
      inv_anti₀ (by positivity) (by exact_mod_cast hRank)
    rw [card_insert_of_notMem haN, harmonic_succ]
    change (∑ n ∈ insert a T, (n : ℚ)⁻¹) ≤ _
    rw [sum_insert haN]
    rw [add_comm (a : ℚ)⁻¹]
    exact add_le_add hLow hInv

/-- The two elementary capacity bounds for matching sets of bounded length. -/
theorem boundedPackingNumber_mass_bounds (r : ℚ) (K N : ℕ) :
    let m := boundedPackingNumber r K N
    (m : ℚ) * r ≤ harmonic N ∧ (m : ℚ) * r ≤ harmonic (m * K) := by
  classical
  let m := boundedPackingNumber r K N
  obtain ⟨F,hF,hCount⟩ := (matchingNumber_spec (boundedEdges 2 N r K)).1
  let U := F.biUnion id
  have hUSub : U ⊆ interval 2 N := by
    intro a ha
    obtain ⟨S,hSF,haS⟩ := mem_biUnion.mp ha
    exact (mem_boundedEdges.mp (hF.1 hSF)).1 haS
  have hMass : mass U = (m : ℚ) * r := calc
    _ = ∑ S ∈ F, mass S := sum_biUnion hF.2
    _ = ∑ _S ∈ F, r := sum_congr rfl (fun S hSF => (mem_boundedEdges.mp (hF.1 hSF)).2.1)
    _ = _ := by rw [sum_const,hCount,nsmul_eq_mul]; rfl
  have hCard : U.card ≤ m * K := calc
    _ ≤ ∑ S ∈ F, S.card := card_biUnion_le
    _ ≤ ∑ _S ∈ F, K := sum_le_sum fun S hSF => (mem_boundedEdges.mp (hF.1 hSF)).2.2
    _ = _ := by rw [sum_const,hCount,nsmul_eq_mul]; rfl
  have hUN : U ⊆ denominators N := by
    intro a ha
    obtain ⟨ha₀,haN⟩ := mem_Icc.mp (hUSub ha)
    exact mem_Icc.mpr ⟨(by norm_num : 1 ≤ 2).trans ha₀,haN⟩
  change (m : ℚ) * r ≤ harmonic N ∧ (m : ℚ) * r ≤ harmonic (m * K)
  rw [← hMass]
  exact ⟨(mass_mono hUN).trans_eq (mass_denominators_eq_harmonic N),
    (mass_le_harmonic_card (fun a ha => (by norm_num : 0 < 2).trans_le (mem_Icc.mp (hUSub ha)).1)).trans
      (harmonic_mono_nat hCard)⟩

/-- The upper half of the two-parameter asymptotic is unconditional. The
constant depends only on r, and the height is arbitrary. -/
theorem eventually_boundedPacking_uniform_upper {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ K : ℕ in atTop, ∀ N : ℕ, 1 ≤ N →
      (boundedPackingNumber r K N : ℝ) * (r : ℝ) ≤
        Real.log (min (N : ℝ) ((K : ℝ) * Real.log (K : ℝ))) + C := by
  let s := (r : ℝ)
  have hs : 0 < s := by dsimp only [s]; exact_mod_cast hr
  let D := |Real.log (s / 2)|
  let G := 2 / s * (1 + D)
  let C := 1 + |Real.log G|
  have hD : 0 ≤ D := abs_nonneg _
  have hG : 0 < G := by dsimp only [G]; positivity
  refine ⟨C, by dsimp only [C]; positivity, ?_⟩
  have hNat : Tendsto (fun K : ℕ => (K : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  filter_upwards [hLog.eventually_ge_atTop 1,eventually_ge_atTop (1 : ℕ)] with K hLog hK
  intro N hN
  let m := boundedPackingNumber r K N
  let V := Real.log (K : ℝ)
  let Z := (K : ℝ) * V
  have hV : 1 ≤ V := hLog
  have hV₀ : 0 < V := zero_lt_one.trans_le hV
  have hK₁ : (1 : ℝ) ≤ (K : ℝ) := by exact_mod_cast hK
  have hK₀ : (0 : ℝ) < (K : ℝ) := zero_lt_one.trans_le hK₁
  have hN₁ : (1 : ℝ) ≤ (N : ℝ) := by exact_mod_cast hN
  have hZ₁ : 1 ≤ Z := one_le_mul_of_one_le_of_one_le hK₁ hV
  have hc : (1 : ℝ) ≤ C := le_add_of_nonneg_right (abs_nonneg _)
  change (m : ℝ) * s ≤ Real.log (min (N : ℝ) Z) + C
  by_cases hm : m = 0
  · rw [hm,Nat.cast_zero,zero_mul]
    exact add_nonneg (Real.log_nonneg (le_min hN₁ hZ₁)) (zero_le_one.trans hc)
  have hm₀ : (0 : ℝ) < (m : ℝ) := Nat.cast_pos.mpr (Nat.pos_of_ne_zero hm)
  have hMasses := boundedPackingNumber_mass_bounds r K N
  have hStock : (m : ℝ) * s ≤ (harmonic N : ℝ) := by
    change (m : ℝ) * (r : ℝ) ≤ (harmonic N : ℝ)
    exact_mod_cast hMasses.1
  have hLength : (m : ℝ) * s ≤ (harmonic (m * K) : ℝ) := by
    change (m : ℝ) * (r : ℝ) ≤ (harmonic (m * K) : ℝ)
    exact_mod_cast hMasses.2
  have hMain : (m : ℝ) * s ≤ 1 + Real.log (m : ℝ) + V := by
    have hH := hLength.trans (harmonic_le_one_add_log (m * K))
    rw [Nat.cast_mul, Real.log_mul hm₀.ne' hK₀.ne'] at hH
    change _ ≤ 1 + Real.log (m : ℝ) + V
    linarith only [hH]
  have hAff := Real.log_le_sub_one_of_pos (mul_pos hm₀ (half_pos hs))
  rw [Real.log_mul hm₀.ne' (half_pos hs).ne'] at hAff
  have hMsmall : (m : ℝ) ≤ G * V := by
    have hHalf : (m : ℝ) * s / 2 ≤ V + D := by
      dsimp only [D]
      linarith only [hMain,hAff, neg_abs_le (Real.log (s / 2))]
    have hVD : V + D ≤ (1 + D) * V := by
      nlinarith only [mul_le_mul_of_nonneg_left hV hD]
    have hDen := (div_le_div_of_nonneg_right (hHalf.trans hVD) (half_pos hs).le)
    dsimp only [G]
    convert hDen using 1
    · field_simp [hs.ne']
    · ring
  have hLogM : Real.log (m : ℝ) ≤ Real.log G + Real.log V := by
    simpa only [Real.log_mul hG.ne' hV₀.ne'] using Real.log_le_log hm₀ hMsmall
  have hHZ : (m : ℝ) * s ≤ Real.log Z + C := by
    rw [show Real.log Z = V + Real.log V by exact Real.log_mul hK₀.ne' hV₀.ne']
    dsimp only [C]
    linarith only [hMain,hLogM,le_abs_self (Real.log G)]
  rcases le_total (N : ℝ) Z with hNZ | hZN
  · rw [min_eq_left hNZ]
    linarith only [hStock,hc,harmonic_le_one_add_log N]
  · rw [min_eq_right hZN]
    exact hHZ


private theorem div_log_mono {x y : ℝ} (hx : 0 < x) (hlog : 1 ≤ Real.log x)
    (hxy : x ≤ y) : x / Real.log x ≤ y / Real.log y := by
  have hy := hx.trans_le hxy
  have hL := zero_lt_one.trans_le hlog
  have hY := hL.trans_le (Real.log_le_log hx hxy)
  have hR := Real.log_le_sub_one_of_pos (div_pos hy hx)
  rw [Real.log_div hy.ne' hx.ne'] at hR
  have hMul : (y / x - 1) ≤ (y / x - 1) * Real.log x := by
    apply le_mul_of_one_le_right _ hlog
    exact sub_nonneg.mpr ((le_div_iff₀ hx).mpr (by simpa using hxy))
  have hBound : Real.log y ≤ (y / x) * Real.log x := by linarith only [hR,hMul]
  apply (div_le_div_iff₀ hL hY).mpr
  have hProd := mul_le_mul_of_nonneg_left hBound hx.le
  rw [show x * (y / x * Real.log x) = y * Real.log x by field_simp [hx.ne']] at hProd
  exact hProd

private theorem eventually_bounded_mass_floor_above_log (r : ℚ) (hr : 0 < r) {C : ℝ} (hC : 0 ≤ C) :
    ∀ᶠ X : ℕ in atTop,
      let H := (mass (interval 1 (targetCutoff r - 1)) : ℝ)
      Real.log (X : ℝ) - H - 1 - (r : ℝ) ≤
        ((⌊((targetStock r X : ℝ) - sufficientLoss X C) / (r : ℝ)⌋ : ℤ) : ℝ) * (r : ℝ) := by
  filter_upwards [eventually_ge_atTop (targetCutoff r - 1),
    eventually_losses_between_zero_one 0 C le_rfl hC] with X hX hLoss
  let s := (r : ℝ)
  have hs : 0 < s := by dsimp only [s]; exact_mod_cast hr
  let H := (mass (interval 1 (targetCutoff r - 1)) : ℝ)
  have hStock : (targetStock r X : ℝ) = (harmonic X : ℝ) - H := by
    rw [targetStock_eq_harmonic_sub r hX, Rat.cast_sub, mass_interval_one_eq_harmonic]
  have hH : Real.log (X : ℝ) ≤ (harmonic X : ℝ) := by
    simpa only [Nat.floor_natCast] using log_le_harmonic_floor (X : ℝ) (by positivity)
  let v := ((targetStock r X : ℝ) - sufficientLoss X C) / s
  have hd := (Int.lt_floor_add_one v)
  have hMul := mul_lt_mul_of_pos_right hd hs
  change Real.log (X : ℝ) - H - 1 - s ≤ (⌊v⌋ : ℝ) * s
  dsimp only [v] at *
  rw [div_mul_cancel₀ _ hs.ne', add_mul, one_mul] at hMul
  linarith only [hMul,hH,hStock,hLoss.2.2]

theorem boundedPackingNumber_height_mono (r : ℚ) (K : ℕ) :
    Monotone (fun N => boundedPackingNumber r K N) := by
  intro X N hXN
  apply matchingNumber_mono
  intro S hS
  obtain ⟨hSub,hMass,hLen⟩ := mem_boundedEdges.mp hS
  exact mem_boundedEdges.mpr ⟨fun a ha =>
    mem_Icc.mpr ⟨(mem_Icc.mp (hSub ha)).1, (mem_Icc.mp (hSub ha)).2.trans hXN⟩,hMass,hLen⟩

/-- Both sides of the two-parameter asymptotic in F2, uniformly for all
large length bounds and heights. -/
theorem eventually_boundedPacking_uniform_of_sufficiency (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∃ N₀ : ℕ, 1 ≤ N₀ ∧
      ∀ᶠ K : ℕ in atTop, ∀ N : ℕ, N₀ ≤ N →
        |(boundedPackingNumber r K N : ℝ) * (r : ℝ) -
          Real.log (min (N : ℝ) ((K : ℝ) * Real.log (K : ℝ)))| ≤ C := by
  obtain ⟨C,hC,hUp⟩ := eventually_boundedPacking_uniform_upper hr
  obtain ⟨A,D,hA,hD,hLower⟩ := eventually_boundedPacking_lower_with_length_of_sufficiency hSuff hr
  let s := (r : ℝ)
  have hs : 0 < s := by dsimp only [s]; exact_mod_cast hr
  let c := 1 / (s + 1)
  have hc : 0 < c := by dsimp only [c]; positivity
  have hc₁ : c ≤ 1 := by
    apply (div_le_iff₀ (by positivity : 0 < s + 1)).mpr
    linarith only [hs]
  let H := (mass (interval 1 (targetCutoff r - 1)) : ℝ)
  have hH : 0 ≤ H := by dsimp only [H]; exact_mod_cast (mass_nonneg (interval 1 (targetCutoff r - 1)))
  let E := C + H + 1 + s + |Real.log (c / 2)|
  have hNat : Tendsto (fun K : ℕ => (K : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  have hNall : ∀ᶠ X : ℕ in atTop,
      (∀ K : ℕ, s * (X : ℝ) / Real.log X + D * (X : ℝ) / (Real.log X) ^ 2 ≤ K →
        ⌊((targetStock r X : ℝ) - sufficientLoss X A) / s⌋ ≤ (boundedPackingNumber r K X : ℤ)) ∧
      0 < X ∧ max 1 D ≤ Real.log (X : ℝ) ∧
      Real.log (X : ℝ) - H - 1 - s ≤
        ((⌊((targetStock r X : ℝ) - sufficientLoss X A) / s⌋ : ℤ) : ℝ) * s := by
    filter_upwards [hLower, eventually_bounded_mass_floor_above_log r hr hA.le,
      hLog.eventually_ge_atTop (max 1 D), eventually_ge_atTop (1 : ℕ)] with X hA hB hC hD
    exact ⟨hA,Nat.succ_le_iff.mp hD,hC,hB⟩
  obtain ⟨T₀,hT₀⟩ := eventually_atTop.mp hNall
  let T := max T₀ 1
  have hT₁ : 1 ≤ T := le_max_right _ _
  have hT₀' : T₀ ≤ T := le_max_left _ _
  refine ⟨E, by dsimp only [E]; positivity, T, hT₁, ?_⟩
  filter_upwards [hUp,hLog.eventually_ge_atTop (2 / c),eventually_ge_atTop T] with K hKU hKV hKT
  intro N hNT
  let V := Real.log (K : ℝ)
  let Z := (K : ℝ) * V
  let Y : ℕ := ⌊c * Z⌋₊
  let X := min N Y
  have hK₀ : 0 < K := Nat.succ_le_iff.mp (hT₁.trans hKT)
  have hKr : (0 : ℝ) < K := Nat.cast_pos.mpr hK₀
  have hVr : 0 < V := (div_pos (by norm_num) hc).trans_le hKV
  have hVscale : 2 ≤ c * V := by
    change 2 / c ≤ V at hKV
    simpa only [mul_comm] using (div_le_iff₀ hc).mp hKV
  have hZr : 0 < Z := mul_pos hKr hVr
  have hKreal : (K : ℝ) ≤ c * Z := calc
    _ ≤ 2 * (K : ℝ) := by linarith only [hKr.le]
    _ ≤ (c * V) * (K : ℝ) := mul_le_mul_of_nonneg_right hVscale hKr.le
    _ = _ := by dsimp [Z]; ring
  have hYK : K ≤ Y := Nat.le_floor hKreal
  have hXT : T ≤ X := le_min hNT (hKT.trans hYK)
  obtain ⟨hXPack, hX₀, hXLog, hXMass⟩ := hT₀ X (hT₀'.trans hXT)
  have hLogX : 1 ≤ Real.log (X : ℝ) := (le_max_left 1 D).trans hXLog
  have hLogXD : D ≤ Real.log (X : ℝ) := (le_max_right 1 D).trans hXLog
  have hLogX₀ := zero_lt_one.trans_le hLogX
  have hXr : (0 : ℝ) < X := Nat.cast_pos.mpr hX₀
  have hYr : (0 : ℝ) < Y := Nat.cast_pos.mpr (hK₀.trans_le hYK)
  have hYup : (Y : ℝ) ≤ c * Z := Nat.floor_le (mul_nonneg hc.le hZr.le)
  have hLogY : V ≤ Real.log (Y : ℝ) :=
    Real.log_le_log hKr (by exact_mod_cast hYK)
  have hRatio₁ : (X : ℝ) / Real.log (X : ℝ) ≤ (Y : ℝ) / Real.log (Y : ℝ) :=
    div_log_mono hXr hLogX (by exact_mod_cast (min_le_right N Y))
  have hRatio₂ : (Y : ℝ) / Real.log (Y : ℝ) ≤ c * (K : ℝ) := calc
    _ ≤ (c * Z) / V := div_le_div₀ (by positivity) hYup hVr hLogY
    _ = _ := by dsimp only [Z]; field_simp [hVr.ne']
  have hBudget : s * (X : ℝ) / Real.log (X : ℝ) + D * (X : ℝ) / Real.log (X : ℝ) ^ 2 ≤ K := calc
    _ = (s + D / Real.log (X : ℝ)) * ((X : ℝ) / Real.log (X : ℝ)) := by ring
    _ ≤ (s + 1) * ((X : ℝ) / Real.log (X : ℝ)) :=
      mul_le_mul_of_nonneg_right (add_le_add le_rfl ((div_le_one₀ hLogX₀).mpr hLogXD)) (by positivity)
    _ ≤ (s + 1) * (c * (K : ℝ)) :=
      mul_le_mul_of_nonneg_left (hRatio₁.trans hRatio₂) (by positivity)
    _ = _ := by dsimp only [c]; field_simp
  have hBoundZ := hXPack K hBudget
  have hBound : (⌊((targetStock r X : ℝ) - sufficientLoss X A) / s⌋ : ℝ) ≤
      (boundedPackingNumber r K X : ℝ) := by
    simpa only [Int.cast_natCast] using (Int.cast_le.mpr hBoundZ : (_ : ℝ) ≤ _)
  have hMassLow : Real.log (X : ℝ) - H - 1 - s ≤ (boundedPackingNumber r K N : ℝ) * s := calc
    _ ≤ (boundedPackingNumber r K X : ℝ) * s :=
      hXMass.trans (mul_le_mul_of_nonneg_right hBound hs.le)
    _ ≤ _ := mul_le_mul_of_nonneg_right
      (by exact_mod_cast boundedPackingNumber_height_mono r K (min_le_left N Y)) hs.le
  have hHalfY : (c / 2) * Z ≤ (Y : ℝ) := by
    have hFloor := Nat.lt_floor_add_one (c * Z)
    change c * Z < (Y : ℝ) + 1 at hFloor
    have hTwo : 2 ≤ c * Z := by
      have hOne : (1 : ℝ) ≤ (K : ℝ) := by exact_mod_cast (Nat.succ_le_iff.mpr hK₀ : 1 ≤ K)
      calc
        _ ≤ 2 * (K : ℝ) := by linarith only [hOne]
        _ ≤ (c * V) * (K : ℝ) := mul_le_mul_of_nonneg_right hVscale hKr.le
        _ = _ := by dsimp [Z]; ring
    nlinarith only [hFloor,hTwo]
  let W := min (N : ℝ) Z
  have hNr : 0 < (N : ℝ) := hXr.trans_le (by exact_mod_cast (min_le_left N Y))
  have hW : 0 < W := lt_min hNr hZr
  have hComparison : Real.log W + Real.log (c / 2) ≤ Real.log (X : ℝ) := by
    have hc₀ : 0 < c / 2 := by positivity
    rw [← Real.log_mul hW.ne' hc₀.ne']
    apply Real.log_le_log (mul_pos hW hc₀)
    change W * (c / 2) ≤ (↑(min N Y) : ℝ)
    rw [Nat.cast_min]
    apply le_min
    · exact (mul_le_of_le_one_right hW.le (by linarith only [hc₁])).trans (min_le_left _ _)
    · rw [mul_comm]
      exact (mul_le_mul_of_nonneg_left (min_le_right _ _) hc₀.le).trans hHalfY
  have hHigh := hKU N (hT₁.trans hNT)
  change |(boundedPackingNumber r K N : ℝ) * s - Real.log W| ≤ E
  dsimp only [E]
  exact abs_le.mpr ⟨by linarith only [hMassLow,hComparison,hC,neg_abs_le (Real.log (c / 2))],
    by linarith only [hHigh,hH,hs,abs_nonneg (Real.log (c / 2))]⟩


theorem boundedPackingNumber_length_mono (r : ℚ) (N : ℕ) :
    Monotone (fun K => boundedPackingNumber r K N) := by
  intro K₁ K₂ hK
  apply matchingNumber_mono
  intro S hS
  obtain ⟨hSub,hMass,hLen⟩ := mem_boundedEdges.mp hS
  exact mem_boundedEdges.mpr ⟨hSub,hMass,hLen.trans hK⟩

/-- The matching number without a height cap is the supremum of
the finite height matching numbers. -/
noncomputable def lengthPackingNumber (r : ℚ) (K : ℕ) : ℕ :=
  sSup (Set.range (boundedPackingNumber r K))

private theorem boundedPackingNumber_bddAbove {r : ℚ} (hr : 0 < r) (K : ℕ) :
    BddAbove (Set.range (boundedPackingNumber r K)) := by
  obtain ⟨C,hC,hUp⟩ := eventually_boundedPacking_uniform_upper hr
  obtain ⟨K₀,hK₀⟩ := eventually_atTop.mp hUp
  let K' := max K (max 2 K₀)
  let s := (r : ℝ)
  let Z := (K' : ℝ) * Real.log (K' : ℝ)
  let B := Real.log Z + C
  have hs : 0 < s := by dsimp only [s]; exact_mod_cast hr
  have hKK : K ≤ K' := le_max_left _ _
  have hK₀' : K₀ ≤ K' := (le_max_right _ _).trans (le_max_right _ _)
  have hK₂ : 2 ≤ K' := (le_max_left _ _).trans (le_max_right _ _)
  have hKreal : (1 : ℝ) < (K' : ℝ) := by exact_mod_cast (show 1 < K' by omega)
  have hZ : 0 < Z := mul_pos (zero_lt_one.trans hKreal) (Real.log_pos hKreal)
  refine ⟨⌈B / s⌉₊, ?_⟩
  rintro m ⟨N,rfl⟩
  let N' := max N 1
  have hN₁ : 1 ≤ N' := le_max_right _ _
  have hNr : 0 < (N' : ℝ) := Nat.cast_pos.mpr (Nat.succ_le_iff.mp hN₁)
  have hNear := hK₀ K' hK₀' N' hN₁
  have hlog : Real.log (min (N' : ℝ) Z) ≤ Real.log Z :=
    Real.log_le_log (lt_min hNr hZ) (min_le_right _ _)
  have hUpper : (boundedPackingNumber r K' N' : ℝ) * s ≤ B := by
    dsimp only [B]
    exact hNear.trans (add_le_add hlog le_rfl)
  have hOrd : boundedPackingNumber r K N ≤ boundedPackingNumber r K' N' :=
    (boundedPackingNumber_length_mono r N hKK).trans
      (boundedPackingNumber_height_mono r K' (le_max_left _ _))
  have hUpReal : (boundedPackingNumber r K N : ℝ) ≤ B / s := by
    apply (le_div_iff₀ hs).mpr
    exact (mul_le_mul_of_nonneg_right (by exact_mod_cast hOrd) hs.le).trans hUpper
  have hFinal := hUpReal.trans (Nat.le_ceil (B / s))
  exact_mod_cast hFinal

theorem boundedPackingNumber_le_lengthPackingNumber {r : ℚ} (hr : 0 < r) (K N : ℕ) :
    boundedPackingNumber r K N ≤ lengthPackingNumber r K :=
  le_csSup (boundedPackingNumber_bddAbove hr K) (Set.mem_range_self N)

/-- The supremum is a genuine maximum attained at some finite height. -/
theorem lengthPackingNumber_attains {r : ℚ} (hr : 0 < r) (K : ℕ) :
    ∃ N : ℕ, boundedPackingNumber r K N = lengthPackingNumber r K :=
  Nat.sSup_mem (Set.range_nonempty _) (boundedPackingNumber_bddAbove hr K)

/-- The unrestricted-height length asymptotic from F2. -/
theorem eventually_lengthPackingNumber_of_sufficiency (hSuff : PackingSufficiency)
    {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ K : ℕ in atTop,
      |(lengthPackingNumber r K : ℝ) * (r : ℝ) -
        (Real.log (K : ℝ) + Real.log (Real.log (K : ℝ)))| ≤ C := by
  obtain ⟨C,hC,T,hT,hUniform⟩ := eventually_boundedPacking_uniform_of_sufficiency hSuff hr
  refine ⟨C,hC,?_⟩
  have hNat : Tendsto (fun K : ℕ => (K : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hNat
  filter_upwards [hUniform, hLog.eventually_ge_atTop 1, eventually_ge_atTop (1 : ℕ)] with K hK hLog hK₁
  let V := Real.log (K : ℝ)
  let Z := (K : ℝ) * V
  obtain ⟨M,hM⟩ := lengthPackingNumber_attains hr K
  let N := max M (max T ⌈Z⌉₊)
  have hN₀ : T ≤ N := (le_max_left _ _).trans (le_max_right _ _)
  have hNZ : Z ≤ (N : ℝ) :=
    (Nat.le_ceil Z).trans (by exact_mod_cast (le_max_right T ⌈Z⌉₊).trans (le_max_right M (max T ⌈Z⌉₊)))
  have hFin := hK N hN₀
  change |(boundedPackingNumber r K N : ℝ) * (r : ℝ) - Real.log (min (N : ℝ) Z)| ≤ C at hFin
  have hEq : boundedPackingNumber r K N = lengthPackingNumber r K := le_antisymm
    (boundedPackingNumber_le_lengthPackingNumber hr K N)
    (hM ▸ boundedPackingNumber_height_mono r K (le_max_left M (max T ⌈Z⌉₊)))
  have hLogEq : Real.log Z = Real.log (K : ℝ) + Real.log V :=
    Real.log_mul (Nat.cast_pos.mpr (Nat.succ_le_iff.mp hK₁)).ne'
      (zero_lt_one.trans_le hLog).ne'
  rw [hEq,min_eq_right hNZ,hLogEq] at hFin
  exact hFin

end LeanAB.PaperB.FixedTargets

