module

public import PaperB.PointwiseCover
public import PaperB.BaselineCutoff
public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
meta import Mathlib.Tactic

/-! Reduction of the uniform height estimate for a/p to the short modular cover
in F2. The Liu–Sawhney height estimate is an explicit theorem parameter. -/

@[expose] public section

open Finset Filter
open scoped Topology

namespace LeanAB.PaperB.ShortPointwise

open Closure

/-- Reduction of the mass of positive denominators prime to the modulus. -/
theorem mass_cast_of_cofactors {p : ℕ} [Fact p.Prime] (S : Finset ℕ)
    (hS : ∀ b ∈ S, 0 < b ∧ ¬ p ∣ b) :
    ((mass S).den : ZMod p) ≠ 0 ∧
      (mass S : ZMod p) = ∑ b ∈ S, (b : ZMod p)⁻¹ := by
  classical
  induction S using Finset.induction_on with
  | empty => simp [mass]
  | @insert b S hb ih =>
      have hb₀ := (hS b (mem_insert_self _ _)).1
      have hbMod : (b : ZMod p) ≠ 0 := fun h =>
        (hS b (mem_insert_self _ _)).2 ((ZMod.natCast_eq_zero_iff _ _).mp h)
      have hbDen : ((b : ℚ)⁻¹).den = b := by
        rw [Rat.den_inv_of_ne_zero (by exact_mod_cast hb₀.ne'), Rat.num_natCast,
          Int.natAbs_natCast]
      have hbInv : (((b : ℚ)⁻¹ : ℚ) : ZMod p) = (b : ZMod p)⁻¹ := by
        rw [Rat.cast_inv_of_ne_zero]
        · simp
        · simpa only [Rat.num_natCast, Int.cast_natCast] using hbMod
      obtain ⟨hD, hZ⟩ := ih (fun a ha => hS a (mem_insert_of_mem ha))
      have hbDenMod : (((b : ℚ)⁻¹).den : ZMod p) ≠ 0 := by simpa only [hbDen]
      rw [show mass (insert b S) = (b : ℚ)⁻¹ + mass S from sum_insert hb,
        sum_insert hb]
      refine ⟨?_, ?_⟩
      · intro h
        have hd := ((ZMod.natCast_eq_zero_iff _ p).mp h).trans
          (Rat.add_den_dvd ((b : ℚ)⁻¹) (mass S))
        have hProd := (ZMod.natCast_eq_zero_iff _ p).mpr hd
        rw [Nat.cast_mul] at hProd
        exact mul_ne_zero hbDenMod hD hProd
      · rw [Rat.cast_add_of_ne_zero hbDenMod hD, hbInv, hZ]

/-- Finite reduction: all residues represented at height at most pQ give a
reciprocal cover in [1,Q], provided Q < p. -/
theorem covers_of_prime_heights {p Q : ℕ} (hp : p.Prime) (hQ : Q < p)
    (hRep : ∀ a : ℕ, 0 < a → a < p →
      ∃ S ⊆ interval 1 (p * Q), mass S = (a : ℚ) / p) :
    CoversResidues p (interval 1 Q) := by
  classical
  let _ : Fact p.Prime := ⟨hp⟩
  intro u
  let a := u.val
  have haLT : a < p := ZMod.val_lt u
  have haCast : (a : ZMod p) = u := ZMod.natCast_zmod_val u
  by_cases ha : a = 0
  · refine ⟨∅, empty_subset _, ?_⟩
    simpa [ha] using haCast
  obtain ⟨S, hS, hEq⟩ := hRep a (Nat.pos_of_ne_zero ha) haLT
  let V := S.filter (p ∣ ·)
  let W := S \ V
  let J := V.image (· / p)
  have hV (n : ℕ) (hn : n ∈ V) : p ∣ n := (mem_filter.mp hn).2
  have hJ (b : ℕ) (hb : b ∈ J) : b ∈ interval 1 Q := by
    obtain ⟨n, hn, rfl⟩ := mem_image.mp hb
    obtain ⟨hn₀, hnN⟩ := mem_Icc.mp (hS (mem_filter.mp hn).1)
    exact mem_Icc.mpr ⟨Nat.div_pos (Nat.le_of_dvd hn₀ (hV n hn)) hp.pos,
      (Nat.div_le_div_right hnN).trans (by simp [Nat.mul_div_cancel_left _ hp.pos])⟩
  refine ⟨J, hJ, ?_⟩
  have hMarked : mark p J = V := by
    ext n
    simp only [mark, J, image_image, mem_image, Function.comp_apply]
    refine ⟨?_, ?_⟩
    · rintro ⟨m, hm, rfl⟩
      rwa [mul_comm, Nat.div_mul_cancel (hV m hm)]
    · intro hn
      exact ⟨n, hn, by rw [mul_comm, Nat.div_mul_cancel (hV n hn)]⟩
  have hVMass : mass V = mass J / (p : ℚ) := by
    rw [← hMarked, mass_mark p hp.pos]
  have hMass : mass W + mass V = mass S := sum_sdiff (filter_subset _ _)
  have hpq : (p : ℚ) ≠ 0 := by exact_mod_cast hp.ne_zero
  have hEqQ : mass J + (p : ℚ) * mass W = (a : ℚ) := by
    rw [hVMass, hEq] at hMass
    calc
      _ = (mass W + mass J / (p : ℚ)) * (p : ℚ) := by
        rw [add_mul, div_mul_cancel₀ _ hpq]
        ring
      _ = _ := by rw [hMass, div_mul_cancel₀ _ hpq]
  obtain ⟨hJDen,hJCast⟩ := mass_cast_of_cofactors (p := p) J (fun b hb => by
    obtain ⟨hb₀,hbQ⟩ := mem_Icc.mp (hJ b hb)
    exact ⟨hb₀, fun h => (hbQ.trans_lt hQ).not_ge (Nat.le_of_dvd hb₀ h)⟩)
  obtain ⟨hWDen,_⟩ := mass_cast_of_cofactors (p := p) W (fun b hb => by
    obtain ⟨hbS,hbBad⟩ := mem_sdiff.mp hb
    exact ⟨(mem_Icc.mp (hS hbS)).1, fun h => hbBad (mem_filter.mpr ⟨hbS,h⟩)⟩)
  have hpDen : ((p : ℚ).den : ZMod p) ≠ 0 := by simp
  have hProdDen : ((((p : ℚ) * mass W).den : ℕ) : ZMod p) ≠ 0 := by
    intro h
    have hd := ((ZMod.natCast_eq_zero_iff _ p).mp h).trans (Rat.mul_den_dvd (p : ℚ) (mass W))
    have hm := (ZMod.natCast_eq_zero_iff _ p).mpr hd
    rw [Nat.cast_mul] at hm
    exact (mul_ne_zero hpDen hWDen) hm
  have hReduced := congrArg (fun x : ℚ => (x : ZMod p)) hEqQ
  change ((mass J + (p : ℚ) * mass W : ℚ) : ZMod p) = ((a : ℚ) : ZMod p) at hReduced
  rw [Rat.cast_add_of_ne_zero hJDen hProdDen, Rat.cast_mul_of_ne_zero hpDen hWDen,
    hJCast, Rat.cast_natCast, Rat.cast_natCast, ZMod.natCast_self, zero_mul, add_zero,
    haCast] at hReduced
  exact hReduced

open Filter

/-- The width of the baseline modular cover in the manuscript. -/
noncomputable def coverWidth (p : ℕ) : ℕ :=
  ⌈Real.log (p : ℝ) * Real.log (Real.log (p : ℝ)) ^ (4 : ℕ)⌉₊

/-- The prime-denominator specialization of the uniform height estimate in
Liu–Sawhney, Theorem 1.5 (arXiv:2404.07113v1). The constants precede both the
prime and the numerator. The fixed exponent can be taken natural after enlarging
it on the eventual range where the innermost logarithm exceeds one. -/
def LiuSawhneyPrimeHeight : Prop :=
  ∃ C : ℝ, 0 < C ∧ ∃ K : ℕ, ∀ᶠ p : ℕ in atTop, p.Prime →
    ∀ a : ℕ, 0 < a → a < p → ∃ S : Finset ℕ, S.Nonempty ∧
      (∀ n ∈ S, 2 ≤ n ∧ (n : ℝ) ≤ C * (p : ℝ) * Real.log (p : ℝ) *
        Real.log (Real.log (p : ℝ)) ^ (3 : ℕ) *
        Real.log (Real.log (Real.log (p : ℝ))) ^ K) ∧
      mass S = (a : ℚ) / p

/-- The third iterated logarithm contributes less than one more power of the
second iterated logarithm, with any fixed multiplier and exponent. -/
theorem eventually_logloglog_pow_le_loglog {C : ℝ} (hC : 0 < C) (K : ℕ) :
    ∀ᶠ p : ℕ in atTop,
      C * Real.log (Real.log (Real.log (p : ℝ))) ^ K ≤ Real.log (Real.log (p : ℝ)) := by
  have hc : Tendsto (fun p : ℕ => (p : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hloglog := Real.tendsto_log_atTop.comp (Real.tendsto_log_atTop.comp hc)
  have hb := (isLittleO_log_rpow_rpow_atTop (s := (1 : ℝ)) (K : ℝ) (by norm_num)).bound
    (one_div_pos.mpr hC)
  filter_upwards [hloglog.eventually hb, hloglog.eventually_ge_atTop 1] with p hp hU
  let U := Real.log (Real.log (p : ℝ))
  have hU₁ : 1 ≤ U := hU
  have hU₀ : 0 ≤ U := (zero_le_one : (0 : ℝ) ≤ 1).trans hU₁
  have hUpow : 0 ≤ Real.log U ^ K := pow_nonneg (Real.log_nonneg hU₁) _
  change ‖Real.log U ^ (K : ℝ)‖ ≤ (1 / C) * ‖U ^ (1 : ℝ)‖ at hp
  have h := show Real.log U ^ K ≤ (1 / C) * U from by
    simpa only [Real.rpow_natCast, Real.rpow_one, Real.norm_eq_abs, abs_of_nonneg hUpow,
      abs_of_nonneg hU₀] using hp
  have hm := mul_le_mul_of_nonneg_left h hC.le
  change C * Real.log U ^ K ≤ U
  calc
    _ ≤ C * ((1 / C) * U) := hm
    _ = U := by field_simp [hC.ne']

/-- The ceiling in the logarithmic baseline width is strictly below the prime
height once that height is sufficiently large. This is independent of the
height-estimate premise. -/
theorem eventually_coverWidth_lt :
    ∀ᶠ p : ℕ in atTop, coverWidth p < p := by
  have hc : Tendsto (fun p : ℕ => (p : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hb := (isLittleO_log_rpow_rpow_atTop (s := (1 : ℝ)) 5 (by norm_num)).bound
    (show (0 : ℝ) < 1 / 2 by norm_num)
  filter_upwards [(Real.tendsto_log_atTop.comp hc).eventually_ge_atTop 1, hc.eventually hb,
    eventually_ge_atTop (3 : ℕ)] with p hL hB hp
  let L := Real.log (p : ℝ)
  have hL₁ : 1 ≤ L := hL
  have hL₀ : 0 ≤ L := zero_le_one.trans hL₁
  have hpR : (3 : ℝ) ≤ p := by exact_mod_cast hp
  have hlogL : 0 ≤ Real.log L := Real.log_nonneg hL₁
  have hlogLle : Real.log L ≤ L := (Real.log_le_sub_one_of_pos (zero_lt_one.trans_le hL₁)).trans
    (sub_le_self _ zero_le_one)
  have hW : L * Real.log L ^ (4 : ℕ) ≤ L ^ (5 : ℕ) := calc
    _ ≤ L * L ^ (4 : ℕ) :=
      mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hlogL hlogLle _) hL₀
    _ = _ := by ring
  change ‖L ^ (5 : ℝ)‖ ≤ (1 / 2 : ℝ) * ‖(p : ℝ) ^ (1 : ℝ)‖ at hB
  have hB' : L ^ (5 : ℕ) ≤ (1 / 2 : ℝ) * (p : ℝ) := by
    simpa only [show (5 : ℝ) = ((5 : ℕ) : ℝ) by norm_num, Real.rpow_natCast, Real.rpow_one,
      Real.norm_eq_abs, abs_of_nonneg (pow_nonneg hL₀ 5), abs_of_nonneg (show 0 ≤ (p : ℝ) from Nat.cast_nonneg p)]
      using hB
  have hceil := Nat.ceil_lt_add_one
    (mul_nonneg hL₀ (pow_nonneg hlogL (4 : ℕ)))
  exact_mod_cast (show (coverWidth p : ℝ) < (p : ℝ) from by
    change (⌈L * Real.log L ^ (4 : ℕ)⌉₊ : ℝ) < (p : ℝ)
    linarith only [hceil, hW, hB', hpR])

/-- F2's short all-residue cover follows from the one explicit uniform
Liu–Sawhney height premise. -/
theorem eventually_shortPointwiseCover_of_LiuSawhney (h : LiuSawhneyPrimeHeight) :
    ∀ᶠ p : ℕ in atTop, p.Prime → CoversResidues p (interval 1 (coverWidth p)) := by
  obtain ⟨C,hC,K,hRep⟩ := h
  have hc : Tendsto (fun p : ℕ => (p : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  filter_upwards [hRep, eventually_logloglog_pow_le_loglog hC K, eventually_coverWidth_lt,
    (Real.tendsto_log_atTop.comp hc).eventually_ge_atTop 1] with p hRepP hAbs hQ hL hp
  apply covers_of_prime_heights hp hQ
  intro a ha hap
  obtain ⟨S,_,hS,hMass⟩ := hRepP hp a ha hap
  refine ⟨S, ?_, hMass⟩
  intro n hn
  obtain ⟨hn₀, hnUpper⟩ := hS n hn
  let L := Real.log (p : ℝ)
  let U := Real.log L
  have hL₁ : 1 ≤ L := hL
  have hL₀ : 0 ≤ L := zero_le_one.trans hL₁
  have hU₀ : 0 ≤ U := Real.log_nonneg hL₁
  have hUpper : (n : ℝ) ≤ (p : ℝ) * (coverWidth p : ℝ) := calc
    _ ≤ C * (p : ℝ) * L * U ^ (3 : ℕ) * Real.log U ^ K := hnUpper
    _ = ((p : ℝ) * L * U ^ (3 : ℕ)) * (C * Real.log U ^ K) := by ring
    _ ≤ ((p : ℝ) * L * U ^ (3 : ℕ)) * U :=
      mul_le_mul_of_nonneg_left hAbs (by positivity)
    _ = (p : ℝ) * (L * U ^ (4 : ℕ)) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left (Nat.le_ceil _) (Nat.cast_nonneg p)
  exact mem_Icc.mpr ⟨by omega, by exact_mod_cast hUpper⟩

/-- A single width at height N can be used for every sufficiently large p≤N. -/
theorem coverWidth_mono {p N : ℕ} (hp : 0 < p) (hL : 1 ≤ Real.log (p : ℝ)) (hpN : p ≤ N) :
    coverWidth p ≤ coverWidth N := by
  have hlogp : 0 < Real.log (p : ℝ) := zero_lt_one.trans_le hL
  have hlogN : Real.log (p : ℝ) ≤ Real.log (N : ℝ) :=
    Real.log_le_log (Nat.cast_pos.mpr hp) (by exact_mod_cast hpN)
  have hU : 0 ≤ Real.log (Real.log (p : ℝ)) := Real.log_nonneg hL
  have hUN : Real.log (Real.log (p : ℝ)) ≤ Real.log (Real.log (N : ℝ)) :=
    Real.log_le_log hlogp hlogN
  exact Nat.ceil_mono (mul_le_mul hlogN (pow_le_pow_left₀ hU hUN 4) (pow_nonneg hU _) (hlogp.le.trans hlogN))

/-- Taking the ceiling changes the logarithm of the manuscript width by at
most log 2 once the unrounded width exceeds one. -/
theorem eventually_log_coverWidth_bounds :
    ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      let U := Real.log L
      U + 4 * Real.log U ≤ Real.log (coverWidth N : ℝ) ∧
        Real.log (coverWidth N : ℝ) ≤ U + 4 * Real.log U + Real.log 2 := by
  have hc : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hL := Real.tendsto_log_atTop.comp hc
  have hU := Real.tendsto_log_atTop.comp hL
  filter_upwards [hL.eventually_ge_atTop 1, hU.eventually_ge_atTop 1] with N hL₁ hU₁
  dsimp only
  let L := Real.log (N : ℝ)
  let U := Real.log L
  have hL' : 1 ≤ L := hL₁
  have hU' : 1 ≤ U := hU₁
  have hPosL := zero_lt_one.trans_le hL'
  have hPosU := zero_lt_one.trans_le hU'
  let q := L * U ^ (4 : ℕ)
  have hq : 1 ≤ q := one_le_mul_of_one_le_of_one_le hL' (one_le_pow₀ hU')
  have hqPos := zero_lt_one.trans_le hq
  have hqLe : q ≤ (coverWidth N : ℝ) := Nat.le_ceil _
  have hqLe2 : (coverWidth N : ℝ) ≤ 2 * q := by
    have h := Nat.ceil_lt_add_one hqPos.le
    change (⌈q⌉₊ : ℝ) ≤ 2 * q
    linarith only [h, hq]
  have hEq : Real.log q = U + 4 * Real.log U := by
    change Real.log (L * U ^ (4 : ℕ)) = _
    rw [Real.log_mul hPosL.ne' (pow_ne_zero _ hPosU.ne'), Real.log_pow]
    norm_num [U]
  have hLower := Real.log_le_log hqPos hqLe
  have hUpper := Real.log_le_log (hqPos.trans_le hqLe) hqLe2
  rw [Real.log_mul (by norm_num : (2 : ℝ) ≠ 0) hqPos.ne', hEq, add_comm (Real.log 2)] at hUpper
  exact ⟨hEq ▸ hLower,hUpper⟩

/-- A single cofactor bound works throughout the baseline prime window,
and the whole cofactor grid fits below N for each prime under its cutoff. -/
theorem eventually_baseline_common_cover_of_shortPointwise
    (h : ∀ᶠ p : ℕ in atTop, p.Prime → CoversResidues p (interval 1 (coverWidth p))) :
    ∀ᶠ N : ℕ in Filter.atTop, ∀ p ∈ largePrimes N,
      CoversResidues p (interval 1 (baselineCoverBound 4 N)) ∧
      baselineCoverBound 4 N < p ∧
      ((p : ℝ) ≤ baselineCutoff 4 N → p * baselineCoverBound 4 N ≤ N) := by
  obtain ⟨P, hCover⟩ := eventually_atTop.mp h
  obtain ⟨L, hLog⟩ := eventually_atTop.mp ((Real.tendsto_log_atTop.comp
    (tendsto_natCast_atTop_atTop : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop)).eventually_ge_atTop 1)
  let T := max P L
  filter_upwards [eventually_ge_atTop (T * T), eventually_ge_atTop (1 : ℕ),
    eventually_baselineCoverBound_logs 4,
    (tendsto_baselineCoverBound_div_sqrt 4).eventually_lt_const (by norm_num : (0 : ℝ) < 1)]
    with N hN hN₁ hQ hSize p hp
  obtain ⟨hPrime, hpN, hpSqrt⟩ := mem_largePrimes.mp hp
  have hSq := Nat.sqrt_lt.mp hpSqrt
  have hT : T ≤ p := by
    by_contra! ht
    exact hSq.not_ge ((Nat.mul_le_mul ht.le ht.le).trans hN)
  have hC := hCover p ((le_max_left P L).trans hT) hPrime
  have hWidth : coverWidth p ≤ baselineCoverBound 4 N :=
    coverWidth_mono hPrime.pos (hLog p ((le_max_right P L).trans hT)) hpN
  have hQPos : (0 : ℝ) < (baselineCoverBound 4 N : ℝ) := by exact_mod_cast hQ.1
  have hNr : (0 : ℝ) < N := by exact_mod_cast (Nat.succ_le_iff.mp hN₁)
  have hSize' : (baselineCoverBound 4 N : ℝ) < Real.sqrt N :=
    (by simpa only [one_mul] using (div_lt_iff₀ (Real.sqrt_pos.2 hNr)).mp hSize)
  have hQsqrt : baselineCoverBound 4 N ≤ Nat.sqrt N := by
    apply Nat.le_sqrt'.mpr
    have hX : ((baselineCoverBound 4 N : ℕ) : ℝ) ^ 2 ≤ (N : ℝ) :=
      (Real.le_sqrt hQPos.le hNr.le).mp hSize'.le
    exact_mod_cast hX
  refine ⟨?_, hQsqrt.trans_lt hpSqrt, ?_⟩
  · intro a
    obtain ⟨J,hJ,hr⟩ := hC a
    exact ⟨J, hJ.trans (fun b hb => mem_Icc.mpr
      ⟨(mem_Icc.mp hb).1, (mem_Icc.mp hb).2.trans hWidth⟩), hr⟩
  · intro hv
    exact_mod_cast (show (p : ℝ) * (baselineCoverBound 4 N : ℝ) ≤ (N : ℝ) from (le_div_iff₀ hQPos).mp hv)

/-- The baseline prime window using the original published height route. -/
theorem eventually_baseline_common_cover_of_LiuSawhney (h : LiuSawhneyPrimeHeight) :
    ∀ᶠ N : ℕ in atTop, ∀ p ∈ largePrimes N,
      CoversResidues p (interval 1 (baselineCoverBound 4 N)) ∧
      baselineCoverBound 4 N < p ∧
      ((p : ℝ) ≤ baselineCutoff 4 N → p * baselineCoverBound 4 N ≤ N) :=
  eventually_baseline_common_cover_of_shortPointwise (eventually_shortPointwiseCover_of_LiuSawhney h)

end LeanAB.PaperB.ShortPointwise
