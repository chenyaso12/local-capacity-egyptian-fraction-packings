module

public import PaperB.BaselineRepair
public import PaperB.BaselineResources
meta import Mathlib.Tactic

/-! The baseline simultaneous packing theorem with the height input exposed. -/

@[expose] public section

open Filter Finset
open scoped Topology

namespace LeanAB.PaperB.Baseline

open Closure FixedTargets NearCapacity ShortPointwise

private theorem cubeRoot_le_sqrt (N : ℕ) : Nat.nthRoot 3 N ≤ Nat.sqrt N := by
  let r := Nat.nthRoot 3 N
  change r ≤ Nat.sqrt N
  apply Nat.le_sqrt'.mpr
  have hR : r ^ 3 ≤ N := Nat.pow_nthRoot_le (.inl (by decide))
  by_cases h : r = 0
  · simp [h]
  · exact (by
      rw [show (3 : ℕ) = 2 + 1 by decide, pow_succ]
      exact Nat.le_mul_of_pos_right _ (Nat.pos_of_ne_zero h) : r ^ 2 ≤ r ^ 3).trans hR

/-- The same allocation and repair produce a packing whenever the retained
family has enough mass and leaves the small denominators available. -/
theorem highTotalPackingAtLoss_of_retainedBlockMass {width : ℕ → ℕ}
    {excluded : ℕ → Finset ℕ} {loss : ℕ → ℝ → ℝ}
    (hStock : HasRetainedBlockMass width excluded loss)
    (hLossMono : ∀ᶠ N : ℕ in atTop, Monotone (loss N))
    (hLossNonneg : ∀ C : ℝ, 0 ≤ C → ∀ᶠ N : ℕ in atTop, 0 ≤ loss N C) :
    HighTotalPackingAtLoss loss := by
  classical
  intro a A d ha haA hd hStrict
  obtain ⟨a',ha'd,ha'a⟩ := exists_rat_btwn hStrict
  obtain ⟨A',hAA'⟩ := exists_rat_gt A
  have hdp : 0 < (d : ℝ) := by exact_mod_cast hd
  have ha'R : 0 < (a' : ℝ) := (one_div_pos.mpr hdp).trans ha'd
  have ha' : 0 < a' := by exact_mod_cast ha'R
  have hA'R : 0 < (A' : ℝ) := (ha.trans_le haA).trans hAA'
  have hA' : 0 < A' := by exact_mod_cast hA'R
  have hdQ : 0 < (d : ℚ) := by exact_mod_cast hd
  have ha'dQ : (1 : ℚ) / (d : ℚ) < a' := by
    apply (Rat.cast_lt (K := ℝ)).mp
    push_cast
    exact ha'd
  let β : ℚ := 1 / (a' * (max 1 d : ℕ))
  have hβ : β < 1 := by
    dsimp only [β]
    rw [max_eq_right (show 1 ≤ d by omega)]
    apply (div_lt_iff₀ (mul_pos ha' hdQ)).mpr
    simpa only [one_mul,mul_one,mul_comm] using (div_lt_iff₀ hdQ).mp ha'dQ
  let μ : ℚ := min (1 / 16) ((1 - β) / 2)
  have hμ : 0 < μ := lt_min (by norm_num) (div_pos (sub_pos.mpr hβ) (by norm_num))
  have hμ₁ : μ ≤ 1 / 16 := min_le_left _ _
  have hμ₂ : μ ≤ (1 - β) / 2 := min_le_right _ _
  have hLoad : μ + 1 / (a' * (max 1 d : ℕ)) < 1 := by
    change μ + β < 1
    linarith only [hμ₂,hβ]
  obtain ⟨D,hDsize⟩ := exists_nat_ge ((16 : ℚ) / a')
  have hD : 0 < D := by
    have hh : 0 < (D : ℚ) := (div_pos (by norm_num) ha').trans_le hDsize
    exact_mod_cast hh
  have hReg : μ + 1 / (a' * (D : ℚ)) ≤ 1 / 8 := by
    have hdl : (16 : ℚ) ≤ a' * (D : ℚ) := by
      simpa only [mul_comm] using (div_le_iff₀ ha').mp hDsize
    have hn : 1 / (a' * (D : ℚ)) ≤ 1 / 16 :=
      one_div_le_one_div_of_le (by norm_num) hdl
    linarith only [hμ₁,hn]
  let K : ℝ := 2 / (a' : ℝ)
  have hK : 0 < K := div_pos (by norm_num) ha'R
  obtain ⟨Err,hErr,hRes⟩ := eventually_repair_reserves d K hK
  obtain ⟨C₁,hC₁,hStock⟩ := hStock d Err hErr.le
  obtain ⟨C₀,X₀,hClosure⟩ := exists_uniformSmoothClosure
  let C₂ : ℝ := (A' : ℝ) * (5 + 8 * (D : ℝ) * (A' : ℝ))
  let C₃ : ℝ := 2 + 2 * (A' : ℝ)
  let C : ℝ := C₁ + C₂ + C₃
  have hC₂ : 0 < C₂ := by dsimp only [C₂]; positivity
  have hC₃ : 0 < C₃ := by dsimp only [C₃]; positivity
  have hC : 0 < C := add_pos (add_pos hC₁ hC₂) hC₃
  refine ⟨C,hC,?_⟩
  filter_upwards [hRes, hStock, eventually_allocate d D hD ha' hA' hμ hLoad hReg,
    eventually_close_bases d C₀ X₀ hClosure a' A' ha' hA'.le,
    eventually_target_total_and_count_bound_of_mass_le (a' : ℝ) d ha'R,
    hLossMono, hLossNonneg C hC.le]
    with N hResN hStockN hAllocate hRepair hTarget hLossMono hLossNonneg
  intro m hm r hr hHigh hMass
  let L := Real.log (N : ℝ)
  let W : ℝ := (mass (interval d N) : ℝ)
  let Rt : ℝ := (↑(∑ i, r i : ℚ) : ℝ)
  have hr' (i : Fin m) : a' ≤ r i ∧ r i ≤ A' ∧ (r i).den ∣ permittedDenominator N := by
    refine ⟨?_,?_,(hr i).2.2⟩
    · exact_mod_cast ha'a.le.trans (hr i).1
    · exact_mod_cast (hr i).2.1.trans hAA'.le
  obtain ⟨hRt,hCount⟩ := hTarget r (fun i => ha'a.le.trans (hr i).1)
    (hMass.trans (sub_le_self _ hLossNonneg))
  obtain ⟨P,hInj,hP,hPools⟩ := hResN m hCount
  let M : Finset ℕ := univ.image P
  let Q := mediumPrimes N ⌊smoothCutoff N⌋₊ M
  obtain ⟨Cof,S,R,hCof,hCPair,hSContains,hS,hSMass,hSFactor,hR,hRSize,hRPower,hRMass,hBudget⟩ := hPools
  have hM (p : ℕ) (hp : p ∈ M) : p.Prime ∧ Nat.sqrt N < p := by
    obtain ⟨i,_,rfl⟩ := mem_image.mp hp
    exact ⟨(hP i).1,natSqrt_lt_of_sqrt_lt (hP i).2.1⟩
  let M' := M ∪ excluded N
  let Z := (N : ℝ) / width N
  obtain ⟨B,hBMass,hFew⟩ := hStockN M S R hM hSFactor
    (fun b hb => (hRPower b hb).2) hBudget
  have hLoss : loss N C₁ ≤ loss N C := hLossMono (by
    dsimp only [C]
    linarith only [hC₂,hC₃])
  have hSum : (∑ i, r i) ≤ ∑ T ∈ B.family, mass T := by
    have hh : Rt ≤ ∑ T ∈ B.family, (mass T : ℝ) :=
      (hMass.trans (sub_le_sub_left hLoss W)).trans hBMass
    apply (Rat.cast_le (K := ℝ)).mp
    push_cast
    simpa only [Rt,Rat.cast_sum] using hh
  let E := interval d N \ stock d N M' S R (Z := Z)
  have hStockSub : stock d N M' S R (Z := Z) ⊆ interval d N := fun b hb => (mem_stock.mp hb).1
  have hSet : interval d N \ E = stock d N M' S R (Z := Z) := by
    ext b
    rw [Finset.mem_sdiff]
    constructor
    · intro hb
      by_contra h
      exact hb.2 (mem_sdiff.mpr ⟨hb.1,h⟩)
    · intro hb
      exact ⟨hStockSub hb,fun h => (mem_sdiff.mp h).2 hb⟩
  have hGood (T : Finset ℕ) (hT : T ∈ B.family) :
      T.Nonempty ∧ T ⊆ interval d N \ E ∧ (mass T).den ∣ permittedDenominator N ∧
      ((∃ n : ℕ, T = {n}) ∨ ((∀ n ∈ T, Nat.sqrt N < n) ∧
        mass T ≤ harmonic N / (Nat.sqrt N : ℚ))) := by
    simpa only [hSet,mass_denominators_eq_harmonic] using B.good T hT
  have hSurv (n : ℕ) (hn : n ∈ interval d (Nat.nthRoot 3 N) \ E) :
      ∃ T ∈ B.family, n ∈ T := by
    obtain ⟨hnI,hnE⟩ := mem_sdiff.mp hn
    have hi := mem_Icc.mp hnI
    have hs : n ≤ Nat.sqrt N := hi.2.trans (cubeRoot_le_sqrt N)
    have hAvailable : n ∈ interval d N \ E :=
      mem_sdiff.mpr ⟨mem_Icc.mpr ⟨hi.1,hs.trans (Nat.sqrt_le_self N)⟩,hnE⟩
    exact ⟨{n},B.small n (hSet ▸ hAvailable) hs,mem_singleton_self n⟩
  obtain ⟨Base,hPair,hBase⟩ := hAllocate hm r hr' hHigh hRt B.family E hFew hGood B.disjoint hSum hSurv
  have hDenEq : mediumDenominator ⌊smoothCutoff N⌋₊ Q = permittedDenominator N :=
    mediumDenominator_eq_permitted (fun p hp => (hM p hp).2)
  have hForRepair (i : Fin m) : Base i ⊆ interval d N ∧ Disjoint (Base i) S ∧ Disjoint (Base i) R ∧
      (∀ b ∈ Base i, ∀ j, ¬ P j ∣ b) ∧
      (r i - mass (Base i)).den ∣ mediumDenominator ⌊smoothCutoff N⌋₊ Q ∧
      r i * delta N ≤ r i - mass (Base i) ∧
      r i - mass (Base i) ≤ r i * (delta N + eta N) := by
    have hSub : Base i ⊆ stock d N M' S R (Z := Z) := by
      rw [← hSet]
      exact fun b hb => mem_sdiff.mpr ⟨(hBase i).1 hb,(disjoint_left.mp (hBase i).2.1) hb⟩
    obtain ⟨hBS,hBR,hAvoid⟩ := avoids_reservations_of_subset_stock hSub
    refine ⟨(hBase i).1,hBS,hBR,?_,hDenEq ▸ (hBase i).2.2.1,(hBase i).2.2.2.1,(hBase i).2.2.2.2.1⟩
    exact fun b hb j => hAvoid b hb (P j) (mem_union_left _ (mem_image.mpr ⟨j,mem_univ j,rfl⟩))
  obtain ⟨Out,hOutPair,hOut⟩ := hRepair r (fun i => ⟨(hr' i).1,(hr' i).2.1⟩) hRt
    P hInj hP Q Cof S R (fun p hp => by
      obtain ⟨hp₁,hp₂,hp₃,_⟩ := mem_mediumPrimes.mp hp
      exact ⟨hp₁,hp₃,hp₂⟩)
    hCof hCPair hSContains hS hSMass hR hRSize hRPower hRMass Base hPair hForRepair
  refine ⟨Out,hOutPair,fun i => ⟨(hOut i).2.1,(hOut i).2.2.1,?_⟩⟩
  have hLength : ((Out i).card : ℝ) ≤ (N : ℝ) * (r i : ℝ) / Rt +
      (C₂ + C₃) * ((N : ℝ) / L ^ 2) := by
    calc
      _ ≤ (Base i).card + C₃ * ((N : ℝ) / L ^ 2) := (hOut i).2.2.2
      _ ≤ ((N : ℝ) * (r i : ℝ) / Rt + C₂ * ((N : ℝ) / L ^ 2)) + C₃ * ((N : ℝ) / L ^ 2) :=
        add_le_add_left (hBase i).2.2.2.2.2 _
      _ = _ := by ring
  unfold packingLength
  rw [max_eq_left hHigh]
  calc
    _ ≤ _ := hLength
    _ ≤ _ := by
      have hC23 : C₂ + C₃ ≤ C := by dsimp only [C]; linarith only [hC₁]
      calc
        _ ≤ (N : ℝ) * (r i : ℝ) / Rt + C * ((N : ℝ) / L ^ 2) :=
          add_le_add_right (mul_le_mul_of_nonneg_right hC23 (by positivity)) _
        _ = _ := by dsimp only [L,Rt]; ring

/-- The original high-total sufficient side using the published pointwise estimate. -/
theorem highTotalPackingSufficiency_of_LiuSawhney (hHeight : LiuSawhneyPrimeHeight) :
    HighTotalPackingSufficiency := by
  apply highTotalPackingAtLoss_of_retainedBlockMass (hasRetainedBlockMass_of_LiuSawhney hHeight)
  · have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
      Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
    filter_upwards [hLog.eventually_gt_atTop 0,
      (Real.tendsto_log_atTop.comp hLog).eventually_ge_atTop 1] with N hL hU C D hCD
    unfold sufficientLoss
    dsimp only
    apply add_le_add le_rfl
    exact div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hCD (zero_le_one.trans hU))
        (Real.log_nonneg hU)) hL.le
  · intro C hC
    exact (eventually_losses_between_zero_one 0 C le_rfl hC).mono fun _ h => h.1.le.trans h.2.1

/-- The baseline theorem for arbitrary admitted nonempty target lists. -/
theorem packingSufficiency_of_LiuSawhney (hHeight : LiuSawhneyPrimeHeight) :
    PackingSufficiency :=
  packingSufficiency_of_highTotal (highTotalPackingSufficiency_of_LiuSawhney hHeight)

/-- Combine the two baseline directions with a common mass and length constant. -/
theorem simultaneous_rational_packing_of_sufficiency (hSuff : PackingSufficiency)
    (a A : ℝ) (d : ℕ) (ha : 0 < a) (haA : a ≤ A) (hd : 0 < d)
    (haD : 1 / (d : ℝ) < a) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ {m : ℕ}, 0 < m → ∀ r : Fin m → ℚ,
      (∀ i, a ≤ (r i : ℝ) ∧ (r i : ℝ) ≤ A ∧ (r i).den ∣ permittedDenominator N) →
      let W : ℝ := mass (interval d N)
      let R : ℝ := ↑(∑ i,r i : ℚ)
      let L := Real.log (N : ℝ)
      let U := Real.log L
      (R ≤ W - sufficientLoss N C →
        ∃ S : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (S i) (S j)) ∧
          ∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧
            ((S i).card : ℝ) ≤ packingLength N C (r i : ℝ) R) ∧
      (∀ S : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (S i) (S j)) →
        (∀ i, S i ⊆ interval d N ∧ mass (S i) = r i) →
        R ≤ W - U ^ 2 / (2 * L) + C * U / L) := by
  obtain ⟨C₁,hC₁,hS⟩ := hSuff a A d ha haA hd haD
  obtain ⟨C₂,_,hN⟩ := LeanAB.PaperB.eventually_packing_necessary d
  let C := max C₁ C₂
  refine ⟨C,hC₁.trans_le (le_max_left _ _),?_⟩
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [hS,hN,hLog.eventually_ge_atTop 1,
    (Real.tendsto_log_atTop.comp hLog).eventually_ge_atTop 1] with N hs hn hL' hU'
  intro m hm r hr
  let L := Real.log (N : ℝ)
  let U := Real.log L
  have hL : 0 < L := zero_lt_one.trans_le hL'
  have hU : 1 ≤ U := hU'
  have hCU : C₁ * U * Real.log U ≤ C * U * Real.log U :=
    mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right (le_max_left _ _) (zero_le_one.trans hU))
      (Real.log_nonneg hU)
  have hLoss : sufficientLoss N C₁ ≤ sufficientLoss N C :=
    add_le_add le_rfl (div_le_div_of_nonneg_right hCU hL.le)
  constructor
  · intro hR
    obtain ⟨S,hPair,hF⟩ := hs hm r hr (hR.trans (sub_le_sub_left hLoss _))
    refine ⟨S,hPair,fun i => ⟨(hF i).1,(hF i).2.1,(hF i).2.2.trans ?_⟩⟩
    unfold packingLength
    exact add_le_add le_rfl (div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_right (le_max_left _ _) (by positivity)) (sq_nonneg _))
  · intro S hPair hF
    exact (hn r S hPair (fun i => ⟨(hF i).1,(hF i).2,(hr i).2.2⟩)).trans
      (add_le_add le_rfl (div_le_div_of_nonneg_right
        (mul_le_mul_of_nonneg_right (le_max_right _ _) (zero_le_one.trans hU)) hL.le))

/-- The baseline theorem from the published pointwise coverage route. -/
theorem simultaneous_rational_packing_of_LiuSawhney (hHeight : LiuSawhneyPrimeHeight)
    (a A : ℝ) (d : ℕ) (ha : 0 < a) (haA : a ≤ A) (hd : 0 < d)
    (haD : 1 / (d : ℝ) < a) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ {m : ℕ}, 0 < m → ∀ r : Fin m → ℚ,
      (∀ i, a ≤ (r i : ℝ) ∧ (r i : ℝ) ≤ A ∧ (r i).den ∣ permittedDenominator N) →
      let W : ℝ := mass (interval d N)
      let R : ℝ := ↑(∑ i,r i : ℚ)
      let L := Real.log (N : ℝ)
      let U := Real.log L
      (R ≤ W - sufficientLoss N C →
        ∃ S : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (S i) (S j)) ∧
          ∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧
            ((S i).card : ℝ) ≤ packingLength N C (r i : ℝ) R) ∧
      (∀ S : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (S i) (S j)) →
        (∀ i, S i ⊆ interval d N ∧ mass (S i) = r i) →
        R ≤ W - U ^ 2 / (2 * L) + C * U / L) :=
  simultaneous_rational_packing_of_sufficiency (packingSufficiency_of_LiuSawhney hHeight)
    a A d ha haA hd haD

end LeanAB.PaperB.Baseline
