module

public import PaperB.BaselineStock
meta import Mathlib.Tactic

/-! Actual resources for the baseline simultaneous packing construction. -/

@[expose] public section

open Finset Filter
open scoped BigOperators Topology

namespace LeanAB.PaperB.Baseline

open Closure NearCapacity

/-- Real bounds on the baseline markers give the exact exclusion of medium
primes from the marker set. -/
theorem natSqrt_lt_of_sqrt_lt {N p : ℕ} (h : Real.sqrt (N : ℝ) < (p : ℝ)) :
    Nat.sqrt N < p := by
  have hN : (Nat.sqrt N : ℝ) ≤ Real.sqrt N :=
    (Real.le_sqrt (Nat.cast_nonneg _) (Nat.cast_nonneg _)).2 (by exact_mod_cast Nat.sqrt_le' N)
  exact_mod_cast hN.trans_lt h

/-- Choose actual baseline markers, medium-prime repair pools, and a
powersmooth reserve with the total mass lost in all four exclusion families. -/
theorem eventually_repair_reserves (d : ℕ) (K : ℝ) (hK : 0 < K) :
    ∃ E : ℝ, 0 < E ∧ ∀ᶠ N : ℕ in atTop, ∀ m : ℕ, (m : ℝ) ≤ K * Real.log N →
      ∃ P : Fin m → ℕ, Function.Injective P ∧
        (∀ i, (P i).Prime ∧ Real.sqrt (N : ℝ) < (P i : ℝ) ∧
          (P i : ℝ) ≤ 2 * Real.sqrt (N : ℝ)) ∧
        let M := univ.image P
        let Q := mediumPrimes N ⌊smoothCutoff N⌋₊ M
        ∃ Cof : Fin m → ℕ → Finset ℕ, ∃ S R : Finset ℕ,
          (∀ i p, p ∈ Q → (Cof i p).card = ⌊Real.log (N : ℝ) ^ (10 : ℕ)⌋₊ ∧
            (∀ b ∈ Cof i p, b ∣ Nat.lcmUpto ⌊smoothCutoff N⌋₊) ∧
            CoversResidues p (Cof i p)) ∧
          (∀ p ∈ Q, Pairwise (fun i j => Disjoint (Cof i p) (Cof j p))) ∧
          (∀ i, mediumPool Q (Cof i) ⊆ S) ∧
          S ⊆ interval d N ∧
          (mass S : ℝ) ≤ 692 * ((⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) /
            Real.sqrt (N : ℝ) ∧
          (∀ a ∈ S, ∃ p ∈ Q, p ∣ a) ∧
          R ⊆ interval d N ∧ R.card = ⌈(N : ℝ) / Real.log (N : ℝ) ^ (4 : ℕ)⌉₊ ∧
          (∀ a ∈ R, N ≤ 2 * a ∧ a ∣ Nat.lcmUpto ⌊smoothCutoff N⌋₊) ∧
          (R.card : ℚ) / N ≤ mass R ∧
          (mass (repairExclusions d N (smoothCutoff N) M S R) : ℝ) ≤
            E / Real.log (N : ℝ) ^ (4 : ℕ) := by
  obtain ⟨E, hE, hBudget⟩ := eventually_baseline_repair_budget K hK
  refine ⟨E, hE, ?_⟩
  have hMarkers := eventually_marker_primes (show 0 < (1 / 2 : ℝ) by norm_num)
    (show (1 / 2 : ℝ) ≤ 1 by norm_num) hK
  filter_upwards [hMarkers, eventually_medium_repair_pools d K hK,
    eventually_baselineSmoothReserve d, hBudget, eventually_ge_atTop (1 : ℕ)]
    with N hMark hMed hRes hCost hN m hm
  obtain ⟨P, hInj, hP⟩ := hMark m hm
  refine ⟨P, hInj, fun i => by simpa only [Real.sqrt_eq_rpow] using hP i, ?_⟩
  let M := (univ : Finset (Fin m)).image P
  let Q := mediumPrimes N ⌊smoothCutoff N⌋₊ M
  have hx : 1 ≤ (N : ℝ) := by exact_mod_cast hN
  have hy : (N : ℝ) ^ (1 / 20 : ℝ) ≤ (N : ℝ) ^ (1 / 2 : ℝ) :=
    Real.rpow_le_rpow_of_exponent_le hx (by norm_num)
  have hM (p : ℕ) (hp : p ∈ M) : p.Prime ∧ ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ < p := by
    obtain ⟨i, _, rfl⟩ := mem_image.mp hp
    exact ⟨(hP i).1, (Nat.floor_lt (by positivity)).mpr (hy.trans_lt (hP i).2.1)⟩
  have hQ (p : ℕ) (hp : p ∈ Q) :
      p.Prime ∧ ⌊(N : ℝ) ^ (1 / 20 : ℝ)⌋₊ < p ∧ p ≤ Nat.sqrt N := by
    obtain ⟨hPrime,hSmall,hMedium,_⟩ := mem_mediumPrimes.mp hp
    exact ⟨hPrime,hMedium,hSmall⟩
  have hDis : Disjoint M Q := disjoint_left.mpr fun p hp hpQ =>
    (mem_mediumPrimes.mp hpQ).2.2.2 hp
  obtain ⟨Cof,S,hCof,hCPair,_,hSContains,hS,hSAvoid,hSFactor,_,hSCost⟩ :=
    hMed m hm Q M hQ hM hDis
  obtain ⟨R,hR,hRSize,hRPower,hRLower,hRUpper⟩ := hRes
  have hMC : (M.card : ℝ) ≤ K * Real.log N := by
    simpa only [M, card_image_of_injective _ hInj, card_fin] using hm
  have hMP (p : ℕ) (hp : p ∈ M) : (N : ℝ) ^ (1 / 2 : ℝ) ≤ (p : ℝ) := by
    obtain ⟨i, _, rfl⟩ := mem_image.mp hp
    exact (hP i).2.1.le
  have hRPower' (a : ℕ) (ha : a ∈ R) : N ≤ 2 * a ∧ a ∣ Nat.lcmUpto ⌊smoothCutoff N⌋₊ := by
    simpa only [nthRoot_eq_floor_rpow 20 N (by decide), Nat.cast_ofNat, smoothCutoff] using hRPower a ha
  refine ⟨Cof,S,R,hCof,hCPair,hSContains,hS,hSCost,?_,hR,hRSize,hRPower',?_,?_⟩
  · intro a ha
    obtain ⟨p, hp, b, _, rfl⟩ := hSFactor a ha
    exact ⟨p, hp, dvd_mul_right p b⟩
  · rw [hRSize]
    exact hRLower
  · apply hCost d M S R hMC hMP hSCost
    calc
      _ ≤ ((2 * (⌈(N : ℝ) / Real.log (N : ℝ) ^ (4 : ℕ)⌉₊ : ℚ) / N : ℚ) : ℝ) :=
        Rat.cast_le.mpr hRUpper
      _ = _ := by push_cast; rfl

end LeanAB.PaperB.Baseline
