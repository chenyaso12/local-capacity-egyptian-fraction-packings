module

public import PaperB.BaselineAllocation
public import PaperB.BaselineStock
public import PaperB.SmoothClosure
meta import Mathlib.Tactic

/-! Exact closure and its length budget for the baseline marker range. -/

@[expose] public section

open Finset Filter Asymptotics
open scoped Topology

namespace LeanAB.PaperB.Baseline

open Closure

/-- The standard baseline markers satisfy the uniform smooth-closure geometry. -/
theorem eventually_marker_geometry (d C X₀ : ℕ) (hC : 1 < C) :
    ∀ᶠ N : ℕ in atTop, ∀ P : ℕ, Real.sqrt (N : ℝ) < (P : ℝ) →
      (P : ℝ) ≤ 2 * Real.sqrt (N : ℝ) →
      let X := markerScale N C P
      X₀ ≤ X ∧ 0 < X ∧ d ≤ P * X ∧ 8 * P ≤ N ∧
      ⌊smoothCutoff N⌋₊ ≤ Nat.nthRoot 5 X ∧
      ((Nat.nthRoot 5 X : ℕ) : ℝ) < Real.sqrt N ∧
      (C : ℝ) * (X : ℝ) ≤ Real.sqrt N := by
  let K : ℝ := 4 * (C : ℝ)
  have hCr : (1 : ℝ) < C := by exact_mod_cast hC
  have hC₀ : 0 < (C : ℝ) := zero_lt_one.trans hCr
  have hK : 0 < K := by dsimp only [K]; positivity
  have hnat : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have ht' := Real.tendsto_sqrt_atTop.comp hnat
  have hu' := (tendsto_rpow_atTop (show 0 < (1 / 4 : ℝ) by norm_num)).comp hnat
  filter_upwards [ht'.eventually_ge_atTop (max 16 (max (d : ℝ) (K * ((X₀ : ℝ) + 1)))),
    hu'.eventually_ge_atTop K, eventually_ge_atTop (1 : ℕ)] with N ht hu hN P hp hPU
  let x : ℝ := N
  let t := Real.sqrt x
  let X := markerScale N C P
  let q := (C : ℝ) * (P : ℝ)
  have hx : 0 < x := by change 0 < (N : ℝ); exact_mod_cast (Nat.succ_le_iff.mp hN)
  have htall : max 16 (max (d : ℝ) (K * ((X₀ : ℝ) + 1))) ≤ t := ht
  have ht₀ : 0 < t := Real.sqrt_pos.2 hx
  have h16 : 16 ≤ t := (le_max_left _ _).trans htall
  have hd : (d : ℝ) ≤ t := (le_max_left _ _).trans ((le_max_right _ _).trans htall)
  have hXlow : K * ((X₀ : ℝ) + 1) ≤ t :=
    (le_max_right _ _).trans ((le_max_right _ _).trans htall)
  have hP₀ : 0 < (P : ℝ) := ht₀.trans hp
  have hq : 0 < q := mul_pos hC₀ hP₀
  have hSquare : t * t = x := Real.mul_self_sqrt hx.le
  have hFloor : X = ⌊x / q⌋₊ := by
    dsimp only [X, x, q, markerScale]
    rw [← Nat.cast_mul, Nat.floor_div_natCast, Nat.floor_natCast]
  have hXU : (X : ℝ) ≤ x / q := hFloor ▸ Nat.floor_le (div_nonneg hx.le hq.le)
  have hXL : x / q < (X : ℝ) + 1 := hFloor ▸ Nat.lt_floor_add_one _
  have hQuot : t / (2 * (C : ℝ)) ≤ x / q := by
    apply (div_le_div_iff₀ (by positivity : 0 < 2 * (C : ℝ)) hq).mpr
    dsimp only [q]
    rw [← hSquare]
    have h := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hPU hC₀.le) ht₀.le
    nlinarith only [h]
  have hKlow : (X₀ : ℝ) + 1 ≤ t / K :=
    (le_div_iff₀ hK).mpr (by simpa only [mul_comm] using hXlow)
  have hMLow : t / K ≤ (X : ℝ) := by
    have hh : t / (2 * (C : ℝ)) = 2 * (t / K) := by dsimp only [K]; ring
    rw [hh] at hQuot
    linarith only [hQuot,hXL,hKlow,Nat.cast_nonneg (α := ℝ) X₀]
  have hX1 : 1 ≤ X := by
    have hr : (1 : ℝ) ≤ X := by linarith only [hKlow.trans hMLow,Nat.cast_nonneg (α := ℝ) X₀]
    exact_mod_cast hr
  have hX0 : X₀ ≤ X := by
    have hr : (X₀ : ℝ) ≤ X := by linarith only [hKlow.trans hMLow]
    exact_mod_cast hr
  have hPD : d ≤ P := by
    exact_mod_cast hd.trans hp.le
  have hPX : d ≤ P * X := hPD.trans (by simpa only [mul_one] using Nat.mul_le_mul_left P hX1)
  have hP8 : 8 * P ≤ N := by
    have hr : 8 * (P : ℝ) ≤ x := calc
      _ ≤ 16 * t := by linarith only [hPU]
      _ ≤ t * t := mul_le_mul_of_nonneg_right h16 ht₀.le
      _ = _ := hSquare
    exact_mod_cast (show 8 * (P : ℝ) ≤ (N : ℝ) from hr)
  have hXlt : (X : ℝ) < t := hXU.trans_lt (by
    apply (div_lt_iff₀ hq).mpr
    have hqt : t < q := hp.trans_le (le_mul_of_one_le_left hP₀.le hCr.le)
    rw [← hSquare]
    exact mul_lt_mul_of_pos_left hqt ht₀)
  have hRlt : (Nat.nthRoot 5 X : ℝ) < t := by
    have h0 : Nat.nthRoot 5 X ≤ X :=
      (Nat.le_self_pow (by decide : (5 : ℕ) ≠ 0) _).trans (Nat.pow_nthRoot_le (.inl (by decide)))
    exact (show (Nat.nthRoot 5 X : ℝ) ≤ (X : ℝ) by exact_mod_cast h0).trans_lt hXlt
  have uy : (smoothCutoff N) ^ (5 : ℕ) = x ^ (1 / 4 : ℝ) := by
    change (x ^ (1 / 20 : ℝ)) ^ (5 : ℕ) = _
    rw [← Real.rpow_natCast, ← Real.rpow_mul hx.le]
    norm_num
  have huCut : x ^ (1 / 4 : ℝ) ≤ t / K := by
    apply (le_div_iff₀ hK).mpr
    calc
      _ ≤ x ^ (1 / 4 : ℝ) * x ^ (1 / 4 : ℝ) :=
        mul_le_mul_of_nonneg_left hu (Real.rpow_nonneg hx.le _)
      _ = _ := by dsimp only [t]; rw [← Real.rpow_add hx, Real.sqrt_eq_rpow]; norm_num
  have hz : ⌊smoothCutoff N⌋₊ ≤ Nat.nthRoot 5 X := by
    apply (Nat.le_nthRoot_iff (by decide : (5 : ℕ) ≠ 0)).mpr
    have h := (pow_le_pow_left₀ (Nat.cast_nonneg _) (Nat.floor_le
      (Real.rpow_nonneg hx.le (1 / 20 : ℝ))) 5).trans (uy ▸ huCut)
    exact_mod_cast h.trans hMLow
  have hLen : (C : ℝ) * (X : ℝ) ≤ t := calc
    _ ≤ (C : ℝ) * (x / q) := mul_le_mul_of_nonneg_left hXU hC₀.le
    _ = x / (P : ℝ) := by dsimp only [q]; field_simp
    _ ≤ t := (div_le_iff₀ hP₀).mpr (by rw [← hSquare]; exact mul_le_mul_of_nonneg_left hp.le ht₀.le)
  exact ⟨hX0,hX1,hPX,hP8,hz,hRlt,hLen⟩

/-- Quantitative budget for exact closing of the baseline's residuals. -/
theorem eventually_repair_costs (a A : ℚ) (ha : 0 < a) (hA : 0 ≤ A) :
    ∀ᶠ N : ℕ in atTop,
      let x : ℝ := N
      let L := Real.log x
      let δ : ℝ := delta N
      692 * ((⌈L ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) / Real.sqrt x ≤ (a : ℝ) * δ / 2 ∧
      1 / (2 * Real.sqrt x) ≤ (a : ℝ) * δ / 2 ∧
      (∀ R : ℝ, 0 ≤ R → R ≤ L + 1 → 2 * R * δ ≤
        ((⌈x / L ^ 4⌉₊ : ℕ) : ℝ) / x) ∧
      Real.sqrt x * L ^ (10 : ℕ) + x * (2 * (A : ℝ) * δ) + Real.sqrt x ≤
        (2 + 2 * (A : ℝ)) * (x / L ^ 2) := by
  have haR : 0 < (a : ℝ) := by exact_mod_cast ha
  have hAR : 0 ≤ (A : ℝ) := by exact_mod_cast hA
  have hCast : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog := Real.tendsto_log_atTop.comp hCast
  have hSlow := (isLittleO_log_rpow_rpow_atTop 18 (show 0 < (1 / 2 : ℝ) by norm_num)).bound
    (show 0 < (a : ℝ) / 5536 by positivity)
  filter_upwards [hCast.eventually (eventually_ge_atTop (1 : ℝ)), hLog.eventually_ge_atTop 4,
    hCast.eventually hSlow, eventually_residual_parameters,
    eventually_log_pow_le_rpow 12 (show 0 < (1 / 2 : ℝ) by norm_num)]
    with N hN hL' hSlowN hP hL12'
  let x : ℝ := N
  let L := Real.log x
  let δ : ℝ := delta N
  let t := Real.sqrt x
  have hL : 4 ≤ L := hL'
  have hL₁ : 1 ≤ L := by linarith
  have hL₀ : 0 < L := by linarith
  have hx : 0 < x := zero_lt_one.trans_le hN
  have ht : 0 < t := Real.sqrt_pos.2 hx
  have hδ₀ : 0 ≤ δ := by change 0 ≤ (delta N : ℝ); exact_mod_cast hP.1.le
  have hδL : 1 / (2 * L ^ 6) ≤ δ := hP.2.2.2.1
  have hδU : δ ≤ 1 / L ^ 6 := hP.2.2.2.2.1
  have hPow : L ^ (18 : ℕ) ≤ (a : ℝ) / 5536 * t := by
    have e : Real.log (N : ℝ) ^ (18 : ℝ) = L ^ (18 : ℕ) := Real.rpow_natCast L 18
    rw [e] at hSlowN
    have hh : ‖L ^ (18 : ℕ)‖ ≤ (a : ℝ) / 5536 * ‖t‖ := by
      simpa only [t,Real.sqrt_eq_rpow] using hSlowN
    simpa only [Real.norm_of_nonneg (pow_nonneg hL₀.le 18), Real.norm_of_nonneg ht.le] using hh
  have hSub : (a : ℝ) / (4 * L ^ 6) ≤ (a : ℝ) * δ / 2 := calc
    _ = (a : ℝ) * (1 / (2 * L ^ 6)) / 2 := by ring
    _ ≤ _ := div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hδL haR.le) (by norm_num)
  change 692 * ((⌈L ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) / t ≤ (a : ℝ) * δ / 2 ∧
    1 / (2 * t) ≤ (a : ℝ) * δ / 2 ∧
    (∀ R : ℝ, 0 ≤ R → R ≤ L + 1 → 2 * R * δ ≤ ((⌈x / L ^ 4⌉₊ : ℕ) : ℝ) / x) ∧
    t * L ^ (10 : ℕ) + x * (2 * (A : ℝ) * δ) + t ≤ (2 + 2 * (A : ℝ)) * (x / L ^ 2)
  refine ⟨?_,?_,?_,?_⟩
  · have hQ : ((⌈L ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) ≤ 2 * L ^ 12 := by
      have hOne : 1 ≤ L ^ (12 : ℕ) := one_le_pow₀ hL₁
      linarith only [Nat.ceil_lt_add_one (pow_nonneg hL₀.le 12),hOne]
    calc
      _ ≤ 1384 * L ^ (12 : ℕ) / t :=
        div_le_div_of_nonneg_right (by linarith only [hQ]) ht.le
      _ ≤ (a : ℝ) / (4 * L ^ 6) := by
        apply (div_le_div_iff₀ ht (by positivity : 0 < 4 * L ^ 6)).mpr
        calc
          _ = 5536 * L ^ (18 : ℕ) := by ring
          _ ≤ _ := by linarith only [hPow]
      _ ≤ _ := hSub
  · have hLpow : L ^ (6 : ℕ) ≤ L ^ 18 := pow_le_pow_right₀ hL₁ (by decide)
    apply le_trans ?_ hSub
    apply (div_le_div_iff₀ (by positivity : 0 < 2 * t) (by positivity : 0 < 4 * L ^ 6)).mpr
    have hh := hLpow.trans hPow
    have hm : 0 ≤ (a : ℝ) * t := mul_nonneg haR.le ht.le
    nlinarith only [hh,hm]
  · intro R hR hUpper
    have hRtwo : R ≤ 2 * L := by linarith only [hUpper,hL]
    calc
      _ ≤ (2 * (2 * L)) * (1 / L ^ (6 : ℕ)) :=
        mul_le_mul (by linarith only [hRtwo]) hδU hδ₀ (by positivity)
      _ = 4 / L ^ (5 : ℕ) := by field_simp [hL₀.ne']; norm_num
      _ ≤ 1 / L ^ (4 : ℕ) := by
        apply (div_le_div_iff₀ (pow_pos hL₀ 5) (pow_pos hL₀ 4)).mpr
        have hh := mul_le_mul_of_nonneg_right hL (pow_nonneg hL₀.le 4)
        rw [one_mul, show L ^ (5 : ℕ) = L * L ^ (4 : ℕ) by ring]
        exact hh
      _ ≤ _ := by
        apply (le_div_iff₀ hx).mpr
        rw [one_div_mul_eq_div]
        exact Nat.le_ceil _
  · have h12 : L ^ (12 : ℕ) ≤ t := by simpa only [t, Real.sqrt_eq_rpow] using hL12'
    have h2 : L ^ (2 : ℕ) ≤ t := (pow_le_pow_right₀ hL₁ (by decide : (2 : ℕ) ≤ 12)).trans h12
    have hSq : t * t = x := Real.mul_self_sqrt hx.le
    have h1 : t * L ^ (10 : ℕ) ≤ x / L ^ 2 := by
      apply (le_div_iff₀ (pow_pos hL₀ 2)).mpr
      rw [mul_assoc, ← pow_add, ← hSq]
      exact mul_le_mul_of_nonneg_left h12 ht.le
    have h3 : t ≤ x / L ^ 2 := by
      apply (le_div_iff₀ (pow_pos hL₀ 2)).mpr
      exact (mul_le_mul_of_nonneg_left h2 ht.le).trans_eq hSq
    have hδlen : δ ≤ 1 / L ^ (2 : ℕ) := hδU.trans
      (one_div_le_one_div_of_le (pow_pos hL₀ 2) (pow_le_pow_right₀ hL₁ (by decide)))
    have h4 : x * (2 * (A : ℝ) * δ) ≤ 2 * (A : ℝ) * (x / L ^ 2) := calc
      _ ≤ x * (2 * (A : ℝ) * (1 / L ^ (2 : ℕ))) :=
        mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hδlen (by positivity)) hx.le
      _ = _ := by ring
    linarith only [h1,h3,h4]

/-- Close the baseline base groups with the reserved pools and preserve the
leading length bound by charging only O(N/(log N)^2) extra terms. -/
theorem eventually_close_bases (d C X₀ : ℕ) (hClosure : UniformSmoothClosure C X₀)
    (a A : ℚ) (ha : 0 < a) (hA : 0 ≤ A) :
    ∀ᶠ N : ℕ in atTop,
      ∀ {m : ℕ} (r : Fin m → ℚ), (∀ i, a ≤ r i ∧ r i ≤ A) →
      (↑(∑ i, r i : ℚ) : ℝ) ≤ Real.log (N : ℝ) + 1 →
      ∀ (P : Fin m → ℕ), Function.Injective P →
      (∀ i, (P i).Prime ∧ Real.sqrt (N : ℝ) < (P i : ℝ) ∧ (P i : ℝ) ≤ 2 * Real.sqrt (N : ℝ)) →
      ∀ (Q : Finset ℕ) (Cof : Fin m → ℕ → Finset ℕ) (S R : Finset ℕ),
      (∀ p ∈ Q, p.Prime ∧ ⌊smoothCutoff N⌋₊ < p ∧ p ≤ Nat.sqrt N) →
      (∀ i p, p ∈ Q → (Cof i p).card = ⌊Real.log (N : ℝ) ^ (10 : ℕ)⌋₊ ∧
        (∀ b ∈ Cof i p, b ∣ Nat.lcmUpto ⌊smoothCutoff N⌋₊) ∧ CoversResidues p (Cof i p)) →
      (∀ p ∈ Q, Pairwise (fun i j => Disjoint (Cof i p) (Cof j p))) →
      (∀ i, mediumPool Q (Cof i) ⊆ S) → S ⊆ interval d N →
      (mass S : ℝ) ≤ 692 * ((⌈Real.log (N : ℝ) ^ (12 : ℕ)⌉₊ : ℕ) : ℝ) / Real.sqrt N →
      R ⊆ interval d N → R.card = ⌈(N : ℝ) / (Real.log N) ^ 4⌉₊ →
      (∀ b ∈ R, N ≤ 2 * b ∧ b ∣ Nat.lcmUpto ⌊smoothCutoff N⌋₊) →
      (R.card : ℚ) / N ≤ mass R →
      ∀ (Base : Fin m → Finset ℕ), Pairwise (fun i j => Disjoint (Base i) (Base j)) →
      (∀ i, Base i ⊆ interval d N ∧ Disjoint (Base i) S ∧ Disjoint (Base i) R ∧
        (∀ b ∈ Base i, ∀ j, ¬ P j ∣ b) ∧
        (r i - mass (Base i)).den ∣ mediumDenominator ⌊smoothCutoff N⌋₊ Q ∧
        r i * delta N ≤ r i - mass (Base i) ∧
        r i - mass (Base i) ≤ r i * (delta N + eta N)) →
      ∃ Out : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (Out i) (Out j)) ∧
        ∀ i, Base i ⊆ Out i ∧ Out i ⊆ interval d N ∧ mass (Out i) = r i ∧
          ((Out i).card : ℝ) ≤ (Base i).card + (2 + 2 * (A : ℝ)) * ((N : ℝ) / (Real.log N) ^ 2) := by
  filter_upwards [eventually_marker_geometry d C X₀ hClosure.1,
    eventually_residual_parameters, eventually_repair_costs a A ha hA,
    eventually_ge_atTop (1 : ℕ)] with N hGeom hP hBudget hN
  intro m r hr hRTotal P hInj hPr Q Cof S R hQ hCof hCPair hSContains hS hSMass hR hRSize
    hRProps hRMass Base hBasePairwise hBase
  let y := ⌊smoothCutoff N⌋₊
  let δ := delta N
  let η := eta N
  let X (i : Fin m) := markerScale N C (P i)
  let L := Real.log (N : ℝ)
  have hδ : 0 < δ := hP.1
  have hG (i : Fin m) := hGeom (P i) (hPr i).2.1 (hPr i).2.2
  have hMarkerScale (i : Fin m) : X₀ ≤ X i ∧ 0 < X i ∧ d ≤ P i * X i := by
    obtain ⟨h₁, h₂, h₃, _⟩ := hG i
    exact ⟨h₁,h₂,h₃⟩
  have hCut (i : Fin m) : y ≤ Nat.nthRoot 5 (X i) := by
    obtain ⟨_, _, _, _, h, _⟩ := hG i
    exact h
  have hCutDistinct (i j : Fin m) : Nat.nthRoot 5 (X i) < P j := by
    obtain ⟨_, _, _, _, _, hh, _⟩ := hG i
    exact_mod_cast hh.trans (hPr j).2.1
  have hEight (i : Fin m) : 8 * P i ≤ N := by
    obtain ⟨_, _, _, hh, _⟩ := hG i
    exact hh
  have hOrder (p : ℕ) (hp : p ∈ Q) (i : Fin m) : p < P i := by
    have ht : (p : ℝ) ≤ Real.sqrt (N : ℝ) :=
      (Real.le_sqrt (by positivity) (by positivity)).mpr
        (by exact_mod_cast Nat.le_sqrt'.mp (hQ p hp).2.2)
    exact_mod_cast ht.trans_lt (hPr i).2.1
  have hLower (i : Fin m) : markerLower (P i) ≤ a * δ / 2 := by
    have hP₀ : 0 < Real.sqrt (N : ℝ) := Real.sqrt_pos.2 (by exact_mod_cast Nat.succ_le_iff.mp hN)
    apply (Rat.cast_le (K := ℝ)).mp
    unfold markerLower
    push_cast
    exact (div_le_div_of_nonneg_left zero_le_one (by positivity : 0 < 2 * Real.sqrt (N : ℝ))
      (mul_le_mul_of_nonneg_left (hPr i).2.1.le (by norm_num))).trans hBudget.2.1
  have hVolume : (∑ i, (2 : ℚ) * r i * δ) ≤ mass R := by
    have hRM : (R.card : ℝ) / N ≤ (mass R : ℝ) := by
      have hh : (((R.card : ℚ) / N : ℚ) : ℝ) ≤ (mass R : ℝ) := Rat.cast_le.mpr hRMass
      simpa only [Rat.cast_natCast,Rat.cast_div] using hh
    have hRnon : (0 : ℝ) ≤ (↑(∑ i, r i : ℚ) : ℝ) := by
      exact_mod_cast sum_nonneg (fun i _ => ha.le.trans (hr i).1)
    have hh := (hBudget.2.2.1 (↑(∑ i,r i : ℚ) : ℝ) hRnon hRTotal).trans (hRSize ▸ hRM)
    rw [← sum_mul, ← mul_sum]
    apply (Rat.cast_le (K := ℝ)).mp
    push_cast at hh ⊢
    exact hh
  have hCosts (i : Fin m) : mass (mediumPool Q (Cof i)) ≤ a * δ / 2 := by
    have ht : (mass (mediumPool Q (Cof i)) : ℝ) ≤ (mass S : ℝ) :=
      Rat.cast_le.mpr (mass_mono (hSContains i))
    apply (Rat.cast_le (K := ℝ)).mp
    push_cast
    exact ht.trans (hSMass.trans hBudget.1)
  obtain ⟨F,E,G,hPair,hOut⟩ := finite_three_stage_repair
    (Nat.succ_le_iff.mp hN) hClosure P (fun i => (hPr i).1) hInj hEight hMarkerScale hCut hCutDistinct
    Q Cof (fun p hp => ⟨(hQ p hp).1,(hQ p hp).2.1⟩) hOrder
    (fun i p hp => (hCof i p hp).2.1) (fun i p hp => (hCof i p hp).2.2)
    hCPair (fun i => (hSContains i).trans hS)
    Base (fun i => (hBase i).1) hBasePairwise
    (fun i j => (hBase i).2.1.mono_right (hSContains j)) (fun i => (hBase i).2.2.2.1)
    R hR (fun b hb => (hRProps b hb).1) (fun b hb => (hRProps b hb).2)
    (fun i => (hBase i).2.2.1) r ha hδ hP.2.2.1 (fun i => (hr i).1)
    (fun i => (hBase i).2.2.2.2.1) (fun i => (hBase i).2.2.2.2.2)
    hCosts hLower hVolume
  let Out (i : Fin m) := Base i ∪ F i ∪ E i ∪ G i
  refine ⟨Out, hPair, fun i => ⟨?_,(hOut i).2.2.1,(hOut i).2.2.2.1,?_⟩⟩
  · exact (subset_union_left.trans subset_union_left).trans subset_union_left
  · have hQSize : Q.card ≤ Nat.sqrt N := by
      have hSub : Q ⊆ Icc 1 (Nat.sqrt N) := fun p hp =>
        mem_Icc.mpr ⟨(hQ p hp).1.one_le,(hQ p hp).2.2⟩
      simpa using card_le_card hSub
    have hQSizeR : (Q.card : ℝ) ≤ Real.sqrt N :=
      (Real.le_sqrt (by positivity) (by positivity)).mpr (by exact_mod_cast Nat.le_sqrt'.mp hQSize)
    have hLog : 0 ≤ L := Real.log_nonneg (by exact_mod_cast hN)
    have hTerms : (∑ p ∈ Q, ((Cof i p).card : ℝ)) ≤ Real.sqrt N * L ^ (10 : ℕ) := calc
      _ = (Q.card : ℝ) * (⌊L ^ (10 : ℕ)⌋₊ : ℝ) := by
        calc
          _ = ∑ _p ∈ Q, (⌊L ^ (10 : ℕ)⌋₊ : ℝ) := sum_congr rfl fun p hp => by rw [(hCof i p hp).1]
          _ = _ := by rw [sum_const, nsmul_eq_mul]
      _ ≤ _ := mul_le_mul hQSizeR (Nat.floor_le (pow_nonneg hLog _)) (by positivity) (by positivity)
    have hMarked : (C : ℝ) * (X i : ℝ) ≤ Real.sqrt N := (hG i).2.2.2.2.2.2
    have hCardQ := (hOut i).2.2.2.2
    have hCardR : ((Out i).card : ℝ) ≤ (Base i).card + (∑ p ∈ Q, ((Cof i p).card : ℝ)) +
        (N : ℝ) * (2 * (r i : ℝ) * (δ : ℝ)) + (C : ℝ) * (X i : ℝ) := by
      have h' : (((Out i).card : ℚ) : ℝ) ≤
          ((((Base i).card : ℚ) + (∑ p ∈ Q, ((Cof i p).card : ℚ)) +
            (N : ℚ) * (2 * r i * δ) + ((C * X i : ℕ) : ℚ) : ℚ) : ℝ) := Rat.cast_le.mpr hCardQ
      simpa only [Rat.cast_add,Rat.cast_mul,Rat.cast_sum,Rat.cast_natCast,Rat.cast_ofNat,Nat.cast_mul] using h'
    have hRbound : (N : ℝ) * (2 * (r i : ℝ) * (δ : ℝ)) ≤ (N : ℝ) * (2 * (A : ℝ) * (δ : ℝ)) :=
      mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left (by exact_mod_cast (hr i).2) (by norm_num))
        (by exact_mod_cast hδ.le)) (by positivity)
    calc
      _ ≤ _ := hCardR
      _ ≤ (Base i).card + (Real.sqrt N * L ^ (10 : ℕ) +
          (N : ℝ) * (2 * (A : ℝ) * (δ : ℝ)) + Real.sqrt N) := by linarith only [hTerms,hMarked,hRbound]
      _ ≤ _ := add_le_add_right hBudget.2.2.2 _

end LeanAB.PaperB.Baseline
