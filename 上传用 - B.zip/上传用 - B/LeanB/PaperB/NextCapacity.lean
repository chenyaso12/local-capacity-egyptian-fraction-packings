module

public import PaperB.Baseline
public import PaperB.NextCapacityStock
public import PaperB.NextCapacityNecessary
public import PaperB.NextInverseHeights
public import PaperB.LengthMatching
public import PaperB.RestrictedMatching
meta import Mathlib.Tactic

/-! F2 simultaneous packing and inverse heights at the next capacity scale. -/

public section

open Finset Filter
open scoped Topology

namespace LeanAB.PaperB

open Baseline FixedTargets

private theorem packingLength_le_of_const_le {N : ℕ} {C D r R : ℝ} (h : C ≤ D) :
    packingLength N C r R ≤ packingLength N D r R := by
  unfold packingLength
  apply add_le_add le_rfl
  exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right h (Nat.cast_nonneg N))
    (sq_nonneg _)

/-- The sufficient side at the F2 next capacity scale. -/
theorem nextPackingSufficiency : PackingAtLoss nextSufficientLoss := by
  obtain ⟨_, _, hStock⟩ := hasRetainedBlockMass_of_averageCover
  apply packingAtLoss_of_highTotal
    (fun C hC => (eventually_nextSufficientLoss_nonneg_lt_one C hC).mono fun _ h => h.2)
  exact highTotalPackingAtLoss_of_retainedBlockMass hStock eventually_nextSufficientLoss_monotone
    (fun C hC => (eventually_nextSufficientLoss_nonneg_lt_one C hC).mono fun _ h => h.1)

/-- The baseline sufficient side follows from the stronger F2 packing bound. -/
theorem packingSufficiency : PackingSufficiency := by
  intro a A d ha hA hd hda
  obtain ⟨C, hC, h⟩ := nextPackingSufficiency a A d ha hA hd hda
  refine ⟨5 + C, by positivity, ?_⟩
  filter_upwards [h, eventually_nextSufficientLoss_le_sufficientLoss C hC.le]
    with N hN hLoss
  intro m hm r hr hMass
  obtain ⟨S, hPair, hS⟩ := hN hm r hr (hMass.trans (sub_le_sub_left hLoss _))
  exact ⟨S, hPair, fun i => ⟨(hS i).1, (hS i).2.1,
    (hS i).2.2.trans (packingLength_le_of_const_le (by linarith))⟩⟩

/-- Both directions of the original baseline simultaneous packing theorem. -/
theorem simultaneous_rational_packing
    (a A : ℝ) (d : ℕ) (ha : 0 < a) (haA : a ≤ A) (hd : 0 < d)
    (haD : 1 / (d : ℝ) < a) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ {m : ℕ}, 0 < m → ∀ r : Fin m → ℚ,
      (∀ i, a ≤ (r i : ℝ) ∧ (r i : ℝ) ≤ A ∧ (r i).den ∣ permittedDenominator N) →
      let W : ℝ := mass (interval d N)
      let R : ℝ := ↑(∑ i,r i : ℚ)
      let L := Real.log (N : ℝ)
      let U := Real.log L
      (R ≤ W - sufficientLoss N C →
        ∃ S : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (S i) (S j)) ∧
          ∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧
            ((S i).card : ℝ) ≤ packingLength N C (r i : ℝ) R) ∧
      (∀ S : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (S i) (S j)) →
        (∀ i, S i ⊆ interval d N ∧ mass (S i) = r i) →
        R ≤ W - U ^ 2 / (2 * L) + C * U / L) :=
  simultaneous_rational_packing_of_sufficiency packingSufficiency a A d ha haA hd haD

/-- Both directions of the F2 next coefficient theorem use a common constant.
The necessary side allows the wider class of reduced target denominators. -/
theorem eventually_nextCapacity_packing (a A : ℝ) (d : ℕ) (ha : 0 < a)
    (hA : a ≤ A) (hd : 0 < d) (hda : 1 / (d : ℝ) < a) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      let U := Real.log L
      let W : ℝ := mass (interval d N)
      (∀ {m : ℕ}, 0 < m → ∀ r : Fin m → ℚ,
        (∀ i, a ≤ (r i : ℝ) ∧ (r i : ℝ) ≤ A ∧ (r i).den ∣ permittedDenominator N) →
        ((∑ i, r i : ℚ) : ℝ) ≤ W - nextSufficientLoss N C →
        ∃ S : Fin m → Finset ℕ, Pairwise (fun i j => Disjoint (S i) (S j)) ∧
          ∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧
            ((S i).card : ℝ) ≤ packingLength N C (r i : ℝ) ((∑ i, r i : ℚ) : ℝ)) ∧
      (∀ {m : ℕ} (r : Fin m → ℚ) (S : Fin m → Finset ℕ),
        Pairwise (fun i j => Disjoint (S i) (S j)) →
        (∀ i, S i ⊆ interval d N ∧ mass (S i) = r i ∧
          ∀ p : ℕ, p.Prime → Nat.sqrt N < p → ¬ p ∣ (r i).den) →
        ((∑ i, r i : ℚ) : ℝ) ≤ W -
          (U ^ 2 / (2 * L) + U * Real.log U / L -
            U / L * (2 * Real.log (Real.log (Real.log U)) + C))) := by
  obtain ⟨C₁, hC₁, hs⟩ := nextPackingSufficiency a A d ha hA hd hda
  obtain ⟨C₂, _, hn⟩ := eventually_nextCapacity_necessary d
  let C := max C₁ C₂
  have hC₁C : C₁ ≤ C := le_max_left _ _
  have hC₂C : C₂ ≤ C := le_max_right _ _
  refine ⟨C, hC₁.trans_le hC₁C, ?_⟩
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [hs, hn, eventually_nextSufficientLoss_monotone, hLog.eventually_ge_atTop 1]
    with N hs hn hMono hL
  constructor
  · intro m hm r hr hR
    obtain ⟨S, hDisj, hPack⟩ := hs hm r hr (hR.trans (sub_le_sub_left (hMono hC₁C) _))
    exact ⟨S, hDisj, fun i => ⟨(hPack i).1, (hPack i).2.1,
      (hPack i).2.2.trans (packingLength_le_of_const_le hC₁C)⟩⟩
  · intro m r S hDisj hPack
    apply (hn r S hDisj hPack).trans
    apply sub_le_sub_left
    apply sub_le_sub_left
    exact mul_le_mul_of_nonneg_left (add_le_add le_rfl hC₂C)
      (div_nonneg (Real.log_nonneg hL) (zero_le_one.trans hL))

/-- The local capacity deficit has the F2 next term with its stated error scale. -/
theorem eventually_nextCapacity_deficit :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ N : ℕ in atTop,
      let L := Real.log (N : ℝ)
      let U := Real.log L
      |(harmonic N : ℝ) - (capacity N : ℝ) -
        (U ^ 2 / (2 * L) + U * Real.log U / L)| ≤
          D * (U / L * Real.log (Real.log U)) := by
  obtain ⟨B, hB, hLower⟩ := eventually_nextCapacity_deficit_lower
  obtain ⟨C, hC, hUpper⟩ := eventually_nextCapacity_deficit_upper
  let D := max (2 + B) (4 + C)
  refine ⟨D, (by linarith : 0 < 2 + B).trans_le (le_max_left _ _), ?_⟩
  have hL : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hU := Real.tendsto_log_atTop.comp hL
  have hV := Real.tendsto_log_atTop.comp (Real.tendsto_log_atTop.comp hU)
  filter_upwards [hLower, hUpper, hL.eventually_ge_atTop 1, hV.eventually_ge_atTop 1]
    with N hlo hhi hL₁ hV₁
  let L := Real.log (N : ℝ)
  let U := Real.log L
  let V := Real.log (Real.log U)
  have hV : 1 ≤ V := hV₁
  have hLogV : Real.log V ≤ V :=
    (Real.log_le_sub_one_of_pos (zero_lt_one.trans_le hV)).trans (sub_le_self _ zero_le_one)
  have hRatio : 0 ≤ U / L := div_nonneg (Real.log_nonneg hL₁) (zero_le_one.trans hL₁)
  have hlo' : 2 * Real.log V + B ≤ D * V := by
    calc
      _ ≤ (2 + B) * V := by linarith only [hLogV, le_mul_of_one_le_right hB.le hV]
      _ ≤ _ := mul_le_mul_of_nonneg_right (le_max_left _ _) (zero_le_one.trans hV)
  have hhi' : 4 * V + C ≤ D * V := by
    calc
      _ ≤ (4 + C) * V := by linarith only [le_mul_of_one_le_right hC.le hV]
      _ ≤ _ := mul_le_mul_of_nonneg_right (le_max_right _ _) (zero_le_one.trans hV)
  have hl := mul_le_mul_of_nonneg_left hlo' hRatio
  have hu := mul_le_mul_of_nonneg_left hhi' hRatio
  have heq : (U / L) * (D * V) = D * (U / L * V) := by ring
  rw [heq] at hl hu
  change U ^ 2 / (2 * L) + U * Real.log U / L - U / L * (2 * Real.log V + B) ≤
    (harmonic N : ℝ) - (capacity N : ℝ) at hlo
  change (harmonic N : ℝ) - (capacity N : ℝ) ≤
    U ^ 2 / (2 * L) + U * Real.log U / L + U / L * (4 * V + C) at hhi
  exact abs_le.mpr ⟨by linarith only [hlo, hl], by linarith only [hhi, hu]⟩

/-- The unit-group count at the F2 next capacity scale. -/
theorem eventually_unit_lower_at_nextCapacity :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      ⌊(harmonic N : ℝ) - nextSufficientLoss N C⌋ ≤ (k N : ℤ) :=
  eventually_unit_lower_of_nextPacking nextPackingSufficiency

/-- The exact next term in both inverse height expansions. -/
theorem eventually_next_inverse_heights :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ j : ℕ in atTop,
      let V := Real.log (j : ℝ)
      let E := V * Real.log (Real.log V) / (j : ℝ)
      let A := (j : ℝ) - Real.eulerMascheroniConstant +
        V ^ 2 / (2 * (j : ℝ)) + V * Real.log V / (j : ℝ)
      |Real.log (unitInverseHeight j : ℝ) - A| ≤ D * E ∧
      |Real.log (integerInverseHeight j : ℝ) - A| ≤ D * E :=
  eventually_next_inverse_heights_of_count eventually_unit_lower_at_nextCapacity

/-- The baseline asymptotic for both inverse heights, with the sharp coefficient. -/
theorem eventually_inverse_heights :
    ∃ D : ℝ, 0 < D ∧ ∀ᶠ j : ℕ in atTop,
      let V := Real.log (j : ℝ)
      let E := V * Real.log V / (j : ℝ)
      let A := (j : ℝ) - Real.eulerMascheroniConstant + V ^ 2 / (2 * (j : ℝ))
      |Real.log (unitInverseHeight j : ℝ) - A| ≤ D * E ∧
      |Real.log (integerInverseHeight j : ℝ) - A| ≤ D * E := by
  obtain ⟨C,hC,hNext⟩ := eventually_next_inverse_heights
  refine ⟨C + 1,by positivity,?_⟩
  have hLog : Tendsto (fun j : ℕ => Real.log (j : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hLog₂ := Real.tendsto_log_atTop.comp hLog
  filter_upwards [hNext, hLog.eventually_ge_atTop 1, hLog₂.eventually_ge_atTop 1]
    with j hNext hV₁ hV₂
  let V := Real.log (j : ℝ)
  let J := V * Real.log V / (j : ℝ)
  let E := V * Real.log (Real.log V) / (j : ℝ)
  let A := (j : ℝ) - Real.eulerMascheroniConstant + V ^ 2 / (2 * (j : ℝ))
  have hV₀ : 0 ≤ V := zero_le_one.trans hV₁
  have hW : 1 ≤ Real.log V := hV₂
  have hJ₀ : 0 ≤ J :=
    div_nonneg (mul_nonneg hV₀ (zero_le_one.trans hW)) (Nat.cast_nonneg _)
  have hScale : E ≤ J := by
    apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg _)
    apply mul_le_mul_of_nonneg_left _ hV₀
    exact (Real.log_le_sub_one_of_pos (zero_lt_one.trans_le hW)).trans (sub_le_self _ zero_le_one)
  have hTransfer {L : ℝ} (h : |L - (A + J)| ≤ C * E) : |L - A| ≤ (C + 1) * J := calc
    _ = |(L - (A + J)) + J| := by congr 1; ring
    _ ≤ |L - (A + J)| + |J| := abs_add_le _ _
    _ ≤ C * E + J := by rw [abs_of_nonneg hJ₀]; exact add_le_add h le_rfl
    _ ≤ (C + 1) * J := by linarith only [mul_le_mul_of_nonneg_left hScale hC.le]
  exact ⟨hTransfer hNext.1, hTransfer hNext.2⟩

/-- The normalized corrections for the unit and integer inverse heights
both tend to one half. -/
theorem tendsto_normalized_inverse_heights :
    Tendsto (fun j : ℕ => (j : ℝ) *
      (Real.log (unitInverseHeight j : ℝ) - (j : ℝ) + Real.eulerMascheroniConstant) /
        Real.log (j : ℝ) ^ 2) atTop (𝓝 (1 / 2 : ℝ)) ∧
    Tendsto (fun j : ℕ => (j : ℝ) *
      (Real.log (integerInverseHeight j : ℝ) - (j : ℝ) + Real.eulerMascheroniConstant) /
        Real.log (j : ℝ) ^ 2) atTop (𝓝 (1 / 2 : ℝ)) := by
  obtain ⟨_,_,h⟩ := eventually_inverse_heights
  exact ⟨normalized_inverse_correction (h.mono fun _ hj => hj.1),
    normalized_inverse_correction (h.mono fun _ hj => hj.2)⟩


private theorem eventually_baseline_loss_monotonicity :
    ∀ᶠ N : ℕ in atTop, Monotone (sufficientLoss N) ∧ Antitone (necessaryLoss N) := by
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hLog₂ := Real.tendsto_log_atTop.comp hLog
  filter_upwards [hLog.eventually_ge_atTop 1, hLog₂.eventually_ge_atTop 1] with N hL hU
  let L := Real.log (N : ℝ)
  let U := Real.log L
  have hL₀ : 0 ≤ L := zero_le_one.trans hL
  have hU₀ : 0 ≤ U := zero_le_one.trans hU
  have hLogU₀ : 0 ≤ Real.log U := Real.log_nonneg hU
  constructor
  · intro C D hCD
    change U ^ 2 / (2 * L) + C * U * Real.log U / L ≤
      U ^ 2 / (2 * L) + D * U * Real.log U / L
    exact add_le_add le_rfl (div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hCD hU₀) hLogU₀) hL₀)
  · intro C D hCD
    change U ^ 2 / (2 * L) - D * U / L ≤ U ^ 2 / (2 * L) - C * U / L
    exact sub_le_sub_left (div_le_div_of_nonneg_right
      (mul_le_mul_of_nonneg_right hCD hU₀) hL₀) _

/-- The sharp baseline floors, the two possible unit counts, and all represented
integers up to the maximum. -/
theorem eventually_unit_and_integer_initial_segment :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      ⌊(harmonic N : ℝ) - sufficientLoss N C⌋ ≤ (k N : ℤ) ∧
      k N ≤ h N ∧
      (h N : ℤ) ≤ ⌊(harmonic N : ℝ) - necessaryLoss N C⌋ ∧
      ((k N : ℤ) = ⌊(harmonic N : ℝ)⌋ - 1 ∨ (k N : ℤ) = ⌊(harmonic N : ℝ)⌋) ∧
      representedIntegers N = range (h N + 1) := by
  obtain ⟨Cminus,Cplus,hCminus,_,h⟩ :=
    eventually_unit_and_integer_initial_segment_of_sufficiency packingSufficiency
  let C := max Cminus Cplus
  refine ⟨C,hCminus.trans_le (le_max_left _ _),?_⟩
  filter_upwards [h, eventually_baseline_loss_monotonicity] with N hN hMono
  rw [mass_interval_one_eq_harmonic] at hN
  exact ⟨(Int.floor_mono (sub_le_sub_left (hMono.1 (le_max_right _ _)) _)).trans hN.1,
    k_le_h N,
    hN.2.1.trans (Int.floor_mono (sub_le_sub_left (hMono.2 (le_max_left _ _)) _)),
    hN.2.2.1, hN.2.2.2⟩


end LeanAB.PaperB

namespace LeanAB.PaperB.FixedTargets

/-- The fixed-target floor matching and its per-group length bound. -/
theorem eventually_fixed_matching_floor {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      let m := ⌊((targetStock r N : ℝ) - sufficientLoss N C) / (r : ℝ)⌋₊
      ∃ F, IsMatching (edges 2 N r) F ∧ F.card = m ∧
        ∀ S ∈ F, (S.card : ℝ) ≤
          max 1 (packingLength N C (r : ℝ) (((m - 1 : ℕ) : ℝ) * (r : ℝ))) :=
  eventually_fixed_matching_floor_of_sufficiency packingSufficiency hr

/-- The fixed-target inverse height with its actual existence proof. -/
theorem eventually_fixedHeight_log {r : ℚ} (hr : 0 < r) :
    ∃ F : ℝ, 0 < F ∧ ∀ᶠ j : ℕ in atTop,
      let N := fixedHeight r j (exists_fixed_height_of_sufficiency packingSufficiency hr j)
      |Real.log (N : ℝ) - ((r : ℝ) * j +
        (mass (interval 1 (targetCutoff r - 1)) : ℝ) - Real.eulerMascheroniConstant +
        Real.log (j : ℝ) ^ 2 / (2 * (r : ℝ) * j))| ≤
        F * (Real.log (j : ℝ) * Real.log (Real.log (j : ℝ)) / (j : ℝ)) :=
  eventually_fixedHeight_log_of_sufficiency packingSufficiency hr
    (exists_fixed_height_of_sufficiency packingSufficiency hr)

/-- The two floor bounds at the manuscript's uniform length threshold. -/
theorem eventually_boundedPacking_floors {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop, ∀ K : ℕ,
      (r : ℝ) * (N : ℝ) / Real.log N + C * (N : ℝ) / (Real.log N) ^ 2 ≤ K →
      ⌊((targetStock r N : ℝ) - sufficientLoss N C) / (r : ℝ)⌋ ≤
        (boundedPackingNumber r K N : ℤ) ∧
      (boundedPackingNumber r K N : ℤ) ≤
        ⌊((targetStock r N : ℝ) - necessaryLoss N C) / (r : ℝ)⌋ :=
  eventually_boundedPacking_floors_of_sufficiency packingSufficiency hr

/-- Two-sided matching estimate uniform in the length and height. -/
theorem eventually_boundedPacking_uniform {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∃ N₀ : ℕ, 1 ≤ N₀ ∧
      ∀ᶠ K : ℕ in atTop, ∀ N : ℕ, N₀ ≤ N →
        |(boundedPackingNumber r K N : ℝ) * (r : ℝ) -
          Real.log (min (N : ℝ) ((K : ℝ) * Real.log (K : ℝ)))| ≤ C :=
  eventually_boundedPacking_uniform_of_sufficiency packingSufficiency hr

/-- Matching with a length bound and no height restriction. -/
theorem eventually_lengthPackingNumber {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ K : ℕ in atTop,
      |(lengthPackingNumber r K : ℝ) * (r : ℝ) -
        (Real.log (K : ℝ) + Real.log (Real.log (K : ℝ)))| ≤ C :=
  eventually_lengthPackingNumber_of_sufficiency packingSufficiency hr


/-- The fixed-target floors with one constant and a length-controlled matching
attaining the lower floor. -/
theorem eventually_fixedPacking_floors {r : ℚ} (hr : 0 < r) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ N : ℕ in atTop,
      let W := (targetStock r N : ℝ)
      let m := ⌊(W - sufficientLoss N C) / (r : ℝ)⌋
      m ≤ (fixedPackingNumber r N : ℤ) ∧
      (fixedPackingNumber r N : ℤ) ≤ ⌊(W - necessaryLoss N C) / (r : ℝ)⌋ ∧
      ∃ F, IsMatching (edges 2 N r) F ∧ (F.card : ℤ) = m ∧
        ∀ S ∈ F, (S.card : ℝ) ≤
          (r : ℝ) * (N : ℝ) / Real.log (N : ℝ) + C * (N : ℝ) / Real.log (N : ℝ) ^ 2 := by
  obtain ⟨Cminus,_,hUpper⟩ := eventually_fixedPacking_upper hr
  obtain ⟨Cplus,hCplus,hFamily⟩ := eventually_fixed_matching_floor hr
  obtain ⟨D,hD,hLen⟩ := eventually_fixed_length_scale hr Cplus hCplus.le
  obtain ⟨E,_,hStock⟩ := eventually_abs_targetStock_sub_log_le r
  let C := max (max Cminus Cplus) D
  have hMinus : Cminus ≤ C := (le_max_left _ _).trans (le_max_left _ _)
  have hPlus : Cplus ≤ C := (le_max_right _ _).trans (le_max_left _ _)
  have hDle : D ≤ C := le_max_right _ _
  have hC : 0 < C := hD.trans_le hDle
  have hr₀ : (0 : ℝ) < r := by exact_mod_cast hr
  have hLog : Tendsto (fun N : ℕ => Real.log (N : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  refine ⟨C,hC,?_⟩
  filter_upwards [hUpper, hFamily, hLen, hStock, hLog.eventually_ge_atTop (E + 1),
    eventually_losses_between_zero_one 0 C le_rfl hC.le, eventually_baseline_loss_monotonicity]
    with N hUpper hFamily hLen hStock hLog hSmall hMono
  let W := (targetStock r N : ℝ)
  let x := (W - sufficientLoss N C) / (r : ℝ)
  let y := (W - sufficientLoss N Cplus) / (r : ℝ)
  have hx : 0 ≤ x := by
    apply div_nonneg _ hr₀.le
    change |W - Real.log (N : ℝ)| ≤ E at hStock
    linarith only [(abs_le.mp hStock).1,hLog,hSmall.2.2]
  have hxy : x ≤ y := div_le_div_of_nonneg_right (sub_le_sub_left (hMono.1 hPlus) W) hr₀.le
  obtain ⟨F,hF,hCard,hFLen⟩ := hFamily
  have hSubCard : ⌊x⌋₊ ≤ F.card :=
    (Nat.floor_mono hxy).trans (show ⌊y⌋₊ ≤ F.card from hCard.ge)
  obtain ⟨G,hSub,hGCard⟩ := exists_subset_card_eq hSubCard
  have hG : IsMatching (edges 2 N r) G := ⟨hSub.trans hF.1, hF.2.subset hSub⟩
  have hCardZ : (G.card : ℤ) = ⌊x⌋ := by
    rw [hGCard, ← Int.floor_toNat, Int.toNat_of_nonneg (Int.floor_nonneg.mpr hx)]
  have hLower : G.card ≤ fixedPackingNumber r N :=
    (matchingNumber_spec (edges 2 N r)).2 ⟨G,hG,rfl⟩
  have hUpper' : (fixedPackingNumber r N : ℤ) ≤ ⌊(W - necessaryLoss N C) / (r : ℝ)⌋ :=
    hUpper.trans (Int.floor_mono
      (div_le_div_of_nonneg_right (sub_le_sub_left (hMono.2 hMinus) W) hr₀.le))
  change ⌊x⌋ ≤ (fixedPackingNumber r N : ℤ) ∧ _ ∧
    ∃ F, IsMatching (edges 2 N r) F ∧ (F.card : ℤ) = ⌊x⌋ ∧ _
  rw [← hCardZ]
  refine ⟨by exact_mod_cast hLower, hUpper', G, hG, rfl, fun S hS => ?_⟩
  apply ((hFLen S (hSub hS)).trans hLen).trans
  exact add_le_add le_rfl (div_le_div_of_nonneg_right
    (mul_le_mul_of_nonneg_right hDle (Nat.cast_nonneg _)) (sq_nonneg _))



/-- Every positive fixed factor in the height \(K\log K\) gives the same
two-term matching asymptotic, with an error depending on \(r\) and the factor. -/
theorem eventually_boundedPacking_at_fixed_length_height {r : ℚ} (hr : 0 < r)
    {c : ℝ} (hc : 0 < c) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ K : ℕ in atTop,
      let N := ⌊c * (K : ℝ) * Real.log (K : ℝ)⌋₊
      |(boundedPackingNumber r K N : ℝ) * (r : ℝ) -
        (Real.log (K : ℝ) + Real.log (Real.log (K : ℝ)))| ≤ C := by
  obtain ⟨C,hC,N₀,_,hUniform⟩ := eventually_boundedPacking_uniform hr
  let d := min (c / 2) 1
  have hd₀ : 0 < d := lt_min (half_pos hc) zero_lt_one
  have hd₁ : d ≤ 1 := min_le_right _ _
  have hLogD : Real.log d ≤ 0 := Real.log_nonpos hd₀.le hd₁
  refine ⟨C - Real.log d, by linarith only [hC,hLogD], ?_⟩
  have hNat : Tendsto (fun K : ℕ => (K : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hLog : Tendsto (fun K : ℕ => Real.log (K : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp hNat
  have hGrowth : Tendsto (fun K : ℕ => (K : ℝ) * Real.log (K : ℝ)) atTop atTop := by
    refine tendsto_atTop.2 fun z => ?_
    filter_upwards [hNat.eventually_ge_atTop z, hLog.eventually_ge_atTop 1] with K hz hK
    exact hz.trans (le_mul_of_one_le_right (Nat.cast_nonneg _) hK)
  filter_upwards [hUniform, hLog.eventually_ge_atTop 1, eventually_ge_atTop (1 : ℕ),
    hGrowth.eventually_ge_atTop (2 * max 1 (N₀ : ℝ) / c)] with K hUniform hL hK hGrowth
  let Z := (K : ℝ) * Real.log (K : ℝ)
  let N := ⌊c * (K : ℝ) * Real.log (K : ℝ)⌋₊
  let M := min (N : ℝ) Z
  have hK₀ : (0 : ℝ) < K := by exact_mod_cast Nat.succ_le_iff.mp hK
  have hL₀ : 0 < Real.log (K : ℝ) := zero_lt_one.trans_le hL
  have hZ : 0 < Z := mul_pos hK₀ hL₀
  have hHalf : max 1 (N₀ : ℝ) ≤ c * Z / 2 := by
    apply (le_div_iff₀ (by norm_num : (0 : ℝ) < 2)).mpr
    have h := (div_le_iff₀ hc).mp hGrowth
    change 2 * max 1 (N₀ : ℝ) ≤ Z * c at h
    linarith only [h]
  have hFloor : c * Z < (N : ℝ) + 1 := by
    dsimp only [Z,N]
    rw [← mul_assoc]
    exact Nat.lt_floor_add_one _
  have hLower : c * Z / 2 ≤ (N : ℝ) := by
    linarith only [hFloor, (le_max_left (1 : ℝ) (N₀ : ℝ)).trans hHalf]
  have hN : N₀ ≤ N := by exact_mod_cast (le_max_right (1 : ℝ) (N₀ : ℝ)).trans (hHalf.trans hLower)
  have hM₀ : d * Z ≤ M := by
    apply le_min
    · calc
        _ ≤ (c / 2) * Z := mul_le_mul_of_nonneg_right (min_le_left _ _) hZ.le
        _ = c * Z / 2 := by ring
        _ ≤ _ := hLower
    · simpa only [one_mul] using mul_le_mul_of_nonneg_right hd₁ hZ.le
  have hLogLow : Real.log d + Real.log Z ≤ Real.log M := by
    rw [← Real.log_mul hd₀.ne' hZ.ne']
    exact Real.log_le_log (mul_pos hd₀ hZ) hM₀
  have hLogHigh : Real.log M ≤ Real.log Z :=
    Real.log_le_log ((mul_pos hd₀ hZ).trans_le hM₀) (min_le_right _ _)
  have hDiff : |Real.log M - Real.log Z| ≤ -Real.log d :=
    abs_le.mpr ⟨by linarith only [hLogLow], by linarith only [hLogHigh,hLogD]⟩
  have hBound := hUniform N hN
  have hZlog : Real.log Z = Real.log (K : ℝ) + Real.log (Real.log (K : ℝ)) :=
    Real.log_mul hK₀.ne' hL₀.ne'
  change |(boundedPackingNumber r K N : ℝ) * (r : ℝ) -
    (Real.log (K : ℝ) + Real.log (Real.log (K : ℝ)))| ≤ _
  rw [← hZlog]
  calc
    _ = |((boundedPackingNumber r K N : ℝ) * (r : ℝ) - Real.log M) +
        (Real.log M - Real.log Z)| := by congr 1; ring
    _ ≤ _ := (abs_add_le _ _).trans (by simpa only [sub_eq_add_neg] using add_le_add hBound hDiff)


end LeanAB.PaperB.FixedTargets
