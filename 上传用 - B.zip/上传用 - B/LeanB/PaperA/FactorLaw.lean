module

public import PaperA.Eventual
public import PaperA.OutputLaw
import Mathlib.Tactic

public section

/-! The configuration law on the exactly decoded product support. -/

namespace LeanAB.PaperA

open Filter MeasureTheory
open scoped BigOperators

/-- The explicit hypotheses used by the finite decoding proof. -/
structure DecodeBounds (n K : ℕ) : Prop where
  square : ∀ p : blockPrimes n K, n < p.val * p.val
  small : ∀ p : blockPrimes n K, K < p.val
  narrow : ∀ p : blockPrimes n K, (Nat.lcmUpto K : ℚ) * harmonic K < (p.val : ℚ)

theorem eventually_decodeBounds : ∀ᶠ n : ℕ in atTop, DecodeBounds n (paperK n) := by
  filter_upwards [eventually_paperBlockBounds] with n h
  have bounds (p : blockPrimes n (paperK n)) := h p.val (mem_blockPrimes.mp p.property).2.2
  refine ⟨fun p => (bounds p).1, fun p => (bounds p).2.1, fun p => ?_⟩
  exact (mul_le_mul_of_nonneg_left (harmonic_le _) (Nat.cast_nonneg _)).trans_lt
    (by exact_mod_cast (bounds p).2.2)

/-- The option index includes the remainder as well as the prime blocks. -/
@[expose] def factorDomain (n K : ℕ) : Option (blockPrimes n K) → Finset ℕ
  | none => remainder n K
  | some p => interval 1 (n / p.val)

@[simp]
theorem factorDomain_none (n K : ℕ) : factorDomain n K none = remainder n K := rfl

@[simp]
theorem factorDomain_some (n K : ℕ) (p : blockPrimes n K) :
    factorDomain n K (some p) = interval 1 (n / p.val) := rfl

abbrev FactorOutput (n K m : ℕ) := ∀ j, Output (factorDomain n K j) m

private def separateFactors (n K m : ℕ) : FactorOutput n K m ≃ FactorSupport n K m where
  toFun x := (x none, fun p => x (some p))
  invFun x := fun j => match j with
    | none => x.1
    | some p => x.2 p
  left_inv x := by funext j; cases j <;> rfl
  right_inv _ := rfl

noncomputable def decodeOutputEquiv (n K m : ℕ) (h : DecodeBounds n K) :
    FactorOutput n K m ≃ Output (interval 1 n) m :=
  (separateFactors n K m).trans (supportEquiv n K m h.square h.small h.narrow)

theorem decodeOutputEquiv_apply (n K m : ℕ) (h : DecodeBounds n K) (x : FactorOutput n K m) :
    (decodeOutputEquiv n K m h x).val =
      mergeOutput (x none).val (fun p => (x (some p)).val) :=
  supportEquiv_apply n K m h.square h.small h.narrow (separateFactors n K m x)

/-- Under exact decoding the output law is the dependent product of the factor laws. -/
theorem configurationLaw_decode (n K m : ℕ) (h : DecodeBounds n K) :
    (FiniteLaw.pi (fun j => configurationLaw (factorDomain n K j) m)).transport
      (decodeOutputEquiv n K m h) = configurationLaw (interval 1 n) m := by
  apply FiniteLaw.ext
  intro y
  let e := decodeOutputEquiv n K m h
  let x := e.symm y
  have hy : e x = y := e.apply_symm_apply y
  rw [← hy, FiniteLaw.weight_transport, e.symm_apply_apply, FiniteLaw.weight_pi,
    configurationLaw_weight, decodeOutputEquiv_apply, Fintype.prod_option]
  have hh := congrArg (fun a : ℚ => (a : ℝ))
    (probability_mul n K m h.square h.small h.narrow (separateFactors n K m x))
  push_cast at hh
  simpa only [configurationLaw, factorDomain_none, factorDomain_some, separateFactors,
    Equiv.coe_fn_mk] using hh.symm

theorem configurationLaw_hartley (E : Finset ℕ) (m : ℕ) :
    (configurationLaw E m).hartley = supportEntropy E m := by
  unfold FiniteLaw.hartley supportEntropy
  change _ = Real.log (Nat.card (Output E m) : ℝ)
  rw [Nat.card_eq_fintype_card]

theorem configurationLaw_information_decode (n K m : ℕ) (h : DecodeBounds n K)
    (x : FactorOutput n K m) :
    (configurationLaw (interval 1 n) m).information (decodeOutputEquiv n K m h x) =
      (configurationLaw (remainder n K) m).information (x none) +
        ∑ p : blockPrimes n K,
          (configurationLaw (interval 1 (n / p.val)) m).information (x (some p)) := by
  rw [← configurationLaw_decode n K m h, FiniteLaw.information_transport,
    Equiv.symm_apply_apply, FiniteLaw.information_pi, Fintype.sum_option]
  rfl

theorem configurationLaw_shannon_decode (n K m : ℕ) (h : DecodeBounds n K) :
    (configurationLaw (interval 1 n) m).shannon =
      (configurationLaw (remainder n K) m).shannon +
        ∑ p : blockPrimes n K, (configurationLaw (interval 1 (n / p.val)) m).shannon := by
  rw [← configurationLaw_decode n K m h, FiniteLaw.shannon_transport, FiniteLaw.shannon_pi,
    Fintype.sum_option]
  rfl


theorem configurationLaw_renyi_decode (n K m : ℕ) (h : DecodeBounds n K) (a : RenyiOrder) :
    (configurationLaw (interval 1 n) m).renyi a =
      (configurationLaw (remainder n K) m).renyi a +
        ∑ p : blockPrimes n K, (configurationLaw (interval 1 (n / p.val)) m).renyi a := by
  rw [← configurationLaw_decode n K m h, FiniteLaw.renyi_transport, FiniteLaw.renyi_pi,
    Fintype.sum_option]
  rfl

theorem configurationLaw_measure_decode (n K m : ℕ) (h : DecodeBounds n K) :
    (configurationLaw (interval 1 n) m).measure =
      (Measure.pi (fun j => (configurationLaw (factorDomain n K j) m).measure)).map
        (decodeOutputEquiv n K m h) := by
  rw [← configurationLaw_decode n K m h, FiniteLaw.measure_transport, FiniteLaw.measure_pi]

end LeanAB.PaperA
