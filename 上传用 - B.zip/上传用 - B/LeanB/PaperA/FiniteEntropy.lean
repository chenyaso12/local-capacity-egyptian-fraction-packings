module

public import Mathlib.Analysis.SpecialFunctions.Pow.Real
public import Mathlib.Analysis.SpecialFunctions.Log.Deriv
public import Mathlib.Algebra.BigOperators.Ring.Finset
public import Mathlib.Data.Fintype.BigOperators
public import Mathlib.Analysis.Convex.Function
public import Mathlib.Basic.NNReal.Basic
public import Mathlib.Logic.Equiv.Prod
import Mathlib.Analysis.Convex.Jensen
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Analysis.Convex.SpecificFunctions.Pow
import Mathlib.Analysis.Convex.Slope
import Mathlib.Tactic

@[expose] public section

/-! Rényi entropies and information on the positive support of a finite law. -/

open scoped BigOperators NNReal

namespace LeanAB.PaperA

/-- A probability law indexed by its finite positive support. -/
structure FiniteLaw (Ω : Type*) [Fintype Ω] where
  weight : Ω → ℝ
  positive : ∀ x, 0 < weight x
  sum_weight : ∑ x, weight x = 1

namespace FiniteLaw

variable {Ω Ξ : Type*} [Fintype Ω] [Fintype Ξ]

@[ext]
theorem ext {P Q : FiniteLaw Ω} (h : ∀ x, P.weight x = Q.weight x) : P = Q := by
  cases P
  cases Q
  congr 1
  exact funext h

theorem nonempty (P : FiniteLaw Ω) : Nonempty Ω := by
  by_contra h
  have _ : IsEmpty Ω := not_nonempty_iff.mp h
  have heq := P.sum_weight
  simp at heq

theorem weight_le_one (P : FiniteLaw Ω) (x : Ω) : P.weight x ≤ 1 :=
  P.sum_weight ▸ Finset.single_le_sum (fun y _ => (P.positive y).le) (Finset.mem_univ x)

/-- Information of one atom of the positive support. -/
noncomputable def information (P : FiniteLaw Ω) (x : Ω) : ℝ := -Real.log (P.weight x)

theorem information_nonneg (P : FiniteLaw Ω) (x : Ω) : 0 ≤ P.information x :=
  neg_nonneg.mpr (Real.log_nonpos (P.positive x).le (P.weight_le_one x))

/-- Shannon entropy, computed only on atoms of positive mass. -/
noncomputable def shannon (P : FiniteLaw Ω) : ℝ := ∑ x, P.weight x * P.information x

/-- Hartley entropy, the logarithm of the positive support size. -/
noncomputable def hartley (_P : FiniteLaw Ω) : ℝ := Real.log (Fintype.card Ω : ℝ)

theorem shannon_nonneg (P : FiniteLaw Ω) : 0 ≤ P.shannon :=
  Finset.sum_nonneg fun x _ => mul_nonneg (P.positive x).le (P.information_nonneg x)

theorem shannon_le_hartley (P : FiniteLaw Ω) : P.shannon ≤ P.hartley := by
  have h := strictConcaveOn_log_Ioi.concaveOn.le_map_sum
    (t := Finset.univ) (w := P.weight) (p := fun x => (P.weight x)⁻¹)
    (fun x _ => (P.positive x).le) P.sum_weight (fun x _ => inv_pos.mpr (P.positive x))
  have hsum : (∑ x, P.weight x * (P.weight x)⁻¹) = (Fintype.card Ω : ℝ) := by
    simp [fun x => (P.positive x).ne']
  simpa [shannon, hartley, information, smul_eq_mul, Real.log_inv, hsum] using h

/-- Rename the positive support along a bijection. -/
noncomputable def transport (P : FiniteLaw Ω) (e : Ω ≃ Ξ) : FiniteLaw Ξ where
  weight := fun y => P.weight (e.symm y)
  positive := fun _ => P.positive _
  sum_weight := (e.symm.sum_comp P.weight).trans P.sum_weight

@[simp]
theorem weight_transport (P : FiniteLaw Ω) (e : Ω ≃ Ξ) (y : Ξ) :
    (P.transport e).weight y = P.weight (e.symm y) := rfl

@[simp]
theorem information_transport (P : FiniteLaw Ω) (e : Ω ≃ Ξ) (y : Ξ) :
    (P.transport e).information y = P.information (e.symm y) := rfl

@[simp]
theorem shannon_transport (P : FiniteLaw Ω) (e : Ω ≃ Ξ) :
    (P.transport e).shannon = P.shannon := by
  simpa only [shannon, weight_transport, information_transport] using
    e.symm.sum_comp (fun x => P.weight x * P.information x)

@[simp]
theorem hartley_transport (P : FiniteLaw Ω) (e : Ω ≃ Ξ) :
    (P.transport e).hartley = P.hartley := by
  simp only [hartley, Fintype.card_congr e]

/-- Independent product law. -/
noncomputable def prod (P : FiniteLaw Ω) (Q : FiniteLaw Ξ) : FiniteLaw (Ω × Ξ) where
  weight := fun xy => P.weight xy.1 * Q.weight xy.2
  positive := fun xy => mul_pos (P.positive xy.1) (Q.positive xy.2)
  sum_weight := by
    simp only [Fintype.sum_prod_type, ← Finset.mul_sum, Q.sum_weight, mul_one, P.sum_weight]

@[simp]
theorem weight_prod (P : FiniteLaw Ω) (Q : FiniteLaw Ξ) (xy : Ω × Ξ) :
    (P.prod Q).weight xy = P.weight xy.1 * Q.weight xy.2 := rfl

@[simp]
theorem information_prod (P : FiniteLaw Ω) (Q : FiniteLaw Ξ) (xy : Ω × Ξ) :
    (P.prod Q).information xy = P.information xy.1 + Q.information xy.2 := by
  rw [information, weight_prod, Real.log_mul (P.positive _).ne' (Q.positive _).ne']
  simp only [information, neg_add_rev, add_comm]

@[simp]
theorem shannon_prod (P : FiniteLaw Ω) (Q : FiniteLaw Ξ) :
    (P.prod Q).shannon = P.shannon + Q.shannon := by
  simp only [shannon, Fintype.sum_prod_type, weight_prod, information_prod]
  calc
    _ = ∑ x, ∑ y, ((P.weight x * P.information x) * Q.weight y +
        P.weight x * (Q.weight y * Q.information y)) := by
      exact Finset.sum_congr rfl fun x _ => Finset.sum_congr rfl fun y _ => by ring
    _ = _ := by
      simp only [Finset.sum_add_distrib, ← Finset.mul_sum, Q.sum_weight, mul_one]
      rw [← Finset.sum_mul, P.sum_weight, one_mul]

@[simp]
theorem hartley_prod (P : FiniteLaw Ω) (Q : FiniteLaw Ξ) :
    (P.prod Q).hartley = P.hartley + Q.hartley := by
  have _ : Nonempty Ω := P.nonempty
  have _ : Nonempty Ξ := Q.nonempty
  simp only [hartley, Fintype.card_prod, Nat.cast_mul]
  exact Real.log_mul (by positivity) (by positivity)

section Pi

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {Ωs : ι → Type*} [∀ i, Fintype (Ωs i)]

/-- Independent law for a finite indexed family. The empty product has unit mass. -/
noncomputable def pi (P : ∀ i, FiniteLaw (Ωs i)) : FiniteLaw (∀ i, Ωs i) where
  weight := fun x => ∏ i, (P i).weight (x i)
  positive := fun x => Finset.prod_pos fun i _ => (P i).positive (x i)
  sum_weight := by rw [← Fintype.prod_sum]; simp only [sum_weight, Finset.prod_const_one]

@[simp]
theorem weight_pi (P : ∀ i, FiniteLaw (Ωs i)) (x : ∀ i, Ωs i) :
    (pi P).weight x = ∏ i, (P i).weight (x i) := rfl

@[simp]
theorem information_pi (P : ∀ i, FiniteLaw (Ωs i)) (x : ∀ i, Ωs i) :
    (pi P).information x = ∑ i, (P i).information (x i) := by
  simp only [information, weight_pi, Real.log_prod (fun i _ => (P i).positive _ |>.ne'),
    Finset.sum_neg_distrib]

/-- Taking an expectation of one coordinate under the independent product. -/
theorem sum_pi_mul_apply (P : ∀ i, FiniteLaw (Ωs i)) (j : ι) (f : Ωs j → ℝ) :
    ∑ x, (pi P).weight x * f (x j) = ∑ y, (P j).weight y * f y := by
  classical
  let e := Equiv.piSplitAt j Ωs
  let Q : FiniteLaw (∀ i : {i // i ≠ j}, Ωs i) :=
    pi fun i => P i
  have hw (x : ∀ i, Ωs i) : (pi P).weight x = ((P j).prod Q).weight (e x) := by
    change (∏ i, (P i).weight (x i)) = (P j).weight (x j) *
      ∏ i : {i // i ≠ j}, (P i).weight (x i)
    rw [← Finset.prod_subtype (Finset.univ.erase j) (fun i => by simp)
      (fun i => (P i).weight (x i))]
    exact (Finset.mul_prod_erase _ _ (Finset.mem_univ j)).symm
  calc
    _ = ∑ x, ((P j).prod Q).weight (e x) * f (e x).1 := by
      exact Finset.sum_congr rfl fun x _ => congrArg (fun w => w * f (x j)) (hw x)
    _ = ∑ xy, ((P j).prod Q).weight xy * f xy.1 :=
      e.sum_comp (fun xy => ((P j).prod Q).weight xy * f xy.1)
    _ = _ := by
      simp only [Fintype.sum_prod_type, weight_prod]
      simp_rw [mul_right_comm ((P j).weight _), ← Finset.mul_sum, Q.sum_weight, mul_one]

@[simp]
theorem shannon_pi (P : ∀ i, FiniteLaw (Ωs i)) :
    (pi P).shannon = ∑ i, (P i).shannon := by
  simp only [shannon, information_pi, Finset.mul_sum]
  rw [Finset.sum_comm]
  exact Finset.sum_congr rfl fun i _ => sum_pi_mul_apply P i (P i).information

@[simp]
theorem hartley_pi (P : ∀ i, FiniteLaw (Ωs i)) :
    (pi P).hartley = ∑ i, (P i).hartley := by
  have _ (i : ι) : Nonempty (Ωs i) := (P i).nonempty
  simp only [hartley, Fintype.card_pi, Nat.cast_prod]
  exact Real.log_prod (fun i _ => by positivity)

end Pi


/-- Maximum atom weight on the positive support. -/
noncomputable def maxWeight (P : FiniteLaw Ω) : ℝ :=
  Finset.univ.sup' (Finset.univ_nonempty_iff.mpr P.nonempty) P.weight

theorem weight_le_maxWeight (P : FiniteLaw Ω) (x : Ω) : P.weight x ≤ P.maxWeight :=
  Finset.le_sup' P.weight (Finset.mem_univ x)

theorem maxWeight_le (P : FiniteLaw Ω) {M : ℝ} (hM : ∀ x, P.weight x ≤ M) :
    P.maxWeight ≤ M :=
  Finset.sup'_le _ _ fun x _ => hM x

theorem exists_weight_eq_maxWeight (P : FiniteLaw Ω) : ∃ x, P.weight x = P.maxWeight := by
  obtain ⟨x, _, hx⟩ := Finset.exists_mem_eq_sup'
    (H := Finset.univ_nonempty_iff.mpr P.nonempty) P.weight
  exact ⟨x, hx.symm⟩

theorem maxWeight_pos (P : FiniteLaw Ω) : 0 < P.maxWeight := by
  obtain ⟨x, hx⟩ := P.exists_weight_eq_maxWeight
  rw [← hx]
  exact P.positive x

theorem maxWeight_le_one (P : FiniteLaw Ω) : P.maxWeight ≤ 1 :=
  P.maxWeight_le P.weight_le_one

theorem maxWeight_lt_one (P : FiniteLaw Ω) (h : ∃ x y : Ω, x ≠ y) : P.maxWeight < 1 := by
  classical
  obtain ⟨x, hx⟩ := P.exists_weight_eq_maxWeight
  obtain ⟨a, b, hab⟩ := h
  have ⟨y, hxy⟩ : ∃ y, x ≠ y := by
    by_cases ha : x = a
    · exact ⟨b, ha ▸ hab⟩
    · exact ⟨a, ha⟩
  have hsum : P.weight x + P.weight y ≤ 1 := by
    rw [← Finset.sum_pair hxy, ← P.sum_weight]
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) fun z _ _ =>
      (P.positive z).le
  linarith [P.positive y]

/-- Min-entropy of the finite law. -/
noncomputable def minEntropy (P : FiniteLaw Ω) : ℝ := -Real.log P.maxWeight

theorem minEntropy_nonneg (P : FiniteLaw Ω) : 0 ≤ P.minEntropy :=
  neg_nonneg.mpr (Real.log_nonpos P.maxWeight_pos.le P.maxWeight_le_one)

theorem minEntropy_pos (P : FiniteLaw Ω) (h : ∃ x y : Ω, x ≠ y) : 0 < P.minEntropy :=
  neg_pos.mpr (Real.log_neg P.maxWeight_pos (P.maxWeight_lt_one h))

@[simp]
theorem maxWeight_transport (P : FiniteLaw Ω) (e : Ω ≃ Ξ) :
    (P.transport e).maxWeight = P.maxWeight := by
  apply le_antisymm
  · exact maxWeight_le _ fun y => P.weight_le_maxWeight (e.symm y)
  · apply maxWeight_le
    intro x
    simpa using (P.transport e).weight_le_maxWeight (e x)

@[simp]
theorem minEntropy_transport (P : FiniteLaw Ω) (e : Ω ≃ Ξ) :
    (P.transport e).minEntropy = P.minEntropy := by
  simp only [minEntropy, maxWeight_transport]

@[simp]
theorem maxWeight_prod (P : FiniteLaw Ω) (Q : FiniteLaw Ξ) :
    (P.prod Q).maxWeight = P.maxWeight * Q.maxWeight := by
  apply le_antisymm
  · apply maxWeight_le
    intro xy
    rw [weight_prod]
    exact mul_le_mul (P.weight_le_maxWeight xy.1) (Q.weight_le_maxWeight xy.2)
      (Q.positive _).le P.maxWeight_pos.le
  · obtain ⟨x, hx⟩ := P.exists_weight_eq_maxWeight
    obtain ⟨y, hy⟩ := Q.exists_weight_eq_maxWeight
    rw [← hx, ← hy, ← weight_prod P Q (x, y)]
    exact (P.prod Q).weight_le_maxWeight _

@[simp]
theorem minEntropy_prod (P : FiniteLaw Ω) (Q : FiniteLaw Ξ) :
    (P.prod Q).minEntropy = P.minEntropy + Q.minEntropy := by
  simp only [minEntropy, maxWeight_prod, Real.log_mul P.maxWeight_pos.ne' Q.maxWeight_pos.ne',
    neg_add_rev, add_comm]

/-- The real power sum on the positive support. -/
noncomputable def powerSum (P : FiniteLaw Ω) (a : ℝ) : ℝ := ∑ x, P.weight x ^ a

@[simp]
theorem powerSum_zero (P : FiniteLaw Ω) : P.powerSum 0 = Fintype.card Ω := by
  simp [powerSum]

@[simp]
theorem powerSum_one (P : FiniteLaw Ω) : P.powerSum 1 = 1 := by
  simp only [powerSum, Real.rpow_one, P.sum_weight]

theorem powerSum_pos (P : FiniteLaw Ω) (a : ℝ) : 0 < P.powerSum a := by
  have _ : Nonempty Ω := P.nonempty
  exact Finset.sum_pos (fun x _ => Real.rpow_pos_of_pos (P.positive x) a) Finset.univ_nonempty

@[simp]
theorem powerSum_transport (P : FiniteLaw Ω) (e : Ω ≃ Ξ) (a : ℝ) :
    (P.transport e).powerSum a = P.powerSum a :=
  e.symm.sum_comp (fun x => P.weight x ^ a)

@[simp]
theorem powerSum_prod (P : FiniteLaw Ω) (Q : FiniteLaw Ξ) (a : ℝ) :
    (P.prod Q).powerSum a = P.powerSum a * Q.powerSum a := by
  simp only [powerSum, Fintype.sum_prod_type, weight_prod]
  calc
    _ = ∑ x, ∑ y, P.weight x ^ a * Q.weight y ^ a := by
      exact Finset.sum_congr rfl fun x _ =>
        Finset.sum_congr rfl fun y _ => Real.mul_rpow (P.positive x).le (Q.positive y).le
    _ = _ := by simp only [← Finset.mul_sum, ← Finset.sum_mul]

section Pi

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {Ωs : ι → Type*} [∀ i, Fintype (Ωs i)]

@[simp]
theorem maxWeight_pi (P : ∀ i, FiniteLaw (Ωs i)) :
    (pi P).maxWeight = ∏ i, (P i).maxWeight := by
  classical
  apply le_antisymm
  · exact maxWeight_le _ fun x => Finset.prod_le_prod₀
      (fun i _ => ((P i).positive _).le) (fun i _ => (P i).weight_le_maxWeight _)
  · choose x hx using fun i => (P i).exists_weight_eq_maxWeight
    rw [← (show (pi P).weight x = ∏ i, (P i).maxWeight from Finset.prod_congr rfl fun i _ => hx i)]
    exact (pi P).weight_le_maxWeight x

@[simp]
theorem minEntropy_pi (P : ∀ i, FiniteLaw (Ωs i)) :
    (pi P).minEntropy = ∑ i, (P i).minEntropy := by
  simp only [minEntropy, maxWeight_pi, Real.log_prod
    (fun i _ => (P i).maxWeight_pos.ne'), Finset.sum_neg_distrib]

@[simp]
theorem powerSum_pi (P : ∀ i, FiniteLaw (Ωs i)) (a : ℝ) :
    (pi P).powerSum a = ∏ i, (P i).powerSum a := by
  unfold powerSum
  rw [Fintype.prod_sum]
  refine Finset.sum_congr rfl fun x _ => ?_
  have hp (i : ι) := (P i).positive (x i)
  rw [weight_pi, Real.rpow_def_of_pos (Finset.prod_pos fun i _ => hp i),
    Real.log_prod (fun i _ => (hp i).ne'), Finset.sum_mul, Real.exp_sum]
  exact Finset.prod_congr rfl fun i _ => (Real.rpow_def_of_pos (hp i) a).symm

end Pi

end FiniteLaw

/-- Rényi orders are nonnegative reals with a separate point at infinity. -/
abbrev RenyiOrder := WithTop ℝ≥0

namespace FiniteLaw

variable {Ω Ξ : Type*} [Fintype Ω] [Fintype Ξ]

/-- Rényi entropy on the positive support, with explicit endpoint conventions. -/
noncomputable def renyi (P : FiniteLaw Ω) : RenyiOrder → ℝ :=
  WithTop.recTopCoe P.minEntropy fun a =>
    if a = 0 then P.hartley
    else if a = 1 then P.shannon
    else Real.log (P.powerSum a) / (1 - (a : ℝ))

@[simp] theorem renyi_top (P : FiniteLaw Ω) : P.renyi ⊤ = P.minEntropy := by simp [renyi]

@[simp] theorem renyi_zero (P : FiniteLaw Ω) : P.renyi 0 = P.hartley := by
  change (if (0 : ℝ≥0) = 0 then P.hartley else _) = _
  simp

@[simp] theorem renyi_one (P : FiniteLaw Ω) : P.renyi 1 = P.shannon := by
  change (if (1 : ℝ≥0) = 0 then P.hartley else if (1 : ℝ≥0) = 1 then P.shannon else _) = _
  simp

theorem renyi_coe_of_ne_one (P : FiniteLaw Ω) {a : ℝ≥0} (ha : a ≠ 1) :
    P.renyi (a : RenyiOrder) = Real.log (P.powerSum a) / (1 - (a : ℝ)) := by
  change (if a = 0 then P.hartley else if a = 1 then P.shannon else _) = _
  by_cases h : a = 0
  · subst a
    simp [hartley]
  · simp only [h, ha, ite_false]

@[simp]
theorem renyi_transport (P : FiniteLaw Ω) (e : Ω ≃ Ξ) (a : RenyiOrder) :
    (P.transport e).renyi a = P.renyi a := by
  cases a using WithTop.recTopCoe with
  | top => simp only [renyi_top, minEntropy_transport]
  | coe a =>
    by_cases ha : a = 1
    · subst a; simp
    · rw [renyi_coe_of_ne_one _ ha, renyi_coe_of_ne_one _ ha, powerSum_transport]

@[simp]
theorem renyi_prod (P : FiniteLaw Ω) (Q : FiniteLaw Ξ) (a : RenyiOrder) :
    (P.prod Q).renyi a = P.renyi a + Q.renyi a := by
  cases a using WithTop.recTopCoe with
  | top => simp only [renyi_top, minEntropy_prod]
  | coe a =>
    by_cases ha : a = 1
    · subst a; simp
    · simp_rw [renyi_coe_of_ne_one _ ha, powerSum_prod,
        Real.log_mul (P.powerSum_pos _).ne' (Q.powerSum_pos _).ne', add_div]

section Pi

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {Ωs : ι → Type*} [∀ i, Fintype (Ωs i)]

@[simp]
theorem renyi_pi (P : ∀ i, FiniteLaw (Ωs i)) (a : RenyiOrder) :
    (pi P).renyi a = ∑ i, (P i).renyi a := by
  cases a using WithTop.recTopCoe with
  | top => simp only [renyi_top, minEntropy_pi]
  | coe a =>
    by_cases ha : a = 1
    · subst a; simp
    · simp_rw [renyi_coe_of_ne_one _ ha, powerSum_pi,
        Real.log_prod (fun i _ => ((P i).powerSum_pos _).ne'), Finset.sum_div]

end Pi


/-- The logarithm of the power sum is the function whose secants give Rényi entropy. -/
noncomputable def logPowerSum (P : FiniteLaw Ω) (a : ℝ) : ℝ := Real.log (P.powerSum a)

@[simp] theorem logPowerSum_one (P : FiniteLaw Ω) : P.logPowerSum 1 = 0 := by
  simp [logPowerSum]

/-- The normalized atom weights tilted by an arbitrary real exponent. -/
noncomputable def tiltedWeight (P : FiniteLaw Ω) (u : ℝ) (x : Ω) : ℝ :=
  P.weight x ^ u / P.powerSum u

private theorem tiltedWeight_pos (P : FiniteLaw Ω) (u : ℝ) (x : Ω) :
    0 < P.tiltedWeight u x :=
  div_pos (Real.rpow_pos_of_pos (P.positive x) u) (P.powerSum_pos u)

private theorem sum_tiltedWeight (P : FiniteLaw Ω) (u : ℝ) :
    ∑ x, P.tiltedWeight u x = 1 := by
  simp only [tiltedWeight, ← Finset.sum_div]
  exact div_self (P.powerSum_pos u).ne'


private theorem hasDerivAt_weightedPowerSum (P : FiniteLaw Ω) (g : Ω → ℝ) (t : ℝ) :
    HasDerivAt (fun u : ℝ => ∑ x, P.weight x ^ u * g x)
      (∑ x, (P.weight x ^ t * Real.log (P.weight x)) * g x) t := by
  refine HasDerivAt.fun_sum fun x _ => ?_
  have h := ((hasDerivAt_id t).const_mul (Real.log (P.weight x))).exp
  simpa only [id_eq, mul_one, Real.rpow_def_of_pos (P.positive x)] using h.mul_const (g x)

private theorem hasDerivAt_powerSum (P : FiniteLaw Ω) (t : ℝ) :
    HasDerivAt P.powerSum (∑ x, P.weight x ^ t * Real.log (P.weight x)) t := by
  change HasDerivAt (fun u : ℝ => ∑ x, P.weight x ^ u) _ t
  simpa only [mul_one] using P.hasDerivAt_weightedPowerSum (fun _ => 1) t

/-- The first derivative of the logarithmic power sum is the tilted mean of
the logarithms of the atom probabilities. -/
theorem hasDerivAt_logPowerSum (P : FiniteLaw Ω) (t : ℝ) :
    HasDerivAt P.logPowerSum (∑ x, P.tiltedWeight t x * Real.log (P.weight x)) t := by
  change HasDerivAt (fun u : ℝ => Real.log (P.powerSum u)) _ t
  simpa only [tiltedWeight, div_mul_eq_mul_div, Finset.sum_div] using
    (P.hasDerivAt_powerSum t).log (P.powerSum_pos t).ne'

/-- The derivative of the tilted mean is its second moment minus the square
of the mean. -/
theorem hasDerivAt_deriv_logPowerSum (P : FiniteLaw Ω) (t : ℝ) :
    HasDerivAt (deriv P.logPowerSum)
      ((∑ x, P.tiltedWeight t x * (Real.log (P.weight x)) ^ 2) -
        (∑ x, P.tiltedWeight t x * Real.log (P.weight x)) ^ 2) t := by
  have hFun : deriv P.logPowerSum =
      fun u => (∑ x, P.weight x ^ u * Real.log (P.weight x)) / P.powerSum u := by
    funext u
    rw [(P.hasDerivAt_logPowerSum u).deriv]
    simp only [tiltedWeight, div_mul_eq_mul_div, Finset.sum_div]
  rw [hFun]
  have h := (P.hasDerivAt_weightedPowerSum (fun x => Real.log (P.weight x)) t).div
    (P.hasDerivAt_powerSum t) (P.powerSum_pos t).ne'
  have hMoment :
      (∑ x, P.weight x ^ t * Real.log (P.weight x) * Real.log (P.weight x)) =
        ∑ x, P.weight x ^ t * (Real.log (P.weight x)) ^ 2 :=
    Finset.sum_congr rfl fun _ _ => by rw [pow_two, mul_assoc]
  rw [hMoment] at h
  convert h using 1
  simp only [tiltedWeight, div_mul_eq_mul_div, ← Finset.sum_div]
  field_simp [(P.powerSum_pos t).ne']

/-- V2's variance identity for the second derivative of the log power sum. -/
theorem deriv_deriv_logPowerSum_eq_tiltedVariance (P : FiniteLaw Ω) (t : ℝ) :
    deriv (deriv P.logPowerSum) t =
      ∑ x, P.tiltedWeight t x *
        (Real.log (P.weight x) - ∑ y, P.tiltedWeight t y * Real.log (P.weight y)) ^ 2 := by
  rw [(P.hasDerivAt_deriv_logPowerSum t).deriv]
  let m := ∑ y, P.tiltedWeight t y * Real.log (P.weight y)
  symm
  calc
    _ = ∑ x, (P.tiltedWeight t x * (Real.log (P.weight x)) ^ 2 -
        (P.tiltedWeight t x * Real.log (P.weight x)) * (2 * m) + P.tiltedWeight t x * m ^ 2) :=
      Finset.sum_congr rfl fun _ _ => by
        change _ * (_ - m) ^ 2 = _
        ring
    _ = _ := by
      rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.sum_mul, ← Finset.sum_mul,
        P.sum_tiltedWeight t, one_mul]
      change _ - m * (2 * m) + m ^ 2 = _ - m ^ 2
      ring

private theorem tiltedMoment (P : FiniteLaw Ω) (u v b : ℝ) :
    ∑ x, P.tiltedWeight u x * (P.weight x ^ (v - u)) ^ b =
      P.powerSum (u + (v - u) * b) / P.powerSum u := by
  rw [show P.powerSum (u + (v - u) * b) = ∑ x, P.weight x ^ (u + (v - u) * b) from rfl,
    Finset.sum_div]
  refine Finset.sum_congr rfl fun x _ => ?_
  rw [tiltedWeight, div_mul_eq_mul_div, ← Real.rpow_mul (P.positive x).le,
    ← Real.rpow_add (P.positive x)]

private theorem tiltedMean (P : FiniteLaw Ω) (u v : ℝ) :
    ∑ x, P.tiltedWeight u x * P.weight x ^ (v - u) =
      P.powerSum v / P.powerSum u := by
  have h := P.tiltedMoment u v 1
  simpa [show u + (v - u) = v by ring] using h

private theorem tiltedMoment_pos (P : FiniteLaw Ω) (u v b : ℝ) :
    0 < ∑ x, P.tiltedWeight u x * (P.weight x ^ (v - u)) ^ b := by
  rw [tiltedMoment]
  exact div_pos (P.powerSum_pos _) (P.powerSum_pos _)

private theorem convexLogSum_balance (P : FiniteLaw Ω) (u v a b : ℝ) (hab : a + b = 1) :
    Real.log ((∑ x, P.tiltedWeight u x * P.weight x ^ (v - u)) ^ b) -
      Real.log (∑ x, P.tiltedWeight u x * (P.weight x ^ (v - u)) ^ b) =
        a * P.logPowerSum u + b * P.logPowerSum v - P.logPowerSum (a * u + b * v) := by
  have harg : u + (v - u) * b = a * u + b * v := by linear_combination -u * hab
  rw [tiltedMean, tiltedMoment, harg, Real.log_rpow (div_pos (P.powerSum_pos _) (P.powerSum_pos _)),
    Real.log_div (P.powerSum_pos _).ne' (P.powerSum_pos _).ne',
    Real.log_div (P.powerSum_pos _).ne' (P.powerSum_pos _).ne']
  unfold logPowerSum
  linear_combination -Real.log (P.powerSum u) * hab

/-- Convexity of the logarithmic power sum, by Jensen on weights tilted at the left endpoint. -/
theorem convexOn_logPowerSum (P : FiniteLaw Ω) : ConvexOn ℝ Set.univ P.logPowerSum := by
  refine ⟨convex_univ, ?_⟩
  intro u _ v _ a b ha hb hab
  have h := (Real.concaveOn_rpow hb (by linarith)).le_map_sum
    (t := Finset.univ) (w := P.tiltedWeight u) (p := fun x => P.weight x ^ (v - u))
    (fun x _ => (P.tiltedWeight_pos u x).le) (P.sum_tiltedWeight u)
    (fun x _ => (Real.rpow_pos_of_pos (P.positive x) _).le)
  simp only [smul_eq_mul] at h ⊢
  exact sub_nonneg.mp <| (P.convexLogSum_balance u v a b hab) ▸
    sub_nonneg.mpr (Real.log_le_log (P.tiltedMoment_pos u v b) h)

/-- Nonuniform finite laws have strictly convex logarithmic power sums. -/
theorem strictConvexOn_logPowerSum (P : FiniteLaw Ω)
    (hn : ∃ x y, P.weight x ≠ P.weight y) : StrictConvexOn ℝ Set.univ P.logPowerSum := by
  refine ⟨convex_univ, ?_⟩
  intro u _ v _ huv a b ha hb hab
  obtain ⟨x, y, hxy⟩ := hn
  have hne : P.weight x ^ (v - u) ≠ P.weight y ^ (v - u) :=
    mt (Real.rpow_left_inj (P.positive x).le (P.positive y).le (sub_ne_zero.mpr huv.symm)).mp hxy
  have h := (Real.strictConcaveOn_rpow hb (by linarith)).lt_map_sum
    (t := Finset.univ) (w := P.tiltedWeight u) (p := fun z => P.weight z ^ (v - u))
    (fun z _ => P.tiltedWeight_pos u z) (P.sum_tiltedWeight u)
    (fun z _ => (Real.rpow_pos_of_pos (P.positive z) _).le)
    ⟨x, Finset.mem_univ x, y, Finset.mem_univ y, hne⟩
  simp only [smul_eq_mul] at h ⊢
  exact sub_pos.mp <| (P.convexLogSum_balance u v a b hab) ▸
    sub_pos.mpr (Real.log_lt_log (P.tiltedMoment_pos u v b) h)

private theorem momentAtOne (P : FiniteLaw Ω) (a : ℝ) :
    ∑ x, P.weight x * Real.exp ((a - 1) * Real.log (P.weight x)) = P.powerSum a := by
  unfold powerSum
  refine Finset.sum_congr rfl fun x _ => ?_
  rw [mul_comm (a - 1), ← Real.rpow_def_of_pos (P.positive x)]
  calc
    _ = P.weight x ^ (1 : ℝ) * P.weight x ^ (a - 1) := by rw [Real.rpow_one]
    _ = _ := by rw [← Real.rpow_add (P.positive x)]; congr 1; ring

private theorem shannon_scaled (P : FiniteLaw Ω) (a : ℝ) :
    ∑ x, P.weight x * ((a - 1) * Real.log (P.weight x)) = (1 - a) * P.shannon := by
  rw [shannon, Finset.mul_sum]
  exact Finset.sum_congr rfl fun x _ => by unfold information; ring

private theorem shannon_mul_le_logPowerSum (P : FiniteLaw Ω) (a : ℝ) :
    (1 - a) * P.shannon ≤ P.logPowerSum a := by
  have h := convexOn_exp.map_sum_le (t := Finset.univ) (w := P.weight)
    (p := fun x => (a - 1) * Real.log (P.weight x)) (fun x _ => (P.positive x).le)
    P.sum_weight (fun _ _ => Set.mem_univ _)
  simp only [smul_eq_mul, P.momentAtOne, P.shannon_scaled] at h
  exact Real.exp_le_exp.mp <| h.trans_eq (Real.exp_log (P.powerSum_pos a)).symm

private theorem shannon_mul_lt_logPowerSum (P : FiniteLaw Ω) (a : ℝ) (ha : a ≠ 1)
    (hn : ∃ x y, P.weight x ≠ P.weight y) : (1 - a) * P.shannon < P.logPowerSum a := by
  obtain ⟨x, y, hxy⟩ := hn
  have hne : (a - 1) * Real.log (P.weight x) ≠ (a - 1) * Real.log (P.weight y) := by
    intro h
    exact hxy (Real.log_injOn_pos (P.positive x) (P.positive y)
      (mul_left_cancel₀ (sub_ne_zero.mpr ha) h))
  have h := strictConvexOn_exp.map_sum_lt (t := Finset.univ) (w := P.weight)
    (p := fun z => (a - 1) * Real.log (P.weight z)) (fun z _ => P.positive z)
    P.sum_weight (fun _ _ => Set.mem_univ _)
    ⟨x, Finset.mem_univ x, y, Finset.mem_univ y, hne⟩
  simp only [smul_eq_mul, P.momentAtOne, P.shannon_scaled] at h
  exact Real.exp_lt_exp.mp <| h.trans_eq (Real.exp_log (P.powerSum_pos a)).symm

private theorem renyi_eq_neg_secant (P : FiniteLaw Ω) {a : ℝ≥0} (ha : a ≠ 1) :
    P.renyi (a : RenyiOrder) = -((P.logPowerSum a - P.logPowerSum 1) / ((a : ℝ) - 1)) := by
  rw [renyi_coe_of_ne_one _ ha, logPowerSum_one, sub_zero, logPowerSum,
    show 1 - (a : ℝ) = -((a : ℝ) - 1) by ring, div_neg]

private theorem renyi_finite_antitone (P : FiniteLaw Ω) {a b : ℝ≥0} (hab : a ≤ b) :
    P.renyi (b : RenyiOrder) ≤ P.renyi (a : RenyiOrder) := by
  rcases eq_or_lt_of_le hab with rfl | hab
  · exact le_rfl
  have hab' : (a : ℝ) < b := by exact_mod_cast hab
  by_cases ha : a = 1
  · subst a
    rw [WithTop.coe_one, renyi_one, renyi_coe_of_ne_one _ hab.ne']
    exact (div_le_iff_of_neg (by simpa using hab' : 1 - (b : ℝ) < 0)).2
      (by simpa only [mul_comm, logPowerSum] using P.shannon_mul_le_logPowerSum (b : ℝ))
  by_cases hb : b = 1
  · subst b
    rw [WithTop.coe_one, renyi_one, renyi_coe_of_ne_one _ ha]
    exact (le_div_iff₀ (by simpa using hab' : 0 < 1 - (a : ℝ))).2
      (by simpa only [mul_comm, logPowerSum] using P.shannon_mul_le_logPowerSum (a : ℝ))
  have ha' : (a : ℝ) ≠ 1 := by exact_mod_cast ha
  have hb' : (b : ℝ) ≠ 1 := by exact_mod_cast hb
  rw [renyi_eq_neg_secant _ ha, renyi_eq_neg_secant _ hb]
  exact neg_le_neg (P.convexOn_logPowerSum.secant_mono (Set.mem_univ _) (Set.mem_univ _)
    (Set.mem_univ _) ha' hb' hab'.le)

private theorem renyi_finite_strictAnti (P : FiniteLaw Ω) (hn : ∃ x y, P.weight x ≠ P.weight y)
    {a b : ℝ≥0} (hab : a < b) : P.renyi (b : RenyiOrder) < P.renyi (a : RenyiOrder) := by
  have hab' : (a : ℝ) < b := by exact_mod_cast hab
  by_cases ha : a = 1
  · subst a
    have hc : (b : ℝ) ≠ 1 := by exact_mod_cast hab.ne'
    rw [WithTop.coe_one, renyi_one, renyi_coe_of_ne_one _ hab.ne']
    exact (div_lt_iff_of_neg (by simpa using hab' : 1 - (b : ℝ) < 0)).2
      (by simpa only [mul_comm, logPowerSum] using P.shannon_mul_lt_logPowerSum (b : ℝ) hc hn)
  by_cases hb : b = 1
  · subst b
    have hc : (a : ℝ) ≠ 1 := by exact_mod_cast ha
    rw [WithTop.coe_one, renyi_one, renyi_coe_of_ne_one _ ha]
    exact (lt_div_iff₀ (by simpa using hab' : 0 < 1 - (a : ℝ))).2
      (by simpa only [mul_comm, logPowerSum] using P.shannon_mul_lt_logPowerSum (a : ℝ) hc hn)
  have ha' : (a : ℝ) ≠ 1 := by exact_mod_cast ha
  have hb' : (b : ℝ) ≠ 1 := by exact_mod_cast hb
  rw [renyi_eq_neg_secant _ ha, renyi_eq_neg_secant _ hb]
  exact neg_lt_neg ((P.strictConvexOn_logPowerSum hn).secant_strict_mono (Set.mem_univ _)
    (Set.mem_univ _) (Set.mem_univ _) ha' hb' hab')

private theorem minEntropy_le_renyi_of_one_lt (P : FiniteLaw Ω) {a : ℝ≥0} (ha : 1 < a) :
    P.minEntropy ≤ P.renyi (a : RenyiOrder) := by
  have ha' : (1 : ℝ) < a := by exact_mod_cast ha
  have hsum : P.powerSum a ≤ P.maxWeight ^ ((a : ℝ) - 1) := calc
    _ = ∑ x, P.weight x * P.weight x ^ ((a : ℝ) - 1) := by
      unfold powerSum
      refine Finset.sum_congr rfl fun x _ => ?_
      calc
        _ = P.weight x ^ ((1 : ℝ) + ((a : ℝ) - 1)) := by congr 1; ring
        _ = _ := by rw [Real.rpow_add (P.positive x), Real.rpow_one]
    _ ≤ ∑ x, P.weight x * P.maxWeight ^ ((a : ℝ) - 1) := by
      exact Finset.sum_le_sum fun x _ => mul_le_mul_of_nonneg_left
        (Real.rpow_le_rpow (P.positive x).le (P.weight_le_maxWeight x) (by linarith))
        (P.positive x).le
    _ = _ := by rw [← Finset.sum_mul, P.sum_weight, one_mul]
  have h := Real.log_le_log (P.powerSum_pos _) hsum
  rw [Real.log_rpow P.maxWeight_pos] at h
  rw [renyi_coe_of_ne_one _ ha.ne', minEntropy]
  apply (le_div_iff_of_neg (by linarith : 1 - (a : ℝ) < 0)).2
  nlinarith only [h]

theorem minEntropy_le_renyi (P : FiniteLaw Ω) (a : RenyiOrder) :
    P.minEntropy ≤ P.renyi a := by
  cases a using WithTop.recTopCoe with
  | top => simp
  | coe a =>
    have h : 1 < max a 2 := lt_of_lt_of_le (by norm_num) (le_max_right _ _)
    exact (P.minEntropy_le_renyi_of_one_lt h).trans (P.renyi_finite_antitone (le_max_left _ _))

/-- Rényi entropy is nonincreasing on all orders, including the two endpoints. -/
theorem renyi_antitone (P : FiniteLaw Ω) : Antitone P.renyi := by
  intro a b hab
  cases a using WithTop.recTopCoe with
  | top =>
    have h : b = ⊤ := top_le_iff.mp hab
    subst b
    exact le_rfl
  | coe a =>
    cases b using WithTop.recTopCoe with
    | top => rw [renyi_top]; exact P.minEntropy_le_renyi _
    | coe b => exact P.renyi_finite_antitone (WithTop.coe_le_coe.mp hab)

theorem renyi_nonneg (P : FiniteLaw Ω) (a : RenyiOrder) : 0 ≤ P.renyi a :=
  P.minEntropy_nonneg.trans (P.minEntropy_le_renyi a)


theorem renyi_le_hartley (P : FiniteLaw Ω) (a : RenyiOrder) : P.renyi a ≤ P.hartley := by
  have h₀ : 0 ≤ a := by
    cases a using WithTop.recTopCoe with
    | top => exact le_top
    | coe a =>
      rw [← WithTop.coe_zero]
      exact WithTop.coe_le_coe.mpr (show (0 : ℝ≥0) ≤ a from zero_le)
  simpa only [renyi_zero] using P.renyi_antitone h₀

/-- All distinct Rényi orders have distinct entropies for a nonuniform law. -/
theorem renyi_strictAnti (P : FiniteLaw Ω) (hn : ∃ x y, P.weight x ≠ P.weight y) :
    StrictAnti P.renyi := by
  intro a b hab
  cases a using WithTop.recTopCoe with
  | top => exact (not_lt_of_ge le_top hab).elim
  | coe a =>
    cases b using WithTop.recTopCoe with
    | top =>
      rw [renyi_top]
      have h : a < a + 1 := lt_add_of_pos_right a zero_lt_one
      exact (P.minEntropy_le_renyi (↑(a + 1) : RenyiOrder)).trans_lt
        (P.renyi_finite_strictAnti hn h)
    | coe b => exact P.renyi_finite_strictAnti hn (WithTop.coe_lt_coe.mp hab)

end FiniteLaw

end LeanAB.PaperA
