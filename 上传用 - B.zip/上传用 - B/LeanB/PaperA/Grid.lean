module

public import Common
public import Mathlib.Algebra.GCDMonoid.Finset
public import Mathlib.Data.Rat.Floor

@[expose] public section

/-! Finite grid bound for the remainder support in exact decoding. -/

namespace LeanAB.PaperA

/-- Each coordinate of a support vector lies on a common-denominator grid. -/
theorem support_coordinate_grid {E : Finset ℕ} {m D : ℕ}
    (hpos : ∀ a : E, 0 < a.val) (hD : ∀ a : E, a.val ∣ D)
    (s : support E m) (i : Fin m) :
    ∃ k : ℕ, (k : ℚ) = (D : ℚ) * s.val i ∧ k ≤ ⌊(D : ℚ) * mass E⌋₊ := by
  obtain ⟨s, ⟨cfg, rfl⟩⟩ := s
  refine ⟨_, value_clearDenominator hpos hD cfg i, Nat.le_floor ?_⟩
  rw [value_clearDenominator hpos hD cfg i]
  exact mul_le_mul_of_nonneg_left (value_le_mass cfg i) (Nat.cast_nonneg D)

/-- Count the grid points in the box of coordinate-wise reciprocal mass bounds. -/
theorem card_support_le_common_grid {E : Finset ℕ} (m D : ℕ) (hDpos : 0 < D)
    (hpos : ∀ a : E, 0 < a.val) (hD : ∀ a : E, a.val ∣ D) :
    Nat.card (support E m) ≤ (⌊(D : ℚ) * mass E⌋₊ + 1)^m := by
  have grid_cast (s : support E m) (i : Fin m) :
      (⌊(D : ℚ) * s.val i⌋₊ : ℚ) = (D : ℚ) * s.val i := by
    obtain ⟨k, hk, _⟩ := support_coordinate_grid hpos hD s i
    rw [← hk, Nat.floor_natCast]
  let encode (s : support E m) (i : Fin m) : Fin (⌊(D : ℚ) * mass E⌋₊ + 1) :=
    ⟨⌊(D : ℚ) * s.val i⌋₊, by
      obtain ⟨k, hk, hbound⟩ := support_coordinate_grid hpos hD s i
      rw [← hk, Nat.floor_natCast]
      exact Nat.lt_succ_of_le hbound⟩
  have encode_injective : Function.Injective encode := by
    intro s t hst
    apply Subtype.ext
    funext i
    apply mul_left_cancel₀ (Nat.cast_ne_zero.mpr hDpos.ne' : (D : ℚ) ≠ 0)
    rw [← grid_cast s i, ← grid_cast t i]
    exact congrArg (fun u : Fin _ => (u.val : ℚ)) (congrFun hst i)
  exact (Nat.card_le_card_of_injective encode encode_injective).trans_eq (by
    rw [Nat.card_fun, Nat.card_fin, Nat.card_fin])

/-- Use the least common multiple of the denominators as the grid denominator. -/
theorem card_support_le_lcm_grid {E : Finset ℕ} (m : ℕ) (hpos : ∀ a ∈ E, 0 < a) :
    Nat.card (support E m) ≤ (⌊((E.lcm id : ℕ) : ℚ) * mass E⌋₊ + 1)^m := by
  have hDpos : 0 < E.lcm id :=
    Nat.pos_of_ne_zero (Finset.lcm_ne_zero_iff.mpr fun a ha => (hpos a ha).ne')
  exact card_support_le_common_grid m (E.lcm id) hDpos
    (fun a => hpos a.val a.property) (fun a => Finset.dvd_lcm a.property)

end LeanAB.PaperA
