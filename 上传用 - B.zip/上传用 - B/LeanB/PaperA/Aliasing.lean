module

public import PaperA.Grid
public import PaperA.OutputLaw
public import PaperA.LengthSix
public import Mathlib.Algebra.Field.ZMod
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Tactic

@[expose] public section

/-! Finite arithmetic for the two sides of modular aliasing. -/

namespace LeanAB.PaperA

open scoped BigOperators

/-- Candidate primes that divide a difference between two cleared coordinates. -/
def differencePrimes (candidates : Finset ℕ) (x y : ℤ) : Finset ℕ :=
  candidates ∩ (x - y).natAbs.primeFactors

/-- A single exceptional set for all coordinates drawn from the same cleared support. -/
def exceptionalPrimes (candidates : Finset ℕ) (codes : Finset ℤ) : Finset ℕ :=
  codes.offDiag.biUnion (fun xy => differencePrimes candidates xy.1 xy.2)

theorem differencePrimes_card_power_le (candidates : Finset ℕ) {x y : ℤ}
    (hxy : x ≠ y) (L : ℕ) (hL : ∀ p ∈ candidates, L ≤ p) :
    L ^ (differencePrimes candidates x y).card ≤ (x - y).natAbs := by
  have habs : (x - y).natAbs ≠ 0 := by simpa using sub_ne_zero.mpr hxy
  calc
    _ = ∏ _p ∈ differencePrimes candidates x y, L := by simp
    _ ≤ ∏ p ∈ differencePrimes candidates x y, p := by
      apply Finset.prod_le_prod
      intro p hp
      exact hL p (Finset.mem_inter.mp hp).1
    _ ≤ _ := Nat.le_of_dvd (Nat.pos_of_ne_zero habs)
      ((Finset.prod_dvd_prod_of_subset _ _ id Finset.inter_subset_right).trans
        (Nat.prod_primeFactors_dvd _))

theorem exceptionalPrimes_card_le (candidates : Finset ℕ) (codes : Finset ℤ) (B : ℕ)
    (hB : ∀ x ∈ codes, ∀ y ∈ codes, x ≠ y → (differencePrimes candidates x y).card ≤ B) :
    (exceptionalPrimes candidates codes).card ≤ codes.card ^ 2 * B := by
  calc
    _ ≤ ∑ xy ∈ codes.offDiag, (differencePrimes candidates xy.1 xy.2).card :=
      Finset.card_biUnion_le
    _ ≤ ∑ _xy ∈ codes.offDiag, B := by
      apply Finset.sum_le_sum
      intro xy hxy
      obtain ⟨hx, hy, hne⟩ := Finset.mem_offDiag.mp hxy
      exact hB _ hx _ hy hne
    _ ≤ _ := by
      rw [Finset.sum_const, nsmul_eq_mul, pow_two, ← Finset.card_product]
      exact Nat.mul_le_mul_right B (Finset.card_le_card (by
        intro xy hxy
        obtain ⟨hx, hy, _⟩ := Finset.mem_offDiag.mp hxy
        exact Finset.mem_product.mpr ⟨hx, hy⟩))

theorem injOn_intCast_of_not_exceptional {p : ℕ} (hp : p.Prime)
    {candidates : Finset ℕ} (hpc : p ∈ candidates) {codes : Finset ℤ}
    (hpe : p ∉ exceptionalPrimes candidates codes) :
    Set.InjOn (fun x : ℤ => (x : ZMod p)) (codes : Set ℤ) := by
  intro x hx y hy he
  by_contra hxy
  have hd : (p : ℤ) ∣ x - y := (ZMod.intCast_eq_intCast_iff_dvd_sub y x p).mp he.symm
  have hnat : p ∣ (x - y).natAbs := by simpa using Int.natAbs_dvd_natAbs.mpr hd
  have hmem : p ∈ (x - y).natAbs.primeFactors :=
    hp.mem_primeFactors hnat (by simpa using sub_ne_zero.mpr hxy)
  exact hpe (Finset.mem_biUnion.mpr
    ⟨(x, y), Finset.mem_offDiag.mpr ⟨hx, hy, hxy⟩, Finset.mem_inter.mpr ⟨hpc, hmem⟩⟩)

theorem coordinatewise_injOn_of_not_exceptional {ι : Type*} {p : ℕ} (hp : p.Prime)
    {candidates : Finset ℕ} (hpc : p ∈ candidates) {codes : Finset ℤ}
    (hpe : p ∉ exceptionalPrimes candidates codes) :
    Set.InjOn (fun x : ι → ℤ => fun i => (x i : ZMod p)) {x | ∀ i, x i ∈ codes} := by
  intro x hx y hy he
  funext i
  exact injOn_intCast_of_not_exceptional hp hpc hpe (hx i) (hy i) (congrFun he i)

/-- Rational reduction on each positive support coordinate. -/
noncomputable def reduceOutput {q m p : ℕ} [Fact p.Prime] (s : Output (interval 1 q) m) :
    Fin m → ZMod p :=
  fun i => (s.val i : ZMod p)

/-- Pigeonhole step for monochromatic output support and genuine rational reduction. -/
theorem oneColor_collision_of_card_gt {q p : ℕ} [Fact p.Prime]
    (hcard : p < Nat.card (Output (interval 1 q) 1)) :
    ∃ x y : Output (interval 1 q) 1, x ≠ y ∧ reduceOutput (p := p) x = reduceOutput (p := p) y := by
  have hc : Fintype.card (ZMod p) < Fintype.card (Output (interval 1 q) 1) := by
    rwa [ZMod.card, ← Nat.card_eq_fintype_card]
  obtain ⟨x, y, hxy, hred⟩ := Fintype.exists_ne_map_eq_of_card_lt
    (fun s => reduceOutput (p := p) s 0) hc
  refine ⟨x, y, hxy, ?_⟩
  funext i
  have hi : i = 0 := Subsingleton.elim _ _
  simpa only [hi] using hred


private theorem interval_one_pos {q : ℕ} (a : interval 1 q) : 0 < a.val :=
  (Finset.mem_Icc.mp a.property).1

private theorem interval_one_subset {q Q : ℕ} (hle : q ≤ Q) : interval 1 q ⊆ interval 1 Q :=
  Finset.Icc_subset_Icc_right hle

private theorem group_mass {E : Finset ℕ} {m : ℕ} (cfg : Configuration E m) (i : Fin m) :
    value E m cfg i = mass ((group cfg i).image Subtype.val) := by
  classical
  unfold mass
  rw [Finset.sum_image (fun _ _ _ _ h => Subtype.ext h)]
  exact (congrFun (packingValue_toPacking cfg) i).symm

private theorem coordinate_in_oneColor_large {q Q m : ℕ} (hq : q ≤ Q)
    (x : Output (interval 1 q) m) (i : Fin m) :
    ∃ y : Output (interval 1 Q) 1, y.val 0 = x.val i := by
  classical
  obtain ⟨cfg, hcfg⟩ := x.property
  let S := (group cfg i).image Subtype.val
  have hS : S ⊆ interval 1 Q := by
    intro a ha
    obtain ⟨b, _, rfl⟩ := Finset.mem_image.mp ha
    exact interval_one_subset hq b.property
  let one : Configuration (interval 1 Q) 1 :=
    fun a => if a.val ∈ S then (0 : Fin 1).succ else 0
  have hgroup : (group one 0).image Subtype.val = S := by
    ext a
    constructor
    · intro ha
      obtain ⟨b, hb, rfl⟩ := Finset.mem_image.mp ha
      have hc := (mem_group one 0 b).mp hb
      by_contra hn
      simp [one, hn] at hc
    · intro ha
      refine Finset.mem_image.mpr ⟨⟨a, hS ha⟩, (mem_group one 0 _).mpr ?_, rfl⟩
      simp [one, ha]
  refine ⟨sampleOutput _ _ one, ?_⟩
  change value _ _ one 0 = x.val i
  rw [group_mass one 0, hgroup, ← group_mass cfg i, hcfg]

private theorem lcm_code_witness {q m : ℕ} (s : Output (interval 1 q) m) (i : Fin m) :
    ∃ k : ℕ, (k : ℚ) = (Nat.lcmUpto q : ℚ) * s.val i ∧
      k ≤ ⌊(Nat.lcmUpto q : ℚ) * mass (interval 1 q)⌋₊ := by
  refine support_coordinate_grid interval_one_pos ?_ s i
  intro a
  exact Finset.dvd_lcm a.property

noncomputable def clearedCoordinate {q m : ℕ} (s : Output (interval 1 q) m) (i : Fin m) : ℤ :=
  (⌊(Nat.lcmUpto q : ℚ) * s.val i⌋₊ : ℕ)

theorem clearedCoordinate_eq {q m : ℕ} (s : Output (interval 1 q) m) (i : Fin m) :
    (clearedCoordinate s i : ℚ) = (Nat.lcmUpto q : ℚ) * s.val i := by
  obtain ⟨k, hk, _⟩ := lcm_code_witness s i
  unfold clearedCoordinate
  rw [← hk, Nat.floor_natCast, Int.cast_natCast]

theorem output_den_dvd_lcmUpto {q m : ℕ} (s : Output (interval 1 q) m) (i : Fin m) :
    (s.val i).den ∣ Nat.lcmUpto q := by
  have hD : (Nat.lcmUpto q : ℚ) ≠ 0 := by exact_mod_cast Nat.lcmUpto_ne_zero q
  have hrep : Rat.divInt (clearedCoordinate s i) (Nat.lcmUpto q : ℤ) = s.val i := by
    rw [Rat.divInt_eq_div, Int.cast_natCast, div_eq_iff hD, clearedCoordinate_eq, mul_comm]
  have h := Rat.den_dvd (clearedCoordinate s i) (Nat.lcmUpto q : ℤ)
  rw [hrep] at h
  exact_mod_cast h

private theorem prime_not_dvd_lcmUpto {q p : ℕ} (hp : p.Prime) (hqp : q < p) :
    ¬ p ∣ Nat.lcmUpto q := by
  intro hd
  have hh := hp.mem_primeFactors hd (Nat.lcmUpto_ne_zero q)
  rw [Nat.primeFactors_lcmUpto] at hh
  exact hqp.not_ge (Nat.le_of_mem_primesLE hh)

theorem output_den_not_dvd {q m p : ℕ} (hp : p.Prime) (hqp : q < p)
    (s : Output (interval 1 q) m) (i : Fin m) :
    ¬ p ∣ (s.val i).den :=
  fun hd => prime_not_dvd_lcmUpto hp hqp (hd.trans (output_den_dvd_lcmUpto s i))

private theorem cast_clearedCoordinate {q m p : ℕ} [Fact p.Prime] (hqp : q < p)
    (s : Output (interval 1 q) m) (i : Fin m) :
    (clearedCoordinate s i : ZMod p) = (Nat.lcmUpto q : ZMod p) * reduceOutput (p := p) s i := by
  have hn : ((s.val i).den : ZMod p) ≠ 0 :=
    fun h => output_den_not_dvd Fact.out hqp s i ((ZMod.natCast_eq_zero_iff _ _).mp h)
  have h := congrArg (fun a : ℚ => (a : ZMod p)) (clearedCoordinate_eq s i)
  rw [Rat.cast_intCast, Rat.cast_mul_of_ne_zero (by simp) hn, Rat.cast_natCast] at h
  exact h

noncomputable def oneColorClearedCodes (Q : ℕ) : Finset ℤ :=
  Finset.univ.image (fun (y : Output (interval 1 Q) 1) => clearedCoordinate y 0)

/-- A single finite exceptional set for all smaller lengths and every number of colors. -/
noncomputable def shortExceptional (N Q : ℕ) : Finset ℕ :=
  exceptionalPrimes (blockPrimes N Q) (oneColorClearedCodes Q)

theorem short_aliasing_injective {N Q q m p : ℕ} [Fact p.Prime]
    (hq : q ≤ Q) (hqp : Q < p) (hp : p ∈ blockPrimes N Q) (he : p ∉ shortExceptional N Q) :
    Function.Injective (reduceOutput (q := q) (m := m) (p := p)) := by
  intro x y hxy
  apply Subtype.ext
  funext i
  obtain ⟨u, hu⟩ := coordinate_in_oneColor_large hq x i
  obtain ⟨v, hv⟩ := coordinate_in_oneColor_large hq y i
  have hred : reduceOutput (p := p) u 0 = reduceOutput (p := p) v 0 := by
    change (u.val 0 : ZMod p) = (v.val 0 : ZMod p)
    rw [hu, hv]
    exact congrFun hxy i
  have hcast : (clearedCoordinate u 0 : ZMod p) = (clearedCoordinate v 0 : ZMod p) := by
    rw [cast_clearedCoordinate hqp, cast_clearedCoordinate hqp, hred]
  have hcode := injOn_intCast_of_not_exceptional Fact.out hp he
    (show clearedCoordinate u 0 ∈ oneColorClearedCodes Q from Finset.mem_image_of_mem _ (Finset.mem_univ u))
    (show clearedCoordinate v 0 ∈ oneColorClearedCodes Q from Finset.mem_image_of_mem _ (Finset.mem_univ v))
    hcast
  have hrat := congrArg (fun a : ℤ => (a : ℚ)) hcode
  change (clearedCoordinate u 0 : ℚ) = (clearedCoordinate v 0 : ℚ) at hrat
  rw [clearedCoordinate_eq, clearedCoordinate_eq, hu, hv] at hrat
  exact mul_left_cancel₀ (by exact_mod_cast Nat.lcmUpto_ne_zero Q) hrat


private theorem code_bounds {Q : ℕ} {z : ℤ} (hz : z ∈ oneColorClearedCodes Q) :
    0 ≤ z ∧ z ≤ (⌊(Nat.lcmUpto Q : ℚ) * mass (interval 1 Q)⌋₊ : ℕ) := by
  obtain ⟨s, _, hs⟩ := Finset.mem_image.mp hz
  obtain ⟨k, hk, hle⟩ := lcm_code_witness s 0
  rw [← hs, clearedCoordinate, ← hk, Nat.floor_natCast]
  exact ⟨Int.natCast_nonneg _, by exact_mod_cast hle⟩

/-- A numerical sufficient condition for the exceptional-prime count. -/
theorem shortExceptional_card_le (N Q L B : ℕ) (hL : 0 < L)
    (hcandidate : ∀ p ∈ blockPrimes N Q, L ≤ p)
    (hgrid : ⌊(Nat.lcmUpto Q : ℚ) * mass (interval 1 Q)⌋₊ < L ^ (B + 1)) :
    (shortExceptional N Q).card ≤ (Nat.card (Output (interval 1 Q) 1)) ^ 2 * B := by
  have hcard : (oneColorClearedCodes Q).card ≤ Nat.card (Output (interval 1 Q) 1) := by
    rw [Nat.card_eq_fintype_card, ← Finset.card_univ]
    exact Finset.card_image_le
  refine (exceptionalPrimes_card_le _ _ B ?_).trans
    (Nat.mul_le_mul_right _ (Nat.pow_le_pow_left hcard _))
  intro x hx y hy hxy
  have hBound : (x - y).natAbs ≤ ⌊(Nat.lcmUpto Q : ℚ) * mass (interval 1 Q)⌋₊ := by
    obtain ⟨hx₀, hx₁⟩ := code_bounds hx
    obtain ⟨hy₀, hy₁⟩ := code_bounds hy
    omega
  have hp := differencePrimes_card_power_le (blockPrimes N Q) hxy L hcandidate
  by_contra! hmore
  have hmore' : B + 1 ≤ (differencePrimes (blockPrimes N Q) x y).card := hmore
  exact (not_lt_of_ge ((Nat.pow_le_pow_right hL hmore').trans (hp.trans hBound))) hgrid

private def embedOneColor {q : ℕ} (m : ℕ) (x : Output (interval 1 q) 1) :
    Output (interval 1 q) (m + 1) := by
  refine ⟨firstOnlyTarget m (x.val 0), ?_⟩
  have hx : x.val = fun _ => x.val 0 := by
    funext i
    exact congrArg x.val (Subsingleton.elim _ _)
  obtain ⟨cfg, hcfg⟩ := x.property
  let y := (firstOnlyFiberEquiv interval_one_pos m (x.val 0)).symm ⟨cfg, hcfg.trans hx⟩
  exact ⟨y.val, y.property⟩

/-- The finite pigeonhole obstruction holds for every positive number of colors. -/
theorem long_aliasing_collision {q p : ℕ} [Fact p.Prime] (m : ℕ)
    (hcard : p < Nat.card (Output (interval 1 q) 1)) :
    ∃ x y : Output (interval 1 q) (m + 1), x ≠ y ∧
      reduceOutput (p := p) x = reduceOutput (p := p) y := by
  obtain ⟨a, b, hne, hred⟩ := oneColor_collision_of_card_gt hcard
  refine ⟨embedOneColor m a, embedOneColor m b, ?_, ?_⟩
  · intro h
    apply hne
    apply Subtype.ext
    funext i
    have hi : i = 0 := Subsingleton.elim _ _
    subst i
    have he := congrArg (fun (x : Output (interval 1 q) (m + 1)) => x.val 0) h
    simpa [embedOneColor, firstOnlyTarget] using he
  · funext i
    by_cases hi : i = 0
    · subst i
      simpa [reduceOutput, embedOneColor, firstOnlyTarget] using congrFun hred (0 : Fin 1)
    · simp [reduceOutput, embedOneColor, firstOnlyTarget, hi]

end LeanAB.PaperA
