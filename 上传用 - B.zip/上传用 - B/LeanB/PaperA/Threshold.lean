module

public import Mathlib.NumberTheory.LSeries.WeakPNT
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Tactic

@[expose] public section

namespace LeanAB.PaperA

open Filter
open scoped Topology

/-- The cofactor cutoff of the exact decoding proposition. -/
noncomputable def paperK (n : ℕ) : ℕ := ⌊Real.log (n : ℝ) / 2⌋₊

/-- The real cutoff for the large-prime blocks. -/
noncomputable def paperY (n : ℕ) : ℝ := n / ((paperK n : ℝ) + 1)

theorem paperY_lt_iff (n p : ℕ) :
    paperY n < p ↔ n < p * (paperK n + 1) := by
  rw [paperY, div_lt_iff₀ (by positivity)]
  exact_mod_cast Iff.rfl

private theorem tendsto_paperK : Tendsto paperK atTop atTop := by
  exact tendsto_nat_floor_atTop.comp
    ((Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop).atTop_div_const (by norm_num))

private theorem eventually_log_lcmUpto_le :
    ∀ᶠ k : ℕ in atTop, Real.log (Nat.lcmUpto k : ℝ) ≤ (5 / 4 : ℝ) * k := by
  filter_upwards [Nat.tendsto_log_lcmUpto_div_atTop.eventually_lt_const
      (show (1 : ℝ) < 5 / 4 by norm_num), eventually_ge_atTop (1 : ℕ)] with k hk hkpos
  have hpos : (0 : ℝ) < k := by exact_mod_cast (by omega : 0 < k)
  exact ((div_lt_iff₀ hpos).mp hk).le

theorem eventually_log_le_eighth :
    ∀ᶠ n : ℕ in atTop, Real.log (n : ℝ) ≤ (n : ℝ) ^ (1 / 8 : ℝ) := by
  have h := (isLittleO_log_rpow_atTop (show (0 : ℝ) < 1 / 8 by norm_num)).bound
    (show (0 : ℝ) < 1 by norm_num)
  have ht : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  filter_upwards [ht.eventually h] with n hn
  have hp : (0 : ℝ) ≤ (n : ℝ) ^ (1 / 8 : ℝ) := by positivity
  have habs : |Real.log (n : ℝ)| ≤ (n : ℝ) ^ (1 / 8 : ℝ) := by
    simpa only [Real.norm_eq_abs, one_mul, abs_of_nonneg hp] using hn
  exact (le_abs_self _).trans habs

/-- Weak PNT yields both cutoff inequalities, using the elementary bound h_K ≤ K. -/
theorem eventually_paperCutoff :
    ∀ᶠ n : ℕ in atTop,
      (paperK n + 1) * (paperK n + 1) < n ∧
      Nat.lcmUpto (paperK n) * paperK n * (paperK n + 1) < n := by
  have hlog : Tendsto (fun n : ℕ => Real.log (n : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  filter_upwards [tendsto_paperK.eventually eventually_log_lcmUpto_le,
    eventually_log_le_eighth, hlog.eventually_ge_atTop 2,
    eventually_ge_atTop (2 : ℕ)] with n hD hpow hlogn hn
  have hn₁ : (1 : ℝ) < n := by exact_mod_cast (by omega : 1 < n)
  have hn₀ : (0 : ℝ) < n := by linarith
  have hK : (paperK n : ℝ) ≤ Real.log (n : ℝ) / 2 :=
    Nat.floor_le (by linarith)
  have hKpow : (paperK n : ℝ) + 1 ≤ (n : ℝ) ^ (1 / 8 : ℝ) :=
    (show (paperK n : ℝ) + 1 ≤ Real.log (n : ℝ) by linarith).trans hpow
  have hDpow : (Nat.lcmUpto (paperK n) : ℝ) ≤ (n : ℝ) ^ (5 / 8 : ℝ) := by
    have hDpos : (0 : ℝ) < ↑(Nat.lcmUpto (paperK n)) := by
      exact_mod_cast Nat.lcmUpto_pos (paperK n)
    rw [Real.rpow_def_of_pos hn₀, ← Real.exp_log hDpos, Real.exp_le_exp]
    exact hD.trans (by linarith)
  have hquarter : (n : ℝ) ^ (1 / 8 : ℝ) * (n : ℝ) ^ (1 / 8 : ℝ) =
      (n : ℝ) ^ (1 / 4 : ℝ) := by
    rw [← Real.rpow_add hn₀]
    norm_num
  have hsquare : ((paperK n : ℝ) + 1) * ((paperK n : ℝ) + 1) < n := calc
    _ ≤ (n : ℝ) ^ (1 / 8 : ℝ) * (n : ℝ) ^ (1 / 8 : ℝ) :=
      mul_le_mul hKpow hKpow (by positivity) (by positivity)
    _ = (n : ℝ) ^ (1 / 4 : ℝ) := hquarter
    _ < n := by
      simpa using Real.rpow_lt_rpow_of_exponent_lt hn₁ (show (1 / 4 : ℝ) < 1 by norm_num)
  have hproduct : (Nat.lcmUpto (paperK n) : ℝ) * (paperK n : ℝ) *
      ((paperK n : ℝ) + 1) < n := calc
    _ ≤ (n : ℝ) ^ (5 / 8 : ℝ) * (n : ℝ) ^ (1 / 8 : ℝ) * (n : ℝ) ^ (1 / 8 : ℝ) :=
      mul_le_mul (mul_le_mul hDpow (by linarith [hKpow]) (by positivity) (by positivity))
        hKpow (by positivity) (by positivity)
    _ = (n : ℝ) ^ (7 / 8 : ℝ) := by
      rw [mul_assoc, hquarter, ← Real.rpow_add hn₀]
      norm_num
    _ < n := by
      simpa using Real.rpow_lt_rpow_of_exponent_lt hn₁ (show (7 / 8 : ℝ) < 1 by norm_num)
  exact ⟨by exact_mod_cast hsquare, by exact_mod_cast hproduct⟩

/-- Every integer above the paper cutoff meets the finite decoding conditions. -/
theorem eventually_paperBlockBounds :
    ∀ᶠ n : ℕ in atTop, ∀ p : ℕ, n < p * (paperK n + 1) →
      n < p * p ∧ paperK n < p ∧ Nat.lcmUpto (paperK n) * paperK n < p := by
  filter_upwards [eventually_paperCutoff] with n hn p hp
  have hbig : paperK n + 1 < p := by
    by_contra! h
    exact (not_lt_of_ge
      ((Nat.mul_le_mul_right _ h).trans (Nat.le_of_lt hn.1))) hp
  refine ⟨hp.trans_le (Nat.mul_le_mul_left _ hbig.le), by omega, ?_⟩
  by_contra! h
  exact (not_lt_of_ge
    ((Nat.mul_le_mul_right _ h).trans (Nat.le_of_lt hn.2))) hp


/-- The cutoff lies above √n and above the bound for the cleared block outputs. -/
theorem eventually_paperYBounds :
    ∀ᶠ n : ℕ in atTop, √(n : ℝ) < paperY n ∧
      (Nat.lcmUpto (paperK n) : ℝ) * (paperK n : ℝ) < paperY n := by
  filter_upwards [eventually_paperCutoff] with n hn
  have hpos : 0 < (paperK n : ℝ) + 1 := by positivity
  have hn₀ : (0 : ℝ) ≤ n := by positivity
  have hsquare : ((paperK n : ℝ) + 1) ^ 2 < n := by
    rw [pow_two]
    exact_mod_cast hn.1
  rw [paperY, lt_div_iff₀ hpos, lt_div_iff₀ hpos]
  constructor
  · have hsqrt := Real.sq_sqrt hn₀
    have hg : (paperK n : ℝ) + 1 < √(n : ℝ) := by
      have hr := Real.sqrt_lt_sqrt (sq_nonneg ((paperK n : ℝ) + 1)) hsquare
      rwa [Real.sqrt_sq hpos.le] at hr
    have hr : 0 < √(n : ℝ) := hpos.trans hg
    nlinarith [mul_lt_mul_of_pos_left hg hr]
  · exact_mod_cast hn.2

end LeanAB.PaperA
