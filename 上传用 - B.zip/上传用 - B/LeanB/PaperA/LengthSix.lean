module

public import PaperA.OutputLaw
import Mathlib.Tactic

public section

/-! The explicit nonuniform two-atom certificate at length six. -/

namespace LeanAB.PaperA

open scoped BigOperators

private theorem value_pos_of_label {E : Finset ℕ} {m : ℕ}
    (c : Configuration E m) {x : E} (hx : 0 < x.val) (i : Fin m) (hlabel : c x = i.succ) :
    0 < value E m c i := by
  have hle := Finset.single_le_sum
    (f := fun y : E => if c y = i.succ then (y.val : ℚ)⁻¹ else 0)
    (fun y _ => by split <;> positivity) (Finset.mem_univ x)
  rw [ite_eq_left hlabel] at hle
  exact lt_of_lt_of_le (inv_pos.mpr (by exact_mod_cast hx)) hle

/-- If every denominator is positive, the zero vector has just the unused configuration. -/
theorem fiber_card_zero {E : Finset ℕ} (hpos : ∀ x : E, 0 < x.val) (m : ℕ) :
    Nat.card (Fiber E m 0) = 1 := by
  refine Nat.card_eq_one_iff_exists.mpr ⟨⟨fun _ => 0, value_allUnused _ _⟩, fun c => ?_⟩
  apply Subtype.ext
  funext x
  by_contra h
  obtain ⟨i, hi⟩ := Fin.eq_succ_of_ne_zero h
  have hp := value_pos_of_label c.val (hpos x) i hi
  have hz := congrFun c.property i
  change value E m c.val i = 0 at hz
  rw [hz] at hp
  exact (lt_irrefl 0) hp

/-- A target concentrated in the first color. -/
@[expose] def firstOnlyTarget (m : ℕ) (r : ℚ) : Fin (m + 1) → ℚ :=
  fun i => if i = 0 then r else 0

private def toSingleColor {E : Finset ℕ} {m : ℕ} (c : Configuration E (m + 1)) :
    Configuration E 1 :=
  fun x => if c x = (0 : Fin (m + 1)).succ then (0 : Fin 1).succ else 0

private def fromSingleColor {E : Finset ℕ} (m : ℕ) (c : Configuration E 1) :
    Configuration E (m + 1) :=
  fun x => if c x = (0 : Fin 1).succ then (0 : Fin (m + 1)).succ else 0

private theorem value_toSingleColor {E : Finset ℕ} {m : ℕ}
    (c : Configuration E (m + 1)) :
    value E 1 (toSingleColor c) 0 = value E (m + 1) c 0 := by
  simp only [value_apply, toSingleColor]
  exact Finset.sum_congr rfl fun x _ => by
    by_cases h : c x = (0 : Fin (m + 1)).succ
    · simp only [ite_eq_left h, ite_true]
    · simp only [ite_eq_right h, ite_eq_right (Ne.symm (Fin.succ_ne_zero (0 : Fin 1)))]

private theorem value_fromSingleColor {E : Finset ℕ} (m : ℕ) (c : Configuration E 1) :
    value E (m + 1) (fromSingleColor m c) 0 = value E 1 c 0 := by
  simp only [value_apply, fromSingleColor]
  exact Finset.sum_congr rfl fun x _ => by
    by_cases h : c x = (0 : Fin 1).succ
    · simp only [ite_eq_left h, ite_true]
    · simp only [ite_eq_right h, ite_eq_right (Ne.symm (Fin.succ_ne_zero (0 : Fin (m + 1))))]

/-- A fiber whose other coordinates vanish is precisely the matching one-color fiber. -/
def firstOnlyFiberEquiv {E : Finset ℕ} (hpos : ∀ x : E, 0 < x.val) (m : ℕ) (r : ℚ) :
    Fiber E (m + 1) (firstOnlyTarget m r) ≃ Fiber E 1 (fun _ => r) where
  toFun c := ⟨toSingleColor c.val, by
    funext i
    have hi : i = 0 := Subsingleton.elim _ _
    subst i
    rw [value_toSingleColor, c.property]
    simp [firstOnlyTarget]⟩
  invFun c := ⟨fromSingleColor m c.val, by
    funext i
    by_cases hi : i = 0
    · subst i
      rw [value_fromSingleColor, c.property]
      simp [firstOnlyTarget]
    · simp only [firstOnlyTarget, hi, ite_false, value_apply]
      apply Finset.sum_eq_zero
      intro x _
      have h0 : (0 : Fin (m + 1)).succ ≠ i.succ :=
        fun h => hi (Fin.succ_injective _ h).symm
      by_cases h : c.val x = (0 : Fin 1).succ
      · simp only [fromSingleColor, ite_eq_left h, ite_eq_right h0]
      · simp only [fromSingleColor, ite_eq_right h, ite_eq_right i.succ_ne_zero.symm]⟩
  left_inv c := by
    apply Subtype.ext
    funext x
    by_cases hx : c.val x = (0 : Fin (m + 1)).succ
    · simp [fromSingleColor, toSingleColor, hx]
    · have h0 : c.val x = 0 := by
        by_contra h
        obtain ⟨i, hi⟩ := Fin.eq_succ_of_ne_zero h
        have hi0 : i ≠ 0 := by
          intro he
          subst i
          exact hx hi
        have hp := value_pos_of_label c.val (hpos x) i hi
        have hz := congrFun c.property i
        simp only [firstOnlyTarget, hi0, ite_false] at hz
        rw [hz] at hp
        exact (lt_irrefl 0) hp
      simp [fromSingleColor, toSingleColor, h0]
  right_inv c := by
    apply Subtype.ext
    funext x
    by_cases hx : c.val x = 0
    · simp [fromSingleColor, toSingleColor, hx]
    · obtain ⟨i, hi⟩ := Fin.eq_succ_of_ne_zero hx
      have hi0 : i = 0 := Subsingleton.elim _ _
      subst i
      simp [fromSingleColor, toSingleColor, hi]

private theorem pos_six (x : interval 1 6) : 0 < x.val := by
  have h := (Finset.mem_Icc.mp x.property).1
  exact lt_of_lt_of_le (by decide : 0 < 1) h

theorem lengthSix_fiber_zero (m : ℕ) : Nat.card (Fiber (interval 1 6) m 0) = 1 :=
  fiber_card_zero pos_six m

set_option maxRecDepth 10000 in
theorem lengthSix_oneColor_half :
    Nat.card (Fiber (interval 1 6) 1 (fun _ => (1 / 2 : ℚ))) = 2 := by
  change Nat.card {c : Configuration (interval 1 6) 1 //
    value (interval 1 6) 1 c = fun _ => (1 / 2 : ℚ)} = 2
  rw [Nat.card_eq_fintype_card, Fintype.card_subtype]
  decide +kernel

/-- The vector (1/2, 0, ..., 0) has exactly two preimages for every positive color count. -/
theorem lengthSix_fiber_half (m : ℕ) :
    Nat.card (Fiber (interval 1 6) (m + 1) (firstOnlyTarget m (1 / 2))) = 2 := by
  rw [Nat.card_congr (firstOnlyFiberEquiv pos_six m _), lengthSix_oneColor_half]

/-- Exact weights of the two atoms used for the entropy-gap argument. -/
theorem lengthSix_atom_weights (m : ℕ) :
    ∃ z t : Output (interval 1 6) (m + 1),
      z.val = 0 ∧ t.val = firstOnlyTarget m (1 / 2) ∧
      (configurationLaw (interval 1 6) (m + 1)).weight z = 1 / (m + 2 : ℝ)^6 ∧
      (configurationLaw (interval 1 6) (m + 1)).weight t = 2 / (m + 2 : ℝ)^6 := by
  have ht : 0 < Nat.card (Fiber (interval 1 6) (m + 1) (firstOnlyTarget m (1 / 2))) := by
    rw [lengthSix_fiber_half]
    decide
  obtain ⟨t⟩ := (Nat.card_pos_iff.mp ht).1
  let z : Output (interval 1 6) (m + 1) := ⟨0, ⟨fun _ => 0, value_allUnused _ _⟩⟩
  let t' : Output (interval 1 6) (m + 1) := ⟨_, ⟨t.val, t.property⟩⟩
  refine ⟨z, t', rfl, rfl, ?_, ?_⟩
  · rw [configurationLaw_weight, cast_probability]
    change (Nat.card (Fiber (interval 1 6) (m + 1) 0) : ℝ) / _ = _
    rw [lengthSix_fiber_zero]
    simp [interval]
    ring
  · rw [configurationLaw_weight, cast_probability]
    change (Nat.card (Fiber (interval 1 6) (m + 1) (firstOnlyTarget m (1 / 2))) : ℝ) / _ = _
    rw [lengthSix_fiber_half]
    simp [interval]
    ring

/-- Nonuniformity of the configuration law at length six, uniformly over positive color counts. -/
theorem lengthSix_nonuniform (m : ℕ) :
    ∃ z t : Output (interval 1 6) (m + 1),
      (configurationLaw (interval 1 6) (m + 1)).weight z ≠
        (configurationLaw (interval 1 6) (m + 1)).weight t := by
  obtain ⟨z, t, _, _, hz, ht⟩ := lengthSix_atom_weights m
  refine ⟨z, t, ?_⟩
  rw [hz, ht]
  exact (div_lt_div_of_pos_right (by norm_num) (by positivity)).ne

theorem lengthSix_minEntropy_pos (m : ℕ) : 0 < (configurationLaw (interval 1 6) (m + 1)).minEntropy :=
  FiniteLaw.minEntropy_pos _ (by
    obtain ⟨x, y, hxy⟩ := lengthSix_nonuniform m
    exact ⟨x, y, fun h => hxy (congrArg (configurationLaw (interval 1 6) (m + 1)).weight h)⟩)


/-- Every pair of distinct entropy orders has a positive gap at length six. -/
theorem lengthSix_renyi_gap_pos (m : ℕ) {a b : RenyiOrder} (hab : a < b) :
    0 < (configurationLaw (interval 1 6) (m + 1)).renyi a -
      (configurationLaw (interval 1 6) (m + 1)).renyi b :=
  sub_pos.mpr (FiniteLaw.renyi_strictAnti _ (lengthSix_nonuniform m) hab)

end LeanAB.PaperA
