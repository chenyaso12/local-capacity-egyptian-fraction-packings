module

public import Mathlib.Analysis.SpecialFunctions.Log.Monotone
public import Mathlib.Algebra.Order.Floor.Semiring
public import Mathlib.MeasureTheory.Integral.IntervalIntegral.IntegrationByParts
import Mathlib.MeasureTheory.Function.Floor
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Tactic

public section

/-! The iterated-logarithm scale in Paper A, with the constant extension at small arguments. -/

namespace LeanAB.PaperA

open Filter MeasureTheory
open scoped Topology BigOperators

private theorem exp_one_gt_one : 1 < Real.exp 1 := by
  rw [← Real.exp_zero]
  exact Real.exp_lt_exp.mpr (by norm_num)

/-- A logarithm clipped at one, so subsequent iterates remain one after stopping. -/
noncomputable def clippedLog (v : ℝ) : ℝ := max 1 (Real.log (max 1 v))

theorem one_le_clippedLog (v : ℝ) : 1 ≤ clippedLog v := le_max_left _ _

theorem clippedLog_eq_one {v : ℝ} (hv : v ≤ Real.exp 1) : clippedLog v = 1 := by
  unfold clippedLog
  apply max_eq_left
  calc
    _ ≤ Real.log (Real.exp 1) := Real.log_le_log (zero_lt_one.trans_le (le_max_left _ _))
      (max_le exp_one_gt_one.le hv)
    _ = _ := Real.log_exp 1

theorem clippedLog_eq_log {v : ℝ} (hv : Real.exp 1 ≤ v) : clippedLog v = Real.log v := by
  have h : 1 ≤ v := exp_one_gt_one.le.trans hv
  unfold clippedLog
  rw [max_eq_right h]
  exact max_eq_right ((Real.le_log_iff_exp_le (zero_lt_one.trans_le h)).mpr hv)

theorem continuous_clippedLog : Continuous clippedLog := by
  unfold clippedLog
  exact continuous_const.max ((continuous_const.max continuous_id).log
    fun v => (zero_lt_one.trans_le (le_max_left (1 : ℝ) v)).ne')

theorem monotone_clippedLog : Monotone clippedLog := by
  intro u v huv
  unfold clippedLog
  exact max_le_max le_rfl
    (Real.log_le_log (zero_lt_one.trans_le (le_max_left _ _)) (max_le_max le_rfl huv))

/-- The product of the first k successive clipped logarithms. -/
@[expose] noncomputable def truncatedLogProduct : ℕ → ℝ → ℝ
  | 0, _ => 1
  | k + 1, v => clippedLog v * truncatedLogProduct k (clippedLog v)

theorem truncatedLogProduct_eq_one (k : ℕ) {v : ℝ}
    (hv : v ≤ Real.exp 1) : truncatedLogProduct k v = 1 := by
  induction k generalizing v with
  | zero => rfl
  | succ k ih =>
    rw [truncatedLogProduct, clippedLog_eq_one hv, ih exp_one_gt_one.le, one_mul]

theorem continuous_truncatedLogProduct (k : ℕ) : Continuous (truncatedLogProduct k) := by
  induction k with
  | zero => exact continuous_const
  | succ k ih =>
    exact continuous_clippedLog.mul (ih.comp continuous_clippedLog)

theorem one_le_truncatedLogProduct (k : ℕ) (v : ℝ) : 1 ≤ truncatedLogProduct k v := by
  induction k generalizing v with
  | zero => exact le_rfl
  | succ k ih => exact one_le_mul_of_one_le_of_one_le (one_le_clippedLog v) (ih _)

theorem monotone_truncatedLogProduct (k : ℕ) : Monotone (truncatedLogProduct k) := by
  induction k with
  | zero => exact monotone_const
  | succ k ih =>
    intro u v huv
    exact mul_le_mul (monotone_clippedLog huv) (ih (monotone_clippedLog huv))
      (zero_le_one.trans (one_le_truncatedLogProduct k _)) (zero_le_one.trans (one_le_clippedLog v))

private theorem ceil_clippedLog_lt {v : ℝ} (hv : Real.exp 1 ≤ v) : ⌈clippedLog v⌉₊ < ⌈v⌉₊ := by
  have hv' := (Real.exp_pos 1).trans_le hv
  have hc := Nat.ceil_mono (show Real.log v + 1 ≤ v by
    linarith only [Real.log_le_sub_one_of_pos hv'])
  rw [clippedLog_eq_log hv, Nat.ceil_add_one (Real.log_nonneg (exp_one_gt_one.le.trans hv))] at *
  omega

private theorem truncatedLogProduct_stable {v : ℝ} {k l : ℕ}
    (hk : ⌈v⌉₊ ≤ k) (hl : ⌈v⌉₊ ≤ l) :
    truncatedLogProduct k v = truncatedLogProduct l v := by
  induction k generalizing v l with
  | zero =>
    have hv : v ≤ Real.exp 1 :=
      ((Nat.ceil_eq_zero).mp (Nat.eq_zero_of_le_zero hk)).trans (Real.exp_pos 1).le
    rw [truncatedLogProduct_eq_one 0 hv, truncatedLogProduct_eq_one l hv]
  | succ k ih =>
    by_cases hv : v ≤ Real.exp 1
    · rw [truncatedLogProduct_eq_one _ hv, truncatedLogProduct_eq_one _ hv]
    have hc := ceil_clippedLog_lt (le_of_not_ge hv)
    cases l with
    | zero => omega
    | succ l =>
      rw [truncatedLogProduct, truncatedLogProduct, ih (v := clippedLog v) (l := l)
        (by omega) (by omega)]

/-- Product P(v) of successive logarithms of v, stopping before the first factor below one. -/
noncomputable def iterLogProduct (v : ℝ) : ℝ := truncatedLogProduct ⌈v⌉₊ v

/-- The natural ceiling of the starting argument is a sufficient bound on the recursion. -/
theorem iterLogProduct_eq_truncated {v : ℝ} {k : ℕ} (hk : ⌈v⌉₊ ≤ k) :
    iterLogProduct v = truncatedLogProduct k v :=
  truncatedLogProduct_stable le_rfl hk

theorem iterLogProduct_eq_one {v : ℝ} (hv : v ≤ Real.exp 1) : iterLogProduct v = 1 :=
  truncatedLogProduct_eq_one _ hv

theorem iterLogProduct_eq_step (v : ℝ) :
    iterLogProduct v = clippedLog v * iterLogProduct (clippedLog v) := by
  let k := max ⌈v⌉₊ ⌈clippedLog v⌉₊
  rw [iterLogProduct_eq_truncated (k := k + 1)
      ((le_max_left _ _).trans (Nat.le_succ k)),
    truncatedLogProduct, ← iterLogProduct_eq_truncated (k := k) (le_max_right _ _)]

theorem iterLogProduct_eq_log_mul {v : ℝ} (hv : Real.exp 1 ≤ v) :
    iterLogProduct v = Real.log v * iterLogProduct (Real.log v) := by
  rw [iterLogProduct_eq_step v, clippedLog_eq_log hv]

theorem one_le_iterLogProduct (v : ℝ) : 1 ≤ iterLogProduct v :=
  one_le_truncatedLogProduct _ _

theorem monotone_iterLogProduct : Monotone iterLogProduct := by
  intro u v huv
  rw [iterLogProduct_eq_truncated (Nat.ceil_mono huv), iterLogProduct_eq_truncated (k := ⌈v⌉₊) le_rfl]
  exact monotone_truncatedLogProduct _ huv

theorem continuous_iterLogProduct : Continuous iterLogProduct := by
  refine continuous_iff_continuousAt.mpr fun v => ?_
  apply (continuous_truncatedLogProduct ⌈v + 1⌉₊).continuousAt.congr
  filter_upwards [Iio_mem_nhds (lt_add_one v)] with y hy
  exact (iterLogProduct_eq_truncated (Nat.ceil_mono hy.le)).symm

private theorem log_le_half {v : ℝ} (hv : 0 < v) : Real.log v ≤ v / 2 := by
  have ht : 0 < v / 2 := by positivity
  have h := Real.log_le_sub_one_of_pos ht
  rw [Real.log_div hv.ne' (by norm_num)] at h
  linarith [Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 2)]

private theorem clippedLog_mul_self_le {v : ℝ} (hv : 1 ≤ v) :
    clippedLog v * clippedLog v ≤ v := by
  by_cases h : Real.exp 1 ≤ v
  · rw [clippedLog_eq_log h]
    have hs := log_le_half (Real.sqrt_pos.mpr (zero_lt_one.trans_le hv))
    rw [Real.log_sqrt (zero_le_one.trans hv)] at hs
    have hl : Real.log v ≤ Real.sqrt v := by linarith
    have hnonneg := Real.log_nonneg hv
    simpa only [Real.mul_self_sqrt (zero_le_one.trans hv)] using
      mul_le_mul hl hl hnonneg (Real.sqrt_nonneg v)
  · simpa only [clippedLog_eq_one (le_of_not_ge h), one_mul] using hv

private theorem truncatedLogProduct_le_self (k : ℕ) {v : ℝ} (hv : 1 ≤ v) :
    truncatedLogProduct k v ≤ v := by
  induction k generalizing v with
  | zero => exact hv
  | succ k ih =>
    exact (mul_le_mul_of_nonneg_left (ih (one_le_clippedLog v))
      (zero_le_one.trans (one_le_clippedLog v))).trans (clippedLog_mul_self_le hv)

theorem iterLogProduct_le_self {v : ℝ} (hv : 1 ≤ v) : iterLogProduct v ≤ v :=
  truncatedLogProduct_le_self _ hv

/-- The starting point for the positive constant extension of B. -/
noncomputable def scaleStart : ℝ := Real.exp (Real.exp 1)

theorem exp_one_le_scaleStart : Real.exp 1 ≤ scaleStart :=
  Real.exp_le_exp.mpr exp_one_gt_one.le

private theorem scaleStart_pos : 0 < scaleStart := Real.exp_pos _

/-- The truncated product A, starting at the third iterate. -/
noncomputable def iteratedLogA (t : ℝ) : ℝ :=
  iterLogProduct (Real.log (Real.log (max scaleStart t)))

/-- The common benchmark B, with its constant extension up to e^e. -/
noncomputable def iteratedLogB (t : ℝ) : ℝ :=
  max scaleStart t / Real.log (max scaleStart t) * iteratedLogA t

private theorem log_max_ge_one (t : ℝ) : 1 ≤ Real.log (max scaleStart t) :=
  (Real.le_log_iff_exp_le (scaleStart_pos.trans_le (le_max_left _ _))).2
    (exp_one_le_scaleStart.trans (le_max_left _ _))

theorem iteratedLogA_eq {t : ℝ} (ht : scaleStart ≤ t) :
    iteratedLogA t = iterLogProduct (Real.log (Real.log t)) := by
  rw [iteratedLogA, max_eq_right ht]

theorem iteratedLogA_eq_third {t : ℝ} (ht : scaleStart ≤ t)
    (hlog : 1 ≤ Real.log (Real.log (Real.log t))) :
    iteratedLogA t = Real.log (Real.log (Real.log t)) *
      iterLogProduct (Real.log (Real.log (Real.log t))) := by
  have h : Real.exp 1 ≤ Real.log t :=
    (Real.le_log_iff_exp_le (scaleStart_pos.trans_le ht)).mpr ht
  have hv : 0 < Real.log (Real.log t) := Real.log_pos (exp_one_gt_one.trans_le h)
  rw [iteratedLogA_eq ht, iterLogProduct_eq_log_mul ((Real.le_log_iff_exp_le hv).mp hlog)]

theorem one_le_iteratedLogA (t : ℝ) : 1 ≤ iteratedLogA t :=
  one_le_iterLogProduct _

theorem iteratedLogB_pos (t : ℝ) : 0 < iteratedLogB t :=
  mul_pos (div_pos (scaleStart_pos.trans_le (le_max_left _ _)) (zero_lt_one.trans_le (log_max_ge_one _)))
    (zero_lt_one.trans_le (one_le_iteratedLogA _))

theorem iteratedLogB_const_of_le {t : ℝ} (ht : t ≤ scaleStart) :
    iteratedLogB t = iteratedLogB scaleStart := by
  simp only [iteratedLogB, iteratedLogA, max_eq_left ht, max_self]

theorem iteratedLogB_eq {t : ℝ} (ht : scaleStart ≤ t) :
    iteratedLogB t = t / Real.log t * iteratedLogA t := by
  rw [iteratedLogB, max_eq_right ht]

theorem monotone_iteratedLogA : Monotone iteratedLogA := by
  intro u v huv
  unfold iteratedLogA
  exact monotone_iterLogProduct (Real.log_le_log (zero_lt_one.trans_le (log_max_ge_one _))
    (Real.log_le_log (scaleStart_pos.trans_le (le_max_left _ _)) (max_le_max le_rfl huv)))

theorem continuous_iteratedLogA : Continuous iteratedLogA := by
  unfold iteratedLogA
  have h := (continuous_const.max continuous_id : Continuous (fun t : ℝ => max scaleStart t)).log
    (fun t => (scaleStart_pos.trans_le (le_max_left _ _)).ne')
  exact continuous_iterLogProduct.comp (h.log fun t => (zero_lt_one.trans_le (log_max_ge_one t)).ne')

theorem continuous_iteratedLogB : Continuous iteratedLogB := by
  unfold iteratedLogB
  have h : Continuous (fun t : ℝ => max scaleStart t) := continuous_const.max continuous_id
  have hlog := h.log (fun t => (scaleStart_pos.trans_le (le_max_left _ _)).ne')
  exact (h.div hlog (fun t => (zero_lt_one.trans_le (log_max_ge_one t)).ne')).mul continuous_iteratedLogA

theorem monotone_iteratedLogB : Monotone iteratedLogB := by
  intro u v huv
  have hcut (z : ℝ) : max scaleStart z ∈ Set.Ici (Real.exp 1) :=
    exp_one_le_scaleStart.trans (le_max_left _ _)
  have hquot := Real.log_div_self_antitoneOn (hcut u) (hcut v) (max_le_max le_rfl huv)
  have hpos (t : ℝ) : 0 < Real.log (max scaleStart t) / max scaleStart t :=
    div_pos (zero_lt_one.trans_le (log_max_ge_one _)) (scaleStart_pos.trans_le (le_max_left _ _))
  have h : max scaleStart u / Real.log (max scaleStart u) ≤
      max scaleStart v / Real.log (max scaleStart v) := by
    simpa only [one_div, inv_div] using one_div_le_one_div_of_le (hpos v) hquot
  exact mul_le_mul h (monotone_iteratedLogA huv) (zero_le_one.trans (one_le_iteratedLogA _))
    (div_nonneg (scaleStart_pos.trans_le (le_max_left _ _)).le ((log_max_ge_one _).trans' zero_le_one))

private theorem tendsto_thirdLog : Tendsto (fun t : ℝ => Real.log (Real.log (Real.log t))) atTop atTop :=
  Real.tendsto_log_atTop.comp (Real.tendsto_log_atTop.comp Real.tendsto_log_atTop)

/-- The iterated-log product satisfies both elementary bounds in V2. -/
theorem eventually_iteratedLogA_bounds :
    ∀ᶠ t : ℝ in atTop, Real.log (Real.log (Real.log t)) ≤ iteratedLogA t ∧
      iteratedLogA t ≤ (Real.log (Real.log (Real.log t))) ^ 2 := by
  filter_upwards [eventually_ge_atTop scaleStart, tendsto_thirdLog.eventually_ge_atTop 1] with t ht hlog
  rw [iteratedLogA_eq_third ht hlog]
  exact ⟨le_mul_of_one_le_right (zero_le_one.trans hlog) (one_le_iterLogProduct _),
    (mul_le_mul_of_nonneg_left (iterLogProduct_le_self hlog) (zero_le_one.trans hlog)).trans_eq
      (pow_two _).symm⟩

theorem tendsto_iteratedLogA : Tendsto iteratedLogA atTop atTop := by
  refine tendsto_atTop.2 fun M => ?_
  filter_upwards [eventually_iteratedLogA_bounds, tendsto_thirdLog.eventually_ge_atTop M] with t h hM
  exact hM.trans h.1


/-- Halving removes at least the corresponding fraction of the first logarithmic factor. -/
theorem iterLogProduct_half_le {x : ℝ} (hx : 2 * Real.exp 1 ≤ x) :
    iterLogProduct (x / 2) ≤ iterLogProduct x * (Real.log (x / 2) / Real.log x) := by
  have hh : Real.exp 1 ≤ x / 2 := by linarith
  have hx' : Real.exp 1 ≤ x := by linarith [Real.exp_pos (1 : ℝ)]
  have hx0 := (Real.exp_pos _).trans_le hx'
  have hh0 := (Real.exp_pos _).trans_le hh
  have hlx : 0 < Real.log x := Real.log_pos (exp_one_gt_one.trans_le hx')
  rw [iterLogProduct_eq_log_mul hh, iterLogProduct_eq_log_mul hx']
  calc
    _ ≤ Real.log (x / 2) * iterLogProduct (Real.log x) := by
      apply mul_le_mul_of_nonneg_left
      · exact monotone_iterLogProduct (Real.log_le_log hh0 (by linarith))
      · exact Real.log_nonneg (exp_one_gt_one.le.trans hh)
    _ = _ := by field_simp

/-- Quantitative lower bound for V2's positive deficit. -/
theorem iterLogProduct_deficit_lower {x : ℝ} (hx : 2 * Real.exp 1 ≤ x) :
    (x / 2 - 1) * iterLogProduct x * Real.log 2 / Real.log x ≤
      x * iterLogProduct x - ∫ v in (1 : ℝ)..x, iterLogProduct v := by
  have hh : 1 ≤ x / 2 := by linarith [exp_one_gt_one]
  have hg : x / 2 ≤ x := by linarith
  have hleft : (∫ v in (1 : ℝ)..x / 2, iterLogProduct v) ≤
      (x / 2 - 1) * iterLogProduct (x / 2) := by
    have h : (∫ v in (1 : ℝ)..x / 2, iterLogProduct v) ≤ (∫ _v in (1 : ℝ)..x / 2, iterLogProduct (x / 2)) :=
      intervalIntegral.integral_mono_on hh
      (continuous_iterLogProduct.intervalIntegrable _ _) (intervalIntegrable_const)
      (fun v hv => monotone_iterLogProduct hv.2)
    rwa [intervalIntegral.integral_const, smul_eq_mul] at h
  have hright : (∫ v in x / 2..x, iterLogProduct v) ≤
      (x - x / 2) * iterLogProduct x := by
    have h : (∫ v in x / 2..x, iterLogProduct v) ≤ (∫ _v in x / 2..x, iterLogProduct x) :=
      intervalIntegral.integral_mono_on hg
      (continuous_iterLogProduct.intervalIntegrable _ _) (intervalIntegrable_const)
      (fun v hv => monotone_iterLogProduct hv.2)
    rwa [intervalIntegral.integral_const, smul_eq_mul] at h
  have hbound := add_le_add hleft hright
  rw [intervalIntegral.integral_add_adjacent_intervals
    (continuous_iterLogProduct.intervalIntegrable _ _)
    (continuous_iterLogProduct.intervalIntegrable _ _)] at hbound
  have hscaled := mul_le_mul_of_nonneg_left (iterLogProduct_half_le hx) (sub_nonneg.mpr hh)
  have hx0 : 0 < x := by linarith
  have hx1 : 1 < x := by linarith
  have hdiff : Real.log (x / 2) = Real.log x - Real.log 2 :=
    Real.log_div hx0.ne' (by norm_num)
  have halg : (x / 2 - 1) * (iterLogProduct x * (Real.log (x / 2) / Real.log x)) +
      (x - x / 2) * iterLogProduct x =
      (x - 1) * iterLogProduct x - (x / 2 - 1) * iterLogProduct x * Real.log 2 / Real.log x := by
    rw [hdiff]
    field_simp [(Real.log_pos hx1).ne']
    ring
  linarith only [hbound, hscaled, halg, one_le_iterLogProduct x]

private theorem tendsto_id_div_log : Tendsto (fun x : ℝ => x / Real.log x) atTop atTop := by
  have h : Tendsto (fun x : ℝ => Real.log x / x) atTop (𝓝 0) :=
    Real.isLittleO_log_id_atTop.tendsto_div_nhds_zero
  have hpos : ∀ᶠ x : ℝ in atTop, Real.log x / x ∈ Set.Ioi 0 := by
    filter_upwards [eventually_gt_atTop (1 : ℝ)] with x hx
    exact div_pos (Real.log_pos hx) (zero_lt_one.trans hx)
  have h' := tendsto_nhdsWithin_iff.mpr ⟨h, hpos⟩
  convert h'.inv_tendsto_nhdsGT_zero using 1
  funext x
  exact (inv_div _ _).symm

/-- The positive deficit tends to infinity. -/
theorem tendsto_iterLogProduct_deficit :
    Tendsto (fun x : ℝ => x * iterLogProduct x - ∫ v in (1 : ℝ)..x, iterLogProduct v) atTop atTop := by
  apply tendsto_atTop_mono' atTop ?_ (tendsto_id_div_log.const_mul_atTop
    (div_pos (Real.log_pos (by norm_num : (1 : ℝ) < 2)) (by norm_num : (0 : ℝ) < 4)))
  filter_upwards [eventually_ge_atTop (2 * Real.exp 1), eventually_ge_atTop (4 : ℝ)] with x hx hx4
  have hl : 0 < Real.log x := Real.log_pos (by linarith)
  have hp := one_le_iterLogProduct x
  have hmul : x / 4 ≤ (x / 2 - 1) * iterLogProduct x :=
    (show x / 4 ≤ x / 2 - 1 by linarith).trans
      (le_mul_of_one_le_right (by linarith) hp)
  apply le_trans _ (iterLogProduct_deficit_lower hx)
  simpa only [mul_div_assoc, div_mul_eq_mul_div, mul_comm (Real.log 2), ← mul_div_assoc] using
    div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_right hmul
      (Real.log_nonneg (by norm_num : (1 : ℝ) ≤ 2))) hl.le

private theorem scaleStart_gt_one : 1 < scaleStart := exp_one_gt_one.trans_le exp_one_le_scaleStart

private theorem intervalIntegrable_logB_div_sq {a b : ℝ} (ha : 0 < a) (hab : a ≤ b) :
    IntervalIntegrable (fun t => iteratedLogB t / t ^ 2) volume a b := by
  apply ContinuousOn.intervalIntegrable
  refine continuous_iteratedLogB.continuousOn.div (continuous_id.pow 2).continuousOn ?_
  intro t ht
  exact pow_ne_zero _ (ha.trans_le ((Set.uIcc_of_le hab) ▸ ht).1).ne'

/-- Change of variables v = log (log t) for the integral of the benchmark B. -/
theorem iteratedLogB_integral_substitution {n : ℝ} (hn : scaleStart ≤ Real.log n) :
    (∫ t in (1 : ℝ)..Real.log n, iteratedLogB t / t ^ 2) =
      (∫ t in (1 : ℝ)..scaleStart, iteratedLogB t / t ^ 2) +
        ∫ v in (1 : ℝ)..Real.log (Real.log (Real.log n)), iterLogProduct v := by
  have hcut {t : ℝ} (ht : t ∈ Set.uIcc scaleStart (Real.log n)) : scaleStart ≤ t :=
    ((Set.uIcc_of_le hn) ▸ ht).1
  have hint : ∫ t in scaleStart..Real.log n, iteratedLogB t / t ^ 2 =
      ∫ v in (1 : ℝ)..Real.log (Real.log (Real.log n)), iterLogProduct v := by
    let f : ℝ → ℝ := fun t => Real.log (Real.log t)
    let d : ℝ → ℝ := fun t => (Real.log t)⁻¹ * t⁻¹
    have htpos {t : ℝ} (ht : t ∈ Set.uIcc scaleStart (Real.log n)) : 0 < t :=
      scaleStart_pos.trans_le (hcut ht)
    have hlpos {t : ℝ} (ht : t ∈ Set.uIcc scaleStart (Real.log n)) : 0 < Real.log t :=
      Real.log_pos (scaleStart_gt_one.trans_le (hcut ht))
    have hDeriv (t : ℝ) (ht : t ∈ Set.uIcc scaleStart (Real.log n)) : HasDerivAt f (d t) t :=
      (Real.hasDerivAt_log (hlpos ht).ne').comp t (Real.hasDerivAt_log (htpos ht).ne')
    have hd : ContinuousOn d (Set.uIcc scaleStart (Real.log n)) :=
      ((Real.continuousOn_log.mono fun t ht => (htpos ht).ne').inv₀ fun t ht =>
        (hlpos ht).ne').mul (continuous_id.continuousOn.inv₀ fun t ht => (htpos ht).ne')
    calc
      _ = ∫ t in scaleStart..Real.log n, (iterLogProduct ∘ f) t * d t := by
        apply intervalIntegral.integral_congr
        intro t ht
        change iteratedLogB t / t ^ 2 = iterLogProduct (Real.log (Real.log t)) *
          ((Real.log t)⁻¹ * t⁻¹)
        rw [iteratedLogB_eq (hcut ht), iteratedLogA_eq (hcut ht)]
        field_simp [(htpos ht).ne', (hlpos ht).ne']
      _ = ∫ v in f scaleStart..f (Real.log n), iterLogProduct v :=
        intervalIntegral.integral_comp_mul_deriv hDeriv hd continuous_iterLogProduct
      _ = _ := by simp only [f, scaleStart, Real.log_exp]
  rw [← hint, intervalIntegral.integral_add_adjacent_intervals
    (intervalIntegrable_logB_div_sq one_pos scaleStart_gt_one.le)
    (intervalIntegrable_logB_div_sq scaleStart_pos hn)]

/-- The normalized benchmark eventually exceeds its integral by any fixed constant. -/
theorem tendsto_iteratedLogB_integral_deficit :
    Tendsto (fun n : ℝ => iteratedLogA n -
      ∫ t in (1 : ℝ)..Real.log n, iteratedLogB t / t ^ 2) atTop atTop := by
  let c := ∫ t in (1 : ℝ)..scaleStart, iteratedLogB t / t ^ 2
  have hbase := tendsto_atTop_add_const_right atTop (-c)
    (tendsto_iterLogProduct_deficit.comp tendsto_thirdLog)
  apply hbase.congr'
  filter_upwards [eventually_ge_atTop scaleStart,
    Real.tendsto_log_atTop.eventually_ge_atTop scaleStart,
    tendsto_thirdLog.eventually_ge_atTop 1] with n hn hnlog hn3
  dsimp only [Function.comp_def, c]
  rw [iteratedLogA_eq_third hn hn3, iteratedLogB_integral_substitution hnlog]
  ring


private theorem intervalIntegrable_floor_div_sq (g : ℕ → ℝ) {a b : ℝ} (ha : 1 ≤ a) (hab : a ≤ b) :
    IntervalIntegrable (fun t : ℝ => g ⌊t⌋₊ / t ^ 2) volume a b := by
  rw [intervalIntegrable_iff_integrableOn_Icc_of_le hab]
  have hg : Measurable g := Measurable.of_discrete
  have hm : Measurable (fun t : ℝ => g ⌊t⌋₊ / t ^ 2) :=
    (hg.comp Nat.measurable_floor).div (measurable_id.pow_const 2)
  let C := ∑ j ∈ Finset.range (⌊b⌋₊ + 1), ‖g j‖
  refine IntegrableOn.of_bound measure_Icc_lt_top hm.aestronglyMeasurable C
    ((ae_restrict_iff' measurableSet_Icc).mpr (Filter.Eventually.of_forall fun t ht => ?_))
  have hnorm : 1 ≤ ‖t ^ 2‖ := by
    rw [Real.norm_of_nonneg (sq_nonneg t)]
    nlinarith only [ha.trans ht.1, sq_nonneg (t - 1)]
  calc
    _ = ‖g ⌊t⌋₊‖ / ‖t ^ 2‖ := norm_div _ _
    _ ≤ ‖g ⌊t⌋₊‖ := div_le_self (norm_nonneg _) hnorm
    _ ≤ C := Finset.single_le_sum (fun j _ => norm_nonneg _)
      (Finset.mem_range.mpr (Nat.lt_succ_of_le (Nat.floor_mono ht.2)))

/-- A uniform upper integral recursion implies a uniform upper bound by the benchmark B. -/
theorem le_iteratedLogB_of_integral_bound {ι : Type*} (g : ι → ℕ → ℝ) (L c : ℝ)
    (hlin : ∀ i n, g i n ≤ L * (n : ℝ))
    (hrec : ∀ᶠ n : ℕ in atTop, ∀ i, g i n ≤ (n : ℝ) / Real.log n *
      ((∫ t in (1 : ℝ)..Real.log n, g i ⌊t⌋₊ / t ^ 2) + c)) :
    ∃ C ≥ (1 : ℝ), ∀ i n, g i n ≤ C * iteratedLogB (n : ℝ) := by
  let d := max c 0
  have hcast : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hlim := (tendsto_iteratedLogB_integral_deficit.comp hcast).eventually_ge_atTop d
  obtain ⟨T, hT⟩ := eventually_atTop.mp (hrec.and (hlim.and (hcast.eventually_ge_atTop scaleStart)))
  let C := max 1 (∑ j ∈ Finset.range T, max 0 (L * (j : ℝ) / iteratedLogB (j : ℝ)))
  have hC : 1 ≤ C := le_max_left _ _
  have hC₀ : 0 ≤ C := zero_le_one.trans hC
  refine ⟨C, hC, fun i n => ?_⟩
  induction n using Nat.strong_induction_on with
  | ind n ih =>
    by_cases hn : n < T
    · have hc : L * (n : ℝ) / iteratedLogB n ≤ C := calc
        _ ≤ max 0 (L * (n : ℝ) / iteratedLogB n) := le_max_right _ _
        _ ≤ ∑ j ∈ Finset.range T, max 0 (L * (j : ℝ) / iteratedLogB j) :=
          Finset.single_le_sum (f := fun j : ℕ => max 0 (L * (j : ℝ) / iteratedLogB j))
            (fun j _ => le_max_left _ _) (Finset.mem_range.mpr hn)
        _ ≤ _ := le_max_right _ _
      exact (hlin i n).trans ((div_le_iff₀ (iteratedLogB_pos _)).mp hc)
    obtain ⟨hrec_n, hdef, hstart⟩ := hT n (le_of_not_gt hn)
    have hnpos : (0 : ℝ) < n := scaleStart_pos.trans_le hstart
    have hlog : 1 ≤ Real.log (n : ℝ) :=
      (Real.le_log_iff_exp_le hnpos).mpr (exp_one_le_scaleStart.trans hstart)
    have hlt : Real.log (n : ℝ) < n :=
      (Real.log_le_sub_one_of_pos hnpos).trans_lt (by linarith)
    have hratio : 0 ≤ (n : ℝ) / Real.log n := div_nonneg hnpos.le (zero_le_one.trans hlog)
    have hInt := intervalIntegral.integral_mono_on hlog
      (intervalIntegrable_floor_div_sq (g i) le_rfl hlog)
      ((intervalIntegrable_logB_div_sq one_pos hlog).const_mul C)
      (fun t ht => by
        have ht₁ : (⌊t⌋₊ : ℝ) ≤ t := Nat.floor_le (zero_le_one.trans ht.1)
        have ht₂ : ⌊t⌋₊ < n := by exact_mod_cast ht₁.trans_lt (ht.2.trans_lt hlt)
        rw [← mul_div_assoc]
        exact div_le_div_of_nonneg_right
          ((ih _ ht₂).trans (mul_le_mul_of_nonneg_left (monotone_iteratedLogB ht₁) hC₀))
          (sq_nonneg _))
    rw [intervalIntegral.integral_const_mul] at hInt
    have hErr : c ≤ C * d :=
      (le_max_left c 0).trans (le_mul_of_one_le_left (le_max_right c 0) hC)
    have hBound : C * (∫ t in (1 : ℝ)..Real.log n, iteratedLogB t / t ^ 2) + c ≤
        C * iteratedLogA (n : ℝ) := calc
      _ ≤ C * (∫ t in (1 : ℝ)..Real.log n, iteratedLogB t / t ^ 2) + C * d :=
        add_le_add le_rfl hErr
      _ ≤ _ := by
        rw [← mul_add]
        apply mul_le_mul_of_nonneg_left _ hC₀
        exact le_sub_iff_add_le'.mp hdef
    calc
      _ ≤ (n : ℝ) / Real.log n *
          ((∫ t in (1 : ℝ)..Real.log n, g i ⌊t⌋₊ / t ^ 2) + c) := hrec_n i
      _ ≤ _ := mul_le_mul_of_nonneg_left (add_le_add hInt le_rfl) hratio
      _ ≤ (n : ℝ) / Real.log n * (C * iteratedLogA n) :=
        mul_le_mul_of_nonneg_left hBound hratio
      _ = _ := by rw [iteratedLogB_eq hstart]; ring


private theorem integral_floor_div_sq_step (g : ℕ → ℝ) {j : ℕ} (hj : 1 ≤ j) :
    (∫ t in (j : ℝ)..(j : ℝ) + 1, g ⌊t⌋₊ / t ^ 2) =
      g j / ((j : ℝ) * ((j : ℝ) + 1)) := by
  have hj0 : (0 : ℝ) < j := by exact_mod_cast hj
  have hle : (j : ℝ) ≤ (j : ℝ) + 1 := by linarith
  have hint : (∫ t in (j : ℝ)..(j : ℝ) + 1, (t ^ 2)⁻¹) =
      (j : ℝ)⁻¹ - ((j : ℝ) + 1)⁻¹ := by
    have hz : (0 : ℝ) ∉ Set.uIcc (j : ℝ) ((j : ℝ) + 1) := by
      rw [Set.uIcc_of_le hle]
      exact fun h => hj0.not_ge h.1
    have h := integral_zpow (n := -2) (a := (j : ℝ)) (b := (j : ℝ) + 1)
      (Or.inr ⟨by norm_num, hz⟩)
    norm_num [zpow_neg] at h
    linarith only [h]
  calc
    _ = ∫ t in (j : ℝ)..(j : ℝ) + 1, g j / t ^ 2 := by
      apply intervalIntegral.integral_congr_Ioo_of_le hle
      intro t ht
      have hfloor := (Nat.floor_eq_iff (hj0.le.trans ht.1.le)).mpr ⟨ht.1.le, ht.2⟩
      exact congrArg (fun x => g x / t ^ 2) hfloor
    _ = g j * (∫ t in (j : ℝ)..(j : ℝ) + 1, (t ^ 2)⁻¹) := by
      simp only [← intervalIntegral.integral_const_mul, div_eq_mul_inv]
    _ = _ := by
      rw [hint]
      field_simp [hj0.ne', (show 0 < (j : ℝ) + 1 by positivity).ne']
      ring

/-- The interval integral of the step function gives the exact reciprocal-block coefficients. -/
theorem integral_floor_div_sq_eq_sum (g : ℕ → ℝ) (K : ℕ) :
    (∫ t in (1 : ℝ)..(K : ℝ) + 1, g ⌊t⌋₊ / t ^ 2) =
      ∑ j ∈ Finset.Icc 1 K, g j / ((j : ℝ) * ((j : ℝ) + 1)) := by
  induction K with
  | zero => simp
  | succ K ih =>
    have h₁ : (1 : ℝ) ≤ (K : ℝ) + 1 := by linarith [Nat.cast_nonneg (α := ℝ) K]
    have h₂ : ((K + 1 : ℕ) : ℝ) = (K : ℝ) + 1 := by simp only [Nat.cast_add, Nat.cast_one]
    have hstep := integral_floor_div_sq_step g (j := K + 1) (by omega)
    rw [Finset.sum_Icc_succ_top (by omega), ← ih, ← hstep]
    rw [h₂]
    exact (intervalIntegral.integral_add_adjacent_intervals
      (intervalIntegrable_floor_div_sq g le_rfl h₁)
      (intervalIntegrable_floor_div_sq g h₁ (by linarith))).symm

/-- A finite weighted prime-block recurrence supplies the upper integral recursion when g is nonnegative. -/
theorem finiteRecursion_to_integralUpper {g : ℕ → ℝ} (hg : ∀ j, 0 ≤ g j)
    {n K : ℕ} {c : ℝ} (hend : (K : ℝ) + 1 ≤ Real.log n)
    (hrec : g n ≤ (n : ℝ) / Real.log n *
      ((∑ j ∈ Finset.Icc 1 K, g j / ((j : ℝ) * ((j : ℝ) + 1))) + c)) :
    g n ≤ (n : ℝ) / Real.log n * ((∫ t in (1 : ℝ)..Real.log n, g ⌊t⌋₊ / t ^ 2) + c) := by
  have h₁ : (1 : ℝ) ≤ (K : ℝ) + 1 := by linarith [Nat.cast_nonneg (α := ℝ) K]
  have hInt : (∫ t in (1 : ℝ)..(K : ℝ) + 1, g ⌊t⌋₊ / t ^ 2) ≤
      ∫ t in (1 : ℝ)..Real.log n, g ⌊t⌋₊ / t ^ 2 := by
    rw [← intervalIntegral.integral_add_adjacent_intervals
      (intervalIntegrable_floor_div_sq g le_rfl h₁)
      (intervalIntegrable_floor_div_sq g h₁ hend)]
    exact le_add_of_nonneg_right (intervalIntegral.integral_nonneg_of_forall hend
      fun t => div_nonneg (hg _) (sq_nonneg t))
  rw [← integral_floor_div_sq_eq_sum g K] at hrec
  exact hrec.trans <| mul_le_mul_of_nonneg_left (add_le_add hInt le_rfl)
    (div_nonneg (Nat.cast_nonneg _) (zero_le_one.trans (h₁.trans hend)))


/-- Extending the step integral by a factor of at most two costs at most M log 2. -/
theorem integral_floor_div_sq_endpoint {g : ℕ → ℝ} {M : ℝ}
    (hM : 0 ≤ M) (hg : ∀ j, 0 ≤ g j) (hlin : ∀ j, g j ≤ M * (j : ℝ))
    {K : ℕ} {b : ℝ} (hb : (K : ℝ) + 1 ≤ b) (hb₂ : b ≤ 2 * ((K : ℝ) + 1)) :
    let S := ∑ j ∈ Finset.Icc 1 K, g j / ((j : ℝ) * ((j : ℝ) + 1))
    let I := ∫ t in (1 : ℝ)..b, g ⌊t⌋₊ / t ^ 2
    0 ≤ I - S ∧ I - S ≤ M * Real.log 2 := by
  dsimp only
  let a := (K : ℝ) + 1
  have ha : (1 : ℝ) ≤ a := by
    dsimp only [a]
    linarith [Nat.cast_nonneg (α := ℝ) K]
  have ha0 : 0 < a := zero_lt_one.trans_le ha
  have hb0 : 0 < b := ha0.trans_le hb
  rw [← integral_floor_div_sq_eq_sum g K, ← intervalIntegral.integral_add_adjacent_intervals
      (intervalIntegrable_floor_div_sq g le_rfl ha) (intervalIntegrable_floor_div_sq g ha hb),
    add_sub_cancel_left]
  refine ⟨intervalIntegral.integral_nonneg_of_forall hb (fun t => div_nonneg (hg _) (sq_nonneg t)), ?_⟩
  have hpos {t : ℝ} (ht : t ∈ Set.uIcc a b) : 0 < t :=
    ha0.trans_le ((Set.uIcc_of_le hb) ▸ ht).1
  have hc : IntervalIntegrable (fun t : ℝ => M * t⁻¹) volume a b :=
    (continuousOn_const.mul (continuous_id.continuousOn.inv₀ fun t ht => (hpos ht).ne')).intervalIntegrable
  have htail : (∫ t in a..b, g ⌊t⌋₊ / t ^ 2) ≤ ∫ t in a..b, M * t⁻¹ := by
    apply intervalIntegral.integral_mono_on hb (intervalIntegrable_floor_div_sq g ha hb) hc
    intro t ht
    have ht0 : 0 < t := ha0.trans_le ht.1
    have hfloor : (⌊t⌋₊ : ℝ) ≤ t := Nat.floor_le ht0.le
    calc
      _ ≤ (M * t) / t ^ 2 := div_le_div_of_nonneg_right
        ((hlin _).trans (mul_le_mul_of_nonneg_left hfloor hM)) (sq_nonneg t)
      _ = _ := by field_simp [ht0.ne']
  rw [intervalIntegral.integral_const_mul, integral_inv (fun ht => (lt_irrefl 0) (hpos ht))] at htail
  exact htail.trans <| mul_le_mul_of_nonneg_left
    (Real.log_le_log (div_pos hb0 ha0) ((div_le_iff₀ ha0).mpr hb₂)) hM

/-- The two-sided finite prime-block error remains bounded after replacing the sum by the integral. -/
theorem finiteRecursion_to_integralError {g : ℕ → ℝ} {M c : ℝ}
    (hM : 0 ≤ M) (hg : ∀ j, 0 ≤ g j) (hlin : ∀ j, g j ≤ M * (j : ℝ))
    {n K : ℕ} (hend : (K : ℝ) + 1 ≤ Real.log n) (hhalf : Real.log n ≤ 2 * ((K : ℝ) + 1))
    (hrec : |g n - (n : ℝ) / Real.log n *
      (∑ j ∈ Finset.Icc 1 K, g j / ((j : ℝ) * ((j : ℝ) + 1)))| ≤ c * ((n : ℝ) / Real.log n)) :
    |g n - (n : ℝ) / Real.log n *
      (∫ t in (1 : ℝ)..Real.log n, g ⌊t⌋₊ / t ^ 2)| ≤
        (c + M * Real.log 2) * ((n : ℝ) / Real.log n) := by
  let S := ∑ j ∈ Finset.Icc 1 K, g j / ((j : ℝ) * ((j : ℝ) + 1))
  let I := ∫ t in (1 : ℝ)..Real.log n, g ⌊t⌋₊ / t ^ 2
  let q := (n : ℝ) / Real.log n
  have ht : 0 ≤ I - S ∧ I - S ≤ M * Real.log 2 :=
    integral_floor_div_sq_endpoint hM hg hlin hend hhalf
  have hlog : 0 ≤ Real.log n := (show 0 ≤ (K : ℝ) + 1 by positivity).trans hend
  have hq : 0 ≤ q := div_nonneg (Nat.cast_nonneg _) hlog
  change |g n - q * I| ≤ _
  calc
    _ = |(g n - q * S) - q * (I - S)| := by congr 1; ring
    _ ≤ |g n - q * S| + |q * (I - S)| := abs_sub _ _
    _ ≤ c * q + q * (M * Real.log 2) := by
      apply add_le_add hrec
      rw [abs_of_nonneg (mul_nonneg hq ht.1)]
      exact mul_le_mul_of_nonneg_left ht.2 hq
    _ = _ := by ring

theorem halfLog_integral_endpoints {n : ℝ} (hn : 2 ≤ Real.log n) :
    ((⌊Real.log n / 2⌋₊ : ℕ) : ℝ) + 1 ≤ Real.log n ∧
      Real.log n ≤ 2 * (((⌊Real.log n / 2⌋₊ : ℕ) : ℝ) + 1) := by
  have hlow := Nat.floor_le (show 0 ≤ Real.log n / 2 by linarith)
  have hup := Nat.lt_floor_add_one (Real.log n / 2)
  constructor <;> linarith

end LeanAB.PaperA
