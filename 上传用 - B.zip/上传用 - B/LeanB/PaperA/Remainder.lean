module

public import Common
public import PaperA.Threshold
import Mathlib.Tactic

public section

/-! Bounds on the common denominator of the remainder. -/

namespace LeanAB.PaperA

open scoped BigOperators Topology
open Filter

private def smallPrimePowers (n : ℕ) : ℕ :=
  ∏ p ∈ Nat.primesLE n.sqrt, p ^ p.log n

private theorem smallPrimePowers_pos (n : ℕ) : 0 < smallPrimePowers n := by
  unfold smallPrimePowers
  exact Finset.prod_pos fun p hp => pow_pos (Nat.prime_of_mem_primesLE hp).pos _

private theorem smallPrimePowers_le (n : ℕ) (hn : 0 < n) :
    smallPrimePowers n ≤ n ^ n.sqrt := by
  have hcard : (Nat.primesLE n.sqrt).card ≤ n.sqrt := calc
    _ ≤ (Finset.Icc 1 n.sqrt).card := Finset.card_le_card fun p hp =>
      Finset.mem_Icc.mpr ⟨(Nat.prime_of_mem_primesLE hp).pos, Nat.le_of_mem_primesLE hp⟩
    _ = n.sqrt := by simp
  calc
    _ ≤ n ^ (Nat.primesLE n.sqrt).card :=
      Finset.prod_le_pow_card _ _ _ fun p _ => Nat.pow_log_le_self p hn.ne'
    _ ≤ _ := Nat.pow_le_pow_right hn hcard

private theorem lcm_dvd_cutoffEnvelope {n y : ℕ} {E : Finset ℕ} (hE : E ⊆ interval 1 n)
    (hcut : ∀ a ∈ E, ∀ p : ℕ, p.Prime → p ∣ a → p ≤ y) :
    E.lcm id ∣ Nat.lcmUpto y * smallPrimePowers n := by
  apply Finset.lcm_dvd
  intro a ha
  have hain : a ∈ Finset.Icc 1 n := by simpa [interval] using hE ha
  have ha₀ : a ≠ 0 := Nat.ne_of_gt (Finset.mem_Icc.mp hain).1
  have han := (Finset.mem_Icc.mp hain).2
  have hpos : 0 < Nat.lcmUpto y * smallPrimePowers n :=
    Nat.mul_pos (Nat.lcmUpto_pos y) (smallPrimePowers_pos n)
  apply (Nat.factorization_le_iff_dvd ha₀ hpos.ne').mp
  intro p
  by_cases hp : p.Prime
  · apply (hp.pow_dvd_iff_le_factorization hpos.ne').mp
    have hpow : p ^ a.factorization p ∣ a := (hp.pow_dvd_iff_le_factorization ha₀).mpr le_rfl
    by_cases hsmall : p ≤ n.sqrt
    · have hd : a ∣ Nat.lcmUpto n := Finset.dvd_lcm hain
      have he := ((Nat.factorization_le_iff_dvd ha₀ (Nat.lcmUpto_ne_zero n)).mpr hd) p
      rw [Nat.factorization_lcmUpto n hp] at he
      have hprod : p ^ p.log n ∣ smallPrimePowers n :=
        Finset.dvd_prod_of_mem _ (Nat.mem_primesLE.mpr ⟨hsmall, hp⟩)
      exact (pow_dvd_pow p he).trans (hprod.trans (dvd_mul_left _ _))
    · have he : a.factorization p < 2 := by
        by_contra! h
        have hdiv : p ^ 2 ∣ a := (pow_dvd_pow p h).trans hpow
        exact hsmall (Nat.le_sqrt'.mpr ((Nat.le_of_dvd (Nat.pos_of_ne_zero ha₀) hdiv).trans han))
      by_cases hzero : a.factorization p = 0
      · simp [hzero]
      · have hone : a.factorization p = 1 := by omega
        rw [hone, pow_one] at hpow ⊢
        have hpIcc : p ∈ Finset.Icc 1 y := Finset.mem_Icc.mpr ⟨hp.pos, hcut a ha p hp hpow⟩
        exact (show p ∣ Nat.lcmUpto y from Finset.dvd_lcm hpIcc).trans (dvd_mul_right _ _)
  · simp [Nat.factorization_eq_zero_of_not_prime a hp]

/-- A finite common-denominator estimate for y-smooth denominators in [1,n]. -/
theorem log_lcm_le_cutoff {n y : ℕ} {E : Finset ℕ} (hn : 0 < n) (hE : E ⊆ interval 1 n)
    (hcut : ∀ a ∈ E, ∀ p : ℕ, p.Prime → p ∣ a → p ≤ y) :
    Real.log ((E.lcm id : ℕ) : ℝ) ≤ (Real.log 4 + 4) * y + √(n : ℝ) * Real.log n := by
  have hD₀ : E.lcm id ≠ 0 := by
    intro h
    obtain ⟨a, ha, haz⟩ := Finset.lcm_eq_zero_iff.mp h
    have hain : a ∈ Finset.Icc 1 n := by simpa [interval] using hE ha
    exact (Nat.ne_of_gt (Finset.mem_Icc.mp hain).1) haz
  have hD : (0 : ℝ) < (E.lcm id : ℕ) := by exact_mod_cast Nat.pos_of_ne_zero hD₀
  have hle := Nat.le_of_dvd
    (Nat.mul_pos (Nat.lcmUpto_pos y) (smallPrimePowers_pos n)) (lcm_dvd_cutoffEnvelope hE hcut)
  have hψ := Chebyshev.psi_le_const_mul_self (x := (y : ℝ)) (by positivity)
  rw [Chebyshev.psi_eq_log_lcmUpto] at hψ
  have hsmall : Real.log (smallPrimePowers n : ℝ) ≤ (n.sqrt : ℝ) * Real.log n := by
    have hm : (smallPrimePowers n : ℝ) ≤ (n : ℝ) ^ n.sqrt := by
      exact_mod_cast smallPrimePowers_le n hn
    have h0 : (0 : ℝ) < smallPrimePowers n := by exact_mod_cast smallPrimePowers_pos n
    have hl := Real.log_le_log h0 hm
    rwa [Real.log_pow] at hl
  have hsqrt : (n.sqrt : ℝ) ≤ √(n : ℝ) := by
    apply Real.le_sqrt_of_sq_le
    exact_mod_cast Nat.sqrt_le' n
  have hlog : 0 ≤ Real.log (n : ℝ) := Real.log_nonneg (by exact_mod_cast hn)
  calc
    _ ≤ Real.log ((Nat.lcmUpto y : ℝ) * (smallPrimePowers n : ℝ)) :=
      Real.log_le_log hD (by exact_mod_cast hle)
    _ = Real.log (Nat.lcmUpto y : ℝ) + Real.log (smallPrimePowers n : ℝ) := by
      apply Real.log_mul
      · exact_mod_cast Nat.lcmUpto_ne_zero y
      · exact_mod_cast (smallPrimePowers_pos n).ne'
    _ ≤ _ := add_le_add hψ (hsmall.trans (mul_le_mul_of_nonneg_right hsqrt hlog))


private theorem paperY_le (n : ℕ) (hn : 1 < n) :
    paperY n ≤ 2 * ((n : ℝ) / Real.log n) := by
  have hn₁ : (1 : ℝ) < n := by exact_mod_cast hn
  have hlog := Real.log_pos hn₁
  have hfloor : Real.log (n : ℝ) / 2 < (paperK n : ℝ) + 1 := Nat.lt_floor_add_one _
  have hK : (0 : ℝ) < (paperK n : ℝ) + 1 := by positivity
  rw [paperY, ← mul_div_assoc]
  apply (div_le_div_iff₀ hK hlog).mpr
  nlinarith [mul_le_mul_of_nonneg_left (show Real.log (n : ℝ) ≤ 2 * ((paperK n : ℝ) + 1)
    by linarith) (Nat.cast_nonneg n)]

theorem eventually_log_terms_le :
    ∀ᶠ n : ℕ in atTop, √(n : ℝ) * Real.log n ≤ (n : ℝ) / Real.log n ∧
      Real.log n ≤ (n : ℝ) / Real.log n := by
  filter_upwards [eventually_log_le_eighth, eventually_ge_atTop (2 : ℕ)] with n hpow hn
  have hn₁ : (1 : ℝ) < n := by exact_mod_cast (show 1 < n by omega)
  have hn₀ : 0 < (n : ℝ) := zero_lt_one.trans hn₁
  have hlog := Real.log_pos hn₁
  have hsquare : Real.log (n : ℝ) ^ 2 ≤ √(n : ℝ) := calc
    _ ≤ ((n : ℝ) ^ (1 / 8 : ℝ)) ^ 2 := pow_le_pow_left₀ hlog.le hpow _
    _ = (n : ℝ) ^ (1 / 4 : ℝ) := by
      rw [pow_two, ← Real.rpow_add hn₀]
      norm_num
    _ ≤ _ := by
      rw [Real.sqrt_eq_rpow]
      exact Real.rpow_le_rpow_of_exponent_le hn₁.le (by norm_num)
  constructor
  · apply (le_div_iff₀ hlog).mpr
    rw [mul_assoc, ← pow_two]
    exact (mul_le_mul_of_nonneg_left hsquare (Real.sqrt_nonneg (n : ℝ))).trans_eq
      (Real.mul_self_sqrt hn₀.le)
  · apply (le_div_iff₀ hlog).mpr
    rw [← pow_two]
    calc
      _ ≤ √(n : ℝ) := hsquare
      _ ≤ _ := (Real.sqrt_lt_self_iff.mpr hn₁).le

/-- The remainder common denominator has logarithm O(n / log n), uniformly in the set. -/
theorem eventually_log_lcm_at_paperCutoff :
    ∀ᶠ n : ℕ in atTop, ∀ (E : Finset ℕ), E ⊆ interval 1 n →
      (∀ a ∈ E, ∀ p : ℕ, p.Prime → p ∣ a → p ≤ n / (paperK n + 1)) →
      Real.log ((E.lcm id : ℕ) : ℝ) ≤ (2 * (Real.log 4 + 4) + 1) * ((n : ℝ) / Real.log n) := by
  filter_upwards [eventually_log_terms_le, eventually_ge_atTop (2 : ℕ)] with n hn hn₂ E hE hc
  have hcut : ((n / (paperK n + 1) : ℕ) : ℝ) ≤ 2 * ((n : ℝ) / Real.log n) := calc
    _ ≤ paperY n := by
      rw [paperY]
      exact_mod_cast (Nat.cast_div_le (α := ℝ) (m := n) (n := paperK n + 1))
    _ ≤ _ := paperY_le n (by omega)
  have hc₀ : 0 ≤ Real.log 4 + 4 := by positivity
  calc
    _ ≤ (Real.log 4 + 4) * ((n / (paperK n + 1) : ℕ) : ℝ) + √(n : ℝ) * Real.log n :=
      log_lcm_le_cutoff (by omega) hE hc
    _ ≤ (Real.log 4 + 4) * (2 * ((n : ℝ) / Real.log n)) + (n : ℝ) / Real.log n :=
      add_le_add (mul_le_mul_of_nonneg_left hcut hc₀) hn.1
    _ = _ := by ring

end LeanAB.PaperA
