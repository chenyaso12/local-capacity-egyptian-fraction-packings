module

public import PaperA.FactorLaw
public import PaperA.LengthSix
import Mathlib.Algebra.Order.Floor.Semifield
import Mathlib.Tactic

public section

/-! Prime multiplicities in the exact-decoding recursion. -/

namespace LeanAB.PaperA

open Filter Asymptotics
open scoped BigOperators Topology

private def sixPrimeWindow (n : ℕ) :=
  Nat.primesLE (n / 6) \ Nat.primesLE (n / 7)

noncomputable def lengthSixChildren (n K : ℕ) : Finset (blockPrimes n K) :=
  Finset.univ.filter fun p => n / p.val = 6

@[simp] theorem mem_lengthSixChildren {n K : ℕ} (p : blockPrimes n K) :
    p ∈ lengthSixChildren n K ↔ n / p.val = 6 := by
  simp [lengthSixChildren]

private theorem div_eq_six {n p : ℕ} (hp : 0 < p) :
    n / p = 6 ↔ p ≤ n / 6 ∧ n / 7 < p := by
  have h₆ : 6 ≤ n / p ↔ 6 * p ≤ n := Nat.le_div_iff_mul_le hp
  have h₇ := Nat.div_lt_iff_lt_mul (x := n) (y := 7) hp
  rw [Nat.le_div_iff_mul_le (by decide : 0 < 6), Nat.div_lt_iff_lt_mul (by decide : 0 < 7)]
  rw [mul_comm p 6, mul_comm p 7, ← h₆, ← h₇]
  omega

private theorem lengthSixChildren_card {n K : ℕ} (hK : 6 ≤ K) :
    (lengthSixChildren n K).card = (sixPrimeWindow n).card := by
  let e : (blockPrimes n K : Type) ↪ ℕ := ⟨Subtype.val, Subtype.val_injective⟩
  have hs : (lengthSixChildren n K).map e = sixPrimeWindow n := by
    ext p
    constructor
    · intro hp
      obtain ⟨q, hq, hval⟩ := Finset.mem_map.mp hp
      change q.val = p at hval
      have hqprime := (mem_blockPrimes.mp q.property).2.1
      have hlen := (div_eq_six hqprime.pos).mp ((mem_lengthSixChildren q).mp hq)
      simp only [sixPrimeWindow, Finset.mem_sdiff, Nat.mem_primesLE]
      exact ⟨⟨hval ▸ hlen.1, hval ▸ hqprime⟩, fun ha => not_le_of_gt hlen.2 (hval.symm ▸ ha.1)⟩
    · intro hp
      have hu := Finset.mem_sdiff.mp hp
      have hp₆ := Nat.mem_primesLE.mp hu.1
      have hp₇ : n / 7 < p := lt_of_not_ge fun h => hu.2 (Nat.mem_primesLE.mpr ⟨h, hp₆.2⟩)
      have hcut := (Nat.div_lt_iff_lt_mul (by decide : 0 < 7)).mp hp₇
      have hmem : p ∈ blockPrimes n K := mem_blockPrimes.mpr
        ⟨hp₆.1.trans (Nat.div_le_self _ _), hp₆.2,
          hcut.trans_le (Nat.mul_le_mul_left p (by omega))⟩
      exact Finset.mem_map.mpr ⟨⟨p, hmem⟩, (mem_lengthSixChildren _).mpr
        ((div_eq_six hp₆.2.pos).mpr ⟨hp₆.1, hp₇⟩), rfl⟩
  rw [← hs, Finset.card_map]

/-- A node of length n contributes at most twice n/log n complete-interval children. -/
theorem eventually_blockPrimes_card_le :
    ∀ᶠ n : ℕ in atTop, ∀ K : ℕ,
      ((blockPrimes n K).card : ℝ) ≤ 2 * ((n : ℝ) / Real.log n) := by
  have h := (isEquivalent_iff_tendsto_one (by
    filter_upwards [eventually_gt_atTop (1 : ℝ)] with x hx
    exact div_ne_zero (zero_lt_one.trans hx).ne' (Real.log_pos hx).ne')).mp
      Nat.isEquivalent_primeCounting
  have ht : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  filter_upwards [(h.comp ht).eventually_lt_const (show (1 : ℝ) < 2 by norm_num),
    eventually_ge_atTop (2 : ℕ)] with n hn hn₂ K
  have hn₁ : (1 : ℝ) < n := by exact_mod_cast (show 1 < n by omega)
  have hpos : 0 < (n : ℝ) / Real.log n := div_pos (zero_lt_one.trans hn₁) (Real.log_pos hn₁)
  have hcount : (Nat.primeCounting n : ℝ) ≤ 2 * ((n : ℝ) / Real.log n) := by
    have hratio : (Nat.primeCounting n : ℝ) / ((n : ℝ) / Real.log n) < 2 := by
      simpa only [Function.comp_apply, Pi.div_apply, Nat.floor_natCast] using hn
    exact ((div_lt_iff₀ hpos).mp hratio).le
  have hc := Finset.card_le_card (Finset.filter_subset (fun p => n < p * (K + 1)) (Nat.primesLE n))
  exact (Nat.cast_le.mpr (hc.trans_eq (Nat.primesLE_card_eq_primeCounting n))).trans hcount

/-- The length-six children have the multiplicity of the primes in (n/7,n/6]. -/
theorem eventually_lengthSixChildren_card_ge :
    ∀ᶠ n : ℕ in atTop, ((n : ℝ) / Real.log n) / 50 ≤
      ((lengthSixChildren n (paperK n)).card : ℝ) := by
  have ht : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hlog := Real.tendsto_log_atTop.comp ht
  have h₆ := Chebyshev.tendsto_theta_div_atTop.comp (ht.atTop_div_const (by norm_num : (0 : ℝ) < 6))
  have h₇ := Chebyshev.tendsto_theta_div_atTop.comp (ht.atTop_div_const (by norm_num : (0 : ℝ) < 7))
  filter_upwards [h₆.eventually_const_lt (show (99 / 100 : ℝ) < 1 by norm_num),
    h₇.eventually_lt_const (show (1 : ℝ) < 101 / 100 by norm_num),
    hlog.eventually_ge_atTop 12, eventually_ge_atTop (2 : ℕ)] with n hn₆ hn₇ hnlog hn₂
  have hn₁ : (1 : ℝ) < n := by exact_mod_cast (show 1 < n by omega)
  have hnpos : (0 : ℝ) < n := zero_lt_one.trans hn₁
  have hK : 6 ≤ paperK n := Nat.le_floor (by
    change (6 : ℝ) ≤ Real.log (n : ℝ) / 2
    change 12 ≤ Real.log (n : ℝ) at hnlog
    linarith)
  rw [lengthSixChildren_card hK]
  have hpos := Real.log_pos hn₁
  have h₆' : (99 / 100 : ℝ) * ((n : ℝ) / 6) < Chebyshev.theta ((n : ℝ) / 6) :=
    (lt_div_iff₀ (by positivity)).mp hn₆
  have h₇' : Chebyshev.theta ((n : ℝ) / 7) < (101 / 100 : ℝ) * ((n : ℝ) / 7) :=
    (div_lt_iff₀ (by positivity)).mp hn₇
  have hθ : (n : ℝ) / 50 ≤ Chebyshev.theta ((n : ℝ) / 6) - Chebyshev.theta ((n : ℝ) / 7) :=
    by linarith
  have hfloor (k : ℕ) : ⌊(n : ℝ) / (k : ℝ)⌋₊ = n / k := by
    rw [Nat.floor_div_natCast, Nat.floor_natCast]
  rw [Chebyshev.theta_eq_sum_primesLE, Chebyshev.theta_eq_sum_primesLE,
    show ⌊(n : ℝ) / 6⌋₊ = n / 6 by simpa using hfloor 6,
    show ⌊(n : ℝ) / 7⌋₊ = n / 7 by simpa using hfloor 7] at hθ
  have hmono : Nat.primesLE (n / 7) ⊆ Nat.primesLE (n / 6) :=
    Nat.primesLE_mono (by omega)
  rw [← Finset.sum_sdiff hmono, add_sub_cancel_right] at hθ
  have hsum : (∑ p ∈ sixPrimeWindow n, Real.log (p : ℝ)) ≤
      ((sixPrimeWindow n).card : ℝ) * Real.log n := by
    calc
      _ ≤ ∑ _p ∈ sixPrimeWindow n, Real.log (n : ℝ) := by
        apply Finset.sum_le_sum
        intro p hp
        have hpp := Nat.mem_primesLE.mp (Finset.mem_sdiff.mp hp).1
        exact Real.log_le_log (by exact_mod_cast hpp.2.pos)
          (by exact_mod_cast hpp.1.trans (Nat.div_le_self _ _))
      _ = _ := by simp
  rw [div_right_comm]
  exact (div_le_iff₀ hpos).mpr (hθ.trans hsum)


theorem interval_supportEntropy_le (n m : ℕ) :
    supportEntropy (interval 1 n) m ≤ (n : ℝ) * Real.log (m + 1) := by
  have hsurj : Function.Surjective (sampleOutput (interval 1 n) m) := by
    intro x
    obtain ⟨cfg, hcfg⟩ := x.property
    exact ⟨cfg, Subtype.ext hcfg⟩
  have hdom : Nat.card (Configuration (interval 1 n) m) = (m + 1) ^ n := by
    rw [card_configuration, show (interval 1 n).card = n by simp [interval, Nat.card_Icc]]
  have hcard := (Nat.card_le_card_of_surjective _ hsurj).trans_eq hdom
  have hpos : 0 < Nat.card (Output (interval 1 n) m) := by
    let _ := (configurationLaw (interval 1 n) m).nonempty
    exact Nat.card_pos
  calc
    supportEntropy (interval 1 n) m ≤ Real.log (((m : ℝ) + 1) ^ n) := by
      change Real.log (Nat.card (Output (interval 1 n) m) : ℝ) ≤ _
      exact Real.log_le_log (by exact_mod_cast hpos) (by exact_mod_cast hcard)
    _ = _ := Real.log_pow _ _

/-- A nonnegative additive gain with a strictly positive length-six gain dominates Hartley
entropy. Every summand is indexed by its prime, including primes with the same cofactor length. -/
theorem eventually_supportEntropy_le_of_lengthSix (m : ℕ) (gain : ℕ → ℝ)
    (hg : ∀ n, 0 ≤ gain n) (h₆ : 0 < gain 6)
    (hgain : ∀ᶠ n : ℕ in atTop, (∑ p : blockPrimes n (paperK n), gain (n / p.val)) ≤ gain n) :
    ∃ C : ℝ, 0 < C ∧ ∀ᶠ n : ℕ in atTop,
      supportEntropy (interval 1 n) m ≤ C * gain n := by
  obtain ⟨T₀, hT₀⟩ := eventually_atTop.mp
    (eventually_decodeBounds.and (eventually_remainderSupportEntropy.and
      (eventually_blockPrimes_card_le.and (eventually_lengthSixChildren_card_ge.and hgain))))
  let T := max T₀ 7
  let R := (m : ℝ) * (2 * (Real.log 4 + 4) + 3)
  let B := (T : ℝ) * Real.log ((m : ℝ) + 1)
  let A := R + 2 * B + 1
  let G := gain 6 / 50
  let C := A / G
  have hlogColors : 0 ≤ Real.log ((m : ℝ) + 1) :=
    Real.log_nonneg (le_add_of_nonneg_left (Nat.cast_nonneg m))
  have hB : 0 ≤ B := mul_nonneg (Nat.cast_nonneg _) hlogColors
  have hA : 0 < A := by dsimp only [A, R]; positivity
  have hG : 0 < G := div_pos h₆ (by norm_num)
  have hC : 0 < C := div_pos hA hG
  have hT7 : 7 ≤ T := le_max_right _ _
  refine ⟨C, hC, eventually_atTop.mpr ⟨T, ?_⟩⟩
  have hmain (n : ℕ) : T ≤ n → supportEntropy (interval 1 n) m ≤ C * gain n := by
    induction n using Nat.strong_induction_on with
    | ind n ih =>
      intro hn
      obtain ⟨hd, hr, hpcount, hsix, hgSum⟩ := hT₀ n ((le_max_left _ _).trans hn)
      let K := paperK n
      let w := (n : ℝ) / Real.log n
      let old : Finset (blockPrimes n K) := Finset.univ.filter fun p => T ≤ n / p.val
      let small : Finset (blockPrimes n K) := Finset.univ \ old
      let six := lengthSixChildren n K
      have ho : old ⊆ Finset.univ := Finset.subset_univ _
      have hs : Disjoint old six := by
        apply Finset.disjoint_left.mpr
        intro p hpo hps
        have hh := (Finset.mem_filter.mp hpo).2
        rw [(mem_lengthSixChildren p).mp hps] at hh
        omega
      have hpositive : 0 < w := by
        have hn₁ : (1 : ℝ) < n := by exact_mod_cast (show 1 < n by omega)
        exact div_pos (zero_lt_one.trans hn₁) (Real.log_pos hn₁)
      have smallCard : (small.card : ℝ) ≤ 2 * w := by
        have hc : small.card ≤ (blockPrimes n K).card := by
          simpa only [Fintype.card_coe] using Finset.card_le_univ small
        exact (Nat.cast_le.mpr hc).trans (hpcount K)
      have hSmall :
          ∑ p ∈ small, supportEntropy (interval 1 (n / p.val)) m ≤ B * (2 * w) := by
        calc
          _ ≤ ∑ _p ∈ small, B := by
            apply Finset.sum_le_sum
            intro p hp
            have ht : n / p.val ≤ T := by
              have hh := (Finset.mem_sdiff.mp hp).2
              by_contra! he
              exact hh (Finset.mem_filter.mpr ⟨Finset.mem_univ _, he.le⟩)
            exact (interval_supportEntropy_le (n / p.val) m).trans
              (mul_le_mul_of_nonneg_right (by exact_mod_cast ht) hlogColors)
          _ = B * (small.card : ℝ) := by simp [mul_comm]
          _ ≤ _ := mul_le_mul_of_nonneg_left smallCard hB
      have hOld :
          ∑ p ∈ old, supportEntropy (interval 1 (n / p.val)) m ≤
            C * ∑ p ∈ old, gain (n / p.val) := by
        rw [Finset.mul_sum]
        apply Finset.sum_le_sum
        intro p hp
        exact ih (n / p.val)
          (Nat.div_lt_self (by omega) (mem_blockPrimes.mp p.property).2.1.one_lt)
          (Finset.mem_filter.mp hp).2
      have hSix : G * w ≤ ∑ p ∈ six, gain (n / p.val) := by
        have hsum : (∑ p ∈ six, gain (n / p.val)) = (six.card : ℝ) * gain 6 := by
          calc
            _ = ∑ _p ∈ six, gain 6 := by
              apply Finset.sum_congr rfl
              intro p hp
              rw [(mem_lengthSixChildren p).mp hp]
            _ = _ := by simp
        rw [hsum, show G * w = (w / 50) * gain 6 by dsimp only [G]; ring]
        exact mul_le_mul_of_nonneg_right hsix h₆.le
      have hGain : G * w + (∑ p ∈ old, gain (n / p.val)) ≤ gain n := by
        calc
          _ ≤ (∑ p ∈ six, gain (n / p.val)) + ∑ p ∈ old, gain (n / p.val) :=
            add_le_add hSix le_rfl
          _ = ∑ p ∈ six ∪ old, gain (n / p.val) := (Finset.sum_union hs.symm).symm
          _ ≤ ∑ p : blockPrimes n K, gain (n / p.val) :=
            Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) (fun p _ _ => hg _)
          _ ≤ _ := hgSum
      rw [supportEntropy_factor n K m hd.square hd.small hd.narrow,
        ← Finset.sum_sdiff ho]
      have hr' : supportEntropy (remainder n K) m ≤ R * w := (hr m).2
      calc
        _ ≤ R * w + (B * (2 * w) + C * ∑ p ∈ old, gain (n / p.val)) :=
          add_le_add hr' (add_le_add hSmall hOld)
        _ ≤ A * w + C * ∑ p ∈ old, gain (n / p.val) := by
          dsimp only [A]
          nlinarith
        _ = C * (G * w + ∑ p ∈ old, gain (n / p.val)) := by
          dsimp only [C]
          field_simp
        _ ≤ _ := mul_le_mul_of_nonneg_left hGain hC.le
  exact hmain


/-- The Rényi entropy of the uniform configuration output law on [1,n]. -/
@[expose] noncomputable def intervalRenyi (n m : ℕ) (a : RenyiOrder) : ℝ :=
  (configurationLaw (interval 1 n) m).renyi a

theorem intervalRenyi_le_supportEntropy (n m : ℕ) (a : RenyiOrder) :
    intervalRenyi n m a ≤ supportEntropy (interval 1 n) m := by
  rw [← configurationLaw_hartley]
  exact (configurationLaw (interval 1 n) m).renyi_le_hartley a

private theorem relative_lower_of_card (m : ℕ) (gain : ℕ → ℝ)
    (hg : ∀ n, 0 ≤ gain n) (h₆ : 0 < gain 6)
    (hgain : ∀ᶠ n : ℕ in atTop, (∑ p : blockPrimes n (paperK n), gain (n / p.val)) ≤ gain n) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ n : ℕ in atTop, c * supportEntropy (interval 1 n) m ≤ gain n := by
  obtain ⟨C, hC, h⟩ := eventually_supportEntropy_le_of_lengthSix m gain hg h₆ hgain
  refine ⟨C⁻¹, inv_pos.mpr hC, ?_⟩
  filter_upwards [h] with n hn
  calc
    _ ≤ C⁻¹ * (C * gain n) := mul_le_mul_of_nonneg_left hn (inv_pos.mpr hC).le
    _ = _ := by rw [← mul_assoc, inv_mul_cancel₀ hC.ne', one_mul]

/-- The largest atom entropy dominates the support entropy for every fixed positive color count. -/
theorem eventually_minEntropy_relative (m : ℕ) (hm : 1 ≤ m) :
    ∃ c : ℝ, 0 < c ∧
      ∀ᶠ n : ℕ in atTop, c * supportEntropy (interval 1 n) m ≤ intervalRenyi n m ⊤ := by
  cases m with
  | zero => omega
  | succ m =>
    let gain := fun n => intervalRenyi n (m + 1) ⊤
    have h₆ : 0 < gain 6 := by
      change 0 < (configurationLaw (interval 1 6) (m + 1)).renyi ⊤
      rw [FiniteLaw.renyi_top]
      exact lengthSix_minEntropy_pos m
    apply relative_lower_of_card (m + 1) gain (fun n => (configurationLaw _ _).renyi_nonneg _) h₆
    filter_upwards [eventually_decodeBounds] with n h
    change (∑ p : blockPrimes n (paperK n),
      (configurationLaw (interval 1 (n / p.val)) (m + 1)).renyi ⊤) ≤
      (configurationLaw (interval 1 n) (m + 1)).renyi ⊤
    rw [configurationLaw_renyi_decode n (paperK n) (m + 1) h ⊤]
    exact le_add_of_nonneg_left ((configurationLaw (remainder n (paperK n)) (m + 1)).renyi_nonneg ⊤)

/-- The same two-sided comparison with Hartley entropy holds for every order simultaneously. -/
theorem eventually_renyi_relative_all_orders (m : ℕ) (hm : 1 ≤ m) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ n : ℕ in atTop, ∀ a : RenyiOrder,
      c * supportEntropy (interval 1 n) m ≤ intervalRenyi n m a ∧
        intervalRenyi n m a ≤ supportEntropy (interval 1 n) m := by
  obtain ⟨c, hc, he⟩ := eventually_minEntropy_relative m hm
  refine ⟨c, hc, ?_⟩
  filter_upwards [he] with n hn a
  exact ⟨hn.trans ((configurationLaw (interval 1 n) m).renyi_antitone le_top),
    intervalRenyi_le_supportEntropy n m a⟩

/-- A fixed strict pair of orders has a difference comparable with the support entropy. -/
theorem eventually_renyi_gap_relative (m : ℕ) (hm : 1 ≤ m) {a b : RenyiOrder} (hab : a < b) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ n : ℕ in atTop,
      c * supportEntropy (interval 1 n) m ≤ intervalRenyi n m a - intervalRenyi n m b ∧
        intervalRenyi n m a - intervalRenyi n m b ≤ supportEntropy (interval 1 n) m := by
  cases m with
  | zero => omega
  | succ m =>
    let gain := fun n => intervalRenyi n (m + 1) a - intervalRenyi n (m + 1) b
    have hg (n : ℕ) : 0 ≤ gain n :=
      sub_nonneg.mpr ((configurationLaw (interval 1 n) (m + 1)).renyi_antitone hab.le)
    have h₆ : 0 < gain 6 := lengthSix_renyi_gap_pos m hab
    have ha : ∀ᶠ n : ℕ in atTop, (∑ p : blockPrimes n (paperK n), gain (n / p.val)) ≤ gain n := by
      filter_upwards [eventually_decodeBounds] with n h
      dsimp only [gain, intervalRenyi]
      rw [configurationLaw_renyi_decode n (paperK n) (m + 1) h a,
        configurationLaw_renyi_decode n (paperK n) (m + 1) h b, Finset.sum_sub_distrib]
      have hr := (configurationLaw (remainder n (paperK n)) (m + 1)).renyi_antitone hab.le
      linarith
    obtain ⟨c, hc, hl⟩ := relative_lower_of_card (m + 1) gain hg h₆ ha
    refine ⟨c, hc, ?_⟩
    filter_upwards [hl] with n hn
    exact ⟨hn, (sub_le_self _ ((configurationLaw (interval 1 n) (m + 1)).renyi_nonneg b)).trans
      (intervalRenyi_le_supportEntropy n (m + 1) a)⟩

end LeanAB.PaperA
