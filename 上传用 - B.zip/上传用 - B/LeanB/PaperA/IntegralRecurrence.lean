module

public import PaperA.RelativeGap
public import PaperA.IntegralScale
public import Common.StrongPNT
import Mathlib.Algebra.Order.Floor.Semifield
import Mathlib.NumberTheory.Harmonic.Bounds
meta import Mathlib.Tactic

/-! Quantitative prime counts in the cofactor windows of exact decoding. -/

@[expose] public section

open Filter Finset
open scoped BigOperators Topology

namespace LeanAB.PaperA

/-- Primes p with j = ⌊n / p⌋. The endpoints define the half-open interval
(n/(j+1), n/j] when 1 ≤ j. -/
def cofactorPrimes (n j : ℕ) : Finset ℕ :=
  Nat.primesLE (n / j) \ Nat.primesLE (n / (j + 1))

theorem mem_cofactorPrimes_iff {n j p : ℕ} (hj : 0 < j) :
    p ∈ cofactorPrimes n j ↔ p.Prime ∧ n / p = j := by
  simp only [cofactorPrimes, Finset.mem_sdiff, Nat.mem_primesLE]
  constructor
  · rintro ⟨⟨hpUpper, hp⟩, hpLower⟩
    have hlow := (Nat.le_div_iff_mul_le hj).mp hpUpper
    have hu : n / (j + 1) < p := lt_of_not_ge (fun h => hpLower ⟨h, hp⟩)
    have hhigh := (Nat.div_lt_iff_lt_mul (Nat.succ_pos j)).mp hu
    have hlo' : j ≤ n / p := (Nat.le_div_iff_mul_le hp.pos).mpr (by simpa [mul_comm] using hlow)
    have hhi' : n / p < j + 1 := (Nat.div_lt_iff_lt_mul hp.pos).mpr (by simpa [mul_comm] using hhigh)
    exact ⟨hp, by omega⟩
  · rintro ⟨hp, hq⟩
    have hlow := (Nat.le_div_iff_mul_le hp.pos).mp (show j ≤ n / p by omega)
    have hhigh := (Nat.div_lt_iff_lt_mul hp.pos).mp (show n / p < j + 1 by omega)
    exact ⟨⟨(Nat.le_div_iff_mul_le hj).mpr (by simpa [mul_comm] using hlow), hp⟩,
      fun hh => (not_le_of_gt ((Nat.div_lt_iff_lt_mul (Nat.succ_pos j)).mpr
        (by simpa [mul_comm] using hhigh))) hh.1⟩

private theorem cofactorPrimes_subset_blockPrimes {n K j : ℕ}
    (hj : j ∈ Icc 1 K) : cofactorPrimes n j ⊆ blockPrimes n K := by
  obtain ⟨hj₁,hjK⟩ := mem_Icc.mp hj
  intro p hp
  obtain ⟨hpPrime, hq⟩ := (mem_cofactorPrimes_iff hj₁).mp hp
  have hmul : j * p ≤ n := (Nat.le_div_iff_mul_le hpPrime.pos).mp (by omega)
  have hpN := (show p ≤ j * p by
    simpa using Nat.mul_le_mul_right p hj₁).trans hmul
  have hcut := (Nat.div_lt_iff_lt_mul hpPrime.pos).mp (show n / p < K + 1 by omega)
  exact mem_blockPrimes.mpr ⟨hpN, hpPrime, by simpa [mul_comm] using hcut⟩

private theorem blockPrimes_quotient_mem_Icc {n K p : ℕ} (hp : p ∈ blockPrimes n K) :
    n / p ∈ Icc 1 K := by
  obtain ⟨hpN, hprime, hpCut⟩ := mem_blockPrimes.mp hp
  refine mem_Icc.mpr ⟨Nat.div_pos hpN hprime.pos, ?_⟩
  have h := (Nat.div_lt_iff_lt_mul hprime.pos).mpr (show n < (K + 1) * p by
    simpa [mul_comm] using hpCut)
  omega

/-- Regroup the finite sum over decoding factors according to their cofactor sizes. -/
theorem sum_blockPrimes_eq_sum_cofactorPrimes (n K : ℕ) (g : ℕ → ℝ) :
    (∑ p : blockPrimes n K, g (n / p.val)) =
      ∑ j ∈ Icc 1 K, ((cofactorPrimes n j).card : ℝ) * g j := by
  rw [Finset.sum_coe_sort (f := fun p : ℕ => g (n / p))]
  rw [← Finset.sum_fiberwise_of_maps_to
    (s := blockPrimes n K) (t := Icc 1 K) (g := fun p : ℕ => n / p)
    (fun p hp => blockPrimes_quotient_mem_Icc hp) (fun p : ℕ => g (n / p))]
  apply sum_congr rfl
  intro j hj
  have heq : (blockPrimes n K).filter (fun p => n / p = j) = cofactorPrimes n j := by
    ext p
    rw [mem_filter, mem_cofactorPrimes_iff (mem_Icc.mp hj).1]
    exact ⟨fun ⟨hp,hq⟩ => ⟨(mem_blockPrimes.mp hp).2.1, hq⟩,
      fun ⟨hp,hq⟩ => ⟨cofactorPrimes_subset_blockPrimes hj
        ((mem_cofactorPrimes_iff (mem_Icc.mp hj).1).mpr ⟨hp,hq⟩), hq⟩⟩
  calc
    _ = ∑ p ∈ (blockPrimes n K).filter (fun p => n / p = j), g j :=
      sum_congr rfl fun p hp => congrArg g (mem_filter.mp hp).2
    _ = _ := by rw [heq, sum_const, nsmul_eq_mul]

private theorem theta_cofactorPrimes {n j : ℕ} (hj : 0 < j) :
    (∑ p ∈ cofactorPrimes n j, Real.log p) =
      Chebyshev.theta ((n : ℝ) / j) - Chebyshev.theta ((n : ℝ) / (j + 1 : ℕ)) := by
  rw [Chebyshev.theta_eq_sum_primesLE, Chebyshev.theta_eq_sum_primesLE,
    Nat.floor_div_eq_div, Nat.floor_div_eq_div, cofactorPrimes]
  apply eq_sub_of_add_eq
  exact Finset.sum_sdiff (Nat.primesLE_mono (Nat.div_le_div_left (by omega : j ≤ j + 1) hj))

private theorem cofactor_window_bounds {n K j p : ℕ} (hj : 0 < j) (hK : j ≤ K)
    (hp : p ∈ cofactorPrimes n j) :
    (n : ℝ) / (K + 1 : ℕ) < p ∧ (p : ℝ) ≤ n := by
  obtain ⟨hpPrime, hq⟩ := (mem_cofactorPrimes_iff hj).mp hp
  have hmul := (Nat.div_lt_iff_lt_mul hpPrime.pos).mp (show n / p < K + 1 by omega)
  have hpN := (mem_blockPrimes.mp (cofactorPrimes_subset_blockPrimes (mem_Icc.mpr ⟨hj, hK⟩) hp)).1
  exact ⟨(div_lt_iff₀ (by positivity)).mpr (by exact_mod_cast (by simpa [mul_comm] using hmul :
    n < p * (K + 1))), by exact_mod_cast hpN⟩

/-- Uniform estimate for a single cofactor window. The second term comes
from the quantitative theta error; the first replaces all log p by log n. -/
theorem abs_cofactorPrimeCount_sub_main_le {n K j : ℕ} {C : ℝ}
    (hn : 1 < n) (hj : 0 < j) (hjK : j ≤ K) (hC : 0 ≤ C)
    (hHalf : 2 * Real.log (K + 1 : ℕ) ≤ Real.log n)
    (hθ : ∀ t ∈ Set.Icc ((n : ℝ) / (K + 1 : ℕ)) n,
      |Chebyshev.theta t - t| ≤ C * t / (Real.log t)^2) :
    |((cofactorPrimes n j).card : ℝ) -
        (n : ℝ) / ((j : ℝ) * (j + 1 : ℕ) * Real.log n)| ≤
      2 * Real.log (K + 1 : ℕ) / Real.log n *
        ((n : ℝ) / ((j : ℝ) * (j + 1 : ℕ) * Real.log n)) +
      16 * C * ((n : ℝ) / (j * (Real.log n)^3)) := by
  let x : ℝ := n
  let L := Real.log x
  let u := Real.log (K + 1 : ℕ)
  let a := x / (j + 1 : ℕ)
  let b := x / j
  let A := x / (K + 1 : ℕ)
  let D := x / ((j : ℝ) * (j + 1 : ℕ))
  let S := ∑ p ∈ cofactorPrimes n j, Real.log p
  let Q : ℝ := (cofactorPrimes n j).card
  let E := 8 * C * (b / L ^ 2)
  have hx : 0 < x := by
    change (0 : ℝ) < n
    exact_mod_cast (by omega : 0 < n)
  have hL : 0 < L := Real.log_pos (by change (1 : ℝ) < n; exact_mod_cast hn)
  have hu : 0 ≤ u := Real.log_nonneg (by exact_mod_cast (Nat.succ_le_succ (Nat.zero_le K)))
  have hL₀ : 0 < L - u := by linarith only [hL,hHalf]
  have hj₀ : (0 : ℝ) < j := by exact_mod_cast hj
  have hj₁ : (0 : ℝ) < (j + 1 : ℕ) := by positivity
  have hA : 0 < A := div_pos hx (by positivity)
  have hab : a ≤ b := div_le_div_of_nonneg_left hx.le hj₀ (by exact_mod_cast Nat.le_succ j)
  have hAa : A ≤ a := div_le_div_of_nonneg_left hx.le hj₁ (by exact_mod_cast Nat.succ_le_succ hjK)
  have hbx : b ≤ x := div_le_self hx.le (by exact_mod_cast (show 1 ≤ j from hj))
  have hLogA : Real.log A = L - u := Real.log_div hx.ne' (by positivity)
  have hθ' (t : ℝ) (ht : t ∈ Set.Icc A x) : |Chebyshev.theta t - t| ≤ 4 * C * (t / L^2) := by
    have ht₀ := hA.trans_le ht.1
    have hlog : L / 2 ≤ Real.log t := by
      have := Real.log_le_log hA ht.1
      linarith only [this, hLogA, hHalf]
    calc
      _ ≤ C * t / (Real.log t)^2 := hθ t ht
      _ ≤ C * t / (L / 2)^2 := div_le_div_of_nonneg_left (mul_nonneg hC ht₀.le)
        (by positivity) (pow_le_pow_left₀ (by positivity) hlog _)
      _ = _ := by ring
  have hD : b - a = D := by
    dsimp [a,b,D]
    push_cast
    field_simp [hj₀.ne']
    ring
  have hS : S = Chebyshev.theta b - Chebyshev.theta a := theta_cofactorPrimes hj
  have hSE : |S - D| ≤ E := by
    rw [← hD, hS, show Chebyshev.theta b - Chebyshev.theta a - (b - a) =
      (Chebyshev.theta b - b) - (Chebyshev.theta a - a) by ring]
    refine (abs_sub _ _).trans (add_le_add (hθ' b ⟨hAa.trans hab,hbx⟩)
      (hθ' a ⟨hAa,hab.trans hbx⟩) |>.trans ?_)
    have hle := mul_le_mul_of_nonneg_left
      (div_le_div_of_nonneg_right hab (sq_nonneg L)) (show 0 ≤ 4 * C by positivity)
    dsimp [E]
    linarith only [hle]
  have hLog (p : ℕ) (hp : p ∈ cofactorPrimes n j) : L - u ≤ Real.log p ∧ Real.log p ≤ L := by
    obtain ⟨h₁,h₂⟩ := cofactor_window_bounds hj hjK hp
    have hpn : 0 < (p : ℝ) := hA.trans (show A < p from h₁)
    exact ⟨hLogA ▸ Real.log_le_log hA h₁.le, Real.log_le_log hpn h₂⟩
  have hSLo : Q * (L - u) ≤ S := by
    dsimp [Q,S]
    rw [← nsmul_eq_mul, ← sum_const]
    exact sum_le_sum fun p hp => (hLog p hp).1
  have hSHi : S ≤ Q * L := by
    dsimp [Q,S]
    rw [← nsmul_eq_mul, ← sum_const]
    exact sum_le_sum fun p hp => (hLog p hp).2
  obtain ⟨hSELo,hSEHi⟩ := abs_le.mp hSE
  have hQHi : Q ≤ (D + E) / (L - u) :=
    (le_div_iff₀ hL₀).mpr (by linarith only [hSEHi,hSLo])
  have hQLo : (D - E) / L ≤ Q :=
    (div_le_iff₀ hL).mpr (by linarith only [hSELo,hSHi])
  have hE : 0 ≤ E := by dsimp [E,b]; positivity
  have hDu : 0 ≤ D * u / L := by dsimp [D]; positivity
  have hRecip : 1 / (L - u) ≤ 2 / L :=
    (div_le_div_iff₀ hL₀ hL).mpr (by linarith only [hHalf])
  have hErr : 2 * (D * u / L + E) / L ≤
      2 * u / L * (D / L) + 16 * C * (x / (j * L^3)) := by
    dsimp [E,b]
    ring_nf
    exact le_rfl
  have hMain : D / L = (n : ℝ) / ((j : ℝ) * (j + 1 : ℕ) * Real.log n) := by
    dsimp [D,x,L]
    rw [div_div]
  change |Q - (n : ℝ) / _| ≤ 2 * u / L * _ + 16 * C * (x / (j * L^3))
  rw [← hMain]
  apply abs_le.mpr
  constructor
  · have hLo : -(E / L) ≤ Q - D / L := by rw [sub_div] at hQLo; linarith only [hQLo]
    have hDom : E / L ≤ 2 * (D * u / L + E) / L :=
      div_le_div_of_nonneg_right (by linarith only [hE,hDu]) hL.le
    exact (neg_le_neg (hDom.trans hErr)).trans hLo
  · calc
      _ ≤ (D + E) / (L - u) - D / L := sub_le_sub_right hQHi _
      _ = (D * u / L + E) * (1 / (L - u)) := by
        field_simp [hL.ne',hL₀.ne']
        ring
      _ ≤ (D * u / L + E) * (2 / L) := mul_le_mul_of_nonneg_left hRecip (add_nonneg hDu hE)
      _ = 2 * (D * u / L + E) / L := by ring
      _ ≤ _ := hErr


private theorem sum_cofactor_inv_le (K : ℕ) :
    (∑ j ∈ Icc 1 K, ((j + 1 : ℕ) : ℝ)⁻¹) ≤ 1 + Real.log (K + 1 : ℕ) := calc
  _ ≤ ∑ j ∈ Finset.range (K + 1), ((j + 1 : ℕ) : ℝ)⁻¹ :=
    Finset.sum_le_sum_of_subset_of_nonneg
      (fun j hj => Finset.mem_range.mpr (Nat.lt_succ_of_le (Finset.mem_Icc.mp hj).2))
      (fun _ _ _ => by positivity)
  _ = (_root_.harmonic (K + 1) : ℝ) := by
    simp only [_root_.harmonic, Rat.cast_sum, Rat.cast_inv, Rat.cast_natCast]
  _ ≤ _ := harmonic_le_one_add_log (K + 1)

/-- The error from replacing the sum over prime blocks by its weighted
cofactor sum. The bound is uniform in all linearly bounded nonnegative g. -/
theorem abs_sum_blockPrimes_sub_cofactor_main_le {n K : ℕ} {B C : ℝ} {g : ℕ → ℝ}
    (hn : 1 < n) (hB : 0 ≤ B) (hC : 0 ≤ C)
    (hHalf : 2 * Real.log (K + 1 : ℕ) ≤ Real.log n)
    (hShape : Real.log (K + 1 : ℕ) * (1 + Real.log (K + 1 : ℕ)) ≤ Real.log n)
    (hK : (K : ℝ) ≤ (Real.log n)^2)
    (hθ : ∀ t ∈ Set.Icc ((n : ℝ) / (K + 1 : ℕ)) n,
      |Chebyshev.theta t - t| ≤ C * t / (Real.log t)^2)
    (hG : ∀ j ∈ Icc 1 K, 0 ≤ g j ∧ g j ≤ B * (j : ℝ)) :
    |(∑ p : blockPrimes n K, g (n / p.val)) -
        ((n : ℝ) / Real.log n) * (∑ j ∈ Icc 1 K, g j / ((j : ℝ) * (j + 1 : ℕ)))| ≤
      (2 * B + 16 * B * C) * ((n : ℝ) / Real.log n) := by
  let x : ℝ := n
  let L := Real.log x
  let u := Real.log (K + 1 : ℕ)
  let a := 2 * B * u * (x / L^2)
  let b := 16 * B * C * (x / L^3)
  have hx : 0 ≤ x := Nat.cast_nonneg _
  have hL : 0 < L := Real.log_pos (by change (1 : ℝ) < n; exact_mod_cast hn)
  have hu : 0 ≤ u := Real.log_nonneg (by exact_mod_cast Nat.succ_le_succ (Nat.zero_le K))
  have hag : 0 ≤ a := by dsimp [a]; positivity
  rw [sum_blockPrimes_eq_sum_cofactorPrimes, Finset.mul_sum, ← Finset.sum_sub_distrib]
  calc
    _ ≤ ∑ j ∈ Icc 1 K, |((cofactorPrimes n j).card : ℝ) * g j -
          (x / L) * (g j / ((j : ℝ) * (j + 1 : ℕ)))| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ j ∈ Icc 1 K, (a * ((j + 1 : ℕ) : ℝ)⁻¹ + b) := by
      apply Finset.sum_le_sum
      intro j hj
      obtain ⟨hj₁,hjK⟩ := mem_Icc.mp hj
      have hj₀ : (0 : ℝ) < j := by exact_mod_cast hj₁
      have hjSucc : (0 : ℝ) < ((j + 1 : ℕ) : ℝ) := by positivity
      let T := x / ((j : ℝ) * (j + 1 : ℕ) * L)
      let err := 2 * u / L * T + 16 * C * (x / (j * L^3))
      have hcount : |((cofactorPrimes n j).card : ℝ) - T| ≤ err :=
        abs_cofactorPrimeCount_sub_main_le hn hj₁ hjK hC hHalf hθ
      have he : 0 ≤ err := by dsimp [err,T]; positivity
      obtain ⟨hgj₀,hgj⟩ := hG j hj
      rw [show ((cofactorPrimes n j).card : ℝ) * g j -
          (x / L) * (g j / ((j : ℝ) * (j + 1 : ℕ))) =
            (((cofactorPrimes n j).card : ℝ) - T) * g j by
          dsimp [T]
          field_simp [hL.ne', hj₀.ne', hjSucc.ne'], abs_mul, abs_of_nonneg hgj₀]
      refine (mul_le_mul hcount hgj hgj₀ he).trans_eq ?_
      dsimp [err,T,a,b]
      field_simp [hL.ne', hj₀.ne', hjSucc.ne']
    _ = a * (∑ j ∈ Icc 1 K, ((j + 1 : ℕ) : ℝ)⁻¹) + (K : ℝ) * b := by
      rw [sum_add_distrib, ← Finset.mul_sum, sum_const, nsmul_eq_mul]
      simp [Nat.card_Icc]
    _ ≤ a * (1 + u) + (K : ℝ) * b :=
      add_le_add_left (mul_le_mul_of_nonneg_left (sum_cofactor_inv_le K) hag) _
    _ ≤ (2 * B + 16 * B * C) * (x / L) := by
      have h₁ : a * (1 + u) ≤ 2 * B * (x / L) := calc
        _ = (2 * B * (x / L)) * ((u * (1 + u)) / L) := by dsimp [a]; ring
        _ ≤ _ := mul_le_of_le_one_right (by positivity) ((div_le_one hL).mpr hShape)
      have h₂ : (K : ℝ) * b ≤ 16 * B * C * (x / L) := calc
        _ = (16 * B * C * (x / L)) * ((K : ℝ) / L^2) := by dsimp [b]; ring
        _ ≤ _ := mul_le_of_le_one_right (by positivity) ((div_le_one (pow_pos hL _)).mpr hK)
      calc
        _ ≤ (2 * B * (x / L)) + (16 * B * C * (x / L)) := add_le_add h₁ h₂
        _ = _ := by ring


/-- The pinned quantitative PNT supplies all window hypotheses uniformly for the
manuscript's choice K = floor(log n / 2). -/
theorem eventually_paperPrimeCountInputs :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ n : ℕ in atTop,
      let L := Real.log (n : ℝ)
      let K := paperK n
      let u := Real.log (K + 1 : ℕ)
      1 < n ∧ 2 * u ≤ L ∧ u * (1 + u) ≤ L ∧ (K : ℝ) ≤ L^2 ∧
        ∀ t ∈ Set.Icc ((n : ℝ) / (K + 1 : ℕ)) n,
          |Chebyshev.theta t - t| ≤ C * t / (Real.log t)^2 := by
  obtain ⟨C, hC, hθ⟩ := thetaLogSquaredError_pntPlus
  obtain ⟨T, hT⟩ := eventually_atTop.mp hθ
  let T₀ := max T 0
  have hT₀ : 0 ≤ T₀ := le_max_right _ _
  have hLog : Tendsto (fun n : ℕ => Real.log (n : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  have hSmall := (isLittleO_log_rpow_atTop (r := (1 / 2 : ℝ)) (by norm_num)).bound
    (show (0 : ℝ) < 1 / 2 by norm_num)
  refine ⟨C, hC, ?_⟩
  filter_upwards [eventually_ge_atTop (2 : ℕ), eventually_ge_atTop ⌈T₀ ^ 2⌉₊,
    eventually_paperYBounds, hLog.eventually_ge_atTop 4, hLog.eventually hSmall]
    with n hn hNT hY hL hSmall
  let L := Real.log (n : ℝ)
  let K := paperK n
  let u := Real.log (K + 1 : ℕ)
  change (4 : ℝ) ≤ L at hL
  change ‖Real.log L‖ ≤ (1 / 2 : ℝ) * ‖L ^ (1 / 2 : ℝ)‖ at hSmall
  have hL₀ : 0 ≤ L := by linarith only [hL]
  have hL₁ : 1 ≤ L := by linarith only [hL]
  have hK : (K : ℝ) ≤ L / 2 := Nat.floor_le (by positivity)
  have hK1 : ((K + 1 : ℕ) : ℝ) ≤ L := by
    rw [Nat.cast_succ]
    linarith only [hK, hL]
  have hU₀ : 0 ≤ u := Real.log_nonneg (by exact_mod_cast Nat.succ_le_succ (Nat.zero_le K))
  have hU : u ≤ Real.log L := Real.log_le_log (by positivity) hK1
  have hs : Real.log L ≤ (1 / 2 : ℝ) * Real.sqrt L := by
    simpa only [Real.norm_eq_abs, abs_of_nonneg (Real.log_nonneg hL₁), ← Real.sqrt_eq_rpow,
      abs_of_nonneg (Real.sqrt_nonneg L)] using hSmall
  have hS₂ : 2 ≤ Real.sqrt L := by
    have h := Real.sqrt_le_sqrt hL
    simpa [show (4 : ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (show (0 : ℝ) ≤ 2 by norm_num)]
      using h
  have hS₀ := Real.sqrt_nonneg L
  have hSQ := Real.mul_self_sqrt hL₀
  have hSL : Real.sqrt L ≤ L := by
    have hh := mul_le_mul_of_nonneg_right (show 1 ≤ Real.sqrt L by linarith only [hS₂]) hS₀
    simpa only [one_mul, hSQ] using hh
  have hU' : u ≤ Real.sqrt L := by linarith only [hU, hs, hS₀]
  have hsum : 1 + u ≤ Real.sqrt L := by linarith only [hU, hs, hS₂]
  have hShape := (mul_le_mul hU' hsum (by positivity : 0 ≤ 1 + u) hS₀).trans_eq hSQ
  have hHalf : 2 * u ≤ L := by linarith only [hU, hs, hSL]
  have hK' : (K : ℝ) ≤ L^2 := by
    have hh := mul_le_mul_of_nonneg_right hL₁ hL₀
    nlinarith only [hh, hK, hL₀]
  have hTn : T₀ ^ 2 ≤ (n : ℝ) := (Nat.le_ceil _).trans (by exact_mod_cast hNT)
  have hTs : T ≤ Real.sqrt (n : ℝ) :=
    (le_max_left T 0).trans ((Real.le_sqrt hT₀ (by positivity)).mpr hTn)
  have hTA : T ≤ (n : ℝ) / (K + 1 : ℕ) := by
    rw [Nat.cast_succ]
    exact hTs.trans hY.1.le
  refine ⟨by omega, hHalf, hShape, hK', fun t ht => hT t (hTA.trans ht.1)⟩

/-- Uniform large-height version of the individual prime-count bound. -/
theorem eventually_cofactorPrimeCount_sub_main_le :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ n : ℕ in atTop, ∀ j : ℕ,
      0 < j → j ≤ paperK n →
      |((cofactorPrimes n j).card : ℝ) -
          (n : ℝ) / ((j : ℝ) * (j + 1 : ℕ) * Real.log n)| ≤
        2 * Real.log (paperK n + 1 : ℕ) / Real.log n *
          ((n : ℝ) / ((j : ℝ) * (j + 1 : ℕ) * Real.log n)) +
        16 * C * ((n : ℝ) / (j * (Real.log n)^3)) := by
  obtain ⟨C, hC, h⟩ := eventually_paperPrimeCountInputs
  refine ⟨C, hC, ?_⟩
  filter_upwards [h] with n hn j hj hjK
  obtain ⟨hN, hHalf, _, _, htheta⟩ := hn
  exact abs_cofactorPrimeCount_sub_main_le hN hj hjK hC hHalf htheta



/-- Before the integral substitution, the error in the finite cofactor recurrence
is uniform over the whole range of Rényi orders. -/
theorem eventually_intervalRenyi_finiteRecurrence (m : ℕ) :
    ∃ c : ℝ, 0 ≤ c ∧ ∀ᶠ n : ℕ in atTop, ∀ order : RenyiOrder,
      |intervalRenyi n m order - ((n : ℝ) / Real.log n) *
        (∑ j ∈ Icc 1 (paperK n), intervalRenyi j m order / ((j : ℝ) * ((j : ℝ) + 1)))| ≤
        c * ((n : ℝ) / Real.log n) := by
  obtain ⟨C, hC, hprime⟩ := eventually_paperPrimeCountInputs
  let B := Real.log ((m : ℝ) + 1)
  let R := (m : ℝ) * (2 * (Real.log 4 + 4) + 3)
  have hB : 0 ≤ B := Real.log_nonneg (by linarith only [Nat.cast_nonneg (α := ℝ) m])
  have hR : 0 ≤ R := by dsimp [R]; positivity
  refine ⟨R + (2 * B + 16 * B * C), by positivity, ?_⟩
  filter_upwards [hprime, eventually_remainderSupportEntropy, eventually_decodeBounds]
    with n hp hrem hd order
  obtain ⟨hn, hHalf, hShape, hK, hΘ⟩ := hp
  let K := paperK n
  let q := (n : ℝ) / Real.log n
  let g (j : ℕ) := intervalRenyi j m order
  let S := ∑ p : blockPrimes n K, g (n / p.val)
  let M := ∑ j ∈ Icc 1 K, g j / ((j : ℝ) * ((j : ℝ) + 1))
  let rem := (configurationLaw (remainder n K) m).renyi order
  have hG (j : ℕ) : 0 ≤ g j ∧ g j ≤ B * (j : ℝ) := by
    refine ⟨(configurationLaw (interval 1 j) m).renyi_nonneg order, ?_⟩
    calc
      _ ≤ supportEntropy (interval 1 j) m := intervalRenyi_le_supportEntropy j m order
      _ ≤ (j : ℝ) * B := interval_supportEntropy_le j m
      _ = _ := mul_comm _ _
  have hMain : |S - q * M| ≤ (2 * B + 16 * B * C) * q := by
    simpa only [S, q, M, Nat.cast_succ] using
      (abs_sum_blockPrimes_sub_cofactor_main_le (g := g) hn hB hC hHalf hShape hK hΘ
        (fun j _ => hG j))
  have hRem₀ : 0 ≤ rem := (configurationLaw (remainder n K) m).renyi_nonneg order
  have hRem : rem ≤ R * q := by
    calc
      _ ≤ (configurationLaw (remainder n K) m).hartley :=
        (configurationLaw (remainder n K) m).renyi_le_hartley order
      _ = supportEntropy (remainder n K) m := configurationLaw_hartley _ _
      _ ≤ _ := (hrem m).2
  have hDecode : g n = rem + S := configurationLaw_renyi_decode n K m hd order
  change |g n - q * M| ≤ _
  calc
    _ = |rem + (S - q * M)| := by rw [hDecode, add_sub_assoc]
    _ ≤ |rem| + |S - q * M| := abs_add_le _ _
    _ ≤ R * q + (2 * B + 16 * B * C) * q := by
      rw [abs_of_nonneg hRem₀]
      exact add_le_add hRem hMain
    _ = _ := by ring

/-- The integral recurrence in Paper A, uniformly over all Rényi orders with a
single height threshold and error constant for each m. -/
theorem eventually_intervalRenyi_integralRecurrence (m : ℕ) :
    ∃ c : ℝ, 0 ≤ c ∧ ∀ᶠ n : ℕ in atTop, ∀ order : RenyiOrder,
      |intervalRenyi n m order - ((n : ℝ) / Real.log n) *
        (∫ t in (1 : ℝ)..Real.log n, intervalRenyi ⌊t⌋₊ m order / t ^ 2)| ≤
        c * ((n : ℝ) / Real.log n) := by
  obtain ⟨c, hc, he⟩ := eventually_intervalRenyi_finiteRecurrence m
  let B := Real.log ((m : ℝ) + 1)
  have hB : 0 ≤ B := Real.log_nonneg (by linarith only [Nat.cast_nonneg (α := ℝ) m])
  have hLog : Tendsto (fun n : ℕ => Real.log (n : ℝ)) atTop atTop :=
    Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
  refine ⟨c + B * Real.log 2, by positivity, ?_⟩
  filter_upwards [he, hLog.eventually_ge_atTop 2] with n hn hLog order
  let g (j : ℕ) := intervalRenyi j m order
  have hgn (j : ℕ) : 0 ≤ g j := (configurationLaw (interval 1 j) m).renyi_nonneg order
  have hgl (j : ℕ) : g j ≤ B * (j : ℝ) := by
    calc
      _ ≤ supportEntropy (interval 1 j) m := intervalRenyi_le_supportEntropy j m order
      _ ≤ (j : ℝ) * B := interval_supportEntropy_le j m
      _ = _ := mul_comm _ _
  obtain ⟨hend, hhalf⟩ := halfLog_integral_endpoints hLog
  exact finiteRecursion_to_integralError (g := g) (n := n) (K := paperK n)
    hB hgn hgl hend hhalf (hn order)



/-- The upper bound on Paper A's scale holds with one constant across all orders. -/
theorem intervalRenyi_le_iteratedLogB (m : ℕ) :
    ∃ C ≥ (1 : ℝ), ∀ (order : RenyiOrder) (n : ℕ),
      intervalRenyi n m order ≤ C * iteratedLogB (n : ℝ) := by
  obtain ⟨c, _, hrec⟩ := eventually_intervalRenyi_integralRecurrence m
  let B := Real.log ((m : ℝ) + 1)
  refine le_iteratedLogB_of_integral_bound (fun (order : RenyiOrder) (n : ℕ) =>
    intervalRenyi n m order) B c ?_ ?_
  · intro order n
    exact (intervalRenyi_le_supportEntropy n m order).trans
      ((interval_supportEntropy_le n m).trans_eq (mul_comm _ _))
  · filter_upwards [hrec] with n hn order
    have hi := (abs_le.mp (hn order)).2
    rw [mul_add]
    linarith only [hi]


end LeanAB.PaperA
