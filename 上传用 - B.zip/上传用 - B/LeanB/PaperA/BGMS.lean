module

public import PaperA.ScaleComparison
public import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Data.Nat.Prime.Int
import Mathlib.Data.Rat.Lemmas
import Mathlib.Algebra.GCDMonoid.FinsetLemmas
import Mathlib.Analysis.SumIntegralComparisons
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
import Mathlib.Tactic

@[expose] public section

/-! Finite arithmetic steps from BGMS v1 §2 (arXiv:2509.10030v1). -/

namespace LeanAB.PaperA.BGMS

open Filter
open scoped BigOperators

/-- The distinct reciprocal subset sums of E, including the empty sum. -/
def subsetSums (E : Finset ℕ) : Finset ℚ := E.powerset.image LeanAB.mass

@[simp] theorem mem_subsetSums {E : Finset ℕ} {r : ℚ} :
    r ∈ subsetSums E ↔ ∃ S ⊆ E, LeanAB.mass S = r := by
  simp only [subsetSums, Finset.mem_image, Finset.mem_powerset]

theorem subsetSums_mono {E F : Finset ℕ} (h : E ⊆ F) : subsetSums E ⊆ subsetSums F := by
  intro r hr
  obtain ⟨S, hS, hm⟩ := mem_subsetSums.mp hr
  exact mem_subsetSums.mpr ⟨S, hS.trans h, hm⟩

/-- A new denominator is irreducible if its reciprocal cannot be a signed sum of earlier
reciprocals. A signed sum is represented as a difference of two subset sums. -/
def Irreducible (n : ℕ) : Prop :=
  0 < n ∧ ∀ S T : Finset ℕ, S ⊆ interval 1 (n - 1) → T ⊆ interval 1 (n - 1) →
    mass S - mass T ≠ (n : ℚ)⁻¹

private theorem mass_insert {n : ℕ} {S : Finset ℕ} (hn : n ∉ S) :
    mass (insert n S) = (n : ℚ)⁻¹ + mass S := by
  simp only [mass, Finset.sum_insert hn]

theorem subsetSums_insert {n : ℕ} {E : Finset ℕ} (hn : n ∉ E) :
    subsetSums (insert n E) =
      subsetSums E ∪ (subsetSums E).image (fun s => s + (n : ℚ)⁻¹) := by
  ext r
  simp only [Finset.mem_union, Finset.mem_image, mem_subsetSums]
  constructor
  · rintro ⟨S, hS, rfl⟩
    by_cases hs : n ∈ S
    · have he : S.erase n ⊆ E := by
        intro x hx
        obtain ⟨hxn, hxs⟩ := Finset.mem_erase.mp hx
        exact (Finset.mem_insert.mp (hS hxs)).resolve_left hxn
      refine Or.inr ⟨mass (S.erase n), ⟨_, he, rfl⟩, ?_⟩
      have hm := mass_insert (Finset.notMem_erase n S)
      rw [Finset.insert_erase hs, add_comm] at hm
      exact hm.symm
    · exact Or.inl ⟨S, fun x hx => (Finset.mem_insert.mp (hS hx)).resolve_left
        (fun h => hs (h ▸ hx)), rfl⟩
  · rintro (⟨S, hS, hR⟩ | ⟨s, ⟨S, hS, rfl⟩, hR⟩)
    · exact ⟨S, hS.trans (Finset.subset_insert _ _), hR⟩
    · refine ⟨insert n S, Finset.insert_subset_insert _ hS, ?_⟩
      rw [mass_insert (fun h => hn (hS h)), add_comm]
      exact hR

private theorem interval_succ (n : ℕ) : interval 1 (n + 1) = insert (n + 1) (interval 1 n) := by
  ext x
  simp only [interval, max_self, Finset.mem_Icc, Finset.mem_insert]
  omega

private theorem notMem_interval_succ (n : ℕ) : n + 1 ∉ interval 1 n := by
  simp [interval]

/-- BGMS Lemma 1: exactly the irreducible insertions double the number of sums. -/
theorem irreducible_iff_subsetSums_double (n : ℕ) :
    Irreducible (n + 1) ↔
      (subsetSums (interval 1 (n + 1))).card = 2 * (subsetSums (interval 1 n)).card := by
  let S := subsetSums (interval 1 n)
  let T := S.image (fun s => s + ((n + 1 : ℕ) : ℚ)⁻¹)
  have hc : T.card = S.card := Finset.card_image_of_injective _ (fun _ _ => add_right_cancel)
  have hd : (S ∪ T).card = S.card + T.card ↔ Disjoint S T :=
    Finset.card_union_eq_card_add_card
  rw [hc] at hd
  rw [interval_succ, subsetSums_insert (notMem_interval_succ n), two_mul]
  change Irreducible (n + 1) ↔ (S ∪ T).card = S.card + S.card
  rw [hd]
  constructor
  · intro h
    apply Finset.disjoint_left.mpr
    intro x hx hx'
    obtain ⟨S, hS, hmass⟩ := mem_subsetSums.mp hx
    obtain ⟨y, hy, hEq⟩ := Finset.mem_image.mp hx'
    obtain ⟨T, hT, hmass'⟩ := mem_subsetSums.mp hy
    apply h.2 S T (by simpa using hS) (by simpa using hT)
    linarith
  · intro h
    refine ⟨Nat.succ_pos _, fun S T hS hT hmass => ?_⟩
    apply (Finset.disjoint_left.mp h) (a := mass S)
    · exact mem_subsetSums.mpr ⟨S, by simpa using hS, rfl⟩
    · exact Finset.mem_image.mpr ⟨mass T, mem_subsetSums.mpr ⟨T, by simpa using hT, rfl⟩,
        by linarith⟩

/-- BGMS's set of irreducible denominators up to height N. -/
noncomputable def irreducibles (N : ℕ) : Finset ℕ := by
  classical
  exact (interval 1 N).filter Irreducible

@[simp] theorem mem_irreducibles {N n : ℕ} :
    n ∈ irreducibles N ↔ n ∈ interval 1 N ∧ Irreducible n := by
  classical
  simp only [irreducibles, Finset.mem_filter]

/-- BGMS Lemma 2: every irreducible contributes a factor of two. -/
theorem pow_irreducibles_le_subsetSums (N : ℕ) :
    2 ^ (irreducibles N).card ≤ (subsetSums (interval 1 N)).card := by
  classical
  induction N with
  | zero => simp [irreducibles, interval, subsetSums, mass]
  | succ n ih =>
    by_cases hn : Irreducible (n + 1)
    · have hIns : irreducibles (n + 1) = insert (n + 1) (irreducibles n) := by
        simp only [irreducibles, interval_succ, Finset.filter_insert, hn, ite_true]
      rw [hIns, Finset.card_insert_of_notMem (fun h =>
        notMem_interval_succ n (mem_irreducibles.mp h).1),
        pow_succ, (irreducible_iff_subsetSums_double n).mp hn, mul_comm 2]
      exact Nat.mul_le_mul_right _ ih
    · have hEq : irreducibles (n + 1) = irreducibles n := by
        simp only [irreducibles, interval_succ, Finset.filter_insert, hn, ite_false]
      rw [hEq]
      exact ih.trans (Finset.card_le_card (subsetSums_mono
        (interval_succ n ▸ Finset.subset_insert _ _)))

/-- In one color the values are exactly the reciprocal subset sums. -/
theorem mem_subsetSums_iff_exists_value (E : Finset ℕ) (r : ℚ) :
    r ∈ subsetSums E ↔ ∃ c : Configuration E 1, value E 1 c 0 = r := by
  classical
  constructor
  · intro h
    obtain ⟨S, hS, rfl⟩ := mem_subsetSums.mp h
    let c : Configuration E 1 := fun x => if x.val ∈ S then (0 : Fin 1).succ else 0
    refine ⟨c, ?_⟩
    rw [value_apply]
    have hsum : (∑ x : E, if c x = (0 : Fin 1).succ then (x.val : ℚ)⁻¹ else 0) =
        ∑ x : E, if x.val ∈ S then (x.val : ℚ)⁻¹ else 0 := by
      exact Finset.sum_congr rfl fun x _ => by
        by_cases hx : x.val ∈ S <;> simp [c, hx]
    rw [hsum, E.sum_coe_sort (fun x : ℕ => if x ∈ S then (x : ℚ)⁻¹ else 0), ← Finset.sum_filter, mass]
    congr 1
    ext x
    simp only [Finset.mem_filter]
    exact and_iff_right_of_imp (fun hx => hS hx)
  · rintro ⟨c, rfl⟩
    let T : Finset E := Finset.univ.filter (fun x => c x = (0 : Fin 1).succ)
    let S := T.map ⟨Subtype.val, Subtype.val_injective⟩
    have hS : S ⊆ E := by
      intro x hx
      obtain ⟨y, _, rfl⟩ := Finset.mem_map.mp hx
      exact y.property
    refine mem_subsetSums.mpr ⟨S, hS, ?_⟩
    simp only [S, T, mass, Finset.sum_map, Finset.sum_filter, value_apply,
      Function.Embedding.coeFn_mk]

theorem card_subsetSums_eq_card_output (E : Finset ℕ) :
    (subsetSums E).card = Nat.card (Output E 1) := by
  classical
  let e : (subsetSums E : Type) ≃ Output E 1 :=
    { toFun := fun r => ⟨fun _ => r.val, by
        obtain ⟨c, hc⟩ := (mem_subsetSums_iff_exists_value E r.val).mp r.property
        refine ⟨c, funext fun i => ?_⟩
        simpa only [show i = 0 from Subsingleton.elim _ _] using hc⟩
      invFun := fun x => ⟨x.val 0, by
        obtain ⟨c, hc⟩ := x.property
        exact (mem_subsetSums_iff_exists_value E _).mpr ⟨c, congrFun hc 0⟩⟩
      left_inv := fun _ => rfl
      right_inv := fun x => Subtype.ext (funext fun i =>
        congrArg x.val (Subsingleton.elim _ _)) }
  rw [← Nat.card_congr e, Nat.card_eq_fintype_card, Fintype.card_coe]

theorem supportEntropy_lower_by_irreducibles (N : ℕ) :
    ((irreducibles N).card : ℝ) * Real.log 2 ≤ supportEntropy (interval 1 N) 1 := by
  have h := pow_irreducibles_le_subsetSums N
  rw [card_subsetSums_eq_card_output] at h
  change _ ≤ Real.log (Nat.card (Output (interval 1 N) 1) : ℝ)
  rw [← Real.log_pow]
  exact Real.log_le_log (by positivity) (by exact_mod_cast h)


/-- A prime is compatible with m if it divides none of the new reciprocal-difference numerators. -/
def PrimeCompatible (p m : ℕ) : Prop :=
  ∀ S T : Finset ℕ, S ⊆ interval 1 (m - 1) → T ⊆ interval 1 (m - 1) →
    ¬ (p : ℤ) ∣ ((m : ℚ)⁻¹ - (mass S - mass T)).num

private def LocallyZero (p : ℕ) (r : ℚ) : Prop :=
  ¬ p ∣ r.den ∧ (p : ℤ) ∣ r.num

private theorem locallyZero_add {p : ℕ} (hp : p.Prime) {x y : ℚ}
    (hx : LocallyZero p x) (hy : LocallyZero p y) : LocallyZero p (x + y) := by
  have hd : ¬p ∣ x.den * y.den := fun h => (hp.dvd_mul.mp h).elim hx.1 hy.1
  refine ⟨fun h => hd (h.trans (Rat.add_den_dvd _ _)), ?_⟩
  have hpx : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp hp
  have hxd : ¬(p : ℤ) ∣ (x.den : ℤ) := fun h => hx.1 (Int.natCast_dvd_natCast.mp h)
  have hyd : ¬(p : ℤ) ∣ (y.den : ℤ) := fun h => hy.1 (Int.natCast_dvd_natCast.mp h)
  have h : (p : ℤ) ∣ (x + y).num * x.den * y.den := by
    rw [Rat.add_num_den']
    exact dvd_mul_of_dvd_left (dvd_add (dvd_mul_of_dvd_left hx.2 _) (dvd_mul_of_dvd_left hy.2 _)) _
  exact (hpx.dvd_mul.mp ((hpx.dvd_mul.mp h).resolve_right hyd)).resolve_right hxd

private theorem locallyZero_neg {p : ℕ} {x : ℚ} (hx : LocallyZero p x) :
    LocallyZero p (-x) := by
  simpa only [LocallyZero, Rat.neg_den, Rat.num_neg_eq_neg_num, dvd_neg] using hx

private theorem locallyZero_sum {α : Type*} {p : ℕ} (hp : p.Prime)
    (s : Finset α) (f : α → ℚ) (h : ∀ a ∈ s, LocallyZero p (f a)) :
    LocallyZero p (∑ a ∈ s, f a) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [LocallyZero, hp.ne_one]
  | insert a s ha ih =>
    rw [Finset.sum_insert ha]
    exact locallyZero_add hp (h a (Finset.mem_insert_self _ _))
      (ih (fun b hb => h b (Finset.mem_insert_of_mem hb)))

private theorem locallyZero_of_div {p c d : ℕ} (hp : p.Prime) (hd : d ≠ 0)
    (hc : p ∣ c) (hpd : ¬p ∣ d) : LocallyZero p ((c : ℚ) / d) := by
  let r := (c : ℚ) / d
  have hr : r = Rat.divInt (c : ℤ) (d : ℤ) := by simp only [r, Rat.divInt_eq_div, Int.cast_natCast]
  have hden : r.den ∣ d := by
    apply Int.natCast_dvd_natCast.mp
    rw [hr]
    exact Rat.den_dvd _ _
  obtain ⟨k, h₁, h₂⟩ := Rat.num_den_mk (q := r) (n := (c : ℤ)) (d := (d : ℤ))
    (by exact_mod_cast hd) hr
  refine ⟨fun h => hpd (h.trans hden), ?_⟩
  have hcast := Int.natCast_dvd_natCast.mpr hc
  rw [h₁] at hcast
  rcases ((Nat.prime_iff_prime_int.mp hp).dvd_mul.mp hcast) with hk | hnum
  · exfalso
    apply hpd
    apply Int.natCast_dvd_natCast.mp
    rw [h₂]
    exact dvd_mul_of_dvd_left hk _
  · exact hnum

private theorem locallyZero_scaled_inv {p k n : ℕ} (hp : p.Prime)
    (hn : n ≠ 0) (hdiv : ¬p ^ k ∣ n) :
    LocallyZero p (((p ^ k : ℕ) : ℚ) * (n : ℚ)⁻¹) := by
  let e := n.factorization p
  let d := n / p ^ e
  let c := p ^ (k - e)
  have hpow : p ^ e ∣ n := (hp.pow_dvd_iff_le_factorization hn).mpr le_rfl
  have he : e < k := lt_of_not_ge (fun h => hdiv ((hp.pow_dvd_iff_le_factorization hn).mpr h))
  have hnd : d * p ^ e = n := Nat.div_mul_cancel hpow
  have hd : d ≠ 0 := by intro hz; apply hn; rw [← hnd, hz, zero_mul]
  have hpd : ¬p ∣ d := by
    intro h
    have h' : p ^ (e + 1) ∣ n := by rw [pow_succ', ← hnd]; exact mul_dvd_mul_right h _
    have hlt := (hp.pow_dvd_iff_le_factorization hn).mp h'
    change e + 1 ≤ e at hlt
    omega
  have hpc : p ∣ c := dvd_pow_self _ (by omega)
  have hc : c * p ^ e = p ^ k := by
    dsimp only [c]
    rw [← pow_add, Nat.sub_add_cancel he.le]
  have hD : (n : ℚ) = (d : ℚ) * ((p ^ e : ℕ) : ℚ) := by exact_mod_cast hnd.symm
  have hC : ((p ^ k : ℕ) : ℚ) = (c : ℚ) * ((p ^ e : ℕ) : ℚ) := by exact_mod_cast hc.symm
  have hq : (((p ^ k : ℕ) : ℚ) * (n : ℚ)⁻¹) = (c : ℚ) / d := by
    rw [hC, hD]
    have hpq : (((p ^ e : ℕ) : ℚ)) ≠ 0 := by exact_mod_cast (pow_ne_zero e hp.ne_zero)
    have hdq : (d : ℚ) ≠ 0 := by exact_mod_cast hd
    field_simp
  rw [hq]
  exact locallyZero_of_div hp hd hpc hpd

private def cofactorSelection (q : ℕ) (S : Finset ℕ) : Finset ℕ :=
  (S.filter (q ∣ ·)).image (· / q)

private theorem cofactorSelection_subset {m q : ℕ} (hq : 0 < q) {S : Finset ℕ}
    (hS : S ⊆ interval 1 (m * q - 1)) : cofactorSelection q S ⊆ interval 1 (m - 1) := by
  intro b hb
  obtain ⟨a, ha, hEq⟩ := Finset.mem_image.mp hb
  obtain ⟨haS, hqa⟩ := Finset.mem_filter.mp ha
  have hab := Nat.div_mul_cancel hqa
  have han : 1 ≤ a ∧ a ≤ m * q - 1 := by simpa [interval] using hS haS
  have hpos : 0 < a / q := by
    by_contra! hz
    rw [Nat.eq_zero_of_le_zero hz, zero_mul] at hab
    omega
  have hm : 0 < m * q := by omega
  have hlt : a / q < m :=
    (Nat.div_lt_iff_lt_mul hq).mpr (by omega)
  simpa only [interval, max_self, Finset.mem_Icc, ← hEq] using
    (show 1 ≤ a / q ∧ a / q ≤ m - 1 from ⟨hpos, by omega⟩)

private theorem scale_mass_cofactorSelection {q : ℕ} (hq : 0 < q) {S : Finset ℕ}
    (hS : ∀ x ∈ S, 0 < x) :
    (q : ℚ) * mass (S.filter (q ∣ ·)) = mass (cofactorSelection q S) := by
  unfold mass cofactorSelection
  rw [Finset.mul_sum, Finset.sum_image]
  · apply Finset.sum_congr rfl
    intro a ha
    obtain ⟨hmem, hd⟩ := Finset.mem_filter.mp ha
    have ha0 : (a : ℚ) ≠ 0 := by exact_mod_cast (hS a hmem).ne'
    have hqa0 : (q : ℚ) ≠ 0 := by exact_mod_cast hq.ne'
    have hD : (a : ℚ) = ((a / q : ℕ) : ℚ) * q := by exact_mod_cast (Nat.div_mul_cancel hd).symm
    have hdiv0 : ((a / q : ℕ) : ℚ) ≠ 0 := by
      intro hh
      rw [hD, hh, zero_mul] at ha0
      exact ha0 rfl
    rw [hD]
    field_simp
  · intro a ha b hb h
    have heq := congrArg (· * q) h
    rwa [Nat.div_mul_cancel (Finset.mem_filter.mp ha).2,
      Nat.div_mul_cancel (Finset.mem_filter.mp hb).2] at heq

private theorem locallyZero_scale_mass_filter {p k : ℕ} (hp : p.Prime) {S : Finset ℕ}
    (hS : ∀ x ∈ S, 0 < x) :
    LocallyZero p (((p ^ k : ℕ) : ℚ) * mass (S.filter (fun x => ¬ p ^ k ∣ x))) := by
  rw [mass, Finset.mul_sum]
  apply locallyZero_sum hp
  intro a ha
  exact locallyZero_scaled_inv hp ((hS a (Finset.mem_filter.mp ha).1).ne')
    (Finset.mem_filter.mp ha).2

private theorem mass_split (q : ℕ) (S : Finset ℕ) :
    mass (S.filter (q ∣ ·)) + mass (S.filter (fun a => ¬q ∣ a)) = mass S := by
  exact Finset.sum_filter_add_sum_filter_not S (q ∣ ·) (fun a => (a : ℚ)⁻¹)

/-- BGMS Lemma 4: adjoining any power of a compatible prime preserves irreducibility. -/
theorem irreducible_mul_primePow {m p : ℕ} (hm : 0 < m) (hp : p.Prime)
    (hCompat : PrimeCompatible p m) (k : ℕ) : Irreducible (m * p ^ k) := by
  let q := p ^ k
  have hq : 0 < q := pow_pos hp.pos k
  refine ⟨Nat.mul_pos hm hq, fun S T hS hT hEq => ?_⟩
  have hSpos (x : ℕ) (hx : x ∈ S) : 0 < x := by
    have h : x ∈ interval 1 (m * q - 1) := hS hx
    exact (Finset.mem_Icc.mp h).1
  have hTpos (x : ℕ) (hx : x ∈ T) : 0 < x := by
    have h : x ∈ interval 1 (m * q - 1) := hT hx
    exact (Finset.mem_Icc.mp h).1
  have he := congrArg (fun x : ℚ => (q : ℚ) * x) hEq
  change (q : ℚ) * (mass S - mass T) = (q : ℚ) * ((m * q : ℕ) : ℚ)⁻¹ at he
  rw [← mass_split q S, ← mass_split q T, mul_sub, mul_add, mul_add,
    scale_mass_cofactorSelection hq hSpos, scale_mass_cofactorSelection hq hTpos] at he
  have hr : (q : ℚ) * ((m * q : ℕ) : ℚ)⁻¹ = (m : ℚ)⁻¹ := by
    have hmc : (m : ℚ) ≠ 0 := by exact_mod_cast hm.ne'
    have hqc : (q : ℚ) ≠ 0 := by exact_mod_cast hq.ne'
    push_cast
    field_simp
  rw [hr] at he
  have hLoc := locallyZero_add hp (locallyZero_scale_mass_filter hp hSpos (k := k))
    (locallyZero_neg (locallyZero_scale_mass_filter hp hTpos (k := k)))
  have heq : (m : ℚ)⁻¹ - (mass (cofactorSelection q S) - mass (cofactorSelection q T)) =
      (q : ℚ) * mass (S.filter (fun a => ¬q ∣ a)) +
        -((q : ℚ) * mass (T.filter (fun a => ¬q ∣ a))) := by linarith only [he]
  exact hCompat _ _ (cofactorSelection_subset hq hS) (cofactorSelection_subset hq hT)
    (heq.symm ▸ hLoc.2)

theorem primeCompatible_one {p : ℕ} (hp : p.Prime) : PrimeCompatible p 1 := by
  intro S T hS hT he
  have hS₀ : S = ∅ := Finset.subset_empty.mp (by simpa [interval] using hS)
  have hT₀ : T = ∅ := Finset.subset_empty.mp (by simpa [interval] using hT)
  rw [hS₀, hT₀] at he
  have he' : (p : ℤ) ∣ (↑(1 : ℕ) : ℤ) := by simpa [mass] using he
  exact hp.ne_one (Nat.dvd_one.mp (Int.natCast_dvd_natCast.mp he'))

/-- All prime powers are in BGMS's doubling set. -/
theorem irreducible_primePow {p : ℕ} (hp : p.Prime) (k : ℕ) : Irreducible (p ^ k) := by
  simpa only [one_mul] using irreducible_mul_primePow Nat.one_pos hp (primeCompatible_one hp) k


theorem primesLE_subset_irreducibles (N : ℕ) : Nat.primesLE N ⊆ irreducibles N := by
  intro p hp
  obtain ⟨hpN, hPrime⟩ := Nat.mem_primesLE.mp hp
  exact mem_irreducibles.mpr ⟨Finset.mem_Icc.mpr ⟨hPrime.pos, hpN⟩,
    by simpa only [pow_one] using irreducible_primePow hPrime 1⟩

theorem primeCounting_mul_log_two_le_supportEntropy (N : ℕ) :
    (Nat.primeCounting N : ℝ) * Real.log 2 ≤ supportEntropy (interval 1 N) 1 := by
  have h := Finset.card_le_card (primesLE_subset_irreducibles N)
  rw [Nat.primesLE_card_eq_primeCounting] at h
  exact (mul_le_mul_of_nonneg_right (by exact_mod_cast h) (Real.log_nonneg (by norm_num))).trans
    (supportEntropy_lower_by_irreducibles N)

/-- The prime contribution alone gives an unconditional support lower bound of order n / log n. -/
theorem eventually_supportEntropy_lower (m : ℕ) :
    ∀ᶠ n : ℕ in Filter.atTop, (Real.log 2 / 2) * ((n : ℝ) / Real.log n) ≤
      supportEntropy (interval 1 n) (m + 1) := by
  have h := (Asymptotics.isEquivalent_iff_tendsto_one (by
    filter_upwards [Filter.eventually_gt_atTop (1 : ℝ)] with x hx
    exact div_ne_zero (zero_lt_one.trans hx).ne' (Real.log_pos hx).ne')).mp
      Nat.isEquivalent_primeCounting
  have ht : Filter.Tendsto (fun n : ℕ => (n : ℝ)) Filter.atTop Filter.atTop :=
    tendsto_natCast_atTop_atTop
  filter_upwards [(h.comp ht).eventually_const_lt (show (1 / 2 : ℝ) < 1 by norm_num),
    Filter.eventually_ge_atTop (2 : ℕ)] with n hn hn₂
  have hn₁ : (1 : ℝ) < n := by exact_mod_cast (show 1 < n by omega)
  have hpos : 0 < (n : ℝ) / Real.log n := div_pos (zero_lt_one.trans hn₁) (Real.log_pos hn₁)
  have hratio : (1 / 2 : ℝ) < (Nat.primeCounting n : ℝ) / ((n : ℝ) / Real.log n) := by
    simpa only [Function.comp_apply, Pi.div_apply, Nat.floor_natCast] using hn
  calc
    _ = (1 / 2 : ℝ) * ((n : ℝ) / Real.log n) * Real.log 2 := by ring
    _ ≤ (Nat.primeCounting n : ℝ) * Real.log 2 :=
      mul_le_mul_of_nonneg_right ((lt_div_iff₀ hpos).mp hratio).le (Real.log_nonneg (by norm_num))
    _ ≤ supportEntropy (interval 1 n) 1 := primeCounting_mul_log_two_le_supportEntropy n
    _ ≤ _ := supportEntropy_oneColor_le (interval 1 n) (fun x => (Finset.mem_Icc.mp x.property).1) m


/-- The paper's signed-sum condition, with coefficients in {-1,0,1}. -/
theorem irreducible_iff_no_signed_relation {n : ℕ} (hn : 0 < n) :
    Irreducible n ↔
      ∀ w : ℕ → ℤ,
        (∀ j ∈ interval 1 (n - 1), w j = -1 ∨ w j = 0 ∨ w j = 1) →
        (∑ j ∈ interval 1 (n - 1), (w j : ℚ) * (j : ℚ)⁻¹) ≠ (n : ℚ)⁻¹ := by
  let E := interval 1 (n - 1)
  constructor
  · intro h w hw hsum
    let S := E.filter (fun j => w j = 1)
    let T := E.filter (fun j => w j = -1)
    have he : (∑ j ∈ E, (w j : ℚ) * (j : ℚ)⁻¹) = mass S - mass T := by
      simp only [S, T, mass, Finset.sum_filter, ← Finset.sum_sub_distrib]
      refine Finset.sum_congr rfl fun j hj => ?_
      rcases hw j hj with h | h | h <;> simp [h]
    exact h.2 S T (Finset.filter_subset _ _) (Finset.filter_subset _ _) (he.symm.trans hsum)
  · intro h
    refine ⟨hn, fun S T hS hT he => ?_⟩
    let w : ℕ → ℤ := fun j => (if j ∈ S then 1 else 0) - (if j ∈ T then 1 else 0)
    have hw (j : ℕ) (_ : j ∈ E) : w j = -1 ∨ w j = 0 ∨ w j = 1 := by
      by_cases hs : j ∈ S <;> by_cases ht : j ∈ T <;> simp [w, hs, ht]
    have hS' : E.filter (· ∈ S) = S := by
      ext j
      exact Finset.mem_filter.trans (and_iff_right_of_imp (fun hj => hS hj))
    have hT' : E.filter (· ∈ T) = T := by
      ext j
      exact Finset.mem_filter.trans (and_iff_right_of_imp (fun hj => hT hj))
    have he' : (∑ j ∈ E, (w j : ℚ) * (j : ℚ)⁻¹) = mass S - mass T := by
      rw [← hS', ← hT']
      simp only [mass, Finset.sum_filter, ← Finset.sum_sub_distrib]
      refine Finset.sum_congr rfl fun j hj => ?_
      by_cases hs : j ∈ S <;> by_cases ht : j ∈ T <;> simp [w, hs, ht]
    exact h w hw (he'.trans he)

private theorem dvd_lcmUpto_of_mem {n x : ℕ} (hx : x ∈ interval 1 n) : x ∣ Nat.lcmUpto n := by
  unfold Nat.lcmUpto
  exact Finset.dvd_lcm (f := id) (by simpa [interval] using hx)

private theorem mass_den_dvd_lcmUpto {S : Finset ℕ} {n : ℕ} (hS : S ⊆ interval 1 n) :
    (mass S).den ∣ Nat.lcmUpto n := by
  unfold mass
  refine (Finset.Rat.den_sum_dvd_lcm_den S _).trans (Finset.lcm_dvd fun x hx => ?_)
  have hx' := hS hx
  rw [Rat.inv_natCast_den_of_pos (Finset.mem_Icc.mp hx').1]
  exact dvd_lcmUpto_of_mem hx'

/-- The explicit sufficient compatibility criterion of BGMS: p > D_m h_m. -/
theorem primeCompatible_of_lcm_mul_mass_lt {m p : ℕ} (hm : Irreducible m)
    (hp : (Nat.lcmUpto m : ℚ) * mass (interval 1 m) < (p : ℚ)) :
    PrimeCompatible p m := by
  intro S T hS hT hpdiv
  let r := (m : ℚ)⁻¹ - (mass S - mass T)
  have hmp : m - 1 + 1 = m := by have := hm.1; omega
  have hInt : interval 1 m = insert m (interval 1 (m - 1)) := by
    simpa only [hmp] using interval_succ (m - 1)
  have hNot : m ∉ interval 1 (m - 1) := by
    simpa only [hmp] using notMem_interval_succ (m - 1)
  have hSub : interval 1 (m - 1) ⊆ interval 1 m := by
    rw [hInt]
    exact Finset.subset_insert _ _
  have hmd : ((m : ℚ)⁻¹).den ∣ Nat.lcmUpto m := by
    rw [Rat.inv_natCast_den_of_pos hm.1]
    exact dvd_lcmUpto_of_mem (by rw [hInt]; exact Finset.mem_insert_self _ _)
  have hdif : (mass S - mass T).den ∣ Nat.lcmUpto m :=
    (Rat.sub_den_dvd_lcm _ _).trans (lcm_dvd (mass_den_dvd_lcmUpto (hS.trans hSub))
      (mass_den_dvd_lcmUpto (hT.trans hSub)))
  have hd : r.den ∣ Nat.lcmUpto m :=
    (Rat.sub_den_dvd_lcm _ _).trans (lcm_dvd hmd hdif)
  have hmass : mass (interval 1 m) = (m : ℚ)⁻¹ + mass (interval 1 (m - 1)) := by
    rw [hInt, mass_insert hNot]
  have hA : |r| ≤ mass (interval 1 m) := by
    rw [abs_le, hmass]
    have hsm := mass_mono hS
    have htm := mass_mono hT
    have hs0 := mass_nonneg S
    have ht0 := mass_nonneg T
    have hm0 : (0 : ℚ) ≤ (m : ℚ)⁻¹ := inv_nonneg.mpr (Nat.cast_nonneg _)
    dsimp only [r]
    constructor <;> linarith
  have hnum : (r.num : ℚ) = r * (r.den : ℚ) :=
    (div_eq_iff (by exact_mod_cast r.den_ne_zero)).mp r.num_div_den
  have hden : (r.den : ℚ) ≤ Nat.lcmUpto m := by exact_mod_cast Nat.le_of_dvd (Nat.lcmUpto_pos m) hd
  have hnumlt : (r.num.natAbs : ℚ) < p := by
    rw [Nat.cast_natAbs, Int.cast_abs, hnum, abs_mul, abs_of_nonneg (Nat.cast_nonneg (α := ℚ) r.den)]
    calc
      _ ≤ mass (interval 1 m) * (Nat.lcmUpto m : ℚ) :=
        mul_le_mul hA hden (Nat.cast_nonneg _) (mass_nonneg _)
      _ < _ := by simpa only [mul_comm] using hp
  have hr0 : r ≠ 0 := sub_ne_zero.mpr (hm.2 S T hS hT).symm
  have hdvd : p ∣ r.num.natAbs := Int.natCast_dvd_natCast.mp (Int.dvd_natAbs.mpr hpdiv)
  have hle := Nat.le_of_dvd (Int.natAbs_pos.mpr (Rat.num_ne_zero.mpr hr0)) hdvd
  exact (not_lt_of_ge (by exact_mod_cast hle)) hnumlt


private theorem antitoneOn_inv_div_log :
    AntitoneOn (fun t : ℝ => t⁻¹ / Real.log t) (Set.Ioi 1) := by
  intro x hx y hy hxy
  have hx' : 1 < x := hx
  have hy' : 1 < y := hy
  have hLog := Real.log_le_log (zero_lt_one.trans hx') hxy
  have hprod : x * Real.log x ≤ y * Real.log y :=
    mul_le_mul hxy hLog (Real.log_pos hx').le (zero_lt_one.trans hy').le
  change y⁻¹ / Real.log y ≤ x⁻¹ / Real.log x
  simp only [div_eq_mul_inv, ← mul_inv]
  exact (inv_le_inv₀ (mul_pos (zero_lt_one.trans hy') (Real.log_pos hy'))
    (mul_pos (zero_lt_one.trans hx') (Real.log_pos hx'))).2 hprod

private theorem log_log_paperK_succ_lower (n : ℕ) (hL : 4 ≤ Real.log (n : ℝ)) :
    Real.log (Real.log (Real.log (n : ℝ))) - Real.log 2 ≤
      Real.log (Real.log (((paperK n : ℕ) : ℝ) + 1)) := by
  let L := Real.log (n : ℝ)
  let K : ℝ := paperK n
  have hL0 : 0 < L := by linarith
  have hhalf : L / 2 ≤ K + 1 := by
    have hL₂ : 2 ≤ Real.log (n : ℝ) := by linarith
    have h := (halfLog_integral_endpoints hL₂).2
    dsimp only [L, K, paperK] at *
    linarith
  have hLog := Real.log_le_log (by positivity : 0 < L / 2) hhalf
  rw [Real.log_div hL0.ne' (by norm_num)] at hLog
  have hfour : Real.log (4 : ℝ) ≤ Real.log L := Real.log_le_log (by norm_num) hL
  rw [show (4 : ℝ) = 2 * 2 by norm_num, Real.log_mul (by norm_num) (by norm_num)] at hfour
  have hLoghalf : Real.log L / 2 ≤ Real.log (K + 1) := by linarith
  have hLogL : 0 < Real.log L := Real.log_pos (by linarith)
  have h := Real.log_le_log (by positivity : 0 < Real.log L / 2) hLoghalf
  rw [Real.log_div hLogL.ne' (by norm_num)] at h
  exact h

/-- The finite decoding recurrence and the prime contribution force an extra factor log₃ n. -/
theorem eventually_supportEntropy_lower_log₃ (m : ℕ) :
    ∀ᶠ n : ℕ in Filter.atTop,
      (Real.log 2 / 8) * ((n : ℝ) / Real.log n) * Real.log (Real.log (Real.log (n : ℝ))) ≤
        supportEntropy (interval 1 n) (m + 1) := by
  let g (j : ℕ) := supportEntropy (interval 1 j) (m + 1)
  let c₀ := Real.log 2 / 2
  have hc₀ : 0 < c₀ := div_pos (Real.log_pos (by norm_num)) (by norm_num)
  obtain ⟨T₀, hT₀⟩ := Filter.eventually_atTop.mp (eventually_supportEntropy_lower m)
  let T := max (2 : ℕ) T₀
  have hT (j : ℕ) (hj : T ≤ j) : c₀ * ((j : ℝ) / Real.log j) ≤ g j :=
    hT₀ j ((le_max_right _ _).trans hj)
  have hT₂ : (2 : ℕ) ≤ T := le_max_left _ _
  have hT₁ : (1 : ℝ) < T := by exact_mod_cast (show 1 < T by omega)
  obtain ⟨C, _, hRec⟩ := eventually_intervalRenyi_finiteRecurrence (m + 1)
  have hcast : Filter.Tendsto (fun n : ℕ => (n : ℝ)) Filter.atTop Filter.atTop := tendsto_natCast_atTop_atTop
  have hlog := Real.tendsto_log_atTop.comp hcast
  have hlog₃ := Real.tendsto_log_atTop.comp (Real.tendsto_log_atTop.comp hlog)
  let err := c₀ / 2 * (Real.log 2 + Real.log (Real.log (T : ℝ))) + C
  filter_upwards [hRec, hlog.eventually_ge_atTop 4, hlog.eventually_ge_atTop (2 * (T : ℝ)),
    hlog₃.eventually_ge_atTop (4 * err / c₀)] with n hR hL hTL hBig
  change 4 ≤ Real.log (n : ℝ) at hL
  change 2 * (T : ℝ) ≤ Real.log (n : ℝ) at hTL
  change 4 * err / c₀ ≤ Real.log (Real.log (Real.log (n : ℝ))) at hBig
  let K := paperK n
  let q := (n : ℝ) / Real.log n
  let f : ℝ → ℝ := fun t => t⁻¹ / Real.log t
  have hTK : T ≤ K := (Nat.le_floor_iff' (by omega)).mpr (by linarith only [hTL])
  have hK₁ : (1 : ℝ) < ((K + 1 : ℕ) : ℝ) := by
    exact_mod_cast (show 1 < K + 1 by omega)
  have hq : 0 ≤ q := div_nonneg (Nat.cast_nonneg _) (by linarith only [hL])
  have hanti := antitoneOn_inv_div_log.mono
    (show Set.Icc (T : ℝ) ((K + 1 : ℕ) : ℝ) ⊆ Set.Ioi 1 from fun t ht => hT₁.trans_le ht.1)
  have hi := hanti.integral_le_sum_Ico (by omega : T ≤ K + 1)
  have hIntegr : Real.log (Real.log (((K + 1 : ℕ) : ℝ))) - Real.log (Real.log (T : ℝ)) ≤
      ∑ j ∈ Finset.Ico T (K + 1), f (j : ℝ) := by
    change (∫ t in (T : ℝ)..((K + 1 : ℕ) : ℝ), t⁻¹ / Real.log t) ≤ _ at hi
    rwa [integral_inv_div_log hT₁ hK₁] at hi
  have hTail : Real.log (Real.log (Real.log (n : ℝ))) - Real.log 2 -
      Real.log (Real.log (T : ℝ)) ≤ ∑ j ∈ Finset.Ico T (K + 1), f (j : ℝ) := by
    apply le_trans _ hIntegr
    have hh := log_log_paperK_succ_lower n hL
    simpa only [K, Nat.cast_add, Nat.cast_one] using sub_le_sub_right hh (Real.log (Real.log (T : ℝ)))
  have hPoint (j : ℕ) (hj : j ∈ Finset.Ico T (K + 1)) :
      c₀ / 2 * f (j : ℝ) ≤ g j / ((j : ℝ) * ((j : ℝ) + 1)) := by
    have hjT := (Finset.mem_Ico.mp hj).1
    have hj₁ : (1 : ℝ) < j := hT₁.trans_le (by exact_mod_cast hjT)
    have hj₀ : (0 : ℝ) < j := zero_lt_one.trans hj₁
    have hlj : 0 < Real.log j := Real.log_pos hj₁
    have hjadd : (0 : ℝ) < (j : ℝ) + 1 := by positivity
    dsimp only [f]
    calc
      _ = c₀ * (1 / (2 * (j : ℝ) * Real.log j))  := by field_simp
      _ ≤ c₀ * (1 / (((j : ℝ) + 1) * Real.log j)) := by
        apply mul_le_mul_of_nonneg_left _ hc₀.le
        exact one_div_le_one_div_of_le (mul_pos hjadd hlj)
          (mul_le_mul_of_nonneg_right (by linarith) hlj.le)
      _ = (c₀ * ((j : ℝ) / Real.log j)) / ((j : ℝ) * ((j : ℝ) + 1)) := by
        field_simp
      _ ≤ _ := div_le_div_of_nonneg_right (hT j hjT) (by positivity)
  let M := ∑ j ∈ Finset.Icc 1 K, g j / ((j : ℝ) * ((j : ℝ) + 1))
  have hComp : c₀ / 2 * (Real.log (Real.log (Real.log (n : ℝ))) - Real.log 2 -
      Real.log (Real.log (T : ℝ))) ≤ M := calc
    _ ≤ c₀ / 2 * (∑ j ∈ Finset.Ico T (K + 1), f (j : ℝ)) := mul_le_mul_of_nonneg_left hTail (by positivity)
    _ ≤ ∑ j ∈ Finset.Ico T (K + 1), g j / ((j : ℝ) * ((j : ℝ) + 1)) := by
      rw [Finset.mul_sum]
      exact Finset.sum_le_sum hPoint
    _ ≤ _ := by
      apply Finset.sum_le_sum_of_subset_of_nonneg
      · intro j hj
        obtain ⟨hjt, hjk⟩ := Finset.mem_Ico.mp hj
        exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩
      · intro j _ _
        exact div_nonneg (supportEntropy_nonneg _ _) (by positivity)
  have hAbs : |g n - q * M| ≤ C * q := by
    simpa only [g, q, M, K, intervalRenyi, FiniteLaw.renyi_zero, configurationLaw_hartley] using hR 0
  have hG : q * (M - C) ≤ g n := by
    have hh := (neg_le_abs (g n - q * M)).trans hAbs
    linarith only [hh]
  have hE : err ≤ c₀ / 4 * Real.log (Real.log (Real.log (n : ℝ))) := by
    have hh := (div_le_iff₀ hc₀).mp hBig
    linarith only [hh]
  have hFinal : c₀ / 4 * Real.log (Real.log (Real.log (n : ℝ))) ≤ M - C := by
    dsimp only [err] at hE
    linarith only [hComp, hE]
  change _ ≤ g n
  calc
    _ = q * (c₀ / 4 * Real.log (Real.log (Real.log (n : ℝ)))) := by
      dsimp only [q, c₀]
      ring
    _ ≤ q * (M - C) := mul_le_mul_of_nonneg_left hFinal hq
    _ ≤ _ := hG


/-- The fixed-depth lower bound is uniform across all Rényi orders for each color count. -/
theorem eventually_intervalRenyi_lower_log₃ (m : ℕ) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ n : ℕ in Filter.atTop, ∀ a : RenyiOrder,
      c * ((n : ℝ) / Real.log n) * Real.log (Real.log (Real.log (n : ℝ))) ≤
        intervalRenyi n (m + 1) a := by
  obtain ⟨d, hd, h⟩ := eventually_renyi_relative_all_orders (m + 1) (by omega)
  let c := Real.log 2 / 8
  have hc : 0 < c := div_pos (Real.log_pos (by norm_num)) (by norm_num)
  refine ⟨d * c, mul_pos hd hc, ?_⟩
  filter_upwards [eventually_supportEntropy_lower_log₃ m, h] with n hn hb a
  rw [mul_assoc d c, mul_assoc d (c * ((n : ℝ) / Real.log n))]
  exact (mul_le_mul_of_nonneg_left hn hd.le).trans (hb a).1

end LeanAB.PaperA.BGMS
