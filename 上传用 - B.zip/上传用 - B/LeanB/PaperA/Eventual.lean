module

public import PaperA.Decode
public import PaperA.Grid
public import PaperA.Remainder
import Mathlib.Tactic

@[expose] public section

/-! The exact decoding and remainder bounds with the manuscript's choice of cutoff. -/

namespace LeanAB.PaperA

open Filter
open scoped BigOperators

/-- For all sufficiently large n the paper's support bijection, fiber formula and product
law hold simultaneously for every number of colors. -/
theorem eventually_exactDecoding :
    ∀ᶠ n : ℕ in atTop, ∀ m : ℕ,
      ∃ e : FactorSupport n (paperK n) m ≃ (support (interval 1 n) m : Type),
        ∀ s : FactorSupport n (paperK n) m,
          (e s).val = mergeOutput s.1.val (fun p => (s.2 p).val) ∧
          Nat.card (Fiber (interval 1 n) m (e s).val) =
            Nat.card (Fiber (remainder n (paperK n)) m s.1.val) *
              ∏ p : blockPrimes n (paperK n),
                Nat.card (Fiber (interval 1 (n / p.val)) m (s.2 p).val) ∧
          probability (interval 1 n) m (e s).val =
            probability (remainder n (paperK n)) m s.1.val *
              ∏ p : blockPrimes n (paperK n),
                probability (interval 1 (n / p.val)) m (s.2 p).val := by
  filter_upwards [eventually_paperBlockBounds] with n hn m
  have bounds (p : blockPrimes n (paperK n)) :=
    hn p.val (Finset.mem_filter.mp p.property).2
  have hsquare (p : blockPrimes n (paperK n)) := (bounds p).1
  have hsmall (p : blockPrimes n (paperK n)) := (bounds p).2.1
  have hnarrow (p : blockPrimes n (paperK n)) :
      (Nat.lcmUpto (paperK n) : ℚ) * harmonic (paperK n) < (p.val : ℚ) :=
    (mul_le_mul_of_nonneg_left (harmonic_le _) (Nat.cast_nonneg _)).trans_lt
      (by exact_mod_cast (bounds p).2.2)
  let e := supportEquiv n (paperK n) m hsquare hsmall hnarrow
  refine ⟨e, fun s => ⟨supportEquiv_apply _ _ _ _ _ _ _, ?_, ?_⟩⟩
  · rw [supportEquiv_apply]
    exact fiberCount_mul n (paperK n) m hsquare hsmall hnarrow s
  · rw [supportEquiv_apply]
    exact probability_mul n (paperK n) m hsquare hsmall hnarrow s

private theorem remainder_subset (n K : ℕ) : remainder n K ⊆ interval 1 n :=
  Finset.filter_subset _ _

private theorem remainder_prime_le {n K a p : ℕ} (ha : a ∈ remainder n K)
    (hp : p.Prime) (hpa : p ∣ a) : p ≤ n / (K + 1) := by
  have hain : a ∈ Finset.Icc 1 n := by
    simpa [interval] using remainder_subset n K ha
  have hna := Finset.mem_Icc.mp hain
  have hpn := (Nat.le_of_dvd hna.1 hpa).trans hna.2
  by_contra! h
  have hcut := (Nat.div_lt_iff_lt_mul (Nat.zero_lt_succ K)).mp h
  have hblock : p ∈ blockPrimes n K := Finset.mem_filter.mpr
    ⟨Nat.mem_primesLE.mpr ⟨hpn, hp⟩, by simpa only [Nat.mul_comm (K + 1) p] using hcut⟩
  exact (Finset.mem_filter.mp ha).2 p hblock hpa

/-- Hartley entropy of the finite reciprocal-sum support. -/
noncomputable def supportEntropy (E : Finset ℕ) (m : ℕ) : ℝ :=
  Real.log (Nat.card (support E m))

private theorem support_card_pos (E : Finset ℕ) (m : ℕ) : 0 < Nat.card (support E m) := by
  let _ : Finite (support E m) := (Set.finite_range (value E m)).to_subtype
  let _ : Nonempty (support E m) := ⟨⟨_, ⟨(fun _ => 0), rfl⟩⟩⟩
  exact Nat.card_pos

theorem supportEntropy_nonneg (E : Finset ℕ) (m : ℕ) : 0 ≤ supportEntropy E m :=
  Real.log_nonneg (by exact_mod_cast support_card_pos E m)


/-- The Hartley entropy adds across the factors of the finite decoding bijection. -/
theorem supportEntropy_factor (n K m : ℕ)
    (hsquare : ∀ p : blockPrimes n K, n < p.val * p.val)
    (hsmall : ∀ p : blockPrimes n K, K < p.val)
    (hnarrow : ∀ p : blockPrimes n K, (Nat.lcmUpto K : ℚ) * harmonic K < (p.val : ℚ)) :
    supportEntropy (interval 1 n) m = supportEntropy (remainder n K) m +
      ∑ p : blockPrimes n K, supportEntropy (interval 1 (n / p.val)) m := by
  have hc := Nat.card_congr (supportEquiv n K m hsquare hsmall hnarrow)
  rw [Nat.card_prod, Nat.card_pi] at hc
  have hR : (0 : ℝ) < Nat.card (support (remainder n K) m) := by
    exact_mod_cast support_card_pos (remainder n K) m
  have hP (p : blockPrimes n K) :
      (0 : ℝ) < Nat.card (support (interval 1 (n / p.val)) m) := by
    exact_mod_cast support_card_pos (interval 1 (n / p.val)) m
  unfold supportEntropy
  rw [← hc, Nat.cast_mul, Nat.cast_prod, Real.log_mul hR.ne'
    (Finset.prod_pos fun p _ => hP p).ne', Real.log_prod (fun p _ => (hP p).ne')]

private theorem supportEntropy_le (m : ℕ) {n : ℕ} (hn : 2 ≤ n) {E : Finset ℕ}
    (hE : E ⊆ interval 1 n) :
    supportEntropy E m ≤ (m : ℝ) * (Real.log ((E.lcm id : ℕ) : ℝ) + 2 * Real.log n) := by
  have hpos (a : ℕ) (ha : a ∈ E) : 0 < a := by
    have ha' : a ∈ Finset.Icc 1 n := by simpa [interval] using hE ha
    exact (Finset.mem_Icc.mp ha').1
  let D : ℕ := E.lcm id
  have hD : 0 < D :=
    Nat.pos_of_ne_zero (Finset.lcm_ne_zero_iff.mpr fun a ha => (hpos a ha).ne')
  have hDn : 0 < D * n := Nat.mul_pos hD (by omega)
  have hmass : mass E ≤ (n : ℚ) := (mass_mono hE).trans (harmonic_le n)
  have hfloor : ⌊(D : ℚ) * mass E⌋₊ ≤ D * n := by
    have h := Nat.floor_mono (mul_le_mul_of_nonneg_left hmass (Nat.cast_nonneg D))
    simpa only [← Nat.cast_mul, Nat.floor_natCast] using h
  have hcard := (card_support_le_lcm_grid m hpos).trans
    (show (⌊(D : ℚ) * mass E⌋₊ + 1) ^ m ≤ (2 * (D * n)) ^ m from
      Nat.pow_le_pow_left (by omega) m)
  have hD' : (0 : ℝ) < D := by exact_mod_cast hD
  have hn' : (0 : ℝ) < n := by exact_mod_cast (show 0 < n by omega)
  have htwo : Real.log 2 ≤ Real.log (n : ℝ) :=
    Real.log_le_log (by norm_num) (by exact_mod_cast hn)
  calc
    _ ≤ Real.log (((2 : ℝ) * ((D : ℝ) * (n : ℝ))) ^ m) :=
      Real.log_le_log (by exact_mod_cast support_card_pos E m) (by exact_mod_cast hcard)
    _ = (m : ℝ) * (Real.log 2 + Real.log (D : ℝ) + Real.log n) := by
      rw [Real.log_pow, Real.log_mul (by norm_num) (by positivity),
        Real.log_mul hD'.ne' hn'.ne']
      ring
    _ ≤ _ := mul_le_mul_of_nonneg_left (by linarith) (Nat.cast_nonneg m)

/-- The paper's remainder Hartley entropy bound, for all numbers of colors. -/
theorem eventually_remainderSupportEntropy :
    ∀ᶠ n : ℕ in atTop, ∀ m : ℕ,
      0 ≤ supportEntropy (remainder n (paperK n)) m ∧
      supportEntropy (remainder n (paperK n)) m ≤
        (m : ℝ) * (2 * (Real.log 4 + 4) + 3) * ((n : ℝ) / Real.log n) := by
  filter_upwards [eventually_log_lcm_at_paperCutoff, eventually_log_terms_le,
    eventually_ge_atTop (2 : ℕ)] with n hD hlog hn m
  let R := remainder n (paperK n)
  have hR : R ⊆ interval 1 n := remainder_subset n (paperK n)
  refine ⟨supportEntropy_nonneg R m, (supportEntropy_le m hn hR).trans ?_⟩
  have hl := hD R hR fun a ha p hp hpa => remainder_prime_le ha hp hpa
  calc
    _ ≤ (m : ℝ) * ((2 * (Real.log 4 + 4) + 1) * ((n : ℝ) / Real.log n) +
        2 * ((n : ℝ) / Real.log n)) := by
      apply mul_le_mul_of_nonneg_left _ (Nat.cast_nonneg m)
      linarith [hlog.2]
    _ = _ := by ring

end LeanAB.PaperA
