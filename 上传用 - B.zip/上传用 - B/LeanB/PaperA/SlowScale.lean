module

public import PaperA.IntegralScale
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Tactic

public section

/-! Slow variation of the iterated-logarithm factor used in modular aliasing. -/

namespace LeanAB.PaperA

open Filter Asymptotics
open scoped Topology

private theorem clippedLog_sub_le_log_sub {u v : ℝ} (hu : 1 ≤ u) (huv : u ≤ v) :
    clippedLog v - clippedLog u ≤ Real.log v - Real.log u := by
  have hpos : 0 < u := zero_lt_one.trans_le hu
  have hmono := Real.log_le_log hpos huv
  by_cases hv : v ≤ Real.exp 1
  · rw [clippedLog_eq_one hv, clippedLog_eq_one (huv.trans hv)]
    linarith
  by_cases he : Real.exp 1 ≤ u
  · rw [clippedLog_eq_log he, clippedLog_eq_log (he.trans huv)]
  · rw [clippedLog_eq_one (le_of_not_ge he), clippedLog_eq_log (le_of_not_ge hv)]
    have hle := Real.log_le_log hpos (le_of_not_ge he)
    rw [Real.log_exp] at hle
    linarith

private theorem log_clippedLog_sub_le {u v M : ℝ} (hu : 1 ≤ u) (huv : u ≤ v)
    (hM : 0 < M) (hMu : M ≤ clippedLog u) :
    Real.log (clippedLog v) - Real.log (clippedLog u) ≤ (Real.log v - Real.log u) / M := by
  have hu1 : 0 < clippedLog u := zero_lt_one.trans_le (one_le_clippedLog u)
  have hv1 : 0 < clippedLog v := zero_lt_one.trans_le (one_le_clippedLog v)
  have hsub : 0 ≤ clippedLog v - clippedLog u :=
    sub_nonneg.mpr (monotone_clippedLog huv)
  calc
    _ = Real.log (clippedLog v / clippedLog u) := (Real.log_div hv1.ne' hu1.ne').symm
    _ ≤ clippedLog v / clippedLog u - 1 := Real.log_le_sub_one_of_pos (div_pos hv1 hu1)
    _ = (clippedLog v - clippedLog u) / clippedLog u := by rw [sub_div, div_self hu1.ne']
    _ ≤ (clippedLog v - clippedLog u) / M := div_le_div_of_nonneg_left hsub hM hMu
    _ ≤ _ := div_le_div_of_nonneg_right (clippedLog_sub_le_log_sub hu huv) hM.le

private theorem two_le_exp_one : (2 : ℝ) ≤ Real.exp 1 := by
  have h := Real.add_one_le_exp 1
  linarith

private theorem log_truncatedLogProduct_sub_le (k : ℕ) {u v : ℝ} (hu : 1 ≤ u) (huv : u ≤ v) :
    Real.log (truncatedLogProduct k v) - Real.log (truncatedLogProduct k u) ≤
      2 * (Real.log v - Real.log u) := by
  induction k generalizing u v with
  | zero =>
    simp only [truncatedLogProduct, sub_self]
    exact mul_nonneg zero_le_two (sub_nonneg.mpr (Real.log_le_log (zero_lt_one.trans_le hu) huv))
  | succ k ih =>
    have he : (1 : ℝ) ≤ Real.exp 2 := by
      rw [← Real.exp_zero]
      exact Real.exp_le_exp.mpr (by norm_num)
    have high {u v : ℝ} (h₂ : Real.exp 2 ≤ u) (h : u ≤ v) :
        Real.log (truncatedLogProduct (k + 1) v) - Real.log (truncatedLogProduct (k + 1) u) ≤
          2 * (Real.log v - Real.log u) := by
      have hu0 := he.trans h₂
      have htwo : (2 : ℝ) ≤ clippedLog u := by
        rw [clippedLog_eq_log ((Real.exp_le_exp.mpr (by norm_num)).trans h₂)]
        exact (Real.le_log_iff_exp_le (zero_lt_one.trans_le hu0)).mpr h₂
      have hh := log_clippedLog_sub_le hu0 h (show (0 : ℝ) < 2 by norm_num) htwo
      have hj := ih (one_le_clippedLog u) (monotone_clippedLog h)
      have hclip (x : ℝ) : 0 < clippedLog x := zero_lt_one.trans_le (one_le_clippedLog x)
      have htr (x : ℝ) : 0 < truncatedLogProduct k x :=
        zero_lt_one.trans_le (one_le_truncatedLogProduct k x)
      rw [truncatedLogProduct, truncatedLogProduct, Real.log_mul (hclip _).ne' (htr _).ne',
        Real.log_mul (hclip _).ne' (htr _).ne']
      have hlog := Real.log_le_log (zero_lt_one.trans_le hu0) h
      linarith
    have low {u v : ℝ} (hu' : 1 ≤ u) (h : u ≤ v) (hv' : v ≤ Real.exp 2) :
        Real.log (truncatedLogProduct (k + 1) v) - Real.log (truncatedLogProduct (k + 1) u) ≤
          2 * (Real.log v - Real.log u) := by
      have hc : clippedLog v ≤ Real.exp 1 := by
        calc
          _ ≤ clippedLog (Real.exp 2) := monotone_clippedLog hv'
          _ = 2 := by rw [clippedLog_eq_log (Real.exp_le_exp.mpr (by norm_num)), Real.log_exp]
          _ ≤ _ := two_le_exp_one
      rw [truncatedLogProduct, truncatedLogProduct, truncatedLogProduct_eq_one k hc,
        truncatedLogProduct_eq_one k ((monotone_clippedLog h).trans hc), mul_one, mul_one]
      have hh := log_clippedLog_sub_le hu' h zero_lt_one (one_le_clippedLog u)
      have hlog := Real.log_le_log (zero_lt_one.trans_le hu') h
      linarith
    by_cases hu₂ : Real.exp 2 ≤ u
    · exact high hu₂ huv
    by_cases hv₂ : v ≤ Real.exp 2
    · exact low hu huv hv₂
    linarith [low hu (le_of_not_ge hu₂) le_rfl, high le_rfl (le_of_not_ge hv₂)]

/-- The log of the stopped product is Lipschitz in log v on the positive range. -/
theorem log_iterLogProduct_sub_le {u v : ℝ} (hu : 1 ≤ u) (huv : u ≤ v) :
    Real.log (iterLogProduct v) - Real.log (iterLogProduct u) ≤
      2 * (Real.log v - Real.log u) := by
  rw [iterLogProduct_eq_truncated (v := v) le_rfl,
    iterLogProduct_eq_truncated (v := u) (Nat.ceil_mono huv)]
  exact log_truncatedLogProduct_sub_le _ hu huv

theorem iterLogProduct_div_le_ratio_sq {u v : ℝ} (hu : 1 ≤ u) (huv : u ≤ v) :
    iterLogProduct v / iterLogProduct u ≤ (v / u) ^ 2 := by
  have hpos (x : ℝ) : 0 < iterLogProduct x := zero_lt_one.trans_le (one_le_iterLogProduct x)
  have hu0 : 0 < u := zero_lt_one.trans_le hu
  have hv0 := hu0.trans_le huv
  apply (Real.log_le_log_iff (div_pos (hpos _) (hpos _)) (pow_pos (div_pos hv0 hu0) _)).mp
  rw [Real.log_pow, Real.log_div (hpos v).ne' (hpos u).ne', Real.log_div hv0.ne' hu0.ne']
  exact_mod_cast log_iterLogProduct_sub_le hu huv


/-- The cutoff scale as a function of L = log N. -/
@[expose] noncomputable def aliasScaleFromLog (L : ℝ) : ℝ :=
  L * Real.log L / iteratedLogA L

@[expose] noncomputable def aliasScale (N : ℝ) : ℝ := aliasScaleFromLog (Real.log N)

private theorem eventually_iteratedLogA_le_mul_log (d : ℝ) (hd : 0 < d) :
    ∀ᶠ L : ℝ in atTop, iteratedLogA L ≤ d * Real.log L := by
  have hb := (isLittleO_log_rpow_rpow_atTop (s := (1 : ℝ)) 2 (by norm_num)).bound hd
  have hl : Tendsto (fun L : ℝ => Real.log (Real.log L)) atTop atTop :=
    Real.tendsto_log_atTop.comp Real.tendsto_log_atTop
  filter_upwards [Real.tendsto_log_atTop.eventually hb, hl.eventually_ge_atTop 1,
    Real.tendsto_log_atTop.eventually_ge_atTop 1, eventually_iteratedLogA_bounds] with L hB hLL hLog hA
  have hLL' : 1 ≤ Real.log (Real.log L) := hLL
  have hsmall : Real.log (Real.log (Real.log L)) ≤ Real.log (Real.log L) :=
    (Real.log_le_sub_one_of_pos (zero_lt_one.trans_le hLL')).trans (sub_le_self _ zero_le_one)
  have hnonneg : 0 ≤ Real.log (Real.log (Real.log L)) := Real.log_nonneg hLL'
  have hBound : Real.log (Real.log L) ^ 2 ≤ d * Real.log L := by
    rw [show (2 : ℝ) = ((2 : ℕ) : ℝ) by norm_num, Real.rpow_natCast, Real.rpow_one,
      Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _),
      abs_of_nonneg (zero_le_one.trans hLog)] at hB
    exact hB
  exact hA.2.trans ((pow_le_pow_left₀ hnonneg hsmall 2).trans hBound)

private theorem eventually_scaledAlias_bounds (d : ℝ) (hd : 0 < d) :
    ∀ᶠ L : ℝ in atTop,
      L ≤ d * aliasScaleFromLog L ∧ d * aliasScaleFromLog L ≤ L * (d * Real.log L) := by
  filter_upwards [eventually_iteratedLogA_le_mul_log d hd, eventually_gt_atTop (1 : ℝ)] with L hA hL
  have hA₁ := one_le_iteratedLogA L
  have hA₀ : 0 < iteratedLogA L := zero_lt_one.trans_le hA₁
  have hL₀ : 0 < L := zero_lt_one.trans hL
  have hn : 0 ≤ L * (d * Real.log L) :=
    mul_nonneg hL₀.le (mul_nonneg hd.le (Real.log_pos hL).le)
  rw [aliasScaleFromLog, ← mul_div_assoc, show d * (L * Real.log L) = L * (d * Real.log L) by ring]
  exact ⟨(le_div_iff₀ hA₀).mpr (mul_le_mul_of_nonneg_left hA hL₀.le),
    div_le_self hn hA₁⟩

private theorem tendsto_log_scaledAlias_div_log (d : ℝ) (hd : 0 < d) :
    Tendsto (fun L : ℝ => Real.log (d * aliasScaleFromLog L) / Real.log L) atTop (𝓝 1) := by
  have hl : Tendsto (fun L : ℝ => Real.log (Real.log L) / Real.log L) atTop (𝓝 0) :=
    Real.isLittleO_log_id_atTop.tendsto_div_nhds_zero.comp Real.tendsto_log_atTop
  have hc : Tendsto (fun L : ℝ => Real.log d / Real.log L) atTop (𝓝 0) := by
    simpa only [div_eq_mul_inv, Pi.inv_apply, mul_zero] using
      Real.tendsto_log_atTop.inv_tendsto_atTop.const_mul (Real.log d)
  have hu : Tendsto (fun L : ℝ => 1 +
      (Real.log d + Real.log (Real.log L)) / Real.log L) atTop (𝓝 1) := by
    simpa only [← add_div, add_zero] using (tendsto_const_nhds (x := (1 : ℝ))).add (hc.add hl)
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds hu
  · filter_upwards [eventually_scaledAlias_bounds d hd, eventually_gt_atTop (1 : ℝ)] with L h hL
    have hpos := Real.log_pos hL
    apply (le_div_iff₀ hpos).mpr
    simpa only [one_mul] using Real.log_le_log (zero_lt_one.trans hL) h.1
  · filter_upwards [eventually_scaledAlias_bounds d hd, eventually_gt_atTop (1 : ℝ)] with L h hL
    have hpos := Real.log_pos hL
    have ht : 0 < d * aliasScaleFromLog L := (zero_lt_one.trans hL).trans_le h.1
    have hp := Real.log_le_log ht h.2
    rw [Real.log_mul (zero_lt_one.trans hL).ne' (mul_pos hd hpos).ne',
      Real.log_mul hd.ne' hpos.ne'] at hp
    have he : (Real.log L + (Real.log d + Real.log (Real.log L))) / Real.log L =
        1 + (Real.log d + Real.log (Real.log L)) / Real.log L := by
      rw [add_div, div_self hpos.ne']
    rw [← he]
    exact div_le_div_of_nonneg_right hp hpos.le

private theorem tendsto_loglog_scaledAlias_div_loglog (d : ℝ) (hd : 0 < d) :
    Tendsto (fun L : ℝ => Real.log (Real.log (d * aliasScaleFromLog L)) /
      Real.log (Real.log L)) atTop (𝓝 1) := by
  have hlog := (tendsto_log_scaledAlias_div_log d hd).log (by norm_num : (1 : ℝ) ≠ 0)
  rw [Real.log_one] at hlog
  have hi : Tendsto (fun L : ℝ => (Real.log (Real.log L))⁻¹) atTop (𝓝 0) :=
    (Real.tendsto_log_atTop.comp Real.tendsto_log_atTop).inv_tendsto_atTop
  have hresult := (tendsto_const_nhds (x := (1 : ℝ))).add (hlog.mul hi)
  simp only [mul_zero, add_zero] at hresult
  refine hresult.congr' ?_
  filter_upwards [eventually_scaledAlias_bounds d hd,
    Real.tendsto_log_atTop.eventually_gt_atTop 1, eventually_gt_atTop (1 : ℝ)] with L h hLL hL
  have hLpos : 0 < Real.log L := zero_lt_one.trans hLL
  have hm := Real.log_le_log (zero_lt_one.trans hL) h.1
  have ht : 0 < Real.log (d * aliasScaleFromLog L) := hLpos.trans_le hm
  have hden := (Real.log_pos hLL).ne'
  rw [Real.log_div ht.ne' hLpos.ne']
  field_simp
  ring

private theorem tendsto_iteratedLogA_scaledAlias_ratio (d : ℝ) (hd : 0 < d) :
    Tendsto (fun L : ℝ => iteratedLogA (d * aliasScaleFromLog L) / iteratedLogA L) atTop (𝓝 1) := by
  have hu := (tendsto_loglog_scaledAlias_div_loglog d hd).pow 2
  rw [one_pow] at hu
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds hu
  · filter_upwards [eventually_scaledAlias_bounds d hd] with L h
    apply (le_div_iff₀ (zero_lt_one.trans_le (one_le_iteratedLogA L))).mpr
    simpa only [one_mul] using monotone_iteratedLogA h.1
  · have hloglog : Tendsto (fun L : ℝ => Real.log (Real.log L)) atTop atTop :=
      Real.tendsto_log_atTop.comp Real.tendsto_log_atTop
    filter_upwards [eventually_scaledAlias_bounds d hd, eventually_ge_atTop scaleStart,
      hloglog.eventually_ge_atTop 1, Real.tendsto_log_atTop.eventually_gt_atTop 1,
      eventually_gt_atTop (1 : ℝ)] with L h hL hLL hLog hOne
    rw [iteratedLogA_eq hL, iteratedLogA_eq (hL.trans h.1)]
    have hmono := Real.log_le_log (zero_lt_one.trans hOne) h.1
    exact iterLogProduct_div_le_ratio_sq hLL (Real.log_le_log (zero_lt_one.trans hLog) hmono)

/-- V2 slow variation: B(d Q_*)/(d log N) tends to one for every fixed d > 0. -/
theorem tendsto_iteratedLogB_aliasScale (d : ℝ) (hd : 0 < d) :
    Tendsto (fun N : ℝ => iteratedLogB (d * aliasScale N) / (d * Real.log N)) atTop (𝓝 1) := by
  have h := ((tendsto_log_scaledAlias_div_log d hd).inv₀ (by norm_num)).mul
    (tendsto_iteratedLogA_scaledAlias_ratio d hd)
  simp only [inv_one, mul_one] at h
  have h' : Tendsto (fun L : ℝ =>
      iteratedLogB (d * aliasScaleFromLog L) / (d * L)) atTop (𝓝 1) := by
    refine h.congr' ?_
    filter_upwards [eventually_scaledAlias_bounds d hd, eventually_ge_atTop scaleStart,
      eventually_gt_atTop (1 : ℝ)] with L hbound hL hOne
    have hLpos : 0 < L := zero_lt_one.trans hOne
    have hLog := Real.log_pos hOne
    have hlogt : 0 < Real.log (d * aliasScaleFromLog L) :=
      hLog.trans_le (Real.log_le_log hLpos hbound.1)
    have hA : iteratedLogA L ≠ 0 := (zero_lt_one.trans_le (one_le_iteratedLogA L)).ne'
    rw [iteratedLogB_eq (hL.trans hbound.1)]
    field_simp [hLog.ne', hlogt.ne', hLpos.ne', hd.ne', hA]
    rw [aliasScaleFromLog]
    field_simp
  exact h'.comp Real.tendsto_log_atTop


theorem eventually_scaled_aliasScale_bounds (d : ℝ) (hd : 0 < d) :
    ∀ᶠ N : ℝ in atTop, Real.log N ≤ d * aliasScale N ∧ d * aliasScale N ≤ (Real.log N) ^ 2 := by
  have hs := Real.isLittleO_log_id_atTop.bound (one_div_pos.mpr hd)
  have hL : ∀ᶠ L : ℝ in atTop,
      L ≤ d * aliasScaleFromLog L ∧ d * aliasScaleFromLog L ≤ L ^ 2 := by
    filter_upwards [eventually_scaledAlias_bounds d hd, hs, eventually_gt_atTop (1 : ℝ)] with L ht hs h1
    have hp := zero_lt_one.trans h1
    have hlog := Real.log_pos h1
    have hh : Real.log L ≤ (1 / d) * L := by
      simpa only [Real.norm_eq_abs, id_eq, abs_of_nonneg hlog.le, abs_of_nonneg hp.le] using hs
    have hm : d * Real.log L ≤ L := by
      rw [one_div, ← div_eq_inv_mul, le_div_iff₀ hd] at hh
      linarith
    exact ⟨ht.1, ht.2.trans (by rw [pow_two]; exact mul_le_mul_of_nonneg_left hm hp.le)⟩
  exact Real.tendsto_log_atTop.eventually hL


private theorem tendsto_shifted_loglog_ratio_sq (c : ℝ) :
    Tendsto (fun L : ℝ => ((Real.log (Real.log L) + c) / Real.log (Real.log L)) ^ 2)
      atTop (𝓝 1) := by
  have hW : Tendsto (fun L : ℝ => Real.log (Real.log L)) atTop atTop :=
    Real.tendsto_log_atTop.comp Real.tendsto_log_atTop
  have h := ((tendsto_const_nhds (x := (1 : ℝ))).add (hW.inv_tendsto_atTop.const_mul c)).pow 2
  simp only [mul_zero, add_zero, one_pow] at h
  refine h.congr' ?_
  filter_upwards [hW.eventually_gt_atTop 0] with L hL
  congr 1
  rw [add_div, div_self hL.ne', div_eq_mul_inv, Pi.inv_apply]

/-- The ratio in V2 tends to one uniformly over the entire window [L/2,L²]. -/
theorem eventually_iteratedLogA_ratio_close_on_window (ε : ℝ) (hε : 0 < ε) :
    ∀ᶠ L : ℝ in atTop, ∀ t : ℝ, L / 2 ≤ t → t ≤ L ^ 2 →
      |iteratedLogA t / iteratedLogA L - 1| ≤ ε := by
  have hW : Tendsto (fun L : ℝ => Real.log (Real.log L)) atTop atTop :=
    Real.tendsto_log_atTop.comp Real.tendsto_log_atTop
  have hPow : Tendsto (fun L : ℝ => L ^ (1 / 2 : ℝ)) atTop atTop :=
    tendsto_rpow_atTop (by norm_num)
  filter_upwards [eventually_ge_atTop (4 : ℝ), eventually_ge_atTop scaleStart,
    hPow.eventually_ge_atTop scaleStart, hW.eventually_ge_atTop (1 + Real.log 2),
    (tendsto_shifted_loglog_ratio_sq (-Real.log 2)).eventually_const_lt
      (show 1 - ε < 1 by linarith),
    (tendsto_shifted_loglog_ratio_sq (Real.log 2)).eventually_lt_const
      (show 1 < 1 + ε by linarith)] with L hL hBase hLower hW hMinus hPlus
  intro t ht₁ ht₂
  let w := Real.log (Real.log L)
  let u := w - Real.log 2
  let v := w + Real.log 2
  have hL₁ : 1 < L := by linarith
  have hL₀ := zero_lt_one.trans hL₁
  have hLogL := Real.log_pos hL₁
  have hLog2 : 0 ≤ Real.log 2 := Real.log_nonneg (by norm_num)
  have hu : 1 ≤ u := by dsimp [u,w]; linarith
  have huw : u ≤ w := sub_le_self _ hLog2
  have hwv : w ≤ v := le_add_of_nonneg_right hLog2
  have hw := hu.trans huw
  have hLhalf : L ^ (1 / 2 : ℝ) ≤ L / 2 := by
    rw [← Real.sqrt_eq_rpow]
    have hs : (2 : ℝ) ≤ √L := (Real.le_sqrt (by norm_num) hL₀.le).mpr (by norm_num; exact hL)
    apply (le_div_iff₀ (by norm_num)).mpr
    calc
      _ ≤ √L * √L := mul_le_mul_of_nonneg_left hs (Real.sqrt_nonneg L)
      _ = L := Real.mul_self_sqrt hL₀.le
  have hLt₀ := (zero_lt_one.trans_le (one_le_iterLogProduct u))
  have hw₀ := zero_lt_one.trans_le hw
  have hu₀ := zero_lt_one.trans_le hu
  have hPL : 0 < iterLogProduct w := zero_lt_one.trans_le (one_le_iterLogProduct w)
  have hLowerEq : iteratedLogA (L ^ (1 / 2 : ℝ)) = iterLogProduct u := by
    rw [iteratedLogA_eq hLower, Real.log_rpow hL₀, Real.log_mul (by norm_num) hLogL.ne']
    congr 1
    change Real.log (1 / 2 : ℝ) + w = u
    rw [Real.log_div (by norm_num) (by norm_num), Real.log_one]
    dsimp only [u]
    ring
  have hBaseEq : iteratedLogA L = iterLogProduct w := iteratedLogA_eq hBase
  have hUpperEq : iteratedLogA (L ^ 2) = iterLogProduct v := by
    rw [iteratedLogA_eq (hBase.trans (by nlinarith only [mul_nonneg hL₀.le (sub_nonneg.mpr hL₁.le)])),
      Real.log_pow, Real.log_mul (by norm_num) hLogL.ne']
    congr 1
    change Real.log 2 + w = v
    exact add_comm _ _
  have hLowerRatio : (u / w) ^ 2 ≤ iterLogProduct u / iterLogProduct w := by
    have h := (div_le_iff₀ hLt₀).mp (iterLogProduct_div_le_ratio_sq hu huw)
    apply (le_div_iff₀ hPL).mpr
    calc
      _ ≤ (u / w) ^ 2 * ((w / u) ^ 2 * iterLogProduct u) :=
        mul_le_mul_of_nonneg_left h (sq_nonneg _)
      _ = _ := by field_simp [hu₀.ne', hw₀.ne']
  have hLower' : 1 - ε ≤ (u / w) ^ 2 := by
    change 1 - ε < ((w + -Real.log 2) / w) ^ 2 at hMinus
    simpa only [u, sub_eq_add_neg] using hMinus.le
  have hUpper' : (v / w) ^ 2 ≤ 1 + ε := hPlus.le
  have hRatioLo : 1 - ε ≤ iteratedLogA t / iteratedLogA L := calc
    _ ≤ (u / w) ^ 2 := hLower'
    _ ≤ iterLogProduct u / iterLogProduct w := hLowerRatio
    _ ≤ _ := by
      rw [← hLowerEq, ← hBaseEq]
      exact div_le_div_of_nonneg_right (monotone_iteratedLogA (hLhalf.trans ht₁))
        (zero_le_one.trans (one_le_iteratedLogA L))
  have hRatioHi : iteratedLogA t / iteratedLogA L ≤ 1 + ε := calc
    _ ≤ iteratedLogA (L ^ 2) / iteratedLogA L :=
      div_le_div_of_nonneg_right (monotone_iteratedLogA ht₂) (zero_le_one.trans (one_le_iteratedLogA L))
    _ ≤ (v / w) ^ 2 := by rw [hUpperEq,hBaseEq]; exact iterLogProduct_div_le_ratio_sq hw hwv
    _ ≤ _ := hUpper'
  exact abs_le.mpr ⟨by linarith only [hRatioLo],by linarith only [hRatioHi]⟩

/-- The scale Q_* dominates L = log N. -/
theorem isLittleO_log_aliasScale : Real.log =o[atTop] aliasScale := by
  refine isLittleO_iff.2 fun ε hε => ?_
  filter_upwards [Real.tendsto_log_atTop.eventually (eventually_iteratedLogA_le_mul_log ε hε),
    Real.tendsto_log_atTop.eventually_gt_atTop 1] with N hA hL
  let L := Real.log N
  have hL₀ : 0 < L := zero_lt_one.trans hL
  have hU := Real.log_pos hL
  have hDen := zero_lt_one.trans_le (one_le_iteratedLogA L)
  have hQ : 0 ≤ aliasScale N := div_nonneg (mul_nonneg hL₀.le hU.le) hDen.le
  rw [Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg hL₀.le, abs_of_nonneg hQ]
  change L ≤ ε * (L * Real.log L / iteratedLogA L)
  rw [← mul_div_assoc]
  apply (le_div_iff₀ hDen).mpr
  have h := mul_le_mul_of_nonneg_left hA hL₀.le
  linarith only [h]

/-- The scale Q_* grows more slowly than L². -/
theorem isLittleO_aliasScale_log_sq : aliasScale =o[atTop] (fun N : ℝ => Real.log N ^ 2) := by
  refine isLittleO_iff.2 fun ε hε => ?_
  filter_upwards [Real.tendsto_log_atTop.eventually (Real.isLittleO_log_id_atTop.bound hε),
    Real.tendsto_log_atTop.eventually_gt_atTop 1] with N hA hL
  let L := Real.log N
  have hL₀ : 0 < L := zero_lt_one.trans hL
  have hU := Real.log_pos hL
  have hDen := one_le_iteratedLogA L
  have hQ : 0 ≤ aliasScale N :=
    div_nonneg (mul_nonneg hL₀.le hU.le) (zero_le_one.trans hDen)
  change ‖Real.log L‖ ≤ ε * ‖L‖ at hA
  rw [Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg hU.le, abs_of_nonneg hL₀.le] at hA
  rw [Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg hQ, abs_of_nonneg (sq_nonneg _)]
  change L * Real.log L / iteratedLogA L ≤ ε * L ^ 2
  calc
    _ ≤ L * Real.log L := div_le_self (mul_nonneg hL₀.le hU.le) hDen
    _ ≤ L * (ε * L) := mul_le_mul_of_nonneg_left hA hL₀.le
    _ = _ := by ring

end LeanAB.PaperA
