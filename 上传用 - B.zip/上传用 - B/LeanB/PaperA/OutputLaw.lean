module

public import PaperA.Decode
public import PaperA.FiniteEntropy
public import Mathlib.Probability.ProbabilityMassFunction.Integrals
public import Mathlib.MeasureTheory.Constructions.Pi
import Mathlib.Probability.ProbabilityMassFunction.Constructions
import Mathlib.Tactic

@[expose] public section

/-! The finite output law of a uniformly sampled reciprocal-sum configuration. -/

namespace LeanAB.PaperA

open MeasureTheory ProbabilityTheory
open scoped BigOperators ENNReal

namespace FiniteLaw

variable {Ω : Type*} [Fintype Ω]

noncomputable def toPMF (P : FiniteLaw Ω) : PMF Ω :=
  PMF.ofFintype (fun x => ENNReal.ofReal (P.weight x)) (by
    rw [← ENNReal.ofReal_sum_of_nonneg (fun x _ => (P.positive x).le),
      P.sum_weight, ENNReal.ofReal_one])

@[simp]
theorem toPMF_apply (P : FiniteLaw Ω) (x : Ω) :
    P.toPMF x = ENNReal.ofReal (P.weight x) := by simp [toPMF]

noncomputable def measure [MeasurableSpace Ω] (P : FiniteLaw Ω) : Measure Ω :=
  P.toPMF.toMeasure

instance [MeasurableSpace Ω] (P : FiniteLaw Ω) : IsProbabilityMeasure P.measure :=
  inferInstanceAs (IsProbabilityMeasure P.toPMF.toMeasure)

theorem measure_singleton [MeasurableSpace Ω] [MeasurableSingletonClass Ω]
    (P : FiniteLaw Ω) (x : Ω) : P.measure {x} = ENNReal.ofReal (P.weight x) := by
  rw [measure, PMF.toMeasure_apply_singleton _ _ (measurableSet_singleton _), toPMF_apply]

theorem measureReal_finset [MeasurableSpace Ω] [MeasurableSingletonClass Ω]
    (P : FiniteLaw Ω) (s : Finset Ω) : P.measure.real s = ∑ x ∈ s, P.weight x := by
  rw [measure, measureReal_def, PMF.toMeasure_apply_finset]
  simp_rw [toPMF_apply, ← ENNReal.ofReal_sum_of_nonneg (fun x _ => (P.positive x).le),
    ENNReal.toReal_ofReal (Finset.sum_nonneg fun x _ => (P.positive x).le)]

theorem integral_information [MeasurableSpace Ω] [DiscreteMeasurableSpace Ω]
    (P : FiniteLaw Ω) : ∫ x, P.information x ∂P.measure = P.shannon := by
  rw [measure, PMF.integral_eq_sum]
  simp [shannon, smul_eq_mul, ENNReal.toReal_ofReal, (P.positive _).le]

/-- The contribution of atoms with information above log support size plus t. -/
theorem information_tail [MeasurableSpace Ω] [MeasurableSingletonClass Ω]
    (P : FiniteLaw Ω) {t : ℝ} :
    P.measure.real {x | P.hartley + t < P.information x} ≤ Real.exp (-t) := by
  classical
  let _ := P.nonempty
  let s := Finset.univ.filter (fun x => P.hartley + t < P.information x)
  have hs : (↑s : Set Ω) = {x | P.hartley + t < P.information x} := by
    ext x
    simp [s]
  have hcard : (0 : ℝ) < Fintype.card Ω := by
    exact_mod_cast (Fintype.card_pos : 0 < Fintype.card Ω)
  have hcoef (x : Ω) (hx : x ∈ s) : P.weight x ≤ Real.exp (-t) / Fintype.card Ω := by
    have hh := (Finset.mem_filter.mp hx).2
    change Real.log (Fintype.card Ω : ℝ) + t < -Real.log (P.weight x) at hh
    have h := Real.exp_lt_exp.mpr (show Real.log (P.weight x) <
      -t - Real.log (Fintype.card Ω : ℝ) by linarith)
    rw [Real.exp_log (P.positive x), Real.exp_sub, Real.exp_log hcard] at h
    exact h.le
  rw [← hs, measureReal_finset]
  calc
    _ ≤ ∑ _x ∈ s, Real.exp (-t) / (Fintype.card Ω : ℝ) :=
      Finset.sum_le_sum hcoef
    _ = (s.card : ℝ) * (Real.exp (-t) / (Fintype.card Ω : ℝ)) := by simp
    _ ≤ Fintype.card Ω * (Real.exp (-t) / (Fintype.card Ω : ℝ)) := by
      exact mul_le_mul_of_nonneg_right (by exact_mod_cast Finset.card_le_univ s) (by positivity)
    _ = _ := by field_simp


theorem measure_transport {Ξ : Type*} [Fintype Ξ] [MeasurableSpace Ω] [MeasurableSpace Ξ]
    [DiscreteMeasurableSpace Ω] [DiscreteMeasurableSpace Ξ]
    (P : FiniteLaw Ω) (e : Ω ≃ Ξ) : (P.transport e).measure = P.measure.map e := by
  have he : Measurable e := Measurable.of_discrete
  apply Measure.ext_of_singleton
  intro x
  rw [measure_singleton, weight_transport, Measure.map_apply he (measurableSet_singleton _)]
  have hs : e ⁻¹' ({x} : Set Ξ) = {e.symm x} := by
    ext z
    exact e.eq_symm_apply.symm
  rw [hs, measure_singleton]

theorem measure_pi {ι : Type*} {α : ι → Type*} [Fintype ι] [DecidableEq ι] [∀ i, Fintype (α i)]
    [∀ i, MeasurableSpace (α i)] [∀ i, MeasurableSingletonClass (α i)]
    (P : ∀ i, FiniteLaw (α i)) : (FiniteLaw.pi P).measure = Measure.pi (fun i => (P i).measure) := by
  apply Measure.ext_of_singleton
  intro x
  rw [measure_singleton, weight_pi, Measure.pi_singleton, ENNReal.ofReal_prod_of_nonneg]
  · simp_rw [measure_singleton]
  · exact fun i _ => ((P i).positive _).le

end FiniteLaw

/-- A vector in the actual positive support of the output law. -/
def Output (E : Finset ℕ) (m : ℕ) : Type := support E m

noncomputable instance outputFintype (E : Finset ℕ) (m : ℕ) : Fintype (Output E m) :=
  (Set.finite_range (value E m)).fintype

instance outputMeasurableSpace (E : Finset ℕ) (m : ℕ) : MeasurableSpace (Output E m) := ⊤

instance outputDiscrete (E : Finset ℕ) (m : ℕ) : DiscreteMeasurableSpace (Output E m) :=
  ⟨fun _ => trivial⟩

def sampleOutput (E : Finset ℕ) (m : ℕ) (c : Configuration E m) : Output E m :=
  ⟨value E m c, ⟨c, rfl⟩⟩

/-- Uniform probability of an event in the configuration space. -/
noncomputable def configurationEventProbability (E : Finset ℕ) (m : ℕ)
    (P : Configuration E m → Prop) : ℝ :=
  (Nat.card {c : Configuration E m // P c} : ℝ) / (((m + 1) ^ E.card : ℕ) : ℝ)

private theorem configuration_count_pos (E : Finset ℕ) (m : ℕ) :
    0 < (m + 1) ^ E.card :=
  pow_pos (Nat.succ_pos _) _

private theorem sampleOutput_eq_iff {E : Finset ℕ} {m : ℕ}
    (cfg : Configuration E m) (x : Output E m) :
    sampleOutput E m cfg = x ↔ value E m cfg = x.val :=
  Subtype.ext_iff

private theorem sum_fiber_card_eq_event_card (E : Finset ℕ) (m : ℕ)
    (s : Finset (Output E m)) :
    ∑ x ∈ s, Nat.card (Fiber E m x.val) =
      Nat.card {c : Configuration E m // sampleOutput E m c ∈ s} := by
  classical
  have hs := Finset.card_eq_sum_card_fiberwise
    (s := Finset.univ.filter fun c => sampleOutput E m c ∈ s) (t := s)
    (f := sampleOutput E m) (fun _ hc => (Finset.mem_filter.mp hc).2)
  rw [Nat.card_eq_fintype_card, Fintype.card_subtype, hs]
  apply Finset.sum_congr rfl
  intro x hx
  rw [Nat.card_eq_fintype_card, Fintype.card_subtype]
  congr 1
  ext c
  simp [sampleOutput_eq_iff]
  intro h
  simpa only [(sampleOutput_eq_iff c x).mpr h] using hx

theorem fiber_card_pos_of_output {E : Finset ℕ} {m : ℕ} (x : Output E m) :
    0 < Nat.card (Fiber E m x.val) := by
  obtain ⟨cfg, hc⟩ := x.property
  let _ : Nonempty (Fiber E m x.val) := ⟨⟨cfg, hc⟩⟩
  exact Nat.card_pos

theorem cast_probability (E : Finset ℕ) (m : ℕ) (x : Fin m → ℚ) :
    (probability E m x : ℝ) =
      (Nat.card (Fiber E m x) : ℝ) / (((m + 1) ^ E.card : ℕ) : ℝ) := by
  simp only [probability, Rat.cast_div, Rat.cast_natCast]

noncomputable def configurationLaw (E : Finset ℕ) (m : ℕ) : FiniteLaw (Output E m) where
  weight x := (probability E m x.val : ℝ)
  positive x := by
    rw [cast_probability]
    exact div_pos (by exact_mod_cast fiber_card_pos_of_output x)
      (by exact_mod_cast configuration_count_pos E m)
  sum_weight := by
    simp_rw [cast_probability]
    rw [← Finset.sum_div, ← Nat.cast_sum, sum_fiber_card_eq_event_card]
    have hc : Nat.card {c : Configuration E m // sampleOutput E m c ∈ Finset.univ} =
        Nat.card (Configuration E m) := by
      exact Nat.card_congr (Equiv.subtypeUnivEquiv fun _ => Finset.mem_univ _)
    rw [hc, card_configuration, div_self]
    exact Nat.cast_ne_zero.mpr (configuration_count_pos E m).ne'

@[simp]
theorem configurationLaw_weight (E : Finset ℕ) (m : ℕ) (x : Output E m) :
    (configurationLaw E m).weight x = (probability E m x.val : ℝ) := rfl

/-- The mass of an output event is exactly its proportion of sampled configurations. -/
theorem configurationEvent_eq_measure (E : Finset ℕ) (m : ℕ) (s : Set (Output E m)) :
    configurationEventProbability E m (fun cfg => sampleOutput E m cfg ∈ s) =
      (configurationLaw E m).measure.real s := by
  classical
  let t := Finset.univ.filter (fun x => x ∈ s)
  have ht : (↑t : Set (Output E m)) = s := by ext x; simp [t]
  rw [← ht, FiniteLaw.measureReal_finset]
  simp_rw [configurationLaw_weight, cast_probability]
  rw [← Finset.sum_div, ← Nat.cast_sum, sum_fiber_card_eq_event_card]
  rfl

theorem configurationLaw_information (E : Finset ℕ) (m : ℕ) (x : Output E m) :
    (configurationLaw E m).information x =
      (E.card : ℝ) * Real.log (m + 1) - Real.log (Nat.card (Fiber E m x.val)) := by
  unfold FiniteLaw.information
  rw [configurationLaw_weight, cast_probability,
    Real.log_div (by exact_mod_cast (fiber_card_pos_of_output x).ne')
      (by exact_mod_cast (configuration_count_pos E m).ne')]
  push_cast
  rw [Real.log_pow]
  ring

theorem configurationLaw_information_le (E : Finset ℕ) (m : ℕ) (x : Output E m) :
    (configurationLaw E m).information x ≤ E.card * Real.log (m + 1) := by
  rw [configurationLaw_information]
  exact sub_le_self _ (Real.log_nonneg (by exact_mod_cast fiber_card_pos_of_output x))

end LeanAB.PaperA
