module

public import PaperA.IntegralScale
public import PaperA.RelativeGap
public import PaperA.IntegralRecurrence
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Tactic

public section

/-! Conversion of the truncated BGMS input into the common entropy comparison scale. -/

namespace LeanAB.PaperA

open Filter Function
open scoped BigOperators Topology

private theorem ceil_clippedLog_lt_of_three_le {x : ℝ} (hx : 3 ≤ x) :
    ⌈clippedLog x⌉₊ < ⌈x⌉₊ := by
  have hx0 : 0 < x := by linarith
  have hh := Nat.ceil_mono (show Real.log x + 1 ≤ x by
    linarith only [Real.log_le_sub_one_of_pos hx0])
  have hlog0 := Real.log_nonneg ((show (1 : ℝ) ≤ 3 by norm_num).trans hx)
  rw [Nat.ceil_add_one hlog0] at hh
  rw [clippedLog_eq_log (Real.exp_one_lt_three.le.trans hx)]
  omega

private theorem exists_iterate_below_three (v : ℝ) : ∃ k, (clippedLog^[k]) v < 3 := by
  by_contra! h
  have hceil (k : ℕ) : ⌈(clippedLog^[k]) v⌉₊ + k ≤ ⌈v⌉₊ := by
    induction k with
    | zero => rfl
    | succ k ih =>
      rw [Function.iterate_succ_apply']
      have hlt := ceil_clippedLog_lt_of_three_le (h k)
      omega
  have hbad := hceil (⌈v⌉₊ + 1)
  omega

private theorem iterLogProduct_split (v : ℝ) (k : ℕ) :
    iterLogProduct v = truncatedLogProduct k v * iterLogProduct ((clippedLog^[k]) v) := by
  induction k generalizing v with
  | zero => simp [truncatedLogProduct]
  | succ k ih =>
    rw [iterLogProduct_eq_step v, ih (clippedLog v), truncatedLogProduct,
      Function.iterate_succ_apply]
    ring

private theorem truncatedLogProduct_eq_prod (v : ℝ) (k : ℕ) :
    truncatedLogProduct k v = ∏ j ∈ Finset.range k, (clippedLog^[j + 1]) v := by
  induction k generalizing v with
  | zero => simp [truncatedLogProduct]
  | succ k ih =>
    rw [truncatedLogProduct, ih, Finset.prod_range_succ', mul_comm]
    simp only [zero_add, Function.iterate_one]
    congr 1

private theorem iterLogProduct_truncated (v : ℝ) (hv₀ : 3 ≤ v)
    (hv₁ : 3 ≤ Real.log v) (hv₂ : 3 ≤ Real.log (Real.log v)) :
    ∃ k ≥ 2, (∀ j ≤ k, 3 ≤ (Real.log^[j]) v) ∧
      iterLogProduct v ≤ (∏ j ∈ Finset.range k, (Real.log^[j + 1]) v) * (3 * Real.log 3) := by
  classical
  have hExist := exists_iterate_below_three v
  let d := Nat.find hExist
  have hd₃ : 3 ≤ d := by
    by_contra! h
    have hlt : (clippedLog^[d]) v < 3 := Nat.find_spec hExist
    have hGe : 3 ≤ (clippedLog^[d]) v := by
      interval_cases d
      · exact hv₀
      · simp only [Function.iterate_one]
        rwa [clippedLog_eq_log (Real.exp_one_lt_three.le.trans hv₀)]
      · change 3 ≤ clippedLog (clippedLog v)
        rwa [clippedLog_eq_log (Real.exp_one_lt_three.le.trans hv₀),
          clippedLog_eq_log (Real.exp_one_lt_three.le.trans hv₁)]
    exact hlt.not_ge hGe
  let k := d - 1
  have hkd : k + 1 = d := by dsimp only [k]; omega
  have hk₂ : 2 ≤ k := by omega
  have hBefore (j : ℕ) (hj : j ≤ k) : 3 ≤ (clippedLog^[j]) v :=
    le_of_not_gt (Nat.find_min hExist (by omega : j < d))
  have hAt (j : ℕ) (hj : j ≤ k) : (clippedLog^[j]) v = (Real.log^[j]) v := by
    induction j with
    | zero => rfl
    | succ j ih =>
      rw [Function.iterate_succ_apply', Function.iterate_succ_apply',
        clippedLog_eq_log (Real.exp_one_lt_three.le.trans (hBefore j (by omega))), ih (by omega)]
  refine ⟨k, hk₂, fun j hj => (hAt j hj) ▸ hBefore j hj, ?_⟩
  have hNext : clippedLog ((clippedLog^[k]) v) < 3 := by
    calc
      _ = (clippedLog^[k + 1]) v := (Function.iterate_succ_apply' clippedLog k v).symm
      _ < 3 := hkd ▸ (Nat.find_spec hExist)
  have htail : iterLogProduct ((clippedLog^[k]) v) ≤ 3 * Real.log 3 := by
    have hLog : Real.log 3 ≤ Real.exp 1 := by
      apply (Real.log_le_iff_le_exp (by norm_num : (0 : ℝ) < 3)).mpr
      exact (show (3 : ℝ) ≤ Real.exp 2 by linarith [Real.add_one_le_exp (2 : ℝ)]).trans
        (Real.exp_le_exp.mpr Real.exp_one_gt_two.le)
    calc
      _ = clippedLog ((clippedLog^[k]) v) * iterLogProduct (clippedLog ((clippedLog^[k]) v)) :=
        iterLogProduct_eq_step _
      _ ≤ 3 * iterLogProduct 3 := mul_le_mul hNext.le (monotone_iterLogProduct hNext.le)
        (zero_le_one.trans (one_le_iterLogProduct _)) (by norm_num)
      _ = _ := by
        rw [iterLogProduct_eq_log_mul Real.exp_one_lt_three.le, iterLogProduct_eq_one hLog, mul_one]
  have hprod : truncatedLogProduct k v = ∏ j ∈ Finset.range k, (Real.log^[j + 1]) v := by
    rw [truncatedLogProduct_eq_prod]
    exact Finset.prod_congr rfl fun j hj => hAt (j + 1) (Nat.succ_le_of_lt (Finset.mem_range.mp hj))
  rw [iterLogProduct_split v k]
  exact (mul_le_mul_of_nonneg_left htail (zero_le_one.trans (one_le_truncatedLogProduct k v))).trans_eq
    (congrArg (fun x => x * (3 * Real.log 3)) hprod)

private theorem prod_Icc_three (f : ℕ → ℝ) (k : ℕ) :
    (∏ j ∈ Finset.Icc 3 (k + 2), f j) = ∏ j ∈ Finset.range k, f (j + 3) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [show k.succ + 2 = (k + 2) + 1 by omega, Finset.prod_Icc_succ_top (by omega),
      ih, Finset.prod_range_succ]

/-- The explicit truncated lower-bound input quoted from BGMS in V2 lines 193–198. -/
@[expose] def BGMSTruncatedLowerBound (g : ℕ → ℝ) : Prop :=
  ∀ n k : ℕ, 4 ≤ k → (∀ j ≤ k, 0 < (Real.log^[j]) (n : ℝ)) →
    (3 / 2 : ℝ) ≤ (Real.log^[k]) (n : ℝ) →
    Real.log 2 * (2 - 3 / (Real.log^[k]) (n : ℝ)) * ((n : ℝ) / Real.log n) *
      (∏ j ∈ Finset.Icc 3 k, (Real.log^[j]) (n : ℝ)) ≤ g n

/-- The BGMS input gives the lower bound by the full scale, with the exact omitted-factor bound. -/
theorem eventually_iteratedLogB_le_of_BGMS {g : ℕ → ℝ} (hBGMS : BGMSTruncatedLowerBound g) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ n : ℕ in atTop, c * iteratedLogB n ≤ g n := by
  have hlog₂ : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hlog₃ : 0 < Real.log 3 := Real.log_pos (by norm_num)
  let D := 3 * Real.log 3
  have hD : 0 < D := by dsimp only [D]; positivity
  refine ⟨Real.log 2 / D, div_pos hlog₂ hD, ?_⟩
  have hcast : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have h₁ := Real.tendsto_log_atTop.comp hcast
  have h₂ := Real.tendsto_log_atTop.comp h₁
  have h₃ := Real.tendsto_log_atTop.comp h₂
  have h₄ := Real.tendsto_log_atTop.comp h₃
  filter_upwards [hcast.eventually_ge_atTop scaleStart, h₂.eventually_ge_atTop 3,
    h₃.eventually_ge_atTop 3, h₄.eventually_ge_atTop 3] with n hn hv₀ hv₁ hv₂
  let v := Real.log (Real.log (n : ℝ))
  have hShift (j : ℕ) : (Real.log^[j]) v = (Real.log^[j + 2]) (n : ℝ) := by
    rw [Function.iterate_add_apply]
    rfl
  obtain ⟨k, hk₂, hk₃, hTrunc⟩ := iterLogProduct_truncated v hv₀ hv₁ hv₂
  let S := ∏ j ∈ Finset.Icc 3 (k + 2), (Real.log^[j]) (n : ℝ)
  have hS : S = ∏ j ∈ Finset.range k, (Real.log^[j + 1]) v := by
    dsimp only [S]
    rw [prod_Icc_three]
    exact Finset.prod_congr rfl fun j _ => (hShift (j + 1)).symm
  have hA : iteratedLogA n ≤ S * D := by
    rw [iteratedLogA_eq hn, hS]
    exact hTrunc
  have hS₀ : 0 ≤ S := by
    by_contra! h
    have hp := (one_le_iteratedLogA n).trans (hA.trans (mul_nonpos_of_nonpos_of_nonneg h.le hD.le))
    norm_num at hp
  have htail : 3 ≤ (Real.log^[k + 2]) (n : ℝ) := hShift k ▸ hk₃ k le_rfl
  have hCoef : 1 ≤ 2 - 3 / (Real.log^[k + 2]) (n : ℝ) := by
    have hPos : 0 < (Real.log^[k + 2]) (n : ℝ) := by linarith
    have h := (div_le_iff₀ hPos).mpr (show (3 : ℝ) ≤ 1 * (Real.log^[k + 2]) (n : ℝ) by linarith)
    linarith
  have hn₂ : (2 : ℝ) < n := Real.exp_one_gt_two.trans_le (exp_one_le_scaleStart.trans hn)
  have hlogn : 0 < Real.log (n : ℝ) := Real.log_pos ((by norm_num : (1 : ℝ) < 2).trans hn₂)
  have hDefined (j : ℕ) (hj : j ≤ k + 2) : 0 < (Real.log^[j]) (n : ℝ) := by
    by_cases hj₂ : 2 ≤ j
    · have hEq : j - 2 + 2 = j := by omega
      rw [← hEq, ← hShift]
      linarith only [hk₃ (j - 2) (by omega)]
    · interval_cases j
      · exact (zero_lt_two.trans hn₂)
      · exact hlogn
  have hq : 0 ≤ (n : ℝ) / Real.log n := div_nonneg (Nat.cast_nonneg _) hlogn.le
  calc
    _ = (Real.log 2 * ((n : ℝ) / Real.log n)) * (iteratedLogA n / D) := by
      rw [iteratedLogB_eq hn]
      ring
    _ ≤ Real.log 2 * ((n : ℝ) / Real.log n) * S :=
      mul_le_mul_of_nonneg_left ((div_le_iff₀ hD).mpr hA) (mul_nonneg hlog₂.le hq)
    _ ≤ _ := calc
      _ = Real.log 2 * (1 : ℝ) * ((n : ℝ) / Real.log n) * S := by rw [mul_one]
      _ ≤ Real.log 2 * (2 - 3 / (Real.log^[k + 2]) (n : ℝ)) * ((n : ℝ) / Real.log n) * S :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_left hCoef hlog₂.le) hq) hS₀
      _ ≤ _ := hBGMS n (k + 2) (by omega) hDefined
        ((show (3 / 2 : ℝ) ≤ 3 by norm_num).trans htail)


private noncomputable def embedOneColor (E : Finset ℕ) (hpos : ∀ x : E, 0 < x.val) (m : ℕ) :
    Output E 1 ↪ Output E (m + 1) where
  toFun s := ⟨firstOnlyTarget m (s.val 0), by
    obtain ⟨cfg, hc⟩ := s.property
    have ht : value E 1 cfg = fun _ => s.val 0 := hc.trans (funext fun i => by
      rw [Subsingleton.elim i 0])
    let w := (firstOnlyFiberEquiv hpos m (s.val 0)).symm ⟨cfg, ht⟩
    exact ⟨w.val, w.property⟩⟩
  inj' s t h := by
    apply Subtype.ext
    funext i
    have hzero := congrFun (congrArg (fun x : Output E (m + 1) => x.val) h) 0
    have hi : i = 0 := Subsingleton.elim _ _
    simpa only [firstOnlyTarget, ite_true, hi] using hzero

/-- The one-color support embeds in the support with any positive number of colors. -/
theorem supportEntropy_oneColor_le (E : Finset ℕ) (hpos : ∀ x : E, 0 < x.val) (m : ℕ) :
    supportEntropy E 1 ≤ supportEntropy E (m + 1) := by
  have _ : Nonempty (Output E 1) := (configurationLaw E 1).nonempty
  have hp : 0 < Nat.card (Output E 1) := Nat.card_pos
  have hcard := Nat.card_le_card_of_injective _ (embedOneColor E hpos m).injective
  change Real.log (Nat.card (Output E 1) : ℝ) ≤ Real.log (Nat.card (Output E (m + 1)) : ℝ)
  exact Real.log_le_log (by exact_mod_cast hp) (by exact_mod_cast hcard)

/-- The positive scale lower bound passes from one color to every fixed positive count. -/
theorem eventually_supportEntropy_scale_lower_of_BGMS (m : ℕ) (hm : 1 ≤ m)
    (hBGMS : BGMSTruncatedLowerBound (fun n => supportEntropy (interval 1 n) 1)) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ n : ℕ in atTop, c * iteratedLogB n ≤ supportEntropy (interval 1 n) m := by
  obtain ⟨c, hc, h⟩ := eventually_iteratedLogB_le_of_BGMS hBGMS
  refine ⟨c, hc, ?_⟩
  filter_upwards [h] with n hn
  cases m with
  | zero => omega
  | succ j =>
    exact hn.trans (supportEntropy_oneColor_le (interval 1 n)
      (fun x => (Finset.mem_Icc.mp x.property).1) j)

/-- Uniform entropy separation and order-scale comparisons, given a support lower bound. -/
theorem entropy_separation_of_scale_lower (m : ℕ) (hm : 1 ≤ m)
    (hScale : ∃ c : ℝ, 0 < c ∧ ∀ᶠ n : ℕ in atTop,
      c * iteratedLogB (n : ℝ) ≤ supportEntropy (interval 1 n) m) :
    (∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∀ᶠ n : ℕ in atTop, ∀ a : RenyiOrder,
      c * iteratedLogB n ≤ intervalRenyi n m a ∧ intervalRenyi n m a ≤ C * iteratedLogB n) ∧
    (∀ a b : RenyiOrder, a < b → ∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∀ᶠ n : ℕ in atTop,
      c * iteratedLogB n ≤ intervalRenyi n m a - intervalRenyi n m b ∧
        intervalRenyi n m a - intervalRenyi n m b ≤ C * iteratedLogB n) := by
  obtain ⟨d, hd, hLower⟩ := hScale
  obtain ⟨C, hC, hUpper'⟩ := intervalRenyi_le_iteratedLogB m
  have hUpper : ∀ᶠ n : ℕ in atTop, supportEntropy (interval 1 n) m ≤ C * iteratedLogB n :=
    Eventually.of_forall fun n => by
      simpa only [intervalRenyi, FiniteLaw.renyi_zero, configurationLaw_hartley] using hUpper' 0 n
  constructor
  · obtain ⟨c, hc, hre⟩ := eventually_renyi_relative_all_orders m hm
    refine ⟨c * d, C, mul_pos hc hd, zero_lt_one.trans_le hC, ?_⟩
    filter_upwards [hLower, hUpper, hre] with n hn hl hr a
    refine ⟨?_, (hr a).2.trans hl⟩
    rw [mul_assoc]
    exact (mul_le_mul_of_nonneg_left hn hc.le).trans (hr a).1
  · intro a b hab
    obtain ⟨c, hc, hre⟩ := eventually_renyi_gap_relative m hm hab
    refine ⟨c * d, C, mul_pos hc hd, zero_lt_one.trans_le hC, ?_⟩
    filter_upwards [hLower, hUpper, hre] with n hn hl hr
    refine ⟨?_, hr.2.trans hl⟩
    rw [mul_assoc]
    exact (mul_le_mul_of_nonneg_left hn hc.le).trans hr.1

/-- Compatibility with the explicit BGMS lower bound. -/
theorem entropy_separation_of_BGMS (m : ℕ) (hm : 1 ≤ m)
    (hBGMS : BGMSTruncatedLowerBound (fun n => supportEntropy (interval 1 n) 1)) :
    (∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∀ᶠ n : ℕ in atTop, ∀ a : RenyiOrder,
      c * iteratedLogB n ≤ intervalRenyi n m a ∧ intervalRenyi n m a ≤ C * iteratedLogB n) ∧
    (∀ a b : RenyiOrder, a < b → ∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∀ᶠ n : ℕ in atTop,
      c * iteratedLogB n ≤ intervalRenyi n m a - intervalRenyi n m b ∧
        intervalRenyi n m a - intervalRenyi n m b ≤ C * iteratedLogB n) :=
  entropy_separation_of_scale_lower m hm (eventually_supportEntropy_scale_lower_of_BGMS m hm hBGMS)

end LeanAB.PaperA
