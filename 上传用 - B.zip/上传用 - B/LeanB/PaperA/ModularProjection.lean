module

public import PaperA.Aliasing
public import PaperA.SlowScale
public import PaperA.ScaleComparison
import Mathlib.Tactic

public section

/-! The asymptotic modular projection, from the two one-color support scale bounds. -/

namespace LeanAB.PaperA

open Filter Asymptotics
open scoped Topology

/-- The integer short-block cutoff in the modular projection theorem. -/
@[expose] noncomputable def shortAliasLength (a : ℝ) (N : ℕ) : ℕ :=
  ⌊a * aliasScale (N : ℝ)⌋₊

private theorem tendsto_shortAliasLength (a : ℝ) (ha : 0 < a) :
    Tendsto (shortAliasLength a) atTop atTop := by
  refine tendsto_nat_floor_atTop.comp (tendsto_atTop_mono' _ ?_
    (Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop))
  have hc : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  exact (hc.eventually (eventually_scaled_aliasScale_bounds a ha)).mono (fun _ h => h.1)

private theorem eventually_log_sq_power :
    ∀ᶠ N : ℕ in atTop,
      Real.log (N : ℝ) ^ 2 ≤ (N : ℝ) ^ (1 / 6 : ℝ) ∧
        (Real.log (N : ℝ) ^ 2 + 1) ^ 2 < N := by
  have hc : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hp := (isLittleO_log_rpow_rpow_atTop (s := (1 / 6 : ℝ)) 2 (by norm_num)).bound
    (show (0 : ℝ) < 1 by norm_num)
  have hr := (tendsto_rpow_atTop (show (0 : ℝ) < 1 / 6 by norm_num)).comp hc
  filter_upwards [hc.eventually hp, hr.eventually_ge_atTop 2, eventually_ge_atTop (2 : ℕ)] with
    N hp hr hN
  let r := (N : ℝ) ^ (1 / 6 : ℝ)
  have hNpos : 0 < (N : ℝ) := by exact_mod_cast (show 0 < N by omega)
  have hr₂ : 2 ≤ r := hr
  have hr₀ : 0 < r := zero_lt_two.trans_le hr₂
  have hle : Real.log (N : ℝ) ^ 2 ≤ r := by
    rw [show (2 : ℝ) = ((2 : ℕ) : ℝ) by norm_num, Real.rpow_natCast,
      Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _),
      abs_of_nonneg hr₀.le, one_mul] at hp
    exact hp
  have hrN : r ^ (6 : ℕ) = (N : ℝ) := calc
    _ = (N : ℝ) ^ ((1 / 6 : ℝ) * (6 : ℕ)) := by
      rw [Real.rpow_mul hNpos.le, Real.rpow_natCast]
    _ = _ := by norm_num
  refine ⟨hle, ?_⟩
  calc
    _ ≤ (r + r) ^ 2 := pow_le_pow_left₀ (by positivity) (by linarith) _
    _ = (r ^ 2) * 4 := by ring
    _ < (r ^ 2) * r ^ 4 := mul_lt_mul_of_pos_left
      ((show (4 : ℝ) < 2 ^ 4 by norm_num).trans_le (pow_le_pow_left₀ zero_le_two hr₂ _))
      (sq_pos_of_pos hr₀)
    _ = _ := by rw [← hrN]; ring

private theorem exists_grid_base :
    ∃ M : ℕ, 0 < M ∧ ∀ Q : ℕ,
      ⌊(Nat.lcmUpto Q : ℚ) * mass (interval 1 Q)⌋₊ < M ^ (Q + 1) := by
  let C := Real.log 4 + 4
  have hC : 0 < C := by dsimp only [C]; positivity
  obtain ⟨M, hM⟩ := exists_nat_gt (Real.exp (C + 1))
  have hExp : 1 < Real.exp (C + 1) := by
    rw [← Real.exp_zero]
    exact Real.exp_lt_exp.mpr (by positivity)
  have hM₁ : (1 : ℝ) < M := hExp.trans hM
  refine ⟨M, by exact_mod_cast (zero_lt_one.trans hM₁), fun Q => ?_⟩
  have hD : (0 : ℝ) < Nat.lcmUpto Q := by exact_mod_cast Nat.lcmUpto_pos Q
  have hψ := Chebyshev.psi_le_const_mul_self (x := (Q : ℝ)) (by positivity)
  rw [Chebyshev.psi_eq_log_lcmUpto] at hψ
  have hlogD : (Nat.lcmUpto Q : ℝ) ≤ Real.exp (C * Q) := by
    rw [← Real.exp_log hD]
    exact Real.exp_le_exp.mpr hψ
  have hq : (Q : ℝ) ≤ Real.exp Q := by linarith [Real.add_one_le_exp (Q : ℝ)]
  have hm : mass (interval 1 Q) ≤ Q := harmonic_le Q
  have hbound : ((Nat.lcmUpto Q : ℚ) * mass (interval 1 Q) : ℝ) < (M : ℝ) ^ (Q + 1) := by
    push_cast
    calc
      _ ≤ Real.exp (C * Q) * Real.exp Q :=
        mul_le_mul hlogD ((Rat.cast_le (K := ℝ)).mpr hm |>.trans hq)
          (by exact_mod_cast mass_nonneg (interval 1 Q)) (Real.exp_pos _).le
      _ = Real.exp ((Q : ℝ) * (C + 1)) := by rw [← Real.exp_add]; ring_nf
      _ ≤ (M : ℝ) ^ Q := by
        rw [Real.exp_nat_mul]
        exact pow_le_pow_left₀ (Real.exp_pos _).le hM.le _
      _ < _ := pow_lt_pow_right₀ hM₁ (by omega)
  have hf := Nat.floor_le (show 0 ≤ (Nat.lcmUpto Q : ℚ) * mass (interval 1 Q) from
    mul_nonneg (Nat.cast_nonneg _) (mass_nonneg _))
  have hfReal : (⌊(Nat.lcmUpto Q : ℚ) * mass (interval 1 Q)⌋₊ : ℝ) ≤
      ((Nat.lcmUpto Q : ℚ) * mass (interval 1 Q) : ℝ) := by
    exact_mod_cast hf
  have hh := hfReal.trans_lt hbound
  exact_mod_cast hh

/-- The exceptional set in the short direction is independent of both q and the color count. -/
theorem eventually_modular_short_of_support_upper
    (C : ℝ) (hC : 0 < C)
    (hupper : ∀ᶠ q : ℕ in atTop, supportEntropy (interval 1 q) 1 ≤ C * iteratedLogB q) :
    ∃ a : ℝ, 0 < a ∧ ∀ᶠ N : ℕ in atTop,
      ((shortExceptional N (shortAliasLength a N)).card : ℝ) ≤ √(N : ℝ) ∧
      ∀ (p : ℕ) [Fact p.Prime], p ≤ N →
        (N : ℝ) / ((shortAliasLength a N : ℝ) + 1) < p →
        p ∉ shortExceptional N (shortAliasLength a N) →
        ∀ q : ℕ, q ≤ shortAliasLength a N → ∀ m : ℕ,
          Function.Injective (reduceOutput (q := q) (m := m) (p := p)) := by
  let a := 1 / (12 * C)
  have ha : 0 < a := by dsimp only [a]; positivity
  have hc : Tendsto (fun N : ℕ => (N : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hb := (tendsto_iteratedLogB_aliasScale a ha).eventually_lt_const (show (1 : ℝ) < 2 by norm_num)
  obtain ⟨M, hM, hgrid⟩ := exists_grid_base
  refine ⟨a, ha, ?_⟩
  filter_upwards [hc.eventually (eventually_scaled_aliasScale_bounds a ha), hc.eventually hb,
    (tendsto_shortAliasLength a ha).eventually hupper,
    (tendsto_shortAliasLength a ha).eventually_ge_atTop M,
    (tendsto_shortAliasLength a ha).eventually_ge_atTop 1, eventually_log_sq_power,
    eventually_ge_atTop (2 : ℕ)] with N hnScale hB hU hQM hQ₁ hLog hN
  let Q := shortAliasLength a N
  let t := a * aliasScale (N : ℝ)
  have hN₁ : (1 : ℝ) < N := by exact_mod_cast (show 1 < N by omega)
  have hLogPos := Real.log_pos hN₁
  have hQ : (Q : ℝ) ≤ t := Nat.floor_le (hLogPos.le.trans hnScale.1)
  have hQlog : (Q : ℝ) ≤ Real.log (N : ℝ) ^ 2 := hQ.trans hnScale.2
  have hQsq : (Q + 1) * (Q + 1) < N := by
    have hh : ((Q : ℝ) + 1) ^ 2 < N :=
      (pow_le_pow_left₀ (by positivity) (add_le_add_left hQlog 1) 2).trans_lt hLog.2
    rw [pow_two] at hh
    exact_mod_cast hh
  have hpLarge {p : ℕ} (hp : p ∈ blockPrimes N Q) : Q < p := by
    by_contra! h
    have hcut := (mem_blockPrimes.mp hp).2.2
    exact (not_lt_of_ge (lt_of_le_of_lt (Nat.mul_le_mul_right _ (Nat.le_succ_of_le h)) hQsq).le) hcut
  have hB' : iteratedLogB t ≤ 2 * (a * Real.log N) := by
    have hB'' : iteratedLogB t / (a * Real.log N) < 2 := hB
    exact ((div_lt_iff₀ (mul_pos ha hLogPos)).mp hB'').le
  have hU' : supportEntropy (interval 1 Q) 1 ≤ C * (2 * (a * Real.log N)) :=
    (show supportEntropy (interval 1 Q) 1 ≤ C * iteratedLogB Q from hU).trans
      (mul_le_mul_of_nonneg_left ((monotone_iteratedLogB hQ).trans hB') hC.le)
  let S := Nat.card (Output (interval 1 Q) 1)
  have hSpos : 0 < S := by
    let _ := (configurationLaw (interval 1 Q) 1).nonempty
    exact Nat.card_pos
  have hlogS : 2 * Real.log (S : ℝ) ≤ Real.log (N : ℝ) / 3 := by
    change Real.log (S : ℝ) ≤ _ at hU'
    calc
      _ ≤ 2 * (C * (2 * (a * Real.log N))) := mul_le_mul_of_nonneg_left hU' zero_le_two
      _ = _ := by dsimp only [a]; field_simp; ring
  have hSpow : (S : ℝ) ^ 2 ≤ (N : ℝ) ^ (1 / 3 : ℝ) := by
    have hs₀ : 0 < (S : ℝ) := by exact_mod_cast hSpos
    have hn₀ := zero_lt_one.trans hN₁
    apply (Real.log_le_log_iff (pow_pos hs₀ _) (Real.rpow_pos_of_pos hn₀ _)).mp
    rw [Real.log_pow, Real.rpow_def_of_pos hn₀, Real.log_exp]
    linarith
  have hcard := shortExceptional_card_le N Q M Q hM
    (fun _ hp => (show M ≤ Q from hQM).trans (hpLarge hp).le) (hgrid Q)
  constructor
  · calc
      _ ≤ (S : ℝ) ^ 2 * (Q : ℝ) := by exact_mod_cast hcard
      _ ≤ (N : ℝ) ^ (1 / 3 : ℝ) * (N : ℝ) ^ (1 / 6 : ℝ) :=
        mul_le_mul hSpow (hQlog.trans hLog.1) (Nat.cast_nonneg _) (by positivity)
      _ = _ := by
        rw [Real.sqrt_eq_rpow, ← Real.rpow_add (zero_lt_one.trans hN₁)]
        norm_num
  · intro p inst hpN hpCut he q hq m
    have hc' : N < p * (Q + 1) := by
      have hr := (div_lt_iff₀ (by positivity : 0 < (Q : ℝ) + 1)).mp hpCut
      exact_mod_cast hr
    have hp' : p ∈ blockPrimes N Q := mem_blockPrimes.mpr ⟨hpN, Fact.out, hc'⟩
    exact short_aliasing_injective hq (hpLarge hp') hp' he

/-- The long direction is simultaneous for every eligible prime and every positive color count. -/
theorem eventually_modular_long_of_support_lower (c a : ℝ) (hc : 0 < c)
    (hlower : ∀ᶠ q : ℕ in atTop, c * iteratedLogB q ≤ supportEntropy (interval 1 q) 1) :
    ∃ b : ℝ, 0 < b ∧ a < b ∧ ∀ᶠ N : ℕ in atTop,
      ∀ q : ℕ, b * aliasScale (N : ℝ) ≤ q →
        ∀ (p : ℕ) [Fact p.Prime], q < p → p ≤ N → ∀ m : ℕ,
          ∃ x y : Output (interval 1 q) (m + 1), x ≠ y ∧
            reduceOutput (p := p) x = reduceOutput (p := p) y := by
  obtain ⟨T, hT⟩ := eventually_atTop.mp hlower
  let b := max (a + 1) (4 / c)
  have hb : 0 < b := (div_pos (by norm_num) hc).trans_le (le_max_right _ _)
  have hCa : 4 ≤ c * b := by
    have hh := mul_le_mul_of_nonneg_left (le_max_right (a + 1) (4 / c)) hc.le
    have h4 : c * (4 / c) = 4 := by field_simp
    rwa [h4] at hh
  refine ⟨b, hb, (lt_add_of_pos_right a zero_lt_one).trans_le (le_max_left _ _), ?_⟩
  have hN : Tendsto (fun n : ℕ => (n : ℝ)) atTop atTop := tendsto_natCast_atTop_atTop
  have hh := (tendsto_iteratedLogB_aliasScale b hb).eventually_const_lt
    (show (1 / 2 : ℝ) < 1 by norm_num)
  filter_upwards [hN.eventually hh, hN.eventually (eventually_scaled_aliasScale_bounds b hb),
    (Real.tendsto_log_atTop.comp hN).eventually_ge_atTop (T : ℝ),
    eventually_ge_atTop (2 : ℕ)] with N hB hScale hNT htwo q hq p inst hqp hpN m
  have hN₁ : (1 : ℝ) < N := by exact_mod_cast (show 1 < N by omega)
  have hLog := Real.log_pos hN₁
  have hqT : T ≤ q := by exact_mod_cast hNT.trans (hScale.1.trans hq)
  have hBl : (1 / 2 : ℝ) * (b * Real.log N) < iteratedLogB (b * aliasScale (N : ℝ)) :=
    (lt_div_iff₀ (mul_pos hb hLog)).mp hB
  have hS : Real.log (N : ℝ) < supportEntropy (interval 1 q) 1 := calc
    _ < 2 * Real.log N := by linarith
    _ ≤ c * ((1 / 2 : ℝ) * (b * Real.log N)) := by nlinarith [mul_nonneg (sub_nonneg.mpr hCa) hLog.le]
    _ < c * iteratedLogB (b * aliasScale (N : ℝ)) := mul_lt_mul_of_pos_left hBl hc
    _ ≤ c * iteratedLogB q := mul_le_mul_of_nonneg_left (monotone_iteratedLogB hq) hc.le
    _ ≤ _ := hT q hqT
  let S := Nat.card (Output (interval 1 q) 1)
  have hSpos : (0 : ℝ) < S := by
    let _ := (configurationLaw (interval 1 q) 1).nonempty
    exact_mod_cast (show 0 < S from Nat.card_pos)
  have hNS : N < S := by
    change Real.log (N : ℝ) < Real.log (S : ℝ) at hS
    exact_mod_cast (Real.log_lt_log_iff (zero_lt_one.trans hN₁) hSpos).mp hS
  exact long_aliasing_collision m (hpN.trans_lt hNS)


/-- Short-block injectivity and long-block collisions from a one-color support lower bound. -/
theorem modular_aliasing_of_scale_lower
    (hScale : ∃ c : ℝ, 0 < c ∧ ∀ᶠ n : ℕ in atTop,
      c * iteratedLogB (n : ℝ) ≤ supportEntropy (interval 1 n) 1) :
    ∃ a b : ℝ, 0 < a ∧ a < b ∧ ∀ᶠ N : ℕ in atTop,
      let Q := shortAliasLength a N
      let bad := shortExceptional N Q
      (bad.card : ℝ) ≤ √(N : ℝ) ∧
      (∀ (p : ℕ) [Fact p.Prime], p ≤ N → (N : ℝ) / ((Q : ℝ) + 1) < p →
        p ∉ bad → ∀ q : ℕ, 1 ≤ q → q ≤ Q → ∀ m : ℕ,
          Function.Injective (reduceOutput (q := q) (m := m) (p := p))) ∧
      (∀ q : ℕ, b * aliasScale (N : ℝ) ≤ q → ∀ (p : ℕ) [Fact p.Prime],
        q < p → p ≤ N → ∀ m : ℕ, ∃ x y : Output (interval 1 q) (m + 1),
          x ≠ y ∧ reduceOutput (p := p) x = reduceOutput (p := p) y) := by
  obtain ⟨C, hC, hupper⟩ := intervalRenyi_le_iteratedLogB 1
  have hUp : ∀ᶠ q : ℕ in atTop, supportEntropy (interval 1 q) 1 ≤ C * iteratedLogB q :=
    Eventually.of_forall fun q => by
      have hh := hupper 0 q
      rwa [intervalRenyi, FiniteLaw.renyi_zero, configurationLaw_hartley] at hh
  obtain ⟨a, ha, hshort⟩ := eventually_modular_short_of_support_upper C (zero_lt_one.trans_le hC) hUp
  obtain ⟨c, hc, hlower⟩ := hScale
  obtain ⟨b, _, hab, hlong⟩ := eventually_modular_long_of_support_lower c a hc hlower
  refine ⟨a, b, ha, hab, ?_⟩
  filter_upwards [hshort, hlong] with N hs hl
  exact ⟨hs.1, fun p _ hp hcut he q _ hq m => hs.2 p hp hcut he q hq m, hl⟩

/-- Compatibility with the explicit BGMS lower bound. -/
theorem modular_aliasing_of_BGMS
    (hBGMS : BGMSTruncatedLowerBound (fun n => supportEntropy (interval 1 n) 1)) :
    ∃ a b : ℝ, 0 < a ∧ a < b ∧ ∀ᶠ N : ℕ in atTop,
      let Q := shortAliasLength a N
      let bad := shortExceptional N Q
      (bad.card : ℝ) ≤ √(N : ℝ) ∧
      (∀ (p : ℕ) [Fact p.Prime], p ≤ N → (N : ℝ) / ((Q : ℝ) + 1) < p →
        p ∉ bad → ∀ q : ℕ, 1 ≤ q → q ≤ Q → ∀ m : ℕ,
          Function.Injective (reduceOutput (q := q) (m := m) (p := p))) ∧
      (∀ q : ℕ, b * aliasScale (N : ℝ) ≤ q → ∀ (p : ℕ) [Fact p.Prime],
        q < p → p ≤ N → ∀ m : ℕ, ∃ x y : Output (interval 1 q) (m + 1),
          x ≠ y ∧ reduceOutput (p := p) x = reduceOutput (p := p) y) :=
  modular_aliasing_of_scale_lower (eventually_iteratedLogB_le_of_BGMS hBGMS)

end LeanAB.PaperA
