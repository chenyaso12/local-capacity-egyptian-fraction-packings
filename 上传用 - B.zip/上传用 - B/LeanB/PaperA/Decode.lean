module

public import Common
public import Mathlib.NumberTheory.Chebyshev
public import Mathlib.Algebra.Field.ZMod
public import Mathlib.Tactic.FieldSimp
public import Mathlib.Tactic.Positivity
public import Mathlib.Tactic.Push
public import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
public import Mathlib.Data.Fintype.BigOperators
public import Mathlib.NumberTheory.Harmonic.Bounds

public section

/-! Exact arithmetic factorization for the reciprocal subset-sum law. -/

open scoped BigOperators

namespace LeanAB.PaperA

/-- Primes in the paper's interval `n / (K+1) < p ≤ n`. -/
@[expose] def blockPrimes (n K : ℕ) : Finset ℕ :=
  (Nat.primesLE n).filter fun p => n < p * (K + 1)

theorem mem_blockPrimes {n K p : ℕ} :
    p ∈ blockPrimes n K ↔ p ≤ n ∧ p.Prime ∧ n < p * (K + 1) := by
  simp [blockPrimes, Nat.mem_primesLE, and_assoc]

/-- Denominators that have no prime factor among the block primes. -/
@[expose] def remainder (n K : ℕ) : Finset ℕ :=
  (interval 1 n).filter fun a => ∀ p ∈ blockPrimes n K, ¬ p ∣ a

@[expose] def harmonic (k : ℕ) : ℚ := mass (interval 1 k)

private theorem mem_interval_one {n a : ℕ} :
    a ∈ interval 1 n ↔ 1 ≤ a ∧ a ≤ n := by
  simp [interval]

private theorem block_prime {n K : ℕ} (p : blockPrimes n K) : p.val.Prime :=
  (mem_blockPrimes.mp p.property).2.1

private theorem block_cofactor_le {n K : ℕ} (p : blockPrimes n K) :
    n / p.val ≤ K := by
  have h := (mem_blockPrimes.mp p.property).2.2
  have := (Nat.div_lt_iff_lt_mul (block_prime p).pos).2
    (show n < (K + 1) * p.val by rw [Nat.mul_comm]; exact h)
  omega

/-- Cofactor domains indexed by the large primes. -/
abbrev Cofactors (n K : ℕ) (p : blockPrimes n K) := (interval 1 (n / p.val) : Type)

private def assembleDenominator (n K : ℕ) :
    (remainder n K ⊕ (Σ p : blockPrimes n K, Cofactors n K p)) → (interval 1 n : Type)
  | .inl a => ⟨a.val, (Finset.mem_filter.mp a.property).1⟩
  | .inr ⟨p, a⟩ => ⟨p.val * a.val, mem_interval_one.mpr <| by
      have ha := mem_interval_one.mp a.property
      have hp := (block_prime p).pos
      exact ⟨Nat.mul_pos hp (by omega), by
        rw [Nat.mul_comm]
        exact (Nat.le_div_iff_mul_le hp).mp ha.2⟩⟩

private theorem block_denominator_unique {n K : ℕ}
    (hsquare : ∀ p : blockPrimes n K, n < p.val * p.val)
    {p q : blockPrimes n K} {a : ℕ}
    (ha : 0 < a) (han : a ≤ n) (hp : p.val ∣ a) (hq : q.val ∣ a) : p = q := by
  by_contra hne
  have hpq : p.val ≠ q.val := fun h => hne (Subtype.ext h)
  have hc : p.val.Coprime q.val := (Nat.coprime_primes (block_prime p) (block_prime q)).mpr hpq
  have hle := (Nat.le_of_dvd ha (hc.mul_dvd_of_dvd_of_dvd hp hq)).trans han
  rcases le_total p.val q.val with h | h
  · exact (not_le_of_gt (hsquare p)) ((Nat.mul_le_mul_left _ h).trans hle)
  · exact (not_le_of_gt (hsquare q)) ((Nat.mul_le_mul_right _ h).trans hle)

/-- The denominators split into the remainder and the large-prime blocks. -/
noncomputable def denominatorEquiv (n K : ℕ)
    (hsquare : ∀ p : blockPrimes n K, n < p.val * p.val) :
    (remainder n K ⊕ (Σ p : blockPrimes n K, Cofactors n K p)) ≃ (interval 1 n : Type) :=
  Equiv.ofBijective (assembleDenominator n K) <| by
    classical
    constructor
    · intro x y h
      have hval := congrArg Subtype.val h
      cases x with
      | inl a =>
        cases y with
        | inl b => exact congrArg Sum.inl (Subtype.ext hval)
        | inr b =>
          obtain ⟨q, b⟩ := b
          exact ((Finset.mem_filter.mp a.property).2 q.val q.property ⟨b.val, hval⟩).elim
      | inr a =>
        obtain ⟨p, a⟩ := a
        cases y with
        | inl b =>
          exact ((Finset.mem_filter.mp b.property).2 p.val p.property ⟨a.val, hval.symm⟩).elim
        | inr b =>
          obtain ⟨q, b⟩ := b
          have ha := mem_interval_one.mp
            (assembleDenominator n K (.inr ⟨p, a⟩)).property
          have hpq : p = q := block_denominator_unique hsquare
            (by have h₁ : 1 ≤ p.val * a.val := ha.1; omega)
            (by simpa only [assembleDenominator] using ha.2)
            ⟨a.val, rfl⟩ ⟨b.val, hval⟩
          subst q
          have hab : a = b := Subtype.ext
            (Nat.eq_of_mul_eq_mul_left (block_prime p).pos hval)
          subst b
          rfl
    · intro a
      have ha := mem_interval_one.mp a.property
      by_cases h : ∀ p ∈ blockPrimes n K, ¬ p ∣ a.val
      · exact ⟨.inl ⟨a.val, Finset.mem_filter.mpr ⟨a.property, h⟩⟩, rfl⟩
      · push Not at h
        obtain ⟨p, hp, hd⟩ := h
        have hp' := (block_prime (⟨p, hp⟩ : blockPrimes n K)).pos
        have hd' : p * (a.val / p) = a.val := by
          simpa only [Nat.mul_comm] using Nat.div_mul_cancel hd
        have ha' : a.val / p ∈ interval 1 (n / p) := mem_interval_one.mpr
          ⟨Nat.div_pos (Nat.le_of_dvd (by omega) hd) hp', Nat.div_le_div_right ha.2⟩
        exact ⟨.inr ⟨⟨p, hp⟩, ⟨a.val / p, ha'⟩⟩, Subtype.ext hd'⟩

/-- Restrictions of a configuration to the remainder and the cofactor domains. -/
noncomputable def splitConfiguration (n K m : ℕ)
    (hsquare : ∀ p : blockPrimes n K, n < p.val * p.val) :
    Configuration (interval 1 n) m ≃
      (Configuration (remainder n K) m ×
        ∀ p : blockPrimes n K, Configuration (interval 1 (n / p.val)) m) :=
  (Equiv.arrowCongr (denominatorEquiv n K hsquare).symm (Equiv.refl _)).trans
    (Equiv.sumArrowEquivProdArrow _ _ _ |>.trans
      (Equiv.prodCongr (Equiv.refl _) (Equiv.piCurry (fun _ _ => Fin (m + 1)))))

/-- Add the remainder output and the rescaled large-prime outputs. -/
@[expose] def mergeOutput {n K m : ℕ} (r : Fin m → ℚ)
    (s : blockPrimes n K → Fin m → ℚ) : Fin m → ℚ :=
  fun i => r i + ∑ p : blockPrimes n K, s p i / (p.val : ℚ)

theorem value_splitConfiguration (n K m : ℕ)
    (hsquare : ∀ p : blockPrimes n K, n < p.val * p.val)
    (cfg : Configuration (interval 1 n) m) :
    value (interval 1 n) m cfg =
      mergeOutput (value (remainder n K) m (splitConfiguration n K m hsquare cfg).1)
        (fun p => value (interval 1 (n / p.val)) m
          ((splitConfiguration n K m hsquare cfg).2 p)) := by
  classical
  funext i
  simp only [value, weightedValue, mergeOutput]
  rw [← Fintype.sum_equiv (denominatorEquiv n K hsquare) _ _ (fun _ => rfl),
    Fintype.sum_sum_type, Fintype.sum_sigma]
  congr 1
  apply Finset.sum_congr rfl
  intro p _
  rw [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro a _
  change (if cfg (assembleDenominator n K (.inr ⟨p, a⟩)) = i.succ
      then ((p.val * a.val : ℕ) : ℚ)⁻¹ else 0) =
    (if cfg (assembleDenominator n K (.inr ⟨p, a⟩)) = i.succ
      then (a.val : ℚ)⁻¹ else 0) / (p.val : ℚ)
  split <;> simp [div_eq_mul_inv, mul_comm]

private theorem value_le_harmonic {k K m : ℕ} (hk : k ≤ K)
    (cfg : Configuration (interval 1 k) m) (i : Fin m) :
    value (interval 1 k) m cfg i ≤ harmonic K := by
  exact (value_le_mass cfg i).trans <| mass_mono fun _ ha =>
    mem_interval_one.mpr ⟨(mem_interval_one.mp ha).1, (mem_interval_one.mp ha).2.trans hk⟩

theorem harmonic_eq (k : ℕ) : harmonic k = _root_.harmonic k := by
  classical
  rw [harmonic, mass, ← Finset.sum_coe_sort, _root_.harmonic, ← Fin.sum_univ_eq_sum_range]
  let e : Fin k ≃ (interval 1 k : Type) := Equiv.ofBijective
    (fun a => ⟨a.val + 1, mem_interval_one.mpr ⟨by omega, by omega⟩⟩) <| by
      constructor
      · intro a b h
        have h' := congrArg Subtype.val h
        change a.val + 1 = b.val + 1 at h'
        exact Fin.ext (by omega)
      · intro a
        have ha := mem_interval_one.mp a.property
        exact ⟨⟨a.val - 1, by omega⟩, Subtype.ext (by dsimp; omega)⟩
  exact (Fintype.sum_equiv e _ _ (fun _ => rfl)).symm

theorem harmonic_le (k : ℕ) : harmonic k ≤ (k : ℚ) := by
  rw [harmonic_eq, _root_.harmonic]
  calc
    ∑ i ∈ Finset.range k, (↑(i + 1) : ℚ)⁻¹ ≤
        ∑ _ ∈ Finset.range k, (1 : ℚ) :=
      Finset.sum_le_sum fun i _ => inv_le_one_of_one_le₀ (by exact_mod_cast Nat.succ_pos i)
    _ = _ := by simp

/-- Reduction commutes with summation if all the rational denominators are units. -/
private theorem rat_sum_reduce {p : ℕ} [Fact p.Prime] {ι : Type*}
    (S : Finset ι) (f : ι → ℚ)
    (hf : ∀ a ∈ S, ((f a).den : ZMod p) ≠ 0) :
    ((∑ a ∈ S, f a).den : ZMod p) ≠ 0 ∧
      ((∑ a ∈ S, f a : ℚ) : ZMod p) = ∑ a ∈ S, (f a : ZMod p) := by
  classical
  induction S using Finset.induction_on with
  | empty => simp
  | insert a S ha ih =>
    have hfa := hf a (Finset.mem_insert_self _ _)
    have hS := ih fun b hb => hf b (Finset.mem_insert_of_mem hb)
    simp only [Finset.sum_insert ha]
    refine ⟨?_, (Rat.cast_add_of_ne_zero hfa hS.1).trans (by rw [hS.2])⟩
    intro hz
    have hd := Rat.add_den_dvd (f a) (∑ b ∈ S, f b)
    have hp := (ZMod.natCast_eq_zero_iff _ p).mp hz
    have hz' := (ZMod.natCast_eq_zero_iff _ p).mpr (hp.trans hd)
    rw [Nat.cast_mul] at hz'
    exact mul_ne_zero hfa hS.1 hz'

private theorem value_integral_mod {E : Finset ℕ} {m p : ℕ} [Fact p.Prime]
    (hpos : ∀ a : E, 0 < a.val) (hunit : ∀ a : E, ¬ p ∣ a.val)
    (c : Configuration E m) (i : Fin m) : ((value E m c i).den : ZMod p) ≠ 0 := by
  classical
  rw [value_apply]
  refine (rat_sum_reduce Finset.univ _ (fun a _ => ?_)).1
  split_ifs
  · rw [Rat.den_inv_of_ne_zero (by exact_mod_cast (hpos a).ne')]
    simpa using (ZMod.natCast_eq_zero_iff a.val p).not.mpr (hunit a)
  · simp

private theorem block_value_integral {n K m : ℕ} (p q : blockPrimes n K)
    (hp : K < p.val) (c : Configuration (interval 1 (n / q.val)) m) (i : Fin m) :
    ((value (interval 1 (n / q.val)) m c i).den : ZMod p.val) ≠ 0 := by
  let : Fact p.val.Prime := ⟨block_prime p⟩
  apply value_integral_mod (fun a => by have := (mem_interval_one.mp a.property).1; omega)
  intro a hd
  have ha := mem_interval_one.mp a.property
  have := Nat.le_of_dvd (by omega) hd
  have := block_cofactor_le q
  omega

private theorem scaled_merge_reduce {n K m : ℕ}
    (hsmall : ∀ p : blockPrimes n K, K < p.val)
    (r : Configuration (remainder n K) m)
    (s : ∀ p : blockPrimes n K, Configuration (interval 1 (n / p.val)) m)
    (p : blockPrimes n K) (i : Fin m) :
    let : Fact p.val.Prime := ⟨block_prime p⟩
    (((p.val : ℚ) * mergeOutput (value (remainder n K) m r)
      (fun q => value (interval 1 (n / q.val)) m (s q)) i : ℚ) : ZMod p.val) =
      (value (interval 1 (n / p.val)) m (s p) i : ZMod p.val) := by
  classical
  dsimp only
  let : Fact p.val.Prime := ⟨block_prime p⟩
  let rv := value (remainder n K) m r i
  let sv (q : blockPrimes n K) := value (interval 1 (n / q.val)) m (s q) i
  let t (q : blockPrimes n K) := if q = p then sv p
    else (p.val : ℚ) * (sv q / (q.val : ℚ))
  have hri : (rv.den : ZMod p.val) ≠ 0 := value_integral_mod
    (fun a => by
      have := (mem_interval_one.mp (Finset.mem_filter.mp a.property).1).1
      omega)
    (fun a => by
      have ha := Finset.mem_filter.mp (show a.val ∈ (interval 1 n).filter
        (fun x => ∀ q ∈ blockPrimes n K, ¬ q ∣ x) from a.property)
      exact ha.2 p.val p.property) _ _
  have hsi (q : blockPrimes n K) : ((sv q).den : ZMod p.val) ≠ 0 :=
    block_value_integral p q (hsmall p) (s q) i
  have hqcast (q : blockPrimes n K) (hne : q ≠ p) : (q.val : ZMod p.val) ≠ 0 := by
    rw [ne_eq, ZMod.natCast_eq_zero_iff]
    exact ((block_prime p).coprime_iff_not_dvd).mp
      ((Nat.coprime_primes (block_prime p) (block_prime q)).mpr
        (fun h => hne (Subtype.ext h.symm)))
  have hpi (v : ℚ) (hv : (v.den : ZMod p.val) ≠ 0) :
      ((((p.val : ℚ) * v).den : ℕ) : ZMod p.val) ≠ 0 := by
    intro hz
    have hd := Rat.mul_den_dvd (p.val : ℚ) v
    have h := (ZMod.natCast_eq_zero_iff _ p.val).mpr
      (((ZMod.natCast_eq_zero_iff _ p.val).mp hz).trans hd)
    rw [Rat.den_natCast, one_mul] at h
    exact hv h
  have hdiv (q : blockPrimes n K) (hne : q ≠ p) :
      ((sv q / (q.val : ℚ)).den : ZMod p.val) ≠ 0 := by
    rw [div_eq_mul_inv]
    intro hz
    have hd := Rat.mul_den_dvd (sv q) (q.val : ℚ)⁻¹
    have h := (ZMod.natCast_eq_zero_iff _ p.val).mpr
      (((ZMod.natCast_eq_zero_iff _ p.val).mp hz).trans hd)
    rw [Nat.cast_mul, Rat.den_inv_of_ne_zero
      (by exact_mod_cast (block_prime q).ne_zero)] at h
    exact mul_ne_zero (hsi q) (by simpa using hqcast q hne) h
  have hsum := rat_sum_reduce Finset.univ t (fun q _ => by
    by_cases hq : q = p
    · simpa [t, hq] using hsi p
    · simpa [t, hq] using hpi _ (hdiv q hq))
  have hcast (v : ℚ) (hv : (v.den : ZMod p.val) ≠ 0) :
      (((p.val : ℚ) * v : ℚ) : ZMod p.val) = 0 := by
    rw [Rat.cast_mul_of_ne_zero (by simp) hv, Rat.cast_natCast, ZMod.natCast_self, zero_mul]
  have ht : (p.val : ℚ) * mergeOutput (value (remainder n K) m r)
      (fun q => value (interval 1 (n / q.val)) m (s q)) i =
      (p.val : ℚ) * rv + ∑ q, t q := by
    simp only [mergeOutput, mul_add, Finset.mul_sum, rv]
    congr 1
    refine Finset.sum_congr rfl fun q _ => ?_
    by_cases hq : q = p
    · subst q
      simp only [t, ↓reduceIte, sv]
      field_simp [show (p.val : ℚ) ≠ 0 by exact_mod_cast (block_prime p).ne_zero]
    · simp [t, sv, hq]
  rw [ht, Rat.cast_add_of_ne_zero (hpi _ hri) hsum.1, hcast _ hri, zero_add, hsum.2]
  rw [Finset.sum_eq_single p]
  · simp [t, sv]
  · intro q _ hne
    simpa [t, hne] using hcast _ (hdiv q hne)
  · simp

private theorem block_recover {n K m : ℕ} (p : blockPrimes n K)
    (hnarrow : (Nat.lcmUpto K : ℚ) * harmonic K < (p.val : ℚ))
    (c c' : Configuration (interval 1 (n / p.val)) m) (i : Fin m)
    (hden : ((value (interval 1 (n / p.val)) m c i).den : ZMod p.val) ≠ 0)
    (hden' : ((value (interval 1 (n / p.val)) m c' i).den : ZMod p.val) ≠ 0)
    (h : letI : Fact p.val.Prime := ⟨block_prime p⟩
      (value (interval 1 (n / p.val)) m c i : ZMod p.val) =
      (value (interval 1 (n / p.val)) m c' i : ZMod p.val)) :
    value (interval 1 (n / p.val)) m c i = value (interval 1 (n / p.val)) m c' i := by
  classical
  let : Fact p.val.Prime := ⟨block_prime p⟩
  let D := Nat.lcmUpto K
  have hpos (a : interval 1 (n / p.val)) : 0 < a.val := by
    have := (mem_interval_one.mp a.property).1
    omega
  have hD (a : interval 1 (n / p.val)) : a.val ∣ D := by
    have ha := mem_interval_one.mp a.property
    exact Finset.dvd_lcm (s := Finset.Icc 1 K) (f := id)
      (Finset.mem_Icc.mpr ⟨ha.1, ha.2.trans (block_cofactor_le p)⟩)
  let t (cfg : Configuration (interval 1 (n / p.val)) m) : ℕ :=
    ∑ a : interval 1 (n / p.val), if cfg a = i.succ then D / a.val else 0
  have hclear (cfg : Configuration (interval 1 (n / p.val)) m) :
      (t cfg : ℚ) = (D : ℚ) * value (interval 1 (n / p.val)) m cfg i :=
    value_clearDenominator hpos hD cfg i
  have hlt (cfg : Configuration (interval 1 (n / p.val)) m) : t cfg < p.val := by
    exact_mod_cast (hclear cfg).trans_lt
      (lt_of_le_of_lt
        (mul_le_mul_of_nonneg_left (value_le_harmonic (block_cofactor_le p) cfg i)
          (by positivity)) hnarrow)
  have hmod : (t c : ZMod p.val) = (t c' : ZMod p.val) := by
    rw [← Rat.cast_natCast (t c), ← Rat.cast_natCast (t c'),
      hclear c, hclear c', Rat.cast_mul_of_ne_zero (by simp) hden,
      Rat.cast_mul_of_ne_zero (by simp) hden', show
        (value (interval 1 (n / p.val)) m c i : ZMod p.val) =
          (value (interval 1 (n / p.val)) m c' i : ZMod p.val) from h]
  have heq := congrArg ZMod.val hmod
  rw [ZMod.val_natCast_of_lt (hlt c), ZMod.val_natCast_of_lt (hlt c')] at heq
  apply mul_left_cancel₀ (show (D : ℚ) ≠ 0 by exact_mod_cast Nat.lcmUpto_ne_zero K)
  rw [← hclear c, ← hclear c', heq]

/-- The remainder support times the supports of all cofactor outputs. -/
abbrev FactorSupport (n K m : ℕ) :=
  (support (remainder n K) m : Type) ×
    ∀ p : blockPrimes n K, (support (interval 1 (n / p.val)) m : Type)

private def mergeFactors {n K m : ℕ} (s : FactorSupport n K m) : Fin m → ℚ :=
  mergeOutput s.1.val (fun p => (s.2 p).val)

private theorem mergeFactors_injective {n K m : ℕ}
    (hsmall : ∀ p : blockPrimes n K, K < p.val)
    (hnarrow : ∀ p : blockPrimes n K, (Nat.lcmUpto K : ℚ) * harmonic K < (p.val : ℚ)) :
    Function.Injective (mergeFactors : FactorSupport n K m → _) := by
  classical
  intro s t h
  obtain ⟨rs, hrs⟩ := s.1.property
  obtain ⟨rt, hrt⟩ := t.1.property
  choose bs hbs using fun p => (s.2 p).property
  choose bt hbt using fun p => (t.2 p).property
  have hmerge : mergeOutput (value (remainder n K) m rs)
      (fun p => value (interval 1 (n / p.val)) m (bs p)) =
      mergeOutput (value (remainder n K) m rt)
      (fun p => value (interval 1 (n / p.val)) m (bt p)) := by
    change mergeOutput s.1.val (fun p => (s.2 p).val) =
      mergeOutput t.1.val (fun p => (t.2 p).val) at h
    simpa only [hrs, hrt, hbs, hbt] using h
  have hblocks (p : blockPrimes n K) : s.2 p = t.2 p := by
    apply Subtype.ext
    funext i
    rw [← hbs p, ← hbt p]
    apply block_recover p (hnarrow p) (bs p) (bt p) i
      (block_value_integral p p (hsmall p) (bs p) i)
      (block_value_integral p p (hsmall p) (bt p) i)
    rw [← scaled_merge_reduce hsmall rs bs p i, ← scaled_merge_reduce hsmall rt bt p i,
      hmerge]
  apply Prod.ext
  · apply Subtype.ext
    funext i
    have hi := congrFun h i
    change s.1.val i + ∑ p, (s.2 p).val i / (p.val : ℚ) =
      t.1.val i + ∑ p, (t.2 p).val i / (p.val : ℚ) at hi
    exact add_right_cancel (by simpa only [hblocks] using hi)
  · exact funext hblocks

/-- The paper's exact decoding bijection, with explicit arithmetic hypotheses. -/
noncomputable def supportEquiv (n K m : ℕ)
    (hsquare : ∀ p : blockPrimes n K, n < p.val * p.val)
    (hsmall : ∀ p : blockPrimes n K, K < p.val)
    (hnarrow : ∀ p : blockPrimes n K, (Nat.lcmUpto K : ℚ) * harmonic K < (p.val : ℚ)) :
    FactorSupport n K m ≃ (support (interval 1 n) m : Type) :=
  Equiv.ofBijective (fun s => ⟨mergeFactors s, by
    classical
    obtain ⟨r, hr⟩ := s.1.property
    choose c hc using fun p => (s.2 p).property
    let e := splitConfiguration n K m hsquare
    refine ⟨e.symm (r, c), ?_⟩
    rw [value_splitConfiguration n K m hsquare]
    change mergeOutput (value (remainder n K) m (e (e.symm (r, c))).1)
      (fun p => value (interval 1 (n / p.val)) m ((e (e.symm (r, c))).2 p)) =
      mergeFactors s
    rw [e.apply_symm_apply]
    simp only [mergeFactors, hr, hc]⟩) ⟨
      fun _ _ h => mergeFactors_injective hsmall hnarrow (congrArg Subtype.val h),
      by
        rintro ⟨_, c, rfl⟩
        let s := splitConfiguration n K m hsquare c
        exact ⟨(⟨_, ⟨s.1, rfl⟩⟩, fun p => ⟨_, ⟨s.2 p, rfl⟩⟩),
          Subtype.ext (value_splitConfiguration n K m hsquare c).symm⟩⟩

@[simp] theorem supportEquiv_apply (n K m : ℕ)
    (hsquare : ∀ p : blockPrimes n K, n < p.val * p.val)
    (hsmall : ∀ p : blockPrimes n K, K < p.val)
    (hnarrow : ∀ p : blockPrimes n K, (Nat.lcmUpto K : ℚ) * harmonic K < (p.val : ℚ))
    (s : FactorSupport n K m) :
    (supportEquiv n K m hsquare hsmall hnarrow s).val =
      mergeOutput s.1.val (fun p => (s.2 p).val) := (rfl)

/-- The configuration fiber is itself a product under exact decoding. -/
noncomputable def fiberEquiv (n K m : ℕ)
    (hsquare : ∀ p : blockPrimes n K, n < p.val * p.val)
    (hsmall : ∀ p : blockPrimes n K, K < p.val)
    (hnarrow : ∀ p : blockPrimes n K, (Nat.lcmUpto K : ℚ) * harmonic K < (p.val : ℚ))
    (s : FactorSupport n K m) :
    Fiber (interval 1 n) m (mergeOutput s.1.val (fun p => (s.2 p).val)) ≃
      (Fiber (remainder n K) m s.1.val ×
        ∀ p : blockPrimes n K, Fiber (interval 1 (n / p.val)) m (s.2 p).val) := by
  let e := splitConfiguration n K m hsquare
  let outputs (c : Configuration (interval 1 n) m) : FactorSupport n K m :=
    (⟨_, ⟨(e c).1, rfl⟩⟩, fun p => ⟨_, ⟨(e c).2 p, rfl⟩⟩)
  have hsplit (c : Configuration (interval 1 n) m) :
      value (interval 1 n) m c = mergeFactors (outputs c) :=
    value_splitConfiguration n K m hsquare c
  have hdecode (c : Fiber (interval 1 n) m (mergeOutput s.1.val (fun p => (s.2 p).val))) :
      outputs c.val = s :=
    mergeFactors_injective hsmall hnarrow ((hsplit c.val).symm.trans c.property)
  refine {
    toFun := fun c => (⟨(e c.val).1, congrArg (fun t : FactorSupport n K m => t.1.val)
      (hdecode c)⟩, fun p => ⟨(e c.val).2 p,
        congrArg (fun t : FactorSupport n K m => (t.2 p).val) (hdecode c)⟩)
    invFun := fun a => ⟨e.symm (a.1.val, fun p => (a.2 p).val), ?_⟩
    left_inv := fun _ => Subtype.ext (e.symm_apply_apply _)
    right_inv := ?_
  }
  · rw [hsplit]
    change mergeOutput (value (remainder n K) m (e (e.symm (a.1.val,
      fun p => (a.2 p).val))).1) (fun p => value (interval 1 (n / p.val)) m
        ((e (e.symm (a.1.val, fun q => (a.2 q).val))).2 p)) =
      mergeOutput s.1.val (fun p => (s.2 p).val)
    rw [e.apply_symm_apply]
    simp only [a.1.property, (a.2 _).property]
  · intro a
    apply Prod.ext
    · exact Subtype.ext (congrArg Prod.fst (e.apply_symm_apply
        (a.1.val, fun p => (a.2 p).val)))
    · funext p
      exact Subtype.ext (congrArg (fun u => u.2 p) (e.apply_symm_apply
        (a.1.val, fun q => (a.2 q).val)))

theorem fiberCount_mul (n K m : ℕ)
    (hsquare : ∀ p : blockPrimes n K, n < p.val * p.val)
    (hsmall : ∀ p : blockPrimes n K, K < p.val)
    (hnarrow : ∀ p : blockPrimes n K, (Nat.lcmUpto K : ℚ) * harmonic K < (p.val : ℚ))
    (s : FactorSupport n K m) :
    Nat.card (Fiber (interval 1 n) m (mergeOutput s.1.val (fun p => (s.2 p).val))) =
      Nat.card (Fiber (remainder n K) m s.1.val) *
        ∏ p : blockPrimes n K, Nat.card (Fiber (interval 1 (n / p.val)) m (s.2 p).val) := by
  rw [Nat.card_congr (fiberEquiv n K m hsquare hsmall hnarrow s),
    Nat.card_prod, Nat.card_pi]

private theorem interval_card (n : ℕ) : (interval 1 n).card = n := by
  simp [interval, Nat.card_Icc]

theorem card_partition (n K : ℕ)
    (hsquare : ∀ p : blockPrimes n K, n < p.val * p.val) :
    n = (remainder n K).card + ∑ p : blockPrimes n K, n / p.val := by
  have h := Fintype.card_congr (denominatorEquiv n K hsquare).symm
  simpa only [Fintype.card_coe, Fintype.card_sum, Fintype.card_sigma, interval_card,
    Cofactors] using h

theorem probability_mul (n K m : ℕ)
    (hsquare : ∀ p : blockPrimes n K, n < p.val * p.val)
    (hsmall : ∀ p : blockPrimes n K, K < p.val)
    (hnarrow : ∀ p : blockPrimes n K, (Nat.lcmUpto K : ℚ) * harmonic K < (p.val : ℚ))
    (s : FactorSupport n K m) :
    probability (interval 1 n) m (mergeOutput s.1.val (fun p => (s.2 p).val)) =
      probability (remainder n K) m s.1.val *
        ∏ p : blockPrimes n K, probability (interval 1 (n / p.val)) m (s.2 p).val := by
  rw [probability, fiberCount_mul n K m hsquare hsmall hnarrow s]
  simp only [probability, Nat.cast_mul, Nat.cast_prod, Nat.cast_pow, Nat.cast_add, Nat.cast_one,
    Finset.prod_div_distrib, ← mul_div_mul_comm, Finset.prod_pow_eq_pow_sum, ← pow_add]
  have hparts : (interval 1 n).card =
      (remainder n K).card + ∑ p : blockPrimes n K, (interval 1 (n / p.val)).card := by
    simpa only [interval_card] using card_partition n K hsquare
  rw [hparts]

end LeanAB.PaperA
