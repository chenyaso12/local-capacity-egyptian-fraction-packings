module

public import Common.PrimeBounds
public import PrimeNumberTheoremAnd.StrongPNT

/-! The pinned PNT+ theorem in the quantitative forms used by both papers. -/

public section

open Filter Asymptotics
open scoped Topology

namespace LeanAB

theorem strongPsiError_pntPlus : StrongPsiError := by
  obtain ⟨c, hc, h⟩ := StrongPNT
  refine ⟨c, hc, ?_⟩
  have hf : (fun t : ℝ => Chebyshev.psi t - t) = ChebyshevPsi - id := by
    funext t
    simp only [Pi.sub_apply, id_eq, ChebyshevPsi]
  rw [hf]
  simpa only [Real.sqrt_eq_rpow] using h

theorem thetaLogSquaredError_pntPlus : ThetaLogSquaredError :=
  thetaLogSquaredError_of_strongPsiError strongPsiError_pntPlus

end LeanAB
