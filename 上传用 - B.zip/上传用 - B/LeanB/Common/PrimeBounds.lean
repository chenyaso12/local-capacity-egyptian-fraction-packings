module

public import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
public import Mathlib.NumberTheory.Chebyshev
meta import Mathlib.Tactic

/-! Converting quantitative Chebyshev estimates to the error needed for Abel summation. -/

@[expose] public section

open Filter Asymptotics
open scoped Topology

namespace LeanAB

/-- The de la Vallée Poussin error in the prime number theorem, in Chebyshev ψ form. -/
def StrongPsiError : Prop :=
  ∃ c : ℝ, 0 < c ∧
    (fun t : ℝ => Chebyshev.psi t - t) =O[atTop]
      (fun t : ℝ => t * Real.exp (-c * Real.sqrt (Real.log t)))

/-- A sufficient quantitative prime-counting input for the high-prime mass estimate. -/
def ThetaLogSquaredError : Prop :=
  ∃ C : ℝ, 0 ≤ C ∧ ∀ᶠ t : ℝ in atTop,
    |Chebyshev.theta t - t| ≤ C * t / (Real.log t)^2

private theorem eventually_exp_sqrt_log_le_inv_sq {c : ℝ} (hc : 0 < c) :
    ∀ᶠ t : ℝ in atTop, Real.exp (-c * Real.sqrt (Real.log t)) ≤ 1 / (Real.log t)^2 := by
  have hs : Tendsto (fun t : ℝ => Real.sqrt (Real.log t)) atTop atTop :=
    Real.tendsto_sqrt_atTop.comp Real.tendsto_log_atTop
  have hb := (isLittleO_pow_exp_pos_mul_atTop 4 hc).bound (show (0 : ℝ) < 1 by norm_num)
  filter_upwards [hs.eventually hb, eventually_gt_atTop (1 : ℝ)] with t ht hOne
  have hlog : 0 < Real.log t := Real.log_pos hOne
  have hpow : Real.sqrt (Real.log t) ^ 4 = (Real.log t) ^ 2 := calc
    _ = (Real.sqrt (Real.log t) ^ 2)^2 := by ring
    _ = _ := by rw [Real.sq_sqrt hlog.le]
  have hle : (Real.log t)^2 ≤ Real.exp (c * Real.sqrt (Real.log t)) := by
    simpa only [Real.norm_eq_abs, hpow, one_mul, abs_of_nonneg (sq_nonneg (Real.log t)),
      abs_of_nonneg (Real.exp_pos _).le] using ht
  rw [neg_mul, Real.exp_neg, one_div]
  exact inv_anti₀ (pow_pos hlog _) hle

private theorem eventually_sqrt_mul_log_le :
    ∀ᶠ t : ℝ in atTop, Real.sqrt t * Real.log t ≤ t / (Real.log t)^2 := by
  have hl := (isLittleO_log_rpow_rpow_atTop (s := (1 / 2 : ℝ)) 3 (by norm_num)).bound
    (show (0 : ℝ) < 1 by norm_num)
  filter_upwards [hl, eventually_gt_atTop (1 : ℝ)] with t ht hOne
  have ht₀ : 0 ≤ t := zero_le_one.trans hOne.le
  have hlog : 0 < Real.log t := Real.log_pos hOne
  have h₃ : (Real.log t)^3 ≤ Real.sqrt t := by
    have hp : (0 : ℝ) ≤ (Real.log t)^3 := pow_nonneg hlog.le _
    have hcast : (3 : ℝ) = ((3 : ℕ) : ℝ) := by norm_num
    simpa only [Real.norm_eq_abs, ← Real.sqrt_eq_rpow, hcast, Real.rpow_natCast,
      abs_of_nonneg hp, abs_of_nonneg (Real.sqrt_nonneg t), one_mul] using ht
  apply (le_div_iff₀ (pow_pos hlog _)).mpr
  calc
    _ = Real.sqrt t * (Real.log t)^3 := by ring
    _ ≤ Real.sqrt t * Real.sqrt t := mul_le_mul_of_nonneg_left h₃ (Real.sqrt_nonneg t)
    _ = t := Real.mul_self_sqrt ht₀

/-- The ψ estimate implies the θ estimate after bounding the contribution of prime powers. -/
theorem thetaLogSquaredError_of_strongPsiError (h : StrongPsiError) :
    ThetaLogSquaredError := by
  obtain ⟨c, hc, h⟩ := h
  obtain ⟨B, hB⟩ := h.bound
  let C := max B 0
  have hC : 0 ≤ C := le_max_right _ _
  refine ⟨C + 2, by positivity, ?_⟩
  filter_upwards [hB, eventually_exp_sqrt_log_le_inv_sq hc, eventually_sqrt_mul_log_le,
    eventually_gt_atTop (1 : ℝ)] with t hψ he hs ht
  have ht₀ : 0 ≤ t := zero_le_one.trans ht.le
  have hz : 0 ≤ t * Real.exp (-c * Real.sqrt (Real.log t)) := by positivity
  have hpsi : |Chebyshev.psi t - t| ≤ C * (t / (Real.log t)^2) := calc
    _ ≤ B * (t * Real.exp (-c * Real.sqrt (Real.log t))) := by
      simpa only [Real.norm_eq_abs, abs_of_nonneg hz] using hψ
    _ ≤ C * (t * Real.exp (-c * Real.sqrt (Real.log t))) :=
      mul_le_mul_of_nonneg_right (le_max_left _ _) hz
    _ ≤ _ := by
      rw [← mul_one_div t]
      exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left he ht₀) hC
  have htheta : |Chebyshev.theta t - Chebyshev.psi t| ≤ 2 * (t / (Real.log t)^2) := by
    rw [abs_sub_comm]
    exact (Chebyshev.abs_psi_sub_theta_le_sqrt_mul_log ht.le).trans
      (by simpa only [mul_assoc] using mul_le_mul_of_nonneg_left hs zero_le_two)
  calc
    _ = |(Chebyshev.theta t - Chebyshev.psi t) + (Chebyshev.psi t - t)| := by
      rw [sub_add_sub_cancel]
    _ ≤ |Chebyshev.theta t - Chebyshev.psi t| + |Chebyshev.psi t - t| := abs_add_le _ _
    _ ≤ 2 * (t / (Real.log t)^2) + C * (t / (Real.log t)^2) := add_le_add htheta hpsi
    _ = _ := by ring

end LeanAB
