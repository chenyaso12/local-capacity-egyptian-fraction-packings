module

public import Mathlib.Algebra.BigOperators.Ring.Finset
public import Mathlib.Algebra.Order.BigOperators.Group.Finset
public import Mathlib.Algebra.Order.Field.Rat
public import Mathlib.Data.Fintype.BigOperators
public import Mathlib.Order.Interval.Finset.Nat
public import Mathlib.SetTheory.Cardinal.Finite

/-! Finite configurations, ordered packings, and their output fibers. -/

@[expose] public section

open scoped BigOperators

namespace LeanAB

/-- The positive denominators in the interval `[d, N]`. -/
def interval (d N : ℕ) : Finset ℕ := Finset.Icc (max 1 d) N

/-- Reciprocal mass of a finite set of denominators. -/
def mass (S : Finset ℕ) : ℚ := ∑ a ∈ S, (a : ℚ)⁻¹

theorem mass_nonneg (S : Finset ℕ) : 0 ≤ mass S :=
  Finset.sum_nonneg fun _ _ => inv_nonneg.mpr (Nat.cast_nonneg _)

theorem mass_mono {S T : Finset ℕ} (h : S ⊆ T) : mass S ≤ mass T :=
  Finset.sum_le_sum_of_subset_of_nonneg h fun _ _ _ => inv_nonneg.mpr (Nat.cast_nonneg _)

/-- Label `0` is unused. Label `i.succ` places a denominator in group `i`. -/
abbrev Configuration (E : Finset ℕ) (m : ℕ) := E → Fin (m + 1)

/-- The ordered family of groups, each a subset of the given denominator domain. -/
def Packing (E : Finset ℕ) (m : ℕ) :=
  {p : Fin m → Finset E // Pairwise fun i j => Disjoint (p i) (p j)}

def group {E : Finset ℕ} {m : ℕ} (c : Configuration E m) (i : Fin m) : Finset E :=
  Finset.univ.filter fun x => c x = i.succ

@[simp] theorem mem_group {E : Finset ℕ} {m : ℕ} (c : Configuration E m)
    (i : Fin m) (x : E) : x ∈ group c i ↔ c x = i.succ := by
  simp [group]

def toPacking {E : Finset ℕ} {m : ℕ} (c : Configuration E m) : Packing E m := by
  refine ⟨group c, ?_⟩
  intro i j hij
  exact Finset.disjoint_left.mpr fun x hx hy =>
    hij (Fin.succ_injective _ (((mem_group c i x).1 hx).symm.trans ((mem_group c j x).1 hy)))

noncomputable def fromPacking {E : Finset ℕ} {m : ℕ} (p : Packing E m) :
    Configuration E m := by
  classical
  exact fun x => if h : ∃ i, x ∈ p.1 i then (Classical.choose h).succ else 0

@[simp] theorem fromPacking_eq_succ {E : Finset ℕ} {m : ℕ} (p : Packing E m)
    (x : E) (i : Fin m) : fromPacking p x = i.succ ↔ x ∈ p.1 i := by
  classical
  unfold fromPacking
  split_ifs with h
  · constructor
    · intro heq
      have hi := Fin.succ_injective _ heq
      exact hi ▸ Classical.choose_spec h
    · intro hi
      congr 1
      by_contra hne
      exact Finset.disjoint_left.mp (p.2 hne) (Classical.choose_spec h) hi
  · exact iff_of_false (Ne.symm i.succ_ne_zero) fun hi => h ⟨i, hi⟩

@[simp] theorem fromPacking_eq_zero {E : Finset ℕ} {m : ℕ} (p : Packing E m)
    (x : E) : fromPacking p x = 0 ↔ ∀ i, x ∉ p.1 i := by
  constructor
  · intro h i hi
    exact i.succ_ne_zero (((fromPacking_eq_succ p x i).2 hi).symm.trans h)
  · intro h
    by_contra hne
    obtain ⟨i, hi⟩ := Fin.eq_succ_of_ne_zero hne
    exact h i ((fromPacking_eq_succ p x i).1 hi)

/-- Label assignments and ordered disjoint families are equivalent, with empty groups allowed. -/
noncomputable def configurationEquivPacking (E : Finset ℕ) (m : ℕ) :
    Configuration E m ≃ Packing E m where
  toFun := toPacking
  invFun := fromPacking
  left_inv c := by
    funext x
    by_cases h : c x = 0
    · rw [h, fromPacking_eq_zero]
      intro i hi
      exact i.succ_ne_zero (((mem_group c i x).1 hi).symm.trans h)
    · obtain ⟨i, hi⟩ := Fin.eq_succ_of_ne_zero h
      exact ((fromPacking_eq_succ (toPacking c) x i).2 ((mem_group c i x).2 hi)).trans hi.symm
  right_inv p := by
    apply Subtype.ext
    funext i
    ext x
    exact (mem_group _ _ _).trans (fromPacking_eq_succ _ _ _)

instance (E : Finset ℕ) (m : ℕ) : Finite (Packing E m) :=
  Finite.of_equiv (Configuration E m) (configurationEquivPacking E m)

def weightedValue (E : Finset ℕ) (m : ℕ) (w : E → ℚ) (c : Configuration E m) :
    Fin m → ℚ :=
  fun i => ∑ x : E, if c x = i.succ then w x else 0

def value (E : Finset ℕ) (m : ℕ) (c : Configuration E m) : Fin m → ℚ :=
  weightedValue E m (fun x => (x.val : ℚ)⁻¹) c

theorem value_apply (E : Finset ℕ) (m : ℕ) (c : Configuration E m) (i : Fin m) :
    value E m c i = ∑ x : E, if c x = i.succ then (x.val : ℚ)⁻¹ else 0 :=
  rfl

theorem value_le_mass {E : Finset ℕ} {m : ℕ}
    (c : Configuration E m) (i : Fin m) : value E m c i ≤ mass E := by
  rw [value_apply, mass, ← E.sum_coe_sort (fun a : ℕ => (a : ℚ)⁻¹)]
  apply Finset.sum_le_sum
  intro a _
  split_ifs
  · exact le_rfl
  · exact inv_nonneg.mpr (Nat.cast_nonneg _)

/-- Multiplying by a common denominator yields a sum of natural-number quotients. -/
theorem value_clearDenominator {E : Finset ℕ} {m D : ℕ}
    (hpos : ∀ a : E, 0 < a.val) (hD : ∀ a : E, a.val ∣ D)
    (cfg : Configuration E m) (i : Fin m) :
    ((∑ a : E, if cfg a = i.succ then D / a.val else 0 : ℕ) : ℚ) =
      (D : ℚ) * value E m cfg i := by
  simp only [value, weightedValue, Finset.mul_sum, Nat.cast_sum]
  apply Finset.sum_congr rfl
  intro a _
  split_ifs
  · have hq : (a.val : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr (hpos a).ne'
    apply (eq_div_iff hq).2
    rw [← Nat.cast_mul, Nat.div_mul_cancel (hD a)]
  · simp

def packingValue {E : Finset ℕ} {m : ℕ} (p : Packing E m) : Fin m → ℚ :=
  fun i => ∑ x ∈ p.1 i, (x.val : ℚ)⁻¹

@[simp] theorem packingValue_toPacking {E : Finset ℕ} {m : ℕ} (c : Configuration E m) :
    packingValue (toPacking c) = value E m c := by
  funext i
  exact Finset.sum_filter _ _

def support (E : Finset ℕ) (m : ℕ) : Set (Fin m → ℚ) := Set.range (value E m)

abbrev Fiber (E : Finset ℕ) (m : ℕ) (s : Fin m → ℚ) :=
  {c : Configuration E m // value E m c = s}

abbrev PackingFiber (E : Finset ℕ) (m : ℕ) (s : Fin m → ℚ) :=
  {p : Packing E m // packingValue p = s}

noncomputable def fiberEquivPackingFiber (E : Finset ℕ) (m : ℕ) (s : Fin m → ℚ) :
    Fiber E m s ≃ PackingFiber E m s :=
  (configurationEquivPacking E m).subtypeEquiv fun c => by
    change value E m c = s ↔ packingValue (toPacking c) = s
    rw [packingValue_toPacking]

theorem fiber_card_eq_ordered_packings (E : Finset ℕ) (m : ℕ) (s : Fin m → ℚ) :
    Nat.card (Fiber E m s) = Nat.card (PackingFiber E m s) :=
  Nat.card_congr (fiberEquivPackingFiber E m s)

theorem interval_fiber_card_eq_ordered_packings (d N m : ℕ) (s : Fin m → ℚ) :
    Nat.card (Fiber (interval d N) m s) = Nat.card (PackingFiber (interval d N) m s) :=
  fiber_card_eq_ordered_packings _ _ _

theorem card_configuration (E : Finset ℕ) (m : ℕ) :
    Nat.card (Configuration E m) = (m + 1) ^ E.card := by
  rw [Nat.card_eq_fintype_card, Fintype.card_fun, Fintype.card_fin, Fintype.card_coe]

/-- Output probability under the uniform law on configurations. -/
noncomputable def probability (E : Finset ℕ) (m : ℕ) (s : Fin m → ℚ) : ℚ :=
  (Nat.card (Fiber E m s) : ℚ) / (((m + 1) ^ E.card : ℕ) : ℚ)

@[simp] theorem value_empty {m : ℕ} (c : Configuration ∅ m) : value ∅ m c = 0 := by
  ext i
  simp [value_apply]

@[simp] theorem card_configuration_empty (m : ℕ) : Nat.card (Configuration ∅ m) = 1 := by
  simp

@[simp] theorem support_empty (m : ℕ) : support ∅ m = {0} := by
  ext s
  change (∃ c : Configuration ∅ m, value ∅ m c = s) ↔ s = 0
  simp [eq_comm, exists_const]

@[simp] theorem value_allUnused (E : Finset ℕ) (m : ℕ) :
    value E m (fun _ => 0) = 0 := by
  ext i
  simp [value_apply, Ne.symm i.succ_ne_zero]

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 10000 in
/-- The target `(1, 1)` has exactly two ordered configurations on `[1, 6]`. -/
theorem interval_six_two_unit_fiber :
    Nat.card (Fiber (interval 1 6) 2 (1 : Fin 2 → ℚ)) = 2 := by
  change Nat.card {c : Configuration (interval 1 6) 2 // value (interval 1 6) 2 c = 1} = 2
  rw [Nat.card_eq_fintype_card, Fintype.card_subtype]
  decide +kernel

end LeanAB
